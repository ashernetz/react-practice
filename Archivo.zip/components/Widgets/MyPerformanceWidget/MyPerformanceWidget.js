import React from 'react';
import { Card, Row, Col, Typography, Tag } from 'antd';
// import WidgetHeader from '../WidgetHeader';
import MyPerformanceWidgetGraph from '../../../images/MyPerformanceWidgetGraph.png'
import "./MyPerformanceWidget.scss"

const {Text, Link} = Typography;

export default function MyPerformanceWidget(props) {
  return (
    <Card bordered={false} bodyStyle={{ padding: 0, minHeight: '235px' }}>
      <Row>
        <Col span={24}>
          <Row className='widget-header'>
            <Col span={12}>
              <Row wrap={false} gutter={[8, 0]}>
                  <Col>
                    <Text>MyPerformance</Text>
                  </Col>
                  <Col className='widget-header-new-tag'>
                    <Tag color={'blue'}>NEW</Tag>
                  </Col>
              </Row>
            </Col>
            <Col span={12}>
              <Row justify='end'>
                <Col>
                  <Link target={"_blank"} href={props.config ? props.config.myPerformanceLink : null}>Visit MyPerformance</Link>
                </Col>
              </Row>
            </Col>
          </Row>

          {/* <WidgetHeader title={
            <Row wrap={false}>
              <Col span={24}>
                <Row className='widget-header-title-and-tag' gutter={[12, 0]} wrap={false}>
                  <Col >
                    <Text>MyPerformance</Text>
                  </Col>
                  <Col className='widget-header-new-tag'>
                    <Tag color={'blue'}>NEW</Tag>
                  </Col>
                </Row>
              </Col>
            </Row>
          } 
          label={
            <Row justify='end'>
              <Col>
                <Link target={"_blank"} href={props.config ? props.config.myPerformanceLink : null}>Visit MyPerformance</Link>
              </Col>
            </Row>
          } 
          /> */}
        </Col>
      {/* NEW */}
{/* Visit MyPerformance */}
      </Row>
      <Row className='my-perf-content-wrapper-row'>
        <Col span={24} className='my-perf-content-wrapper-col'>
          <Row>
            <Col span={24}>
              <Text>Visit the beta release of MyPerformance to analyze how your DCS is performing. Full integration with MPulse coming soon!</Text>
            </Col>
          </Row>
          <Row>
            <Col span={24}>
              <img className="my-performance-widget-graph-img" alt="my-performance-widget-graph-img" src={MyPerformanceWidgetGraph} />
            </Col>
          </Row>
        </Col>
      </Row>
    </Card>
  );
}
