import React from 'react';
import {Typography, Space} from 'antd';
import {ArrowUpOutlined, ArrowDownOutlined} from '@ant-design/icons';
import "./PercentageCell.scss";
import {formatNumberToCompact} from '../../../Utils/CommonUtil';
import CompUtil from '../../../Utils/CompUtil';

function getTextColorClassName(amount) {
    if (amount > 0) {
        return "cell-green-text"
    } else if (amount < 0) {
        return "cell-red-text"
    }
    return "";
}

function getChangeIcon(amount) {
    if (amount > 0) {
        return <ArrowUpOutlined />
    } else if (amount < 0) {
        return <ArrowDownOutlined />
    } else {
        //return <MinusOutlined />
        return "";
    }
}

const {Text} = Typography;

const PercentageCell = (props) => {
    let percentage = props[props.value];
    let rawValue = props[props.rawData];
    let rawData = rawValue? (props.rawData === "rawUnits"?
        <Text strong>{formatNumberToCompact(rawValue)}</Text> :
        <Text strong>{CompUtil.formatMuMdPrice(rawValue,true)}</Text>):"N/A";
    return (
        <Space>
        <Text>{rawData}</Text>
        <Text className={getTextColorClassName(percentage)}>{percentage ? percentage+"%":"N/A"} {getChangeIcon(props[props.value])}</Text>
        </Space>
    );
};

export default PercentageCell;
