import React from "react";
import {
  Row,
  Col,
  Empty
} from 'antd';
import { Chart, Tooltip, Axis, Legend, Bar, Coord} from 'viser-react';
import "./ZoneHealthChart.scss";
const DataSet = require('@antv/data-set');

const ZoneHealthChart = (props) => {

  function formGraphBarObjectData(sourceData,...orderedGraphData) {
    let orderOfAddition = ["label","Sales","Units"];
    let outputObject = {};
    for (let i = 0; i < orderOfAddition.length; i++) {
      if (orderedGraphData[i]) {
        outputObject[orderOfAddition[i]] = orderedGraphData[i];
      }
    }
    if(Object.keys(outputObject).length>1){
      sourceData.push(outputObject);
    }
    if(Object.keys(outputObject).length>1){
      sourceData.push(outputObject);
    }


  }
  function populateHealthOverviewData() {
    let sourceData = [];
    if (props.selectedZoneValue === "0") {

      formGraphBarObjectData(sourceData,props.fiscalWeek,props.healthOverviewData.fiscalWeekSalesPercentage,props.healthOverviewData.fiscalWeekUnitsPercentage);
      formGraphBarObjectData(sourceData,'QTD',props.healthOverviewData.quarterToDateSalesPercentage,props.healthOverviewData.quarterToDateUnitsPercentage);
      formGraphBarObjectData(sourceData,'YTD',props.healthOverviewData.yearToDateSalesPercentage,props.healthOverviewData.yearToDateUnitsPercentage);
      formGraphBarObjectData(sourceData,'R52',props.healthOverviewData.rolling52SalesPercentage,props.healthOverviewData.rolling52UnitsPercentage);
    } else {
      let healthPerformance = {};
      if (props.healthOverviewData.zonePerformanceDTOList){
        props.healthOverviewData.zonePerformanceDTOList.forEach(zoneData => {
          if (zoneData.zoneId === props.selectedZoneValue) {
            healthPerformance = zoneData;
          }
        });
      }

      formGraphBarObjectData(sourceData,props.fiscalWeek,healthPerformance.fiscalWeekSalesPercentage,healthPerformance.fiscalWeekUnitsPercentage);
      formGraphBarObjectData(sourceData,'QTD',healthPerformance.quarterToDateSalesPercentage,healthPerformance.quarterToDateUnitsPercentage);
      formGraphBarObjectData(sourceData,'YTD',healthPerformance.yearToDateSalesPercentage,healthPerformance.yearToDateUnitsPercentage);
      formGraphBarObjectData(sourceData,'R52',healthPerformance.rolling52SalesPercentage,healthPerformance.rolling52UnitsPercentage);
    }

    let dv = new DataSet.View().source(sourceData);
    dv.transform({
      type: 'fold',
      fields: ['Sales','Units'],
      key: 'type',
      value: 'value',
    });
    let data = dv.rows;
    return data;
  }

  const toolTipRender = (title, items) => {

    let toolTip =  '<div class="health-tooltip"><div class="g2-tooltip-title" style="margin-bottom: 4px;">' + title + '</div>';
    items.forEach(item=>{
      toolTip = toolTip+ '<li data-index={index}><span style="background-color:'+item.color+';width:4px;height:4px;border-radius:50%;display:inline-block;margin-right:8px;"></span>'+item.name+' : '+item.value+'%</li>'});
    toolTip = toolTip+ '</div>';
    return toolTip;
  };

  if (Object.keys(props.healthOverviewData).length > 0) {
    let chartData = populateHealthOverviewData();
    if (chartData.length > 0) {
      return (<Row><Col  span={24} className="healthContainer"><Chart forceFit height={433} data={chartData}>
        <Coord type="rect" direction="BT" />
        <Tooltip htmlContent={toolTipRender}/>
        <Axis dataKey="value" position="left" label={{formatter:val=>val+'%'}}/>
        <Axis dataKey="label" label={{ offset: 12 }} />
        <Legend clickable={false} hoverable={false}/>
        <Bar position="label*value" color={['type', ['#f96302', '#C9C9C9']]} adjust={[{ type: 'dodge', marginRatio: 1 / 32 }]} />
      </Chart></Col></Row>)
    } else {
      return (<Row className="health-no-data"><Col span={24}><Empty image={Empty.PRESENTED_IMAGE_SIMPLE}/></Col></Row>)
    }
  } else {
    return (
        <Row className="health-no-data"><Col span={24}><Empty image={Empty.PRESENTED_IMAGE_SIMPLE}/></Col></Row>)
  }
};





export default ZoneHealthChart;