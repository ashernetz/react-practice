import React from 'react';
import { SearchOutlined } from '@ant-design/icons';
import {Input, Button} from 'antd';

const TableFilterDropdown = (props) => {
    return (
        <div style={{ padding: 8 }}>
            <Input 
                className="table-filter-dropdown" 
                ref={props.compRef}
                placeholder={props.placeholder}
                value={props.selectedKeys[0]}
                onChange={e => props.setSelectedKeys(e.target.value ? [e.target.value] : [])}
                onPressEnter={() => props.filterFunction(props.selectedKeys, props.confirm)}
                style={{ width: 188, marginBottom: 15, display: 'block' }}
            />
            <Button 
                type="primary"
                size="small"
                icon={<SearchOutlined />}
                style={{ width: 90, marginRight: 8 }}
                onClick={() => props.filterFunction(props.selectedKeys, props.confirm)}
            >Search</Button>
            <Button 
                size="small"
                style={{ width: 90 }}
                onClick={() => {props.resetFunction(props.clearFilters)}}
            >Reset</Button>
        </div>
    );
}

export default TableFilterDropdown;