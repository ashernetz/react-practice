import React from 'react';
import Highlighter from 'react-highlight-words';

const RowFilterHighlighter = (props) => {
    return (
        <Highlighter
            highlightStyle={{ backgroundColor: '#fdb689', padding: 0}}
            searchWords={[props.filter]}
            autoEscape
            textToHighlight={props.text.toString()}
        />
    );
};

export default RowFilterHighlighter;