import React from 'react';
import {ArrowDownOutlined, ArrowUpOutlined, RightOutlined} from '@ant-design/icons';
import {Row, Col, Typography } from 'antd';
import NoSkuImage from "../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import "./ProductCell.scss";
import CompUtil from '../../Utils/CompUtil';
import {formatNumberToCompact} from "../../Utils/CommonUtil";

const {Text} = Typography;

function getTextColorClassName(amount) {
    if (amount > 0) {
        return "product-cell-green-text"
    } else if (amount < 0) {
        return "product-cell-red-text"
    }
    return "";
}

function getChangeIcon(amount) {
    if (amount > 0) {
        return <ArrowUpOutlined />
    } else if (amount < 0) {
        return <ArrowDownOutlined />
    } else {
        //return <MinusOutlined />
      return "";
    }
}

const ProductCell = (props) => {
    return (
        <Row className="overviewProductRow" justify={"space-between"} align="middle" gutter={[16, 16]} >
            <Col span={6} className="productImgCol">
                <img 
                    className="product-cell-image"
                    src={props.product.skuImage?props.product.skuImage:NoSkuImage}
                    alt="sku"
                />
            </Col>
            <Col span={16}>
            <Row>
            <Col span={24} className="product-cell-ellipsis product-sku-text">
                      <Text type={"secondary"}>SKU {props.product.skuNumber}</Text>
                    </Col>
            </Row>
                <Row >
                    <Col span={24} className="product-cell-ellipsis product-vendor-text">
                        <Text type={"primary"}>{props.product.vendorName?props.product.vendorName.toUpperCase():props.product.vendorName}</Text>
                    </Col>                    
                </Row>
                <Row>
                    <Col span={24} className="product-cell-ellipsis product-sku-description">
                        <Text>{props.product.skuDescription ? props.product.skuDescription : props.product.skuDesc}</Text>
                    </Col>
                </Row>
                <Row>
                    <Col span={12}><Text className="product-cell-margin-space">Sales</Text></Col>
                    <Col span={12}><Text className="product-cell-margin-space">Units</Text></Col>
                </Row>
              <Row>
                <Col span={12}>
                  <Row gutter={[8, 0]}>
                    <Col>
                      <Text>{props.product.rawSales ? <Text strong>{CompUtil.formatMuMdPrice( props.product.rawSales, true)}</Text> : 'N/A'}</Text>
                    </Col>
                    <Col>
                      <Text className={getTextColorClassName(props.product.netSalesComp) + ' product-cell-margin-space'}>
                        {props.product.netSalesComp ? props.product.netSalesComp+ '%' : 'N/A'}
                      </Text>
                      {getChangeIcon(props.product.netSalesComp)}
                    </Col>
                  </Row>
                </Col>
                <Col span={12}>
                  <Row gutter={[8,0]}>
                    <Col>
                       <Text>{props.product.rawUnits ? <Text strong>{formatNumberToCompact( props.product.rawUnits)}</Text> : 'N/A'}</Text>
                    </Col>
                    <Col>
                      <Text className={getTextColorClassName(props.product.netUnitsComp)+ ' product-cell-margin-space'}>
                        {props.product.netUnitsComp ? props.product.netUnitsComp+ '%' : 'N/A'}
                      </Text>
                        {getChangeIcon(props.product.netUnitsComp)}
                    </Col>
                  </Row>
                </Col>
              </Row>
            </Col>
            <Col span={2}>
                <RightOutlined />
            </Col>
        </Row>
    );
};

export default ProductCell;
