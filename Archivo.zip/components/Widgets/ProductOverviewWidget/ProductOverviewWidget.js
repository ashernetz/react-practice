import React, { useState, useEffect, useContext, Fragment } from 'react';
import SkuContext from '../../../context/SkuContext';
import { Card, Table, Row, Col, Typography } from 'antd';
import _ from 'lodash';
import WidgetHeader from '../WidgetHeader';
import FilterProducts from './FilterProducts';
import ProductCell from './ProductCell';
import SvgUtil from "../../Utils/SvgUtil";
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import "./ProductOverviewWidget.scss"
// import DataConnectionIssue from '../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue';


const { Text, Paragraph } = Typography;

const ProductOverviewWidget = (props) => {
    const context = useContext(SkuContext);
    const [topOrBottomDropdownChoice, setTopOrBottomDropdownChoice] = useState("Bottom");
    const [originDropdownChoice, setOriginDropdownChoice] = useState("KVI");
    const [metricsDropdownChoice, setMetricsDropdownChoice] = useState("Sales");
    const [tableData, setTableData] = useState([]);

    function sortByDropdownSelections(products) {
        let ascOrDesc = topOrBottomDropdownChoice === "Top" ? "desc" : "asc";
        let sortVal = metricsDropdownChoice === "Sales" ? "product.rawSales" : "product.rawUnits";
        return _.orderBy(products, sortVal, ascOrDesc)
    }

    useEffect(() => {
        let products, performerKey;
        if (originDropdownChoice !== "Favorites") {
            performerKey = topOrBottomDropdownChoice.toLowerCase() + "Performers" + metricsDropdownChoice + "Map";
            products = props.performersData[performerKey];
        } else if (originDropdownChoice === "Favorites") {
            products = context.favSkuMap
        }

        if (products) {
            products = Object.keys(products).map(key => {
                return {
                    key,
                    product: products[key]
                }
            });
            products = sortByDropdownSelections(products);
            setTableData(products)
        } else {
            setTableData([]);
        }
    }, [props.performersData, topOrBottomDropdownChoice, originDropdownChoice, metricsDropdownChoice])

    const columns = [
        {
            key: 'product',
            render: (props) => (<ProductCell {...props} />)
        }
    ];

    const NoKVIData = () => {
        return (<div className="noKVILoad">
            {Object.keys(props.performersData).length === 0 ? null :
                <Fragment>
                    <Row justify="center" align="middle" type="flex">
                        <Col className="noKVI">
                            {SvgUtil.getNoData()}
                        </Col>
                    </Row>
                    <Row justify="center" align="middle" type="flex" style={{ paddingTop: "10px" }}>
                        <Col>
                            <Text className="no-kvi">
                                No KVI SKU's Available
                            </Text>
                        </Col>
                    </Row>
                    <Paragraph />
                </Fragment>}
        </div>)
    };


    return (
        <Card bordered={false} bodyStyle={{ padding: 0, minHeight: '390px', height: '500px' }}>
            <Row>
                <Col span={24}>
                    <WidgetHeader title="Product Overview" label={
                        <Fragment>
                        <a type="link" style={tableData.length === 0 ? {color: 'rgba(0,0,0,.25)',cursor: 'not-allowed',pointerEvents: 'none'}: {}} onClick={() => props.onClickLink(originDropdownChoice)}>View all</a> {/*eslint-disable-line*/}
                        </Fragment>
                    }/>
                </Col>
            </Row>
            {
            props.is5xx 
            ? 
            <Row className='product-overview-no-data-row'>
                <Col className='product-overview-no-data-col' span={24}> 
                    <Row justify="center" align="middle" gutter={[0,8]}>
                        <Col>
                        <Text className="data-connection">Looks like we are having some issues retrieving data</Text>
                        </Col>
                    </Row>
                    <Row justify="center" align="middle"gutter={[0,8]}>
                        <Col>
                            <Text className="data-connection">
                                We're working on this issue.
                            </Text>
                        </Col>
                    </Row>
                </Col>
            </Row>
            
            // <DataConnectionIssue /> 
            :
                <Fragment>
                    <Row>
                        <Col span={24}>
                            <FilterProducts
                                topOrBottomDropdownChoice={topOrBottomDropdownChoice}
                                setTopOrBottomDropdownChoice={setTopOrBottomDropdownChoice}
                                originDropdownChoice={originDropdownChoice}
                                setOriginDropdownChoice={setOriginDropdownChoice}
                                metricsDropdownChoice={metricsDropdownChoice}
                                setMetricsDropdownChoice={setMetricsDropdownChoice}
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <Table
                                // loading={Object.keys(props.performersData).length === 0}
                                loading={{ spinning: Object.keys(props.performersData).length === 0, indicator: <UXSmallPulse /> }}
                                columns={columns}
                                dataSource={tableData}
                                showHeader={false}
                                locale={{ emptyText: <NoKVIData /> }}
                                pagination={false}
                                scroll={{ y: 395 }}
                                className="product-overview-table"
                                onRow={(record, rowIndex) => ({
                                    onClick: () => {
                                        props.skuSearch(record.product.skuNumber, "SKU_CLICKED_FROM_PRODUCT_OVERVIEW_WIDGET")
                                    }
                                })}
                            />
                        </Col>
                    </Row>
                </Fragment>}
        </Card>
    );
};

export default ProductOverviewWidget;
