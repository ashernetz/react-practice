import React from 'react';
import {Row, Col, Select} from 'antd';
import {trackEvent} from '../../Utils/mixpanel';
import "./FilterProducts.scss"

const {Option} = Select;

const FilterProducts = (props) => {
    function handleSelect(updateFunction, value) {
        updateFunction(value);
        trackEvent("CHANGED_PRODUCT_OVERVIEW_WIDGET_DROPDOWN", {"DROPDOWN_VALUE": value});
    }

    let filters = [
        {
            options: ["Bottom", "Top"],
            defaultVal: props.topOrBottomDropdownChoice,
            updateFunction: props.setTopOrBottomDropdownChoice
        },
        {
            options: ["KVI", "Favorites"],
            defaultVal: props.originDropdownChoice,
            updateFunction: props.setOriginDropdownChoice
        },
        {
            options: ["Sales", "Units"],
            defaultVal: `${props.metricsDropdownChoice}`,
            updateFunction: props.setMetricsDropdownChoice,
            addBy: true
        }
    ]

    return (
        <Row
            id="filter-products"
            gutter={[10, 10]}
        >
            {
                filters.map((filter, index) => {
                    return (
                        <Col key={index} span={Math.floor(24/filters.length)}>
                            <Select defaultValue={filter.defaultVal} style={{width: "100%"}} onSelect={(selectedVal) => handleSelect(filter.updateFunction, selectedVal)}>
                                {
                                    filter.options.map((option, index) => {
                                        let displayName = filter.addBy ? "By "+option : option;
                                        return (
                                            <Option key={index} value={option}>{displayName}</Option>
                                        )
                                    })
                                }
                            </Select>
                        </Col>
                    )
                })
            }
        </Row>
    );
};

export default FilterProducts;
