
import React, { useState, useEffect, useContext } from 'react'
import { Card, Row, Col, Divider, Grid } from 'antd';
import Snapshot from './comps/Snapshot/Snapshot';
import CloserLookSection from './comps/CloserLookSection/CloserLookSection';
import "./PerformanceWidget.scss";
import SkuGroupService from '../../../services/SkuGroupService';
import SkuContext from '../../../context/SkuContext';
import { formatTreeDataForSelectedDCS } from './utils/DcsSelectionUtil';
import SnapshotDataUtil from "../../Utils/SnapshotDataUtil";
import WidgetHeader from '../WidgetHeader';
import DashboardServices from '../../../services/DashboardServices';
import { getFwNum } from './utils/PerformanceWidgetUtil'
import {getHierarchy} from '../../Pages/DashboardPage/DashboardPageUtil';
import MyPerfConstants from '../SuperWidget/constants/MyPerfConstants.json';

const { useBreakpoint } = Grid;

const NewSuperWidget = (props) =>{
    const context = useContext(SkuContext);

    const [selectedDcs, setSelectedDcs] = useState({});
    const [salesUnitsAurGraphData,setSalesUnitsAurGraphData] = useState({});
    const [visibleGraphData,setVisibleGraphData]=useState([]);
    const [loadingGraphTypes,setLoadingGraphTypes] = useState([]);
    const [cpiGraphData, setCpiGraphData] = useState({});
    const [ohGraphData, setOhGraphData] = useState({});
    const [grossMarginGraphData,setGrossMarginGraphData] = useState({});
    const [selectedTabDetail, setSelectedTabDetail] = useState({graphType:"Sales",graphUnit:"rawSales"});
    const [dividerLocation, setDividerLocation] = useState();

    const screens = useBreakpoint();
    let metricYear = context.timeTransformType.includes("|") ? parseInt(context.timeTransformType.substring(0, context.timeTransformType.indexOf("|"))) : 1;

    const [selectedTableRows, setSelectedTableRows] = useState({"classes-or-subclasses":[],"SKU Groups":[],"Pricing Groups":[]});

    useEffect(() => {
        if (screens.xl || screens.xxl) {
            setDividerLocation("side")
        } else {
            setDividerLocation("bottom")
        }
    }, [screens])


    useEffect(() => {
        if(props.dcsData && context.selectedDCS){
            setSelectedDcs(formatTreeDataForSelectedDCS(props.dcsData, context.selectedDCS));
        }
    }, [props.dcsData, context.selectedDCS])


    useEffect(()=>{
        let classOrSubclassesKeys = selectedTableRows["classes-or-subclasses"];
        setVisibleGraphData([]);

            let tempPerfData = {};
            classOrSubclassesKeys.forEach((dcs)=>{
                let data = salesUnitsAurGraphData[dcs]||{};
                let copyOfCurrentYearData = data.hasOwnProperty("currentYearPerformance") ? [...data["currentYearPerformance"]]: [];
                let currentYearPerformanceData = copyOfCurrentYearData.sort((a, b) => getFwNum(a.fiscalWeek).localeCompare(getFwNum(b.fiscalWeek), undefined, { numeric: true }));

                if (context.timeTransformType.includes("QTD") || context.timeTransformType.includes("YTD")) {
                    currentYearPerformanceData.pop();
                }
                let updatedCurrentYearPerformanceData = currentYearPerformanceData;
                let lastYearPerformanceData = data.hasOwnProperty("lastYearPerformance") ? data["lastYearPerformance"].sort((a, b) => getFwNum(a.fiscalWeek).localeCompare(getFwNum(b.fiscalWeek), undefined, { numeric: true })) : [];
                let twoYearPerformanceData = data.hasOwnProperty("twoYearCompPerformance") ? data["twoYearCompPerformance"].sort((a, b) => getFwNum(a.fiscalWeek).localeCompare(getFwNum(b.fiscalWeek), undefined, { numeric: true })) : [];
                let totalPerformanceData = [];
                if (metricYear === 2){
                    totalPerformanceData = [...twoYearPerformanceData]
                } else{
                    totalPerformanceData = [...lastYearPerformanceData, ...updatedCurrentYearPerformanceData]
                }
                tempPerfData[dcs]=totalPerformanceData;
            });
        if(selectedTabDetail.graphType === MyPerfConstants.SALES || selectedTabDetail.graphType === MyPerfConstants.UNITS || selectedTabDetail.graphType === MyPerfConstants.AUR){
            setVisibleGraphData(formDataForGraph(tempPerfData,classOrSubclassesKeys,null));
        }else if(selectedTabDetail.graphType === MyPerfConstants.OH){
            setVisibleGraphData(formDataForGraph(ohGraphData,classOrSubclassesKeys,tempPerfData));
        }else if(selectedTabDetail.graphType === MyPerfConstants.PRIMARY_CPI){
            setVisibleGraphData(formDataForGraph(cpiGraphData,classOrSubclassesKeys,tempPerfData));
        }else if(selectedTabDetail.graphType === MyPerfConstants.GM){
            setVisibleGraphData(formDataForGraph(grossMarginGraphData,classOrSubclassesKeys,null));
        }

    },[salesUnitsAurGraphData,selectedTabDetail,
        selectedTableRows["classes-or-subclasses"],
        ohGraphData,cpiGraphData,grossMarginGraphData]);

    useEffect(()=>{
        resetAllData();
    },[selectedDcs,context.timeTransformType,context.locationDetails])

    useEffect(()=>{
        let classOrSubclassesKeys = selectedTableRows["classes-or-subclasses"];
        if(classOrSubclassesKeys.length > 0){
            validateAndRefillData(classOrSubclassesKeys,salesUnitsAurGraphData,fetchGraphDataForSalesUnitsAur);
            validateAndRefillData(classOrSubclassesKeys,ohGraphData,callForOhWeeklyData);
            validateAndRefillData(classOrSubclassesKeys,cpiGraphData,callForCpiWeeklyData);
            validateAndRefillData(classOrSubclassesKeys,grossMarginGraphData,fetchGrossMarginGraphData);

        }

    },[selectedTableRows["classes-or-subclasses"]])

    const formDataForGraph = (eachTypeData,classOrSubClassesKeys,orderedData) => {
        let eachIteration = (data,dcs) => {
            let eachGraphData = [];
            if(orderedData){
                let dataMap = data.reduce((total,current)=>{total[current.fiscalWeek]=current; return total;},{})
                orderedData[dcs].forEach((each)=>{
                    eachGraphData.push({
                        type: dcs,
                        graphUnit: dataMap[each.fiscalWeek] ? dataMap[each.fiscalWeek][selectedTabDetail.graphUnit]:null,
                        fiscalWeek: each.fiscalWeek,
                    })
                })
            }else {
                data.forEach((each)=>{
                    eachGraphData.push({
                        type: dcs,
                        graphUnit: each[selectedTabDetail.graphUnit],
                        fiscalWeek: each.fiscalWeek,
                    })
                });
            }
            addDuplicateFiscalWeek(eachGraphData);
            return eachGraphData;
        }

        let tempGraphData = [];
        classOrSubClassesKeys.forEach((dcs)=>{
            tempGraphData = [...tempGraphData,...eachIteration(eachTypeData[dcs]||[],dcs)];
        });

        return tempGraphData;
    }
    const resetAllData = () =>{
        setLoadingGraphTypes([]);
        setSelectedTableRows(k=>({"classes-or-subclasses":[],"SKU Groups":[],"Pricing Groups":[]}));
        setVisibleGraphData([]);
        setSalesUnitsAurGraphData({});
        setOhGraphData({});
        setCpiGraphData({});
        setGrossMarginGraphData({});
        if(selectedDcs && selectedDcs.name){
            setSelectedTableRows( k => ({...k,"classes-or-subclasses":[selectedDcs.name]}));
        }
    }

    const validateAndRefillData = (checkboxKeys,dataToCheck,callback) =>{
        let existingData = Object.keys(dataToCheck);
        let dataRequiredKeyList = checkboxKeys.filter(x => !existingData.includes(x));
        dataRequiredKeyList.forEach(k=>{
            callback(k);
        })
    }

    const  fetchGraphDataForSalesUnitsAur=(dcs)=> {
        setSalesUnitsAurGraphData(prevState=>({...prevState,[dcs]:[]}));
        setLoadingGraphTypes(k=>[...k,MyPerfConstants.SALES,MyPerfConstants.UNITS,MyPerfConstants.AUR]);
        let hierarchyData = dcsFormat(dcs);
        SkuGroupService.getDcsPerformance_FWLevel(hierarchyData, props.userId).then((response) => {
            setSalesUnitsAurGraphData(prevState=>({...prevState,[dcs]:(response && response.data) || {}}));
        }).catch((e) => {
            console.log("Error with getDcsPerformance_FWLevel", e)
        }).finally(()=>{
            setLoadingGraphTypes(k=>k.filter(k=>![MyPerfConstants.SALES,MyPerfConstants.UNITS,MyPerfConstants.AUR].includes(k)));

        });
    }


    const callForOhWeeklyData=(dcs)=> {
        setOhGraphData(prevState=>({...prevState,[dcs]:[]}))
        setLoadingGraphTypes(k=>[...k,MyPerfConstants.OH]);
        let hierarchyData = dcsFormat(dcs);
        DashboardServices.getOhWeeklyData(props.userId,hierarchyData).then(resp => {
            if(resp && resp.data) {
                setOhGraphData(prevState => ({...prevState, [dcs]: resp.data || []}))
            }
        }).catch(e => {
            console.log("Error loading OH graph data:", e);
        }).finally(()=>{
            setLoadingGraphTypes(k=>k.filter(k=>k !== MyPerfConstants.OH));
        })
    }

    function callForCpiWeeklyData(dcs) {
        setCpiGraphData(prevState=>({...prevState,[dcs]:[]}));
        setLoadingGraphTypes(k=>[...k,MyPerfConstants.PRIMARY_CPI]);

        let hierarchyData = dcsFormat(dcs);
        DashboardServices.getCpiWeeklyData(props.userId, hierarchyData).then(resp => {
            if(resp && resp.data) {
                setCpiGraphData(prevState => ({...prevState, [dcs]: (resp.data && resp.data.cpiData) || []}))
            }
        }).catch(e => {
            console.log("Error loading cpi graph data:", e);
        }).finally(()=>{
            setLoadingGraphTypes(k=>k.filter(k=>k !== MyPerfConstants.PRIMARY_CPI));
        })
    }

    function fetchGrossMarginGraphData(dcs) {
        setGrossMarginGraphData(prevState=>({...prevState,[dcs]:[]}));
        setLoadingGraphTypes(k=>[...k,MyPerfConstants.GM]);

        let hierarchyData = dcsFormat(dcs);
        DashboardServices.getGrossMargin(props.userId, hierarchyData).then(resp => {
            if(resp && resp.data) {
                setGrossMarginGraphData(prevState => ({
                        ...prevState, [dcs]: [
                            {
                                [MyPerfConstants.GROSS_MARGIN_AMT]: resp.data.grossMargin * 100,
                                [MyPerfConstants.GROSS_MARGIN_PERCENT]: resp.data.grossMarginPercent * 100,
                                fiscalWeek: "FW" + context.lastFiscalWeek
                            }]
                    })
                )
            }
        }).catch(e => {
            console.log("Error loading gross margin data:", e);
        }).finally(() => {
            setLoadingGraphTypes(k=>k.filter(k=>k !== MyPerfConstants.GM));
        })
    }

    function addDuplicateFiscalWeek(originalGraphData){
        if(originalGraphData.length === 1){
            let copyOfFiscalWeekData = {
                "fiscalWeek": originalGraphData[0].fiscalWeek + " ",
                "type": originalGraphData[0].type,
                "graphUnit": originalGraphData[0].graphUnit
            };
            originalGraphData.push(copyOfFiscalWeekData);
        }
    }


    let  dcsFormat =(dcsValue) => {
        if(dcsValue){
            let dcs = dcsValue.split("-")[0].trim().split("|");
            let deptNum = parseInt(dcs[0]);
            let classNum = parseInt(dcs[1]);
            let subClassNum = dcs[2]?parseInt(dcs[2]):0;
            let dcsNum = deptNum + "-" + classNum + "-" + subClassNum
            let getDcsHierarchy =  getHierarchy(dcsNum, context.subDeptDataMap, context.dcsDataMap)
            return getDcsHierarchy;
        }else{
            return "";
        }
    }

    const skuGroupSearch = (input) => {
        props.multiItemInquiry(input.skuNumbers, [], null, null,input);
    }

    const selected = selectedDcs;
    let { name, type } = selected;
    const titleWithName = "Performance for " + name + " (" +type+ ")";
    const title = "Performance";

    return (
        <Card bodyStyle={{ padding: 0 }} id="super-widget-container">
            <Row>
                <Col span={24}>
                    <WidgetHeader title={name ? `${titleWithName}`:`${title}`}/>
                </Col>
            </Row>
            <Row style={{width: "100%"}}>
                <Col span={24}>
                    <Row style={{width: "100%"}}>
                        <Col span={24}>
                            <Row style={{width: "100%"}} justify={"space-between"} id="PLACEHOLDER-PerformanceWidget-WRAPPER">
                                <Col xs={24} sm={24} lg={24} xl={13} xxl={13} className="widget-section-wrapper snapshot-section-wrapper">
                                    <Row justify="space-between">
                                        <Col span={24} className={`${dividerLocation === "side" ? "add-border-right" : ""}`}>
                                            <Snapshot
                                                selectedTabDetail = {selectedTabDetail}
                                                setSelectedTabDetail = {setSelectedTabDetail}
                                                graphData={visibleGraphData}
                                                loadingGraph={loadingGraphTypes.includes(selectedTabDetail.graphType)}
                                                selectedDcs={selectedDcs}
                                                metricYear={metricYear}
                                                dataMapper={metricYear === 2 ? SnapshotDataUtil.TIME_TRANSFORM_TYPES_TWO_YEAR : SnapshotDataUtil.TIME_TRANSFORM_TYPES}
                                                removeAllSelectedRow={resetAllData}
                                            />
                                            {dividerLocation === "bottom" && <Divider />}
                                        </Col>
                                    </Row>
                                </Col>
                                <Col xs={24} sm={24} lg={24} xl={11} xxl={11} className={`widget-section-wrapper closer-look-section-wrapper ${dividerLocation === "side" ? "remove-left-padding" : ""}`}>
                                    <CloserLookSection
                                        selectedDcs={selectedDcs} //selectedDeptClassSubClass
                                        setSelectedDcs={setSelectedDcs}  //setSelectedDeptClassSubClass
                                        skuGroups={Object.values(props.skuGroupsData)}
                                        className={dividerLocation === "side" && "widget-section-wrapper-right"}
                                        userId={props.userId}
                                        diverseMultiSearch = {props.diverseMultiSearch}
                                        selectedDCS={context.selectedDCS}
                                        skuGroupSearch={skuGroupSearch}
                                        metricYear={metricYear}
                                        dataMapper={metricYear === 2 ? SnapshotDataUtil.TIME_TRANSFORM_TYPES_TWO_YEAR : SnapshotDataUtil.TIME_TRANSFORM_TYPES}
                                        loadingSkuGroupData ={props.loadingSkuGroupData}
                                        skuGroupAnchors={props.skuGroupAnchors}
                                        selectedTableRows={selectedTableRows}
                                        setSelectedTableRows={setSelectedTableRows}

                                    />
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                </Col>
            </Row>

        </Card>
    )
}

export default NewSuperWidget;
