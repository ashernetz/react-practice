import React, {useContext, useEffect, useState} from "react";
import "./DiscountsWidget.scss";
import {Card, Col, Row, Typography} from "antd";
import DiscountsService from "../../../services/DiscountsService";
import {formatDCS} from "../SuperWidget/utils/PerformanceWidgetUtil";
import {formatCamelCaseString, getChangeColor} from '../../Utils/CommonUtil';
import SkuContext from "../../../context/SkuContext";
import DiscountConstants from "./DiscountConstants";
import WidgetHeader from "../WidgetHeader";
import DiscountsTabOptions from "./DiscountsTab/DiscountsTabOptions";
import DiscountsTabReasons from "./DiscountsTab/DiscountsTabReasons";
import DashboardServices from "../../../services/DashboardServices";
import {UXSpin} from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import { SalesOverviewTitle } from "./SalesOverview/SalesOverviewComponents";
import PromoTable from "./PromoTable/PromoTable";
import SalesOverview from "./SalesOverview/SalesOverview";
import DonutChart from "./DonutChart/DonutChart";
import {SalesAndBreakdown} from "./SalesAndBreakdown/SalesAndBreakdown";
import TotalSalesPerformanceGraph from "./TotalSalesPerformanceGraph/TotalSalesPerformanceGraph";
import {CardTitle} from "../../Pages/SkuPages/CommonCards/CardItems";
import styled from 'styled-components'



const { Text } = Typography;

const DiscountsWidget = (props) =>{
    const context = useContext(SkuContext)
    const [discountsData, setDiscountsData] = useState(null);
    const [tabData, setTabData] = useState(DiscountConstants.reasons.totalSales);
    const [grossMarginData, setGrossMarginData] = useState({
        loadingGMData: false,
        grossMargin: "",
        grossMarginPercent: ""
    })
    const [promoData, setPromoData] = useState({selectedReasonCode: "", reasonCodePromoMap: {}});
    const [reasonCodeFiscalWeekData, setReasonCodeFiscalWeekData] = useState([])
    const [totalSalesFiscalWeekData, setTotalSalesFiscalWeekData] = useState([])
    const [loadingReasonCodeFiscalWeekData, setLoadingReasonCodeFiscalWeekData] = useState(false);
    const [loadingTotalSalesPerformanceData, setLoadingTotalSalesPerformanceData] = useState(false);
    const [sellingChannel, setSellingChannel] = useState("ALL");

    async function fetchDiscountsData() {
        const inputData = formattedDCSName();
        if (props.hierarchyDetails.departmentNumber && (props.hierarchyDetails.classNumber || props.hierarchyDetails.subClassNumber)) {
            setDiscountsData(null);
            let discountResponse = [];
          try {
                const response = await DiscountsService.getDiscounts(props.userId, inputData.formattedClassName, inputData.formattedSubClassName, sellingChannel);

                if (response && response.data) {
                    response.data.forEach(k => {
                        if (k.mumdReasonCD !== "TOTAL") {
                            const reasonCode = k.mumdReasonCD.charAt(0) === "-" ? k.mumdReasonCD.split("-").slice(0, 2).join('-') : k.mumdReasonCD.split("-")[0];
                            const newDesc = DiscountConstants.REASON_CODE_DESC[parseInt(reasonCode)];
                            k.originalReasonCD = k.mumdReasonCD;
                            k.reasonCodeNumber = parseInt(reasonCode);
                            k.mumdReasonCD = newDesc ? reasonCode + "-" + newDesc : reasonCode + "-" + formatCamelCaseString(k.mumdReasonCD.replace(reasonCode + "-", ""));
                        }
                    });
                    discountResponse = response.data;
                }
            }  catch (e) {
                console.log(e);
            } finally {
                const allSale = [], volumeBased = [], promotional = [], stores = [];
                let totalSale = [], totalVolumeSales = 0, totalPromoSales = 0, totalStoresSales = 0;

                discountResponse.forEach(row => {
                    row.mumdReasonCD.toUpperCase() === 'TOTAL' ? totalSale.push(row) : allSale.push(row);
                    if (DiscountConstants.VOLUME_BASED.includes(row.reasonCodeNumber)) {
                        totalVolumeSales += row.salesDollar;
                        volumeBased.push(row);
                    }
                    if (DiscountConstants.PROMOTIONAL.includes(row.reasonCodeNumber)) {
                        totalPromoSales += row.salesDollar;
                        promotional.push(row);
                    }
                    if (DiscountConstants.STORE_MARKDOWN.includes(row.reasonCodeNumber)) {
                        totalStoresSales += row.salesDollar;
                        stores.push(row);
                    }
                });

                totalSale = totalSale[0];

                setDiscountsData(k => ({
                    ...k,
                    [DiscountConstants.reasons.totalSales]: {
                        rows: allSale,
                        total: totalSale
                    },
                    [DiscountConstants.reasons.volumeBased]: {
                        rows: volumeBased,
                        total: aggregatedTabReasons(volumeBased, "VOLUME-BASED TOTAL"),
                        percentTotalSales: totalSale && totalSale.salesDollar ? totalVolumeSales / totalSale.salesDollar * 100 : 0
                    },
                    [DiscountConstants.reasons.promotional]: {
                        rows: promotional,
                        total: aggregatedTabReasons(promotional, "PROMOTIONAL TOTAL"),
                        percentTotalSales: totalSale && totalSale.salesDollar ? totalPromoSales / totalSale.salesDollar * 100 : 0
                    },
                    [DiscountConstants.reasons.stores]: {
                        rows: stores,
                        total: aggregatedTabReasons(stores, "STORE MARKDOWN"),
                        percentTotalSales: totalSale && totalSale.salesDollar ? totalStoresSales / totalSale.salesDollar * 100 : 0
                    }
                }));
            }
        }
    }


    function aggregatedTabReasons(filteredData,selectedTab){

        return filteredData.length> 0 ? filteredData.reduce((previous, current) => {
            return {
                augUnitsPerTrans: previous.augUnitsPerTrans + current.augUnitsPerTrans,
                avgUnitRetail: previous.avgUnitRetail + current.avgUnitRetail,
                mumdDollar: previous.mumdDollar + current.mumdDollar,
                mumdReasonCD: selectedTab,
                salesDollar: previous.salesDollar + current.salesDollar,
                salesDollarBeforeReturns: previous.salesDollarBeforeReturns + current.salesDollarBeforeReturns,
                salesTransaction: previous.salesTransaction + current.salesTransaction,
                salesUnits: previous.salesUnits + current.salesUnits,
                salesUnitsBeforeReturns: previous.salesUnitsBeforeReturns + current.salesUnitsBeforeReturns,
                totalAllocatedUnits: previous.totalAllocatedUnits + current.totalAllocatedUnits
            }
        },{augUnitsPerTrans:0,avgUnitRetail:0,mumdDollar:0,mumdReasonCD:'',
            salesDollar:0,salesDollarBeforeReturns:0,salesTransaction:0,salesUnits:0,
            salesUnitsBeforeReturns:0,totalAllocatedUnits:0}):null;
    }

    async function fetchGrossMarginData() {
        let grossMargin = "";
        let grossMarginPercent = "";
        setGrossMarginData({ loadingGMData: true });
        try {
            const resp = await DashboardServices.getGrossMargin(props.userId, props.hierarchyDetails);
            if (resp && resp.data) {
                grossMargin = resp.data.grossMargin * 100;
                grossMarginPercent = resp.data.grossMarginPercent * 100;
            }
        } catch (e) {
            console.log("Error loading gross margin data:", e);
        } finally {
            setGrossMarginData({
                grossMargin: grossMargin ? grossMargin.toFixed(2) + ' %' : 'NA',
                grossMarginValue: grossMargin ? grossMargin.toFixed(2) : 'NA',
                grossMarginPercent: grossMarginPercent ? grossMarginPercent.toFixed(2) : 'NA',
                loadingGMData: false
            });
        }
    }

    async function fetchTotalSalesLineData() {
        let totalSalesLineData = [];
        const inputData = formattedDCSName();
        if (!(inputData.formattedClassName || inputData.formattedSubClassName)) {
            return;
        }

        try {
            setLoadingTotalSalesPerformanceData(true);
            const response = await DiscountsService.getTotalSalesByFiscalWeek(props.userId, inputData.formattedClassName, inputData.formattedSubClassName, sellingChannel);

                totalSalesLineData = response.data;
        } catch (e) {
            console.log(e);
        } finally {
            setLoadingTotalSalesPerformanceData(false);
            setTotalSalesFiscalWeekData(totalSalesLineData);
        }
    }


    async function fetchTotalSalesBarChartData() {
        let reasonCodeResponseData = [];
        const inputData = formattedDCSName();
      
        if (!(inputData.formattedClassName || inputData.formattedSubClassName)) {
            return; // Early termination if class name and sub-class name are both falsy
        }

        try {
            setLoadingReasonCodeFiscalWeekData(true);
            const response = await DiscountsService.getReasonCodeDollarsByFiscalWeek(
                props.userId,
                inputData.formattedClassName,
                inputData.formattedSubClassName, 
                sellingChannel
            );
            const reasonCodeFiscalWeek = response.data.map(reasonCodeRow => ({
                ...reasonCodeRow,
                reasonCodeNumber: parseInt(
                    reasonCodeRow.mumdReasonCD.charAt(0) === "-"
                        ? reasonCodeRow.mumdReasonCD.split("-").slice(0, 2).join("-")
                        : reasonCodeRow.mumdReasonCD.split("-")[0]
                )
            }));
            reasonCodeResponseData = reasonCodeFiscalWeek;
        } catch (e) {
            console.log(e);
        } finally {
            setLoadingReasonCodeFiscalWeekData(false);
            setReasonCodeFiscalWeekData(reasonCodeResponseData);
        }
    }


    const formattedDCSName = () =>{
        let formattedName = "";
        let formattedSubClassName = "";
        let formattedClassName = "";

        if (props.hierarchyDetails.departmentNumber && props.hierarchyDetails.classNumber) {
            formattedName = formatDCS(props.hierarchyDetails.departmentNumber) + formatDCS(props.hierarchyDetails.classNumber)
            formattedClassName = formattedName + props.hierarchyDetails.className;
        }
        if (props.hierarchyDetails.subClassNumber) {
            formattedSubClassName = formattedName + props.hierarchyDetails.subClassNumber.toString().padStart(3, "0") + "-"
                + props.hierarchyDetails.subClassName;
        }
        return {formattedClassName,formattedSubClassName};
    }

    useEffect(() => {
        if (props.hierarchyDetails) {

            fetchDiscountsData();
            fetchGrossMarginData();
            fetchTotalSalesBarChartData();
            fetchTotalSalesLineData();
            setTabData(DiscountConstants.reasons.totalSales)
            setPromoData({selectedReasonCode: "", reasonCodePromoMap: {}})
        }
    }, [props.hierarchyDetails, context.timeTransformType, sellingChannel])

    useEffect(() => {
        const fetchData = async () => {
            let inputData = formattedDCSName();
            if (promoData.selectedReasonCode && !promoData.reasonCodePromoMap.hasOwnProperty(promoData.selectedReasonCode)) {
                try {
                    let promoDetails = [];
                    const response = await DiscountsService.getPromoDetails(props.userId, inputData.formattedClassName, inputData.formattedSubClassName, promoData.selectedReasonCode);
                    promoDetails = response.data;
                    setPromoData(k => ({ ...k, reasonCodePromoMap: { ...k.reasonCodePromoMap, [promoData.selectedReasonCode]: promoDetails || [] } }));
                } catch (error) {
                    console.log(error);
                }
            }
        };
        fetchData();
    }, [promoData.selectedReasonCode]);


    const setReasonCode = (value) =>{
        setPromoData(k => ({...k, selectedReasonCode: value}));
    }

    const handleSellingChannelChange = (value) =>{
        setSellingChannel(value);
    }

    return(
        <Card bodyStyle={{ padding: 0, minHeight: '395px' }}>
            <Row>
                <Col span={24}>
                    <WidgetHeader title="Discounts"
                                  sellingChannel={sellingChannel}
                                  onSellingChannelChange={handleSellingChannelChange}
                    />
                    <div style={{ padding: '16px 16px 8px 16px' }}>
                        <Row gutter={[32, 16]}>
                            <Col xs={24} sm={24} md={24} lg={24} xl={15}>
                                    {tabData === DiscountConstants.reasons.totalSales ?
                                        <TotalSalesPerformanceGraph
                                            formattedDCSName={formattedDCSName()}
                                            reasonCodeFiscalWeekData={reasonCodeFiscalWeekData}
                                            totalSalesFiscalWeekData={totalSalesFiscalWeekData}
                                            loadingReasonCodeFiscalWeekData={loadingReasonCodeFiscalWeekData}
                                            loadingTotalSalesPerformanceData={loadingTotalSalesPerformanceData}
                                        />
                                        :
                                        <SalesAndBreakdown
                                            tabName={tabData}
                                            reasonCodeFiscalWeekData={reasonCodeFiscalWeekData}
                                            loadingReasonCodeFiscalWeekData={loadingReasonCodeFiscalWeekData}
                                        />
                                    }
                            </Col>
                            <Col xs={24} sm={24} md={24} lg={24} xl={9}>
                                <Row gutter={[16, 16]}>
                                    <Col span={24}>
                                        <SalesOverview
                                            discountsData={discountsData}
                                            selectedTabName={tabData}
                                            grossMarginData={grossMarginData}
                                        />
                                    </Col>
                                    <Col span={24} style={{ height: '300px' }}>
                                        <div>
                                            <Text className="sales-overview-card-title">Total Sales % Breakdown</Text>
                                        </div>
                                        {discountsData ? (
                                            <DonutChart
                                                discountsData={discountsData}
                                                selectedTabName={tabData}
                                            />
                                        ) : <UXSpin fontSize= '100px'/>}
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </div>
                </Col>
            </Row>
            {promoData && promoData.selectedReasonCode ?
                <PromoTable
                    hierarchyDetails={props.hierarchyDetails}
                    promoData={promoData.reasonCodePromoMap[promoData.selectedReasonCode]}
                    setReasonCode={setReasonCode}
                /> :
                <>
                    <Row style={{padding: '8px 16px 18px 16px'}}>
                        <Col>
                            <DiscountsTabOptions
                                tabData={tabData}
                                setTabData={setTabData}
                            />
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <DiscountsTabReasons
                                departmentNumber = {props.hierarchyDetails.departmentNumber}
                                discountsData={discountsData}
                                selectedTabName={tabData}
                                setReasonCode = {setReasonCode}
                                discountPromoEnable ={props.discountPromoEnable}
                            />
                        </Col>
                    </Row>
                </>
            }
        </Card>
    )
}

export default DiscountsWidget;