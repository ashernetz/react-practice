export default class DiscountConstants {

    static REASON_CODE_DESC = {
        "9" : "HD Coupon",
        "10" : "Credit Promotion",
        "14" : "RT Buyer",
        "15" : "Pro Paint",
        "23" : "RTV Markdown",
        "25" : "Price Change Markdowns",
        "26" : "Promotional Markdown",
        "27" : "Clearance Markdown",
        "30" : "VPP/Bid Room",
        "31" : "HDMS Price Adjustment",
        "33" : "Internet Markdown",
        "34" : "Tier Markdown RLC ",
        "35" : "HDMS Closing Adjustment",
        "38" : "GSA Discount",
        "39" : "Incremental Bid Room",
        "40" : "Military",
        "41" : "RTV Buyer Markdown",
        "45" : "PAEs and Pro Support Team",
        "47" : "Every Day Savings",
        "48" : "Grizzly",
        "49" : "Bulk Pricing",
        "50" : "MSB Volume Discounts",
        "51" : "BOPIS/BODFS Timing",
        "60" : "Quote Center Discounts",
        "70" : "Preferred/Loyalty"
    };

    static tabOptions = [
            {label:'Total Sales', value:'TOTAL_SALES'},
            {label:'Volume-Based', value:'VOLUME_BASED'},
            {label:'Promotional', value:'PROMOTIONAL'},
            {label:'Store MarkDown', value:'STORE_MARKDOWN'}
        ];

    static VOLUME_BASED = [30,39,48,49,60,70];
    static PROMOTIONAL = [9,10,15,26,38,40];
    static STORE_MARKDOWN = [1,2,4,5,6,8,24,25,33,36];
    static HIDDEN_REASON_CODES = [24,25];

    static reasons = {
        totalSales : "TOTAL_SALES",
        volumeBased : "VOLUME_BASED",
        promotional : "PROMOTIONAL",
        stores : "STORE_MARKDOWN"
    }

    static clickableReasons = [9,30,40,49,70];

     static sellingChannelOptions = [
        {label:'Core', value:'CORE'},
        {label:'Online', value:'ONLINE'},
        {label:'Core and Online', value:'ALL'}
    ];


}
