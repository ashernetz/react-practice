import React from 'react'
import axios from "axios";
import { render} from '@testing-library/react'
import {act} from "react-dom/test-utils";
import DashboardServices from '../../../services/DashboardServices';
import DiscountsService from "../../../services/DiscountsService";
import WidgetHeader from "../WidgetHeader";
import {UXSpin} from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";


// mocked axios
jest.mock('axios');
let wrapper = null;

// mock input data
const userId = "MC62YE";

const getGrossMarginInput = {
    "subDepartmentDescription":"PLUMBING",
    "subDepartmentNumber":"026P",
    "departmentNumber":26,
    "classDescription":"PIPE AND FITTINGS",
    "classNumber":1,
    "subClassDescription":"",
    "subClassNumber":0,
}

// mock output dataA
const getGrossMarginOutput = {
    data : {
        "grossMargin":0.0514167822,
        "grossMarginPercent":-0.0468644341
    }
}

const getDiscountOutput =
    {
        data : [
            {
                "augUnitsPerTrans": null,
                "avgUnitRetail":6.0421787804,
                "mumdDollar":187399.720999999,
                "mumdReasonCD":"TOTAL",
                "salesDollar":253343283.13,
                "salesDollarBeforeReturns":null,
                "salesTransaction":399404,
                "salesUnits":1929127.28,
                "salesUnitsBeforeReturns":null,
                "totalAllocatedUnits":3.7988159858
            },
            {
                "augUnitsPerTrans": 3.7115275055,
                "avgUnitRetail": 6.7888463182,
                "salesUnits": 1395189.1700000004,
                "salesDollar": 9471724.86,
                "totalAllocatedUnits": null,
                "salesDollarBeforeReturns": null,
                "salesUnitsBeforeReturns": null,
                "mumdDollar": 0,
                "salesTransaction": 375907,
                "mumdReasonCD": "-1 - Shelf No Discounts"
            },
            {
                "augUnitsPerTrans": 3.3416149068,
                "avgUnitRetail": 6.049330855,
                "salesUnits": 538,
                "salesDollar": 3254.54,
                "totalAllocatedUnits": null,
                "salesDollarBeforeReturns": null,
                "salesUnitsBeforeReturns": null,
                "mumdDollar": 1037.86,
                "salesTransaction": 161,
                "mumdReasonCD": "01-AD NOT IN COMPUTER"
            },
            {
                "augUnitsPerTrans": 5.1764705882,
                "avgUnitRetail": 4.16625,
                "salesUnits": 88,
                "salesDollar": 366.63,
                "totalAllocatedUnits": null,
                "salesDollarBeforeReturns": null,
                "salesUnitsBeforeReturns": null,
                "mumdDollar": 59.51,
                "salesTransaction": 17,
                "mumdReasonCD": "02-SLOW MOVING"
            }
        ]
    };

const reasonCodeFiscalWeekMockData = [
    {
        salesDollar: 12000,
        mumdReasonCD: 'VPP/Bid Room',
        week: 'FW1',
    },
    {
        salesDollar: 13000,
        mumdReasonCD: 'Incremental Bid Room',
        week: 'FW1',
    },
    {
        salesDollar: 14000,
        mumdReasonCD: 'Grizzly',
        week: 'FW1',
    },
    {
        salesDollar: 22000,
        mumdReasonCD: 'Bulk Pricing',
        week: 'FW1',
    },

    {
        salesDollar: 33000,
        mumdReasonCD: 'VPP/Bid Room',
        week: 'FW2',
    },
    {
        salesDollar: 32000,
        mumdReasonCD: 'Incremental Bid Room',
        week: 'FW2',
    },
    {
        salesDollar: 31000,
        mumdReasonCD: 'Grizzly',
        week: 'FW2',
    },
    {
        salesDollar: 30000,
        mumdReasonCD: 'Bulk Pricing',
        week: 'FW2',
    },

    {
        salesDollar: 5000,
        mumdReasonCD: 'VPP/Bid Room',
        week: 'FW3',
    },
    {
        salesDollar: 6000,
        mumdReasonCD: 'Incremental Bid Room',
        week: 'FW3',
    },
    {
        salesDollar: 7000,
        mumdReasonCD: 'Grizzly',
        week: 'FW3',
    },
    {
        salesDollar: 8000,
        mumdReasonCD: 'Bulk Pricing',
        week: 'FW3',
    }
]

beforeEach(async () => {

    await act(async () => {
        const mockPost = jest.spyOn(axios, 'post');
        mockPost.mockImplementation((url) => {
            switch (url) {
                case '/api/dataConnect/gross-margin/dcs':
                    return Promise.resolve(getGrossMarginOutput);
                case '/api/dataConnect/getDiscounts':
                    return Promise.resolve(getDiscountOutput);
                case '/api/dataConnect/getReasonCodesByFiscalWeek':
                    return Promise.resolve(reasonCodeFiscalWeekMockData);
            }
        });
    })

})

describe('DiscountWidget', () => {

    test("renders without crashing", () => {
        expect(wrapper).toBeDefined();
    });

    // test('render discountWidget', () => {
    //     render(<DiscountsWidget />)
    // })

    test("getGrossMargin for success", async () => {
        let response = await DashboardServices.getGrossMargin(userId,getGrossMarginInput);
        expect(response.data).toEqual(getGrossMarginOutput.data);
    })

    let formattedClassName = "026-001-PIPE AND FITTINGS";
    let formattedSubClassName  = "026-001-002-PVC PIPE";
    let departmentNumber = 26;
    let classNumber = 1;
    let subClassNumber = 0;

    test("getDiscounts for success", async () => {
        expect(departmentNumber).toEqual(getGrossMarginInput.departmentNumber);
        expect(classNumber).toEqual(getGrossMarginInput.classNumber);
        expect(subClassNumber).toEqual(getGrossMarginInput.subClassNumber);
        let response = await DiscountsService.getDiscounts(userId,formattedClassName,formattedSubClassName);
        expect(response.data).toEqual(getDiscountOutput.data);
    })

    test("Discounts title", () => {
        const {container} = render(
            <WidgetHeader title="Discounts" /> )
    })

    test("UXSpin", () => {
        const {container} = render(
            <UXSpin />)
    })

})