import React, {Fragment} from "react";
import {Card, Col, Row, Typography} from "antd";
import AdvancedTable from "../../../GlobalComponents/AdvancedTable/AdvancedTable";
import UXSmallPulse from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse"
import SvgUtil from "../../../Utils/SvgUtil";
import {LeftOutlined} from "@ant-design/icons";

const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const customDateFormatter = (inputStringDate) => {
    let output = "";
    if(inputStringDate){
        let inputDate = new Date(inputStringDate);
        output = inputDate.toString() === "Invalid Date" ? "" :inputDate.getMonth()+1 + "/" + inputDate.getDate() + "/" + inputDate.getFullYear();
    }
    return output;
};

const getColumns=() =>  [
    {
        title: headerFormatter('Promo ID'),
        dataIndex: 'promoId',
        isCustomFilter: true,
        retainColumnRender: true,
        filterPlaceholder: "Id",
        sorter: (a, b) => a.promoId - b.promoId,
        width: 50,
    },
    {
        title: headerFormatter('Name'),
        dataIndex: 'promoDesc',
        isCustomFilter: true,
        sorter: (a, b) => customStringSorter(a.promoDesc,b.promoDesc),
        width: 50,
    },
    {
        title: headerFormatter('Start Date'),
        dataIndex: 'promoStartDate',
        sorter: (a, b) => new Date(a.promoStartDate).getTime()- new Date(b.promoStartDate).getTime(),
        render: customDateFormatter,
        align:"right",
        width: 50,
    },
    {
        title: headerFormatter('End Date  '),
        dataIndex: 'promoEndDate',
        sorter: (a, b) => {
            return new Date(a.promoEndDate).getTime() - new Date(b.promoEndDate).getTime()
        },
        render: customDateFormatter,
        align:"right",
        width:50

    },
    {
        title: headerFormatter('Source'),
        dataIndex: 'sourceSystem',
        sorter: (a, b) => customStringSorter(a.sourceSystem,b.sourceSystem),
        render:text=>text?text.trim():"",
        width: 50,
        align:"center",
    },
];


const PromoTable = (props) => {

    const NoPromoData = () => {
        return (
            <Fragment>
                <Row justify="center" align="middle" style={{ paddingTop: "90px" }}>
                    <Col>{SvgUtil.getNoData()}</Col>
                </Row>
                <Row justify="center" align="middle" style={{ paddingTop: "90px" }}>
                    <Col><Text className="no-promo-found-text">No Promo Details Available </Text></Col>
                </Row>
            </Fragment>
        )
    };

    return (

        <Card bodyStyle={{ padding: 0 }}>
            <Row gutter={[8,0]} style={{padding:'16px'}}>
                <Col>
                    <LeftOutlined onClick={()=>
                        props.setReasonCode("")
                    }/>
                </Col>
                <Col >
                    <Text>{" Back to Reason Codes"} </Text>
                </Col>
            </Row>
                <Row>
                    <Col span={24}>
                        <AdvancedTable
                            extraTableProps={{ rowKey: "promoId", scroll: { y: 400 },
                                loading :{spinning:!props.promoData, indicator:<UXSmallPulse/>}
                            }}
                            tableClassName="promo-table"
                            locale={{ emptyText: <NoPromoData customClass="promo-no-data" /> }}
                            columns={getColumns()}
                            dataSource={props.promoData}
                            pagination={true}
                        />
                    </Col>
                </Row>
        </Card>

    )
};
export default PromoTable;