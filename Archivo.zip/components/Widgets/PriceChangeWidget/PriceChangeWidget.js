import React, { Fragment, useEffect, useState } from "react";
import "./PriceChangeWidget.scss";
import {Card, Col, Row, Typography, Spin, Tag,Tooltip} from "antd";
import AdvancedTable from "../../GlobalComponents/AdvancedTable/AdvancedTable";
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import SvgUtil from "../../Utils/SvgUtil";
import WidgetHeader from '../WidgetHeader';
import DashboardServices from "../../../services/DashboardServices";
import {
    getDescByStatus,
    statusCodes,
    stockProductUrlType
} from "./PriceChangeWidgetUtil";
import {trackEvent} from "../../Utils/mixpanel";

const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;

const checkCurrentDayDraftRequest = (status,lastUpdTs)=> {
    let showRequest = true;
    if(Object.values(statusCodes.DRAFT.status).includes(status)){
        let zeroedTime = new Date().setHours(0,0,0,0);
        let reqLastUpdatedTime = new Date(lastUpdTs).setHours(0,0,0,0)
        showRequest = reqLastUpdatedTime === zeroedTime;
    }
    return showRequest;
};

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const customDateFormatter = (inputStringDate) => {
    let output = "";
    if(inputStringDate){
        let inputDate = new Date(inputStringDate);
        output = inputDate.toString() === "Invalid Date" ? "" :inputDate.getMonth()+1 + "/" + inputDate.getDate() + "/" + inputDate.getFullYear();
    }
    return output;
};

const customStatusTagRenderer = (requestData) =>{

    return (
        <Tooltip title={requestData.longDesc}>
            <Tag color={requestData.tagColor}>
                {requestData.shortDesc.toUpperCase()}
            </Tag>
    </Tooltip>
    )
};

const redirectToStockProductPage = (eachRow, stockProductUrl) => {
    let urlType = "";
    stockProductUrlType.forEach((values, key) => {
        if (values.includes(eachRow.requestStatusCode)) {
            urlType = key;
        }
    });
    let url =  stockProductUrl + "/" + urlType+"/";
    if (urlType === 'check') {
        url = url + eachRow.requestSubTypeCode + "/";
    }
    url = url+eachRow.requestId;
    trackEvent("REQUEST_SEARCHED_FROM_PRICE_CHANGE_WIDGET", {'ACTION': origin});

    window.open(url);
};

const getColumns=(stockProductUrl) =>  [
    {
        title: headerFormatter('ID'),
        dataIndex: 'requestId',
        isCustomFilter: true,
        retainColumnRender: true,
        filterPlaceholder: "Id",
        sorter: (a, b) => a.requestId - b.requestId,
        render: (text,row) => <a onClick= {() => redirectToStockProductPage(row,stockProductUrl)}>{text}</a> //eslint-disable-line
    },
    {
        title: headerFormatter('Title'),
        dataIndex: 'requestDescription',
        isCustomFilter: true,
        sorter: (a, b) => customStringSorter(a.requestDescription,b.requestDescription),
        width: 220
    },
    {
        title: headerFormatter('Type'),
        dataIndex: 'requestSubType',
        sorter: (a, b) => customStringSorter(a.requestSubType,b.requestSubType),
    },
    {
        title: headerFormatter('Owner'),
        dataIndex: 'createdSystemUserId',
        sorter: (a, b) => customStringSorter(a.createdSystemUserId,b.createdSystemUserId),
        render:text=>text?text.trim():"",
        width: 100,
        align:"center"
    },
    {
        title: headerFormatter('Begins'),
        dataIndex: 'effBgnTimestamp',
        sorter: (a, b) => new Date(a.effBgnTimestamp).getTime()- new Date(b.effBgnTimestamp).getTime(),
        render: customDateFormatter,
        align:"right",
    },
    {
        title: headerFormatter('Ends  '),
        dataIndex: 'effEndTimestamp',
        sorter: (a, b) => {
            return new Date(a.effEndTimestamp).getTime() - new Date(b.effEndTimestamp).getTime()
        },
        render: customDateFormatter,
        align:"right",

    },
    {
        title: headerFormatter('Status'),
        dataIndex: 'derivedStatusDesc',
        sorter: (a, b) => customStringSorter(a.derivedStatusDesc.shortDesc,b.derivedStatusDesc.shortDesc),
        render: (text) =>customStatusTagRenderer(text),
        align:"center"

    },
];


const PriceChangeWidget = (props) => {

    const [priceChangeRequestData,setPriceChangeRequestData] = useState("");

    useEffect(() => {
        if(Object.keys(props.hierarchyDetails).length>0){
            setPriceChangeRequestData("");
            DashboardServices.getPacManRequestDetails(props.hierarchyDetails).then(response => {
                let requests = response.data.filter(k=>checkCurrentDayDraftRequest(k.requestStatusCode,k.lastUpdatedTimestamp));
                requests.forEach(k=>
                    k.derivedStatusDesc=getDescByStatus(k.requestStatusCode)
                    );
                setPriceChangeRequestData(requests);

            }).catch(error => {
                console.log(error);
                setPriceChangeRequestData([]);
            })
        }
    }, [props.hierarchyDetails]);

    const NoPriceChangeData = (props) => {
        return (
            <div className={props.customClass}>
                {!priceChangeRequestData ? null :
                    <Fragment>
                        <Row justify="center" align="middle">
                            <Col>{SvgUtil.getNoData()}</Col>
                        </Row>
                        <Row justify="center" align="middle">
                            <Col><Text className="no-pricechange-found-text">No Recent Price Changes Available </Text></Col>
                        </Row>
                    </Fragment>}
            </div>
        )
    };

    return (
        <Spin indicator={<UXSmallPulse />} spinning={!priceChangeRequestData}>
            <Card bodyStyle={{ padding: 0 }}>
                <Row>
                    <Col span={24}>
                        <WidgetHeader title="Price Change Requests" />
                    </Col>
                </Row>
                {priceChangeRequestData ?
                    <Row>
                        <Col span={24}>
                        <AdvancedTable
                            extraTableProps={{ rowKey: "requestId", scroll: { y: 400 } }}
                            tableClassName="pricechange-table"
                            locale={{ emptyText: <NoPriceChangeData customClass="no-pricechange-found" /> }}
                            columns={getColumns(props.stockProductUrl)}
                            dataSource={priceChangeRequestData}
                            pagination={false}
                            key={props.selectedDCS}
                        /></Col>
                    </Row> : <NoPriceChangeData customClass="pricechange-no-data" />}
            </Card>
        </Spin>
    )
};
export default PriceChangeWidget;