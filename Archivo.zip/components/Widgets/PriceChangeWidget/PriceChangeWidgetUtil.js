const statusCodes = {
  DRAFT: {
    desc: 'Draft Started',
    shortDesc :'Draft',
    tagColor: 'processing',
    status: {
      UPLOAD_INITIATED: 110,
      UPLOAD_VALIDATIONS_SUCCESS: 120,
      UPLOAD_VALIDATIONS_FAILED: 130,
    }
  },
  SUBMITTED: {
    desc: 'Request Submitted',
    shortDesc :'Submitted',
    tagColor: 'processing',
    status: {
      SUBMIT_INITIATED: 210,
      SUBMIT_VALIDATION_SUCCESS: 220
    }
  },
  SUBMIT_VALIDATION_FAILED: {
    desc: 'Submit Validation Failed',
    shortDesc :'Failed',
    tagColor: 'error',
    status: {
      SUBMIT_VALIDATION_FAILED: 230
    }
  },
  APPROVAL_VALIDATION_FAILED: {
    desc: 'Approval Validation Failed',
    shortDesc :'Failed',
    tagColor: 'error',
    status: {
      APPROVAL_VALIDATION_FAILED: 330
    }
  },
  PENDING_APPROVAL: {
    desc: 'Pending Approval',
    shortDesc :'Pending',
    tagColor: 'warning',
    status: {
      APPROVAL_PENDING: 340
    }
  },
  APPROVED: {
    desc: 'Request Approved',
    shortDesc :'Approved',
    tagColor: 'processing',
    status: {
      APPROVAL_APPROVED: 350
    }
  },
  APPROVAL_REJECTED: {
    desc: 'Approval Rejected',
    shortDesc :'Rejected', 
    tagColor: 'error', 
    status: {
      APPROVAL_REJECTED: 360
    }
  },
  APPROVAL_EXPIRED: {
    desc: 'Approval Expired',
    shortDesc :'Expired',
    tagColor: 'error',
    status: {
      APPROVAL_EXPIRED: 370
    }
  },
  EDIT_IN_PROGRESS_BEFORE_TRANSMISSION: {
    desc: 'Edit In Progress',
    shortDesc :'In Progress',
    tagColor: 'processing',
    status: {
      EDIT_IN_PROGRESS_BEFORE_TRANSMISSION: 380
    }
  },
  TRANSMISSION_INITIATED: {
    desc: 'Transmission Initiated',
    shortDesc :'Initiated',
    tagColor: 'processing',
    status: {
      TRANSMISSION_INITIATED: 410
    }
  },
  TRANSMISSION_VALIDATION_FAILED: {
    desc: 'Transmission Validation Failed',
    shortDesc :'Failed',
    tagColor: 'error',
    status: {
      TRANSMISSION_VALIDATION_FAILED: 430
    }
  },
  WAITING_TO_SEND_TO_STORE: {
    desc: 'Waiting to Send to Store',
    shortDesc: 'Waiting',
    tagColor: 'warning',
    status: {
      TRANSMISSION_PENDING: 440
    }
  },
  EXECUTION_INCOMPLETE: {
    desc: 'Execution Incomplete',
    shortDesc: 'Incomplete',
    tagColor: 'warning',
    status: {
      TRANSMISSION_PENDING: 440
    }
  },
  REQUEST_FORCED: {
    desc: 'Request Forced',
    shortDesc: 'Forced',
    tagColor: 'success',
    status: {
      TRANSMISSION_FORCED: 480
    }
  },
  EDIT_IN_PROGRESS_AFTER_TRANSMISSION: {
    desc: 'Edit In Progress',
    shortDesc: 'In Progress',
    tagColor: 'processing',
    status: {
      EDIT_IN_PROGRESS_AFTER_TRANSMISSION: 480
    }
  },
  EXECUTION_COMPLETE: {
    desc: 'Execution Complete',
    shortDesc: 'Complete',
    tagColor: 'success',
    status: {
      TRANSMISSION_COMPLETED: 490
    }
  },

  DELETED: {
    desc: 'Deleted',
    shortDesc: 'Deleted',
    tagColor: 'error',
    status: {
      DELETE_INITIATED: 510,
      DELETE_COMPLETED: 590
    }
  },
  ERROR: {
    desc: 'Error',
    shortDesc: 'Error',
    tagColor: 'error',
    status: {
      ERROR: 999
    }
  }

};

const getDescByStatus = (status) => {
  let desc = {shortDesc:"Unknown",longDesc:"Unknown",tagColor:"default"};
  Object.keys(statusCodes).forEach(key => {
    const level1 = statusCodes[key];
    Object.keys(level1).forEach(key1 => {
      if (key1 === 'status') {
        const level2 = level1[key1];
        Object.keys(level2).forEach(key2 => {
          if (level2[key2] === status) {
            desc.shortDesc = level1.shortDesc;
            desc.longDesc = level1.desc;
            desc.tagColor = level1.tagColor;
          }
        });
      }
    });
  });
  return desc;
};

const statusTagColorCode = {
  warning:"#fa8c16",
  success:"#52c41a",
  processing:"#1890ff",
  error:"#f5222d",
  default:"#000000"
};

const stockProductUrlType = new Map(
    [["check",[110]],
            ["review",[120,130]],
            ["confirm",[210, 220, 230, 330, 340, 350, 360, 370, 380, 430, 440, 480, 490, 510, 590, 999, 1000]]]);

export {
  getDescByStatus,
  statusCodes,
  statusTagColorCode,
  stockProductUrlType
};