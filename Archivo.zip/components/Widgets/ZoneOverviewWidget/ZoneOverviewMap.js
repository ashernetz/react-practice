import React, { useState, useEffect } from 'react';
import GoogleMapReact from 'google-map-react';
import MapStyle from "../../MapComponent/MapView/MapStyle";
import supercluster from 'points-cluster';
import Marker from '../../MapComponent/Marker/Marker';

const ZoneOverviewMap = (props) => {
    const [markers, setMarkers] = useState([]);
    const [clusters, setClusters] = useState([]);
    const [map, setMap] = useState();
    const [mapsAPI, setMapsAPI] = useState();
    const [mapInfo, setMapInfo] = useState({});

    const defaultZoom = 4, defaultCenter = {
        lat:40.98832580000001,
        lng:-98.2643519000000,
    };

    // update map bounds from cluster points triggers creating clusters for given bounds

    function loadMapsAPI(map, maps) {
        setMap(map);
        setMapsAPI(maps);
    }

    useEffect(() => {
        if (props.selectedZone && props.selectedZone.storePerformanceData) {
            let markersWithLatLng = getMarkersWithLatLng()
            setMarkers(markersWithLatLng)
            if (map) {
                map.setCenter(defaultCenter);
                map.setZoom(defaultZoom);
                // if visible markers given bounds do not include all markers with starting zoom 
                // (Alaska, lower parts of Florida and Texas, etc)
                // Doesn't feel totally right. When Anchorage is selected, it can't zoom out enough, only shows one of the stores. Maybe if all points are out of starting map bounds (like Anchorage), just show the zoomed in bounds of that zone.
                    if (getVisibleMarkersGivenBounds(getMapBounds(), markersWithLatLng).length < markersWithLatLng.length) {
                        updateMapBounds(getMapBounds(), markersWithLatLng)
                    }
            }
        } else {
            setMarkers([])
        }
    }, [props.selectedZone, map]);

    useEffect(() => {
        if (mapsAPI && mapInfo.bounds) {
            createClusters();
        }
    }, [mapsAPI, markers, mapInfo.bounds]);

    function getMarkersWithLatLng() {
        let markersWithLatLng = [];
        props.selectedZone.storePerformanceData.forEach(store => {
            if (store.latitudeNumber && store.longitudeNumber) {
                markersWithLatLng.push({
                    id: store.storeNumber,
                    lat: store.latitudeNumber,
                    lng: store.longitudeNumber,
                    shape: "pin-point",
                    store
                })
            }
        })
        return markersWithLatLng
        // updateMapBounds(markersWithLatLng) // or just set map.zoom(3 or 4)
    }

    function handleMapChange(mapInfo) {
        setMapInfo(mapInfo);
    };

    function getMapBounds() {
        let { sw, ne } = mapInfo.bounds;
        return new mapsAPI.LatLngBounds(sw, ne);
    }

    function getVisibleMarkersGivenBounds(mapBounds, markersToCheck) {
        return markersToCheck.filter( marker => mapBounds.contains({lat: marker.lat, lng: marker.lng}))
    }

    function createClusters() {
        let newBounds = getMapBounds();
        let visibleMarkers = getVisibleMarkersGivenBounds(newBounds, markers);
        let newClusters = supercluster(visibleMarkers, {maxZoom: 16, radius: 40});     
        setClusters(convertClustersIntoMarkers(newClusters));
    }

    function convertClustersIntoMarkers(newClusters) {
        return newClusters(mapInfo).map(({ wx, wy, numPoints, points }) => ({
            lat: wy,
            lng: wx,
            numPoints,
            id: `${numPoints}_${points[0].id}`,
            points
        }))
    }

    function updateMapBounds(bounds, points) {
        points.forEach(point => {
            bounds.extend({lat: point.lat, lng: point.lng})
        })
        map.fitBounds(bounds);
    }

    function onClusterClick(key, markerProps) {
        let newBounds = new mapsAPI.LatLngBounds();
        updateMapBounds(newBounds, markerProps.cluster.points);
    }

    function onMapPointerClick() {

    }


    function getStoreMarker(marker) {
        return (
            <Marker
                noHover 
                key={marker.id}
                lat={marker.lat}
                lng={marker.lng}
                store={marker.store}
                valueKey = {"store" + marker.id}
                pointerColor={"#E06950"}
                onMapPointerClick={onMapPointerClick}
            />
        )
    }

    function getClusterMarkers (cluster) {
        let slices = [];
        if (mapsAPI) {
            let colorMap = {};
            cluster.points.forEach(slice => {
                if (colorMap.hasOwnProperty(slice.pointerColor)) {
                    colorMap[slice.pointerColor]["slice"] = null;
                    colorMap[slice.pointerColor]["count"] = colorMap[slice.pointerColor]["count"] + 1;
                    colorMap[slice.pointerColor]["polygonCoords"].push(
                    new mapsAPI.LatLng(slice.lat, slice.lng))
                } else {
                    colorMap[slice.pointerColor] = {
                        count: 1,
                        key: slice.id,
                        lat: slice.lat,
                        lng: slice.lng,
                        polygonCoords: [new mapsAPI.LatLng(slice.lat, slice.lng)],
                        slice
                    };
                }
            });
            Object.keys(colorMap).forEach(color => {
                let bounds = new mapsAPI.LatLngBounds();
                for (let i = 0; i < colorMap[color].polygonCoords.length; i++) {
                    bounds.extend(colorMap[color].polygonCoords[i]);
                }
                let radius = 35;
                if (colorMap[color]["count"] > 50) {
                    radius = colorMap[color]["count"] * 0.08 + 20;
                }
                radius = radius < 35 ? 35 : radius;
                let storeCount = colorMap[color]["count"];
                if (storeCount === 1){
                    slices.push(getStoreMarker(colorMap[color].slice));
                } else {
                    slices.push( 
                        <Marker
                            key={colorMap[color].key + "bubble"}
                            cluster={cluster}
                            valueKey={colorMap[color].key + "bubble"}
                            latt={colorMap[color].lat}
                            lngg={colorMap[color].lng}
                            lat={bounds.getCenter().lat()}
                            lng={bounds.getCenter().lng()}
                            pointerColor={"#E06950"}
                            shape="bubble"
                            onMapPointerClick={onClusterClick}
                            storeCount={storeCount}
                            radius={radius}
                        />
                    )
                }
            });
        }
        return slices;
    };

    return (
        <GoogleMapReact 
            bootstrapURLKeys={{key: props.apiKey}}
            options={{
                zoomControl: false,
                fullscreenControl: false,
                maxZoom: 16,
                minZoom: 3,
                styles: MapStyle.getMapStyle()
            }}
            defaultCenter={defaultCenter}
            defaultZoom={defaultZoom}
            yesIWantToUseGoogleMapApiInternals
            onChange={handleMapChange}
            onGoogleApiLoaded={({map, maps}) => {loadMapsAPI(map, maps)}}
        >
            {
                clusters.map(cluster => {
                    if (cluster.numPoints === 1) {
                        let marker = cluster.points[0];
                        return (getStoreMarker(marker))
                    } else {
                        return (getClusterMarkers(cluster))
                    }
                })
            }
        </GoogleMapReact>
    );
};

export default ZoneOverviewMap;