import React, { useState, useEffect } from 'react';
import {Card, Row, Col} from 'antd';
import WidgetHeader from '../WidgetHeader';
import ZoneOverviewTable from './ZoneOverviewTable';
import ZoneOverviewMap from './ZoneOverviewMap';
import ZoneOverviewModal from './ZoneOverviewModal/ZoneOverviewModal';
import DataConnectionIssue from '../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue';

const ZoneOverviewWidget = (props) => {
    const [selectedZone, setSelectedZone] = useState({});
    const [isOverviewModalOpen, toggleIsOverviewModalOpen] = useState(false);

    useEffect(() => {
        if (props.zoneOverviewData.length && props.zoneOverviewData.length > 0) {
            let zone = props.zoneOverviewData[0];
            zone.key = 0;
            zone.numberOfStores = zone.storePerformanceData.length;
            setSelectedZone(zone);
        }else{
            setSelectedZone({});
        }
    }, [props.zoneOverviewData]);

    return (
        <Card bodyStyle={{padding: 0}}  bordered={false}>
            <ZoneOverviewModal 
                selectedZone={selectedZone}
                hierarchyDetails={props.hierarchyDetails}
                healthOverviewData={props.healthOverviewData}
                zoneOverviewData={props.zoneOverviewData}
                isOpen={isOverviewModalOpen}
                userRestrictionStatus={props.userRestrictionStatus}
                onCancel={() => toggleIsOverviewModalOpen(false)}
                fiscalWeek = {props.fiscalWeek}
            />
            <WidgetHeader title="Zone Overview" />
            {props.is5xx ?  <DataConnectionIssue/>:
            <Row>
                <Col xs={20} lg={12} xxl={11}>
                    <ZoneOverviewTable 
                        zoneOverviewData={props.zoneOverviewData}
                        selectedZone={selectedZone}
                        setSelectedZone={setSelectedZone}
                        toggleIsOverviewModalOpen={toggleIsOverviewModalOpen}
                        selectedDCS = {props.selectedDCS}
                    />
                </Col>
                <Col xs={4} lg={12} xxl={13} style={{height: "450px"}}>
                    <ZoneOverviewMap 
                        apiKey={props.apiKey}
                        selectedZone={selectedZone}
                    />
                </Col>
            </Row>}
        </Card>
    );
};

export default ZoneOverviewWidget;