import React, {useState, useEffect, useRef} from 'react';
import {trackEvent} from '../../Utils/mixpanel';
import {Table, Typography, Row, Col} from 'antd';
import {SearchOutlined} from '@ant-design/icons';
import PercentageCell from '../SharedComponents/PercentageCell/PercentageCell';
import TableFilterDropdown from '../SharedComponents/TableFilter/TableFilterDropdown';
import RowFilterHighlighter from '../SharedComponents/TableFilter/RowFilterHighlighter';
import "./ZoneOverviewWidget.scss"
import SvgUtil from "../../Utils/SvgUtil";
import UXSmallPulse
    from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";

const {Text} = Typography;

const ZoneOverviewTable = (props) => {
    const [tableData, setTableData] = useState([]);
    const [filter, setFilter] = useState("");
    const filterSearchInputRef = useRef(null);

    useEffect(() => {
        setFilter("");
        if (props.zoneOverviewData.zonePerformanceData) {
            setTableData(
                props.zoneOverviewData.zonePerformanceData.map(function(zone, index) {
                    zone.key = index
                    zone.numberOfStores = zone.storePerformanceData.length
                    return zone
                })
            )
        } else {
            setTableData([]);
        }
    }, [props.zoneOverviewData])

    let columns = [
        {
            title: <Text strong id="zone-overview-zone-name-column-title">Zone</Text>,
            // colSpan: 8,
            dataIndex: "zoneName",
            width:"25%",
            align: "left",
            ellipsis: true,
            fixed: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
                <TableFilterDropdown 
                    setSelectedKeys={setSelectedKeys}
                    selectedKeys={selectedKeys}
                    confirm={confirm}
                    clearFilters={clearFilters}
                    filterFunction={handleFilterSearch}
                    resetFunction={handleResetFilter}
                    compRef={filterSearchInputRef}
                    placeholder="Search Name"
                />
            ),
            filterIcon: filtered => (

                <SearchOutlined className={`zone-filter-icon ${filtered ? "zone-filter-icon-filtered" : null}`} />
            ), 
            onFilter: (value, record) => 
                record["zoneName"]
                    .toString()
                    .toLowerCase()
                    .includes(value.toLowerCase())
            ,
            onFilterDropdownVisibleChange: visible => {
                if (visible) {
                  setTimeout(() => focusFilterSearchInput());
                }
            },
            render: text => (
                <RowFilterHighlighter
                    filter={filter}
                    text={text}
                />
            ),
            sorter: (a, b) => {return a.zoneName.localeCompare(b.zoneName)}
        },
        {
            title: <Text strong>Stores</Text>,
            // colSpan: 4,
            dataIndex: "numberOfStores",
            width:"15%",
            align: "right",
            ellipsis: true,
            sorter: (a, b) => a.numberOfStores - b.numberOfStores
        },
        {
            title: <Text strong>Sales</Text>,
            // colSpan: 6,
            key: "zoneCompPercentage",
            sorter: (a, b) => (a.rawSales?a.rawSales:0) - (b.rawSales?b.rawSales:0),
            align: "right",
            ellipsis: true,
            render: (props) => (<PercentageCell rawData={"rawSales"} value={"zoneCompPercentage"} {...props} />)
        },
        {
            title: <Text strong>Units</Text>,
            // colSpan: 6,
            key: "zoneUnitsPercentage",
            sorter: (a, b) => (a.rawUnits?a.rawUnits:0) - (b.rawUnits?b.rawUnits:0),
            align: "right",
            ellipsis: true,
            render: (props) => (<PercentageCell rawData={"rawUnits"} value={"zoneUnitsPercentage"} {...props} />)
        }
    ]

    function handlePaginationFilterOrSorterChange(pagination, filters, sorter, extra) {
        if (extra.currentDataSource[0]) {
            props.setSelectedZone(extra.currentDataSource[0])
        } else {
            props.setSelectedZone({})
        }
    }

    function handleFilterSearch(selectedKeys, confirm) {
        confirm();
        setFilter(selectedKeys[0]);
    }

    function handleResetFilter(clearFilters) {
        clearFilters();
        setFilter("");
    }

    function focusFilterSearchInput() {filterSearchInputRef.current.focus()};

    function setRowClassName (record) {
        return record.zoneId === props.selectedZone.zoneId ? 'selected-row' : '';
    }    

    function handleClickingRow() {
        props.toggleIsOverviewModalOpen(true)
    }

    function handleRowHover(record) {
        props.setSelectedZone(record);
        trackEvent("CHANGED_ZONE_OVERVIEW_WIDGET_ZONE", {'zone': record});
    }

    const NoZonesFound = () => {
        return(
            <div className="no-zone-found-widget">
                {
                    props.zoneOverviewData &&
                    <Row justify="center" align="middle" type="flex" className="no-zone-found-widget">
                        <Col span={24}>
                            <Row><Col span={24}>{SvgUtil.getNoData()}</Col></Row>
                            <Row><Col span={24}><Text>No Zones Found </Text></Col></Row>
                        </Col>
                    </Row>
                }
            </div>
        );
    };

    return (
        <Table
            key={props.selectedDCS}
            columns={columns}
            dataSource={tableData}
            // loading={!props.zoneOverviewData}
            loading = {{spinning:!props.zoneOverviewData, indicator:<UXSmallPulse className="zone-overview-table-spinner"/>}}
            pagination={false}
            scroll={{ x:600,y: 390 }}
            locale={{emptyText:<NoZonesFound/>}}
            onChange={handlePaginationFilterOrSorterChange}
            onRow={(record) => ({
                onClick: () => { handleClickingRow() },
                onMouseOver : () => { handleRowHover(record) },
                onMouseLeave: () => { props.setSelectedZone(record) }
            })}
            className="zone-overview-table"
            rowClassName={setRowClassName}
        />
    );
};

export default ZoneOverviewTable;
