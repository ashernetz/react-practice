import React from 'react';
import HeaderInfo from './HeaderInfo';
import ZoneHealth from './ZoneHealth';
import StoreSummary from './StoreSummary';
import {Modal, Button, Divider} from 'antd'

const ZoneOverviewModal = (props) => {
    const footerButtons = [
        // <Button key="zone-overview-modal-modify-zone-button" type="link">Modify Zone</Button>,
        <Button key="zone-overview-modal-close-button" size="large" type="primary" onClick={props.onCancel}>Close</Button>
    ]

    function getSelectedZoneValue() {
        return props.selectedZone.zoneId
    }

    return (
        <Modal
            id="zone-overview-modal"
            open={props.isOpen}
            onCancel={props.onCancel}
            title="Zone Details"
            footer={footerButtons}
            destroyOnClose={true}
            okButtonProps={{ size: 'large' }}
        >
            <HeaderInfo 
                selectedZone={props.selectedZone}
                hierarchyDetails={props.hierarchyDetails}
            />
            <Divider /> 
            {
                props.userRestrictionStatus === "allowed" && 
                <ZoneHealth
                    fiscalWeek={props.fiscalWeek}
                    healthOverviewData={props.healthOverviewData}
                    selectedZoneValue={getSelectedZoneValue()}
                    userRestrictionStatus={props.userRestrictionStatus}
                />
            }
            <StoreSummary 
                selectedZone={props.selectedZone}
            />
        </Modal>
    );
};

export default ZoneOverviewModal;