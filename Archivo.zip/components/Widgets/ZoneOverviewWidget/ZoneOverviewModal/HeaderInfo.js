import React from 'react';
import {Row, Col, Typography} from 'antd';

const {Text} = Typography;

const HeaderInfo = (props) => {

  const getDCSShortInfo=()=>{
    let dcsInfo = props.hierarchyDetails.departmentNumber ? "D"+props.hierarchyDetails.departmentNumber:"";
    dcsInfo += props.hierarchyDetails.classNumber ? " C"+props.hierarchyDetails.classNumber:"";
    dcsInfo += props.hierarchyDetails.subClassNumber ? " SC"+props.hierarchyDetails.subClassNumber:"";
    return dcsInfo;
  };
    return (
        <Row>
            <Col span={20}> 
                <Row>
                    <Text strong>{props.selectedZone.zoneName}</Text>
                </Row>
                <Row>
                    <Text>{getDCSShortInfo()}</Text>
                </Row>
            </Col>
            <Col span={4}>
                <Row>
                    <Text strong>{props.selectedZone.numberOfStores}</Text>
                </Row>
                <Row>
                    <Text>Stores</Text>
                </Row>
            </Col>
            {/* <Col span={4}>
                <Row>
                    <Text strong>N/A</Text>
                </Row>
                <Row>
                    <Text>Markets</Text>
                </Row>
            </Col> */}
        </Row>
    );
};

export default HeaderInfo;