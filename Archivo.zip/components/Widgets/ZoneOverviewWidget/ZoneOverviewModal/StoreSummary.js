import React, {useState, useEffect, useRef} from 'react';
import {Row, Col, Table, Typography} from 'antd';
import {SearchOutlined} from '@ant-design/icons';
import PercentageCell from '../../SharedComponents/PercentageCell/PercentageCell';
import TableFilterDropdown from '../../SharedComponents/TableFilter/TableFilterDropdown';
import RowFilterHighlighter from '../../SharedComponents/TableFilter/RowFilterHighlighter';
import "./ZoneOverviewModal.scss"

const {Text,Title} = Typography;

const StoreSummary = (props) => {
    const [tableData, setTableData] = useState([]);
    const [filter, setFilter] = useState("");
    const numberFilterSearchInputRef = useRef(null);
    const nameFilterSearchInputRef = useRef(null);

    useEffect(() => {
        if (props.selectedZone.storePerformanceData) {
            setTableData(
                props.selectedZone.storePerformanceData.map((store, index) => {
                    store.key = index;
                    if (!store.storeName) {
                        store.storeName = "";
                    }
                    return store
                })
            )
        } else {
            setTableData([])
        }
    }, [props.selectedZone.storePerformanceData])

    let columns = [
        {
            title: () => (<Text strong>Store #</Text>),
            dataIndex: "storeNumber",
            ellipsis: true,
            sorter: (a, b) => a.storeNumber - b.storeNumber,
            filterIcon: filtered => (
                <SearchOutlined className={`zone-filter-icon ${filtered ? "zone-filter-icon-filtered" : null}`} />
            ),
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
                <TableFilterDropdown 
                    setSelectedKeys={setSelectedKeys}
                    selectedKeys={selectedKeys}
                    confirm={confirm}
                    clearFilters={clearFilters}
                    filterFunction={handleFilterSearch}
                    resetFunction={handleResetFilter}
                    compRef={numberFilterSearchInputRef}
                    placeholder="Search Number"
                />
            ),
            onFilter: (value, record) => 
                record["storeNumber"]
                    .toString()
                    .toLowerCase()
                    .includes(value.toLowerCase())
            ,
            onFilterDropdownVisibleChange: visible => {
                if (visible) {
                  setTimeout(() => focusFilterSearchInput(numberFilterSearchInputRef));
                }
            },
            render: text => (
                <RowFilterHighlighter
                    filter={filter}
                    text={text}
                />
            )
        }, 
        {
            title: () => (<Text strong>Store Name</Text>),
            dataIndex: "storeName",
            ellipsis: true,
            sorter: (a, b) => {return a.storeName.localeCompare(b.storeName)},
            filterIcon: filtered => (
                <SearchOutlined className={`filter-icon ${filtered ? "filter-icon-filtered" : null}`} />
            ),
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
                <TableFilterDropdown 
                    setSelectedKeys={setSelectedKeys}
                    selectedKeys={selectedKeys}
                    confirm={confirm}
                    clearFilters={clearFilters}
                    filterFunction={handleFilterSearch}
                    resetFunction={handleResetFilter}
                    compRef={nameFilterSearchInputRef}
                    placeholder="Search Name"
                />
            ),
            onFilter: (value, record) => 
                record["storeName"]
                    .toString()
                    .toLowerCase()
                    .includes(value.toLowerCase())
            ,
            onFilterDropdownVisibleChange: visible => {
                if (visible) {
                  setTimeout(() => focusFilterSearchInput(nameFilterSearchInputRef));
                }
            },
            render: text => (
                <RowFilterHighlighter
                    filter={filter}
                    text={text}
                />
            )
        }, 
        {
            title: () => (<Text strong>Sales</Text>),
            key: "compPercentage",
            ellipsis: true,
            align: "right",
            sorter: (a, b) => (a.rawSales?a.rawSales:0) - (b.rawSales?b.rawSales:0),
            render: (props) => (<PercentageCell rawData={"rawSales"} value={"compPercentage"} {...props} />)
        }, 
        {
            title: () => (<Text strong>Units</Text>),
            key: "unitsPercentage",
            ellipsis: true,
            align: "right",
            sorter: (a, b) => (a.rawUnits?a.rawUnits:0) - (b.rawUnits?b.rawUnits:0),
            render: (props) => (<PercentageCell rawData={"rawUnits"} value={"unitsPercentage"} {...props} />)
        }
    ]

    function focusFilterSearchInput(ref) {ref.current.focus()};

    function handleFilterSearch(selectedKeys, confirm) {
        confirm();
        setFilter(selectedKeys[0]);
    }

    function handleResetFilter(clearFilters) {
        clearFilters();
        setFilter("");
    }

    return (
        <Row>
            <Col span={24} style={{marginBottom: "30px"}}>
                <Title className="titleText" level={4}>Store Summary</Title>
                {/* <Button type="secondary">Download</Button> */}
                <Row>
                    <Col>
                        <Table
                            columns={columns}
                            dataSource={tableData}
                            pagination={{pageSize: 6,showSizeChanger:false}}
                        />
                    </Col>
                </Row>
            </Col>
        </Row>
    );
};

export default StoreSummary;
