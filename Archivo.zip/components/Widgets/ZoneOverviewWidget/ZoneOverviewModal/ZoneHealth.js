import React from 'react';
import {Row, Col, Typography, Divider} from 'antd';
import ZoneHealthChart from '../../SharedComponents/ZoneHealthChart';

const {Title} = Typography;

const ZoneHealth = (props) => {
    return (
        <Row>
            <Col span={24}>
                <Title className="titleText" level={4}>Zone Health</Title>
                <ZoneHealthChart
                    fiscalWeek = {props.fiscalWeek}
                    healthOverviewData={props.healthOverviewData}
                    selectedZoneValue={props.selectedZoneValue}
                />
                <Divider />
            </Col>
        </Row>
    );
};

export default ZoneHealth;