import React, { useEffect, useState} from 'react';
import {Card, Typography, Tabs, Row, Col, Select, Spin } from 'antd';
import "./CPIWidget.scss";
import CPIWidgetHeader from './CPIWidgetHeader/CPIWidgetHeader';
import CPITable from './CPITable/CPITable';
import OffsideProductWidget from '../OffsideProductWidget/OffsideProductWidget';
import SvgUtil from "../../Utils/SvgUtil";
import CPIUtil from '../../Utils/CPIUtil';
import {
  isErroredResponse,
} from '../../Utils/CommonUtil';
import SingleAndMultiSkuServices
  from '../../../services/SingleAndMultiSkuServices';
import UXSmallPulse
  from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse';
import DataConnectionIssue
  from '../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue';
import HeaderServices from '../../../services/HeaderServices';
import CPIWidgetTooltip from "./CPIWidgetTooltip/CPIWidgetTooltip";

const { TabPane } = Tabs;
const { Text } = Typography;
const { Option } = Select;


const CPIWidget = (props) => {
  const [cpiData, setCpiData] = useState({data:"",is5xx: false});
  const [cpiMarkets, setCpiMarkets] = useState({ data: []});
  const [marketValue, setMarketValue] = useState(0);

  useEffect( () => {
    if (Object.keys(props.hierarchyDetails).length > 0) {
      setMarketValue(0);
      fetchCPIData(0);
    }
  },[props.hierarchyDetails]);

  useEffect( () => {
    if(marketValue){
      fetchCPIData(marketValue);
    }
  },[marketValue]);

  const fetchCPIData = (marketNbr) => {
    setCpiData({data: "", is5xx: false});
    let formattedName =
        props.hierarchyDetails.departmentNumber.toString().padStart(3, "0") + "-" +
        props.hierarchyDetails.classNumber.toString().padStart(3, "0") + "-";
    let userId = props.userId;

    if (props.hierarchyDetails.subClassNumber) {
      let formattedSubClassName = formattedName + props.hierarchyDetails.subClassNumber.toString().padStart(3, "0") + "-"
          + props.hierarchyDetails.subClassName;
      SingleAndMultiSkuServices.fetchSubClassLevelCPI({formattedSubClassName, userId, marketNbr})
          .then(response => {
            setCpiData({data: extractResponse(response.data, "sub-class"), is5xx: false});
          }).catch(error => {
        setCpiData({data: [], is5xx: isErroredResponse(error)});
        console.log(error);
      })
    } else {
      let formattedClassName = formattedName + props.hierarchyDetails.className;

      Promise.all([
        SingleAndMultiSkuServices.fetchClassLevelCPI({formattedClassName, userId, marketNbr})
            .then(response => extractResponse(response.data, "class")).catch(error => {
          console.log(error);
          return isErroredResponse(error) ? "isError" : [];
        }),
        SingleAndMultiSkuServices.fetchSubClassByClassLevelCPI({formattedClassName, userId, marketNbr})
            .then(response => extractResponse(response.data, "sub-class")).catch(error => {
          console.log(error);
          return isErroredResponse(error) ? "isError" : [];
        })
      ]).then(response => {
        if (response[0] === "isError" || response[1] === "isError") {
          setCpiData({data: [], is5xx: true});
        } else {
          setCpiData({data: [...response[0], ...response[1]], is5xx: false});
        }
      });

    }
  };

  const extractResponse = (response, type) => {
                return Object.keys(response).map(k =>
                    ({
                      formattedName: k,type, ...response[k].reduce((total, current) => {
                        if (CPIUtil.cpiThresholdFilter(current.cpiSalesCovDlyPercentage)) {
                          total[current.competitorId] = current;
                        }
                        return total;
                      }, {})
                    }));

  }

  useEffect( () => {
    HeaderServices.fetchMarketsList().then(response => {
      setCpiMarkets(
          { data: response.data?response.data:[]});
    }).catch(error => {
      setCpiMarkets({ data: [] });
      console.log(error);
    });

  },[]);




  const MarketDropdown = ({isMarketDisabled}) => {
    let  marketData=cpiMarkets.data;
    return (
        <Select
            defaultValue="markets"
            bordered={false}
            style={{ width: 150 }}
            disabled={isMarketDisabled}
            onSelect={(selectedValue) => {setMarketValue(selectedValue);}}
            value={marketValue?marketValue:"All Markets"}
            optionFilterProp="children">

          <Option value="0">All Markets</Option>
          {marketData ? marketData.map(market =>
              (<Option key={market.marketNumber} value={market.marketNumber}>
                <Text>{market.marketNumber+ " - " +market.marketName}</Text>
              </Option>)):""}
        </Select>
    );
  };


    const NoCPIData = (tempProps) => {
        return (
            <div className={tempProps.customClass}>
                {!cpiData.data ? null : (
                    <>
                        <Row type="flex" justify="center" align="middle">
                            <Col>{SvgUtil.getNoData()}</Col>
                        </Row>
                        <Row type="flex" justify="center" align="middle">
                            <Col>
                                <Text className="no-offside-found-text">
                                    No CPI Data Available{" "}
                                </Text>
                            </Col>
                        </Row>
                    </>
                )}
            </div>
        );
    };

    let headingName = Object.keys(props.hierarchyDetails).length > 0? (props.hierarchyDetails.subClassNumber? props.hierarchyDetails.subClassName:props.hierarchyDetails.className):"";
  return(
      <Card  bordered={false} bodyStyle={{padding: 0}}>
        <Row>
          <Col span={24}>
        <Tabs size="large"  className="cpi-tab-ink cpi-tab-spacing">
          <TabPane  tab={<Row justify="space-between" align="middle">
            <Col span={12}>
                <Text className="cpi-head-txt">CPI <CPIWidgetTooltip/></Text>
            </Col>
          </Row> } key="1">
                  <CPIWidgetHeader name ={headingName} marketDropdown={<MarketDropdown isMarketDisabled = {cpiData.data?false:true} />}  />
            {cpiData.is5xx ? <DataConnectionIssue/>:
            <Spin indicator={<UXSmallPulse/>} spinning={cpiData.data?false:true}>
            {cpiData.data?<>
                  <CPITable
                      diverseMultiSearch = {props.diverseMultiSearch}
                      locale={{
                      emptyText: <NoCPIData customClass="no-offside-found" />,
                  }} cpiData={cpiData.data}/>
              </>:<NoCPIData customClass="offside-no-data" />}</Spin>}

          </TabPane>
          <TabPane tab={<Row justify="space-between" align="middle"><Col span={12}><Text className="offside-head-txt">Offsides Products</Text></Col></Row>}>
            <OffsideProductWidget
                skuSearch={props.skuSearch}
                userId={props.userId}
                hierarchyDetails={props.hierarchyDetails}
                favouriteSku={props.favouriteSku}
                favSkuMap={props.favSkuMap}
                competitorDataUrl={props.competitorDataUrl}
                selectedDCS={props.selectedDCS}
            />
          </TabPane>
        </Tabs>
          </Col>
        </Row>
      </Card>
  )
};
export default CPIWidget;
