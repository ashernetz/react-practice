import React, {Fragment} from 'react';
import { Card, Row, Col, Typography, Button } from 'antd';
import {BarChartOutlined} from '@ant-design/icons';
import "./AuthWidget.scss";
import WidgetHeader from "../WidgetHeader";

const {Text} = Typography;

const AuthWidget = (props) => {

  const accessText = (access) => {
    let isSecondary = false;
    let containerClassMargin = "80px";
    let requestAccessText = "Permissions Needed to View this Widget";
    if (access === "denied") {
      containerClassMargin = "120px";
      isSecondary = true;
      requestAccessText = "You are not Authorized to View this DCS "+ props.title;
    } else if (access === "requested-not-allowed") {
      containerClassMargin = "120px";
      isSecondary = true;
      requestAccessText = "Request Access has been submitted";
    }
    return {containerClassMargin,requestAccessText,isSecondary};
  };
  const EachRow = (props) => {
    return(<Row type="flex" justify="center" align="middle" gutter={props.gutter}>
      <Col>{props.rowData}</Col>
    </Row>);
  };

  if(props.userRestrictionStatus === "allowed"){
    return props.allowedComponent;
  }else
  {
    let {requestAccessText, containerClassMargin,isSecondary}=accessText(props.userRestrictionStatus);
    return (
        <Card bodyStyle={{height:'500px', padding:0}}>
          <WidgetHeader title={props.title}/>
          {props.userRestrictionStatus &&
          <div style={{padding:'12px',marginTop:containerClassMargin}}>
            <EachRow rowData = {<BarChartOutlined id="request-access-icon" />}/>
            <EachRow rowData = {<Text type={isSecondary?"secondary":"primary"} className="request-access-text-one request-access-align" >{requestAccessText}</Text>} gutter={[0, 32]}/>
            {props.userRestrictionStatus === "not-allowed" && <Fragment>
              <EachRow rowData = {<Text className="request-access-text-two request-access-align">Request access by clicking the button below</Text>} gutter={[0, 24]}/>
              <EachRow rowData = {<Button block type="primary" onClick={props.onRequestAccessClick} ghost='true' size='large'>Request Access</Button>} gutter={[0, 32]}/>
            </Fragment>}
          </div>}
        </Card>

    );}
};

export default AuthWidget;