import {Badge, Col, Row, Tooltip, Typography} from "antd";
import React from "react";
import WidgetHeader from "../WidgetHeader";
const {Text} = Typography;

const OffsideProductHeader = (props) => {

  //TODO: Will be added in Future.

  // const option = () => {
  //   return (<Row type="flex" justify="end" align="middle" gutter={[8,0]}>
  //      <Col >
  //           <Icon type="setting" className="icon-size" onClick={event => {
  //                   // If you don't want click extra trigger collapse, you can prevent this:
  //                   event.stopPropagation();
  //               }}
  //           />
  //       </Col>
  //       <Col >
  //           <Icon type="more" className="icon-size" onClick={event => {
  //                   // If you don't want click extra trigger collapse, you can prevent this:
  //                   event.stopPropagation();
  //               }}
  //           />
  //       </Col>
  //   </Row >)
  // };

  const OffsideTitle = ()=>{
    return (<Row >
      <Col>
        <Text className="offside-product-title"> Offside Products </Text>
      </Col>
      <Col>
        <Badge
            offset={[12, -6]}
            count={
              <div>
                <Tooltip title={"Competitor Pressure on KVI & Favorite SKUs ranked by R12 sales and days at price."} placement="top">
                  <i id="offside-info" className="material-icons-outlined">
                    info
                  </i>
                </Tooltip>
              </div>
            }
        ></Badge>
      </Col>
    </Row>)
  };

    return (
        <WidgetHeader title={<OffsideTitle/>} label={props.offsideProductsFilterDropdown} />

    )
};

export default OffsideProductHeader;
