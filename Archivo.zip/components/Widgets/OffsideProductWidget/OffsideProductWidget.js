import React, {Fragment, useEffect, useState} from 'react';
import { Col, Popover, Row, Select, Spin, Typography} from 'antd';
import SvgUtil from '../../Utils/SvgUtil';
import DashboardServices from '../../../services/DashboardServices';
import AdvancedTable from '../../GlobalComponents/AdvancedTable/AdvancedTable';
import './OffsideProductWidget.scss';
import NoSkuImage from '../../SkuDetailComponent/SkuCard/no-sku-image.jpg';
import UXSmallPulse
  from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse';
import OffsideProductHeader from './OffsideProductHeader';
import {trackEvent} from '../../Utils/mixpanel';
import {formatNumberToCompact} from '../../Utils/CommonUtil';
import TableUtil from '../../Utils/TableUtil';
import CompetitorComparisonModal
  from '../../CompetitorComparisonModal/CompetitorComparisonModal';

const { Text } = Typography;
const { Option } = Select;

const OffsideProductWidget = (props) => {
  const [offsideProductData, setOffsideProductData] = useState("");
  const [offsideComparisonData, setOffsideComparisonData] = useState("");
  const [selectedOffsideFilterValue, setSelectedOffsideFilterValue] = useState(
    "All"
  );

  const replaceThisWithArrayLengthOfUserPreferenceCompetitorsToShow = 5;

  let skuList = props.favSkuMap
    ? Object.keys(props.favSkuMap).length > 0
      ? Object.keys(props.favSkuMap).map(Number)
      : []
    : [];

  const filterOffsideTableData = () => {
    return offsideProductData.filter((k) =>
      selectedOffsideFilterValue === "All"
        ? true
        : selectedOffsideFilterValue === "Favorites"
        ? skuList.includes(k.SKU_NBR)
        : !skuList.includes(k.SKU_NBR)
    );
  };

  useEffect(() => {
    if (Object.keys(props.hierarchyDetails).length > 0) {
      if (skuList.length === 0) {
        skuList = props.favouriteSku
          ? Object.keys(JSON.parse(props.favouriteSku)).map(Number)
          : [];
      }
      setOffsideProductData("");
      setSelectedOffsideFilterValue("All");
      DashboardServices.getOffsideDetails(props.hierarchyDetails, skuList)
        .then((response) => {
          setOffsideProductData(response.data);
        })
        .catch((error) => {
          console.log(error);
          setOffsideProductData([]);
        });
    }
  }, [props.hierarchyDetails]);

  const offsideProductsFilterDropdown = () => {
    let offsideFilterValues = ["All", "KVI", "Favorites"];
    return (
      <Select
        size="small"
        style={{ width: 200 }}
        optionFilterProp="children"
        onSelect={(selectedValue) => {
          setSelectedOffsideFilterValue(selectedValue);
        }}
        bordered={false}
        value={selectedOffsideFilterValue}
      >
        {offsideFilterValues.map((k) => (
          <Option value={k} key={k}>
            {k}
          </Option>
        ))}
      </Select>
    );
  };

  const headerFormatter = (input) => <Text strong>{input}</Text>;

  const cellColorIdentifier = (record, competitorRetail) => {
    return {
      className: record[competitorRetail]
        ? record[competitorRetail] > record.THD_PRICE
          ? "table-cell-green"
          : record[competitorRetail] < record.THD_PRICE
          ? "table-cell-red"
          : ""
        : "",
    };
  };

  const popoverContent = (skuImageUrl, skuDescription, sku) => {
    let skuImage = skuImageUrl ? skuImageUrl : NoSkuImage;
    let skuDesc = skuDescription ? skuDescription : "";
    return (
      <Row type="flex" align="middle" justify="space-between" gutter={[16, 0]}>
        <Col>
          <img alt="sku-data" className="sku-popover-image" src={skuImage} />{" "}
        </Col>
        <Col>
          <Row type="flex" justify="start">
            <Text strong>{skuDesc}</Text>
          </Row>
        </Col>
      </Row>
    );
  };

  const onSkuNumberClick = (skuNumber) => {
    trackEvent("SKU_CLICKED_FROM_OFFSIDE_PRODUCT", {
      sku: skuNumber,
      ACTION: origin,
    });
    props.skuSearch(skuNumber, "SKU_CLICKED_FROM_OFFSIDE_PRODUCT_WIDGET");
  };

  const onPriceClick = (competitorId, record, competitorType) => {
    trackEvent("OFFSIDE_COMPETITOR_ON_CLICK", {
      sku: record.SKU_NBR,
      competitorType: competitorType,
      ACTION: origin,
    });
    let skuImage = record.SKU_IMAGE_URL ? record.SKU_IMAGE_URL : NoSkuImage;
    let skuDesc = record.SKU_DESCRIPTION ? record.SKU_DESCRIPTION : "";
    setOffsideComparisonData({
      ...record,
      competitorId,
      competitorType,
      skuImage,
      skuDesc,
      competitorPrice:record[competitorType]
    });
  };


  function buildCompetitorColumns(title, dataIndex, competitorId) {
    return {
      title: headerFormatter(title),
      className: "column-text-align",
      dataIndex,
      onCell: (record, index) => cellColorIdentifier(record, dataIndex),
      sorter: (a, b) => a[dataIndex] - b[dataIndex],
      align: "right",
      render: (retail, record) =>
        retail ? (
          <Text
            className="comp-price-text"
            onClick={() => {
              onPriceClick(competitorId, record, dataIndex);
            }}
          >
            {retail ? "$" + retail : "-"}
          </Text>
        ) : (
          <Text>-</Text>
        ),
    };
  }

  function buildColumns(offsideProducts) {
    return [
      {
        title: headerFormatter("Sku#"),
        width: 130,
        dataIndex: "SKU_NBR",
        isCustomFilter: true,
        retainColumnRender: true,
        filterPlaceholder: "Sku",
        sorter: (a, b) => a.SKU_NBR - b.SKU_NBR,
        fixed: 'left',
        render: (SKU_NBR, row) => (
          <Popover
            content={popoverContent(
              row.SKU_IMAGE_URL,
              row.SKU_DESCRIPTION,
              SKU_NBR
            )}
            placement="topLeft"
            arrowPointAtCenter
          >
            <a onClick={() => onSkuNumberClick(SKU_NBR)}>{SKU_NBR}</a> {/*eslint-disable-line*/}
          </Popover>
        ),
      },
      {
        title: headerFormatter("Price"),
        dataIndex: "THD_PRICE",
        sorter: (a, b) => a.THD_PRICE - b.THD_PRICE,
        align: "right",
        render: (retail) => <Text>{retail ? "$" + retail : ""}</Text>,
      },
      buildCompetitorColumns("Low", "LOWES_PRICE", "3141"),
      buildCompetitorColumns("Men", "MENARDS_PRICE", "6488"),
      buildCompetitorColumns("F&D", "FLOOR_DECOR_PRICE", "588623"),
      buildCompetitorColumns("Amz", "AMAZON_PRICE", "18214"),
      buildCompetitorColumns("Wal", "WALMART_PRICE", "527"),
      buildCompetitorColumns("Amz Mkt", "AMAZON_MARKET_PRICE", "1"),
      {
        title: headerFormatter("Sales"),
        dataIndex: "THD_R12_SALES",
        sorter: (a, b) => a.THD_R12_SALES - b.THD_R12_SALES,
        align: "right",
        render: (retail) => (
          <Text>{retail ? "$" + formatNumberToCompact(retail) : ""}</Text>
        ),
      },
    ]

  }

  const NoOffsideData = (props) => {
    return (
      <div className={props.customClass}>
        {!offsideProductData ? null : (
          <Fragment>
            <Row type="flex" justify="center" align="middle">
              <Col>{SvgUtil.getNoData()}</Col>
            </Row>
            <Row type="flex" justify="center" align="middle">
              <Col>
                <Text className="no-offside-found-text">
                  No Offsides Products Found{" "}
                </Text>
              </Col>
            </Row>
          </Fragment>
        )}
      </div>
    );
  };

  return (
    <Spin indicator={<UXSmallPulse />} spinning={!offsideProductData}>
      <Row>
        <Col span={24}>
        <OffsideProductHeader offsideProductsFilterDropdown={offsideProductsFilterDropdown()}/>

        {Object.keys(offsideProductData).length > 0 ? (
          <Row justify="space-between" align="middle">
            <Col span={24}>
              <AdvancedTable
                extraTableProps={{ rowKey: "SKU_NBR", scroll: {x: TableUtil.getDynamicScrollableColumnsAreaWidth(90, 2, replaceThisWithArrayLengthOfUserPreferenceCompetitorsToShow), y: 300 } }}
                tableClassName="offside-table"
                locale={{
                  emptyText: <NoOffsideData customClass="no-offside-found" />,
                }}
                columns={buildColumns(filterOffsideTableData())}
                dataSource={filterOffsideTableData()}
                pagination={false}
                key={props.selectedDCS + selectedOffsideFilterValue}
              />
            </Col>
          </Row>
        ) : (
          offsideProductData && <NoOffsideData customClass="offside-no-data" />
        )}

        </Col>
      </Row>
      {offsideComparisonData && (
          <CompetitorComparisonModal
              isOffside={true}
              offsideComparisonData={offsideComparisonData}
              onClose={() => setOffsideComparisonData("")}/>
        // <OffsideComparisonModal
        //   offsideComparisonData={offsideComparisonData}
        //   onClose={() => setOffsideComparisonData("")}
        //   competitorDataUrl={props.competitorDataUrl}
        // />
      )}
    </Spin>
  );
};

export default OffsideProductWidget;
