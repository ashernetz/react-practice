import React from 'react';
import {Row, Col, Typography} from 'antd';
import "./WidgetHeader.scss";
import SellingChannelSelection from "./DiscountsWidget/SellingChannelSelection/SellingChannelSelection";

const {Text} = Typography;

const WidgetHeader = (props) => {
    return (
        <Row justify={"space-between"} className="widget-header">
            <Col span={(props.label || props.sellingChannel) ? 12 : 24}><Text className="widget-header-title">{props.title}</Text></Col>
            {
                props.label &&
                <Col span={12} className="widget-header-label"><Text type="secondary">{props.label}</Text></Col>
            }
          {props.sellingChannel &&
            <Col span={12} className="selling-channel-col">
              <SellingChannelSelection
                sellingChannel={props.sellingChannel}
                onSellingChannelChange={props.onSellingChannelChange}
              />
            </Col>

          }
        </Row>
    );
};

export default WidgetHeader;