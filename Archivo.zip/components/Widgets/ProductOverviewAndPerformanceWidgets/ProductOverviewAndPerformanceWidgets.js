import React from 'react';
import {Row, Col} from 'antd';
import ProductOverviewWidget from '../ProductOverviewWidget/ProductOverviewWidget';
import MyPerformanceWidget from '../MyPerformanceWidget/MyPerformanceWidget';
import "./ProductOverviewAndPerformanceWidgets.scss"

export default function ProductOverviewAndPerformanceWidgets(props) {
  return (
    <Row className='product-overview-and-performance-widgets-row'>
      <Col span={24} className='product-overview-and-performance-widgets-col'>
        <Row>
          <Col span={24}>
            <MyPerformanceWidget {...props} />
          </Col>
        </Row>
        {/* <Row>
          <Col span={8}>
            <ProductOverviewWidget {...props} />
          </Col>
        </Row> */}
      </Col>
    </Row>
  );
}
