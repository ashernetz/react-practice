import React from 'react'
import "./SkuGroups.scss";
import { Row, Col, Space, Typography } from 'antd';
import { getAmount, getPercentageChanged, getArrow } from './SkuGroupsWidgetUtil';

const { Text } = Typography;

export default function PerformanceCell(props) {
    let percentageInfo = getPercentageChanged(props.percentage);
    return (
        <Row>
            <Space>
                {props.amount && !isNaN(props.amount) &&
                    <Col><Text>{getAmount(props.amount, props.isSales)}</Text></Col>}
                <Col>
                    <Space><Text className={percentageInfo.color}>{percentageInfo.text}</Text>{getArrow(props.percentage)}</Space>
                </Col>
            </Space>
        </Row>
    )
}
