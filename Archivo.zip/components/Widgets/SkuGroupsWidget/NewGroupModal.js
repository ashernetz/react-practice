import React, { Component } from "react";
import {
    Row,
    Col,
    Modal,
    Input,
    Typography,
    Space,
    message

} from "antd";
import "./NewGroupModal.scss";
import SkuGroupService from "../../../services/SkuGroupService";
import {trackEvent} from "../../Utils/mixpanel";
import {isGroupNameValid} from "../../Utils/SkuGroupUtil";

const { Text } = Typography;
const { TextArea } = Input;

export default class NewGroupModal extends Component {

    state = {
        groupName: "",
        groupDescription: "",
        skuNumbers: []
    };

    disableSaveButton = () => {
        if (this.state.groupName !== "" && this.state.groupDescription !== "" && this.state.skuNumbers.length > 0) {
            return false;
        }
        return true;
    }

    saveNewGroupChanges = async () => {
        this.props.onClose();
        trackEvent("SKU_GROUP_WIDGET_SAVE_GROUP", {
            "groupName": this.state.groupName,
            "groupDescription": this.state.groupDescription,
            "userId":this.props.userId
        })
        let group = {
            skuGroupName: this.state.groupName, skuGroupDesc:
                this.state.groupDescription, skus: this.state.skuNumbers, createdUserId: this.props.userId
        }
        try {
            const newSkuGroupIds = await SkuGroupService.insertSkuGroups(group);
            if(newSkuGroupIds?.data?.length>0){
                this.props.skuGroupSearch({...this.state,skuGroupId:newSkuGroupIds.data[0]});
                message.success({
                    content: 'Group has been successfully created.',
                    style: {
                        marginTop: '15vh',
                    },
                });
            }

        } catch(error) {
            const errorMsg = (error.response && error.response.status === 400) ? error.response.data : 'Error occurred while creating group.';
            message.error({
                content: errorMsg,
                style: {
                    marginTop: '15vh',
                },
            });
        }

    }

    handleSkuInput = (value) => {
        let numberCheck = /^[0-9,\n]*$/;
        if (numberCheck.test(value)) {
            let skuNumbers = value.split(/[ ,\n]+/).map(k => k.trim());
            this.setState({ skuNumbers });
        }
    }

    handleGroupNameInput = (groupName) => {
        if (!isGroupNameValid(groupName)) {
            this.setState({ groupName });
        }
    };

    handleDescriptionInput = (groupDescription) => {
        if (!isGroupNameValid(groupDescription)) {
            this.setState({ groupDescription });
        }
    };

    filterSkuNumbers = () =>{
        this.setState({skuNumbers: this.state.skuNumbers.filter(sku => sku)});
    }

    render() {
        return (
            <Modal
                open={this.props.isOpen}
                className="newGroup-modal"
                onCancel={this.props.onClose}
                title="Save as Group"
                okButtonProps={{ disabled: this.disableSaveButton() }}
                okText="Save"
                cancelText="Cancel"
                onOk={this.saveNewGroupChanges}
            >
                <Row gutter={[0, 8]} className="input-label">
                    <Col span={24}>
                        <Space direction="horizontal" size={2}><Text className="mandatory-input">*</Text><Text>Group Name</Text></Space>
                    </Col>
                </Row>
                <Row gutter={[0, 16]} className="input-field">
                    <Col span={24}>
                        <Input size="large" style={{ fontSize: '14px' }} placeholder="Give your Group a name" value={this.state.groupName}
                               onChange={(e) => e.target.value ? this.handleGroupNameInput(e.target.value) : this.setState({ groupName: "" })}
                        />
                    </Col>
                </Row>
                <Row gutter={[0, 8]} className="input-label">
                    <Col span={24}>
                        <Space direction="horizontal" size={2}><Text className="mandatory-input">*</Text><Text>Group Description</Text></Space>
                    </Col>
                </Row>
                <Row gutter={[0, 16]} className="input-field">
                    <Col span={24}>
                        <TextArea style={{ height: '60px', resize: "none" }} placeholder="Give your Group a description" value={this.state.groupDescription}
                                  onChange={(e) => e.target.value ? this.handleDescriptionInput(e.target.value) : this.setState({ groupDescription: "" })}
                        />
                    </Col>
                </Row>
                <Row gutter={[0, 8]} className="input-label">
                    <Col span={24}>
                        <Space direction="horizontal" size={2}><Text className="mandatory-input">*</Text><Text>SKUs</Text></Space>
                    </Col>
                </Row>
                <Row className="input-field">
                    <Col span={24}>
                        <TextArea className="skus-textarea"
                            style={{ resize: "none" }}
                            placeholder="Paste the SKUs you want to be part of your Group"
                            value={this.state.skuNumbers}
                            onBlur={this.filterSkuNumbers}
                            onChange={(e) => e.target.value ? this.handleSkuInput(e.target.value) : this.setState({ skuNumbers: [] })}
                        />
                    </Col>
                </Row>

            </Modal>
        );
    }

}

