import React,{ Fragment } from 'react';
import {formatNumberToCompact} from '../../Utils/CommonUtil';
import "./SkuGroups.scss";
import {ArrowUpOutlined, ArrowDownOutlined} from '@ant-design/icons';
import {UXSpin} from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";

export function getAmount(amount, isSales) {
    return isSales ? `$${formatNumberToCompact(amount)}` : formatNumberToCompact(amount);
}

export function getPercentageChanged(percentage) {
    return {
        text: percentage && !isNaN(percentage) ? `${percentage.toFixed(2)}%` : percentage === null ?  "N/A": <Fragment><UXSpin/></Fragment>,
        color: percentage ? percentage > 0 ? "green" : "red" : ""
    }
}

export function getArrow(percentage) {
    return percentage ? percentage > 0 ? <ArrowUpOutlined className="green"/> :
        <ArrowDownOutlined className="red"/> : null
}


