import { getAmount, getPercentageChanged, getArrow } from './SkuGroupsWidgetUtil';
import React, {Fragment} from 'react';
import { ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';
import {UXSpin} from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';

describe('SkuGroupsWidgetUtil', () => {
    describe('getAmount()', () => {
        it('returns the correctly formatted sales amount vs units amount', () => {
            expect(getAmount(400, true)).toEqual("$400.00")
            // expect(getAmount(400)).toEqual("400.00")
            // expect(getAmount(400.50, true)).toEqual("$400.50")
            // expect(getAmount(400.55)).toEqual("400.55")
        })
    });
    describe('getPercentageChanged()', () => {
        it('returns correctly formatted increases', () => {
            let actual = getPercentageChanged(15.50)
            expect(actual.text).toEqual("15.50%")
        });

        it('returns correctly formatted increases color', () => {
            let actual = getPercentageChanged(15.50)
            expect(actual.color).toEqual("green")

        });

        it('returns correctly formatted decreases', () => {
            let actual = getPercentageChanged(-15.50)
            expect(actual.text).toEqual("-15.50%")
        });

        it('returns correctly formatted decreases color', () => {
            let actual = getPercentageChanged(-15.50)
            expect(actual.color).toEqual("red")
        });

        it('returns correctly formatted no changes', () => {
            let actual = getPercentageChanged(0)
            expect(actual.text).toEqual(<Fragment><UXSpin/></Fragment>)
        });
    });
    describe('getArrow()-positive', () => {
        it('returns the correctly formatted up arrow for positive changes', () => {
            expect(getArrow(100)).toEqual(<ArrowUpOutlined className="green" />)
        })
    });

    describe('getArrow()-negative', () => {
        it('returns the correctly formatted down arrow for negative changes', () => {
            expect(getArrow(-100)).toEqual(<ArrowDownOutlined className="red" />)
        })
    });

    describe('getArrow()-null', () => {
        it('returns nothing for no changes', () => {
            expect(getArrow(0)).toBe(null)
        })
    });
})
