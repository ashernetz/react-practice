import React, { useState } from 'react'
import { Row, Col, Table, Typography, Empty, Tooltip, Input, Button } from 'antd';
import PerformanceCell from './PerformanceCell';
import './SkuGroups.scss';
import Highlighter from 'react-highlight-words';
import { SearchOutlined } from '@ant-design/icons';
import { trackEvent } from '../../Utils/mixpanel';

const { Link, Text } = Typography;

export default function SkuGroupsTable(props) {
    let searchInput;

    const [groupSearchText, setGroupSearchText] = useState('');

    const getColumnSearchProps = (dataIndex, placeholder = dataIndex) => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div style={{ padding: 8 }}>
                <Input
                    ref={node => {
                        searchInput = node;
                    }}
                    placeholder={`Search Groups`}
                    value={selectedKeys[0]}
                    onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => handleSearch(selectedKeys, confirm)}
                    style={{ width: 188, marginBottom: 15, display: 'block' }}

                />
                <Button
                    type="primary"
                    onClick={() => handleSearch(selectedKeys, confirm)}
                    icon={<SearchOutlined />}
                    size="small"
                    style={{ width: 90, marginRight: 8 }}
                >
                    Search
              </Button>
                <Button onClick={() => handleReset(clearFilters)} size="small" style={{ width: 90 }}>
                    Reset
              </Button>
            </div>
        ),
        filterIcon: filtered => (
            <SearchOutlined style={{ color: filtered ? 'rgba (250,99,4,0.5)' : undefined }} />
        ),
        onFilter: (value, record) => {
            let rowValue = Array.isArray(dataIndex) ? dataIndex.reduce((total, current) => { return total[current] }, record) : record[dataIndex];
            return rowValue.toString()
                .toLowerCase()
                .includes(value.toLowerCase())
        },
        onFilterDropdownVisibleChange: visible => {
            if (visible) {
                setTimeout(() => searchInput.select());
            }
        },
        render: text => (
            <Highlighter
                highlightStyle={{ backgroundColor: '#fdb689', padding: 0 }}
                searchWords={[groupSearchText]}
                autoEscape
                textToHighlight={text.toString()}
            />
        ),
    });

    const handleSearch = (selectedKeys, confirm) => {
        confirm();
        setGroupSearchText({ searchText: selectedKeys[0] });
    };

    const handleReset = clearFilters => {
        clearFilters();
        setGroupSearchText({ searchText: '' });
    };

    const handleSkuGroupSearch = (skuNumbers, row) => {
        trackEvent("SKU_GROUP_SEARCH", { 'SKUS': skuNumbers, 'GROUP': row.skuGroupName });
        props.skuGroupSearch(skuNumbers, {isPLS:row["sku_GROUP_TYPE"]==="PLS",groupName:row.skuGroupName,zoneGroupMultiplierId:row["zone_GROUP_ID"], skuGroupId: row.skuGroupId })
    }

    const columns = [
        {
            title: "Group Name",
            dataIndex: "skuGroupName",
            ...getColumnSearchProps('skuGroupName'),
            sorter: (a, b) => { return a.skuGroupName.localeCompare(b.skuGroupName) },
            render: (name, row) => name ?
                <Tooltip title={row.skuGroupDescription} placement="leftTop">
                    <Link onClick={() => handleSkuGroupSearch(row.skuNumbers, row)}>{name}</Link>
                </Tooltip>
                :
                ""
        },
        {
            title: "SKUs",
            dataIndex: "skuNumbers",
            render: (skus, row) => skus ?
                <Text>{skus.length}</Text>
                :
                ""
        },
        {
            title: "Sales",
            dataIndex: "totalThisYearSales",
            sorter: (a, b) => (a.totalThisYearSales && !isNaN(a.totalThisYearSales) ? a.totalThisYearSales : 0) - (b.totalThisYearSales && !isNaN(b.totalThisYearSales) ? b.totalThisYearSales : 0),
            render: (comps, row) =>
                <PerformanceCell isSales amount={comps} percentage={row.totalCompPercentage} />

        },
        {
            title: "Units",
            dataIndex: "totalThisYearUnits",
            sorter: (a, b) => (a.totalThisYearUnits && !isNaN(a.totalThisYearUnits) ? a.totalThisYearUnits : 0) - (b.totalThisYearUnits && !isNaN(b.totalThisYearUnits) ? b.totalThisYearUnits : 0),
            render: (units, row) =>
                <PerformanceCell amount={units} percentage={row.totalUnitsPercentage} />

        }
    ]

    let isDataAvailable = props.skuGroupsData && props.skuGroupsData.length > 0;
    return (
        <Row className={!isDataAvailable && "no-data-widget-table"}>
            <Col span={24}>
                {
                    isDataAvailable ?
                        <Table
                            className="sku-groups-table"
                            columns={columns}
                            dataSource={props.skuGroupsData}
                            pagination={{ pageSize: 5, showSizeChanger: false, hideOnSinglePage: true }}
                            rowKey={"skuGroupId"}
                        />
                        :
                        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                }

            </Col>
        </Row>
    )
}
