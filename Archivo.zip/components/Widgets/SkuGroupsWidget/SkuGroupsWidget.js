import React, { useState } from 'react'
import { Card, Spin } from 'antd';
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import SkuGroupsHeader from './SkuGroupsHeader';
import SkuGroupsTable from './SkuGroupsTable';

export default function SkuGroupsWidget(props) {
    const [setGroupsFilter] = useState("All Groups");
    const [setDcsFilter] = useState("Selected DCS");

    function skuGroupSearch(skuList,input) {
        props.multiItemInquiry(skuList, [], null, null,input);
    }

    return (
        <Spin indicator={<UXSmallPulse />} spinning={props.loadingSkuGroupData}>
            <Card bordered={false} bodyStyle={{ padding: 0 }}>
                <SkuGroupsHeader
                    setGroupsFilter={setGroupsFilter}
                    setDcsFilter={setDcsFilter}
                    userId={props.userId}
                    newGroupButtonEnabled={props.newGroupButtonEnabled}
                    skuGroupSearch={skuGroupSearch}
                />
                <SkuGroupsTable
                    skuGroupsData={Object.values(props.skuGroupsData)}
                    skuGroupSearch={skuGroupSearch}
                />
            </Card>
        </Spin>
    )
}
