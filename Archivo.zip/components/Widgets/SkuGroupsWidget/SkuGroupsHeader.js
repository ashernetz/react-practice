import React, { useState, Fragment } from 'react'
import { Row, Col, Button } from 'antd';
import WidgetHeader from "../WidgetHeader";
import "./SkuGroups.scss";
import { trackEvent } from '../../Utils/mixpanel';
import NewGroupModal from "../SkuGroupsWidget/NewGroupModal"


export default function SkuGroupsHeader(props) {

    const [isNewGroupModalOpen, setNewGroupModalOpen] = useState();


    function handleNewGroupButonClick() {
        trackEvent("SKU_GROUP_WIDGET_NEW_GROUP_BUTTON_CLICK")
        setNewGroupModalOpen(true);
    }


    return (
        <Fragment>
            <Row>
                <Col span={24}>
                    <Row>
                        <Col span={24}>
                            <WidgetHeader title="Groups Overview" label={<Button type={"primary"} disabled={!props.newGroupButtonEnabled} onClick={handleNewGroupButonClick}>New Group</Button>} />
                        </Col>
                    </Row>
                </Col>
            </Row>
            {isNewGroupModalOpen && <NewGroupModal
                isOpen={true}
                onClose={() => setNewGroupModalOpen(false)}
                userId={props.userId.toUpperCase()}
                skuGroupSearch={props.skuGroupSearch}
            />
            }
        </Fragment>
    )
}
