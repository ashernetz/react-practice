import React, { useEffect, useState } from "react";
import {
  Card,
  Row,
  Col,
  Select,
  Spin
} from 'antd';
import WidgetHeader from '../WidgetHeader';
import ZoneHealthChart from '../SharedComponents/ZoneHealthChart';
import "./HealthWidget.scss";
import UXSmallPulse
  from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import DataConnectionIssue from '../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue';

const {Option} = Select;
const HealthWidget = (props) => {
  const [selectedZoneValue, setSelectedZoneValue] = useState("0");

  function populateZones() {
    let zonesMap = {};
    if (Object.keys(props.healthOverviewData).length>0) {
      zonesMap[0]= {"zoneId": "0", "zoneName": "All Zones"};
      if (props.healthOverviewData.zonePerformanceDTOList) {
        props.healthOverviewData.zonePerformanceDTOList.forEach(data => {
          zonesMap[data.zoneId]= {"zoneId":data.zoneId,"zoneName":data.zoneName}
        });
      }
    }

    const getZoneDropdownMenu = () => {
      return Object.values(zonesMap).map(
          (k) => <Option value={k.zoneId} key={k.zoneId}>{k.zoneName}</Option>);
    };

    if (Object.keys(props.healthOverviewData).length>0){
    return (
        <Select
            showSearch
            size="small"
            // style={{ width: 200 }}
            optionFilterProp="children"
            onChange={setSelectedZoneValue}
            onSearch={()=>{}}
            bordered={false}
            value={selectedZoneValue}
            filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
        >
          {getZoneDropdownMenu()}
        </Select>
    )}else{
      return (
        <Select size="small" 
        // style={{ width: 200 }} 
        value="No Zones" disabled bordered={false}/>
    )

    }
    
  }

  useEffect(() => {
    if (Object.keys(props.hierarchyDetails).length > 0) {
      setSelectedZoneValue("0");
    }
  }, [props.hierarchyDetails]);


  return (
    <Spin indicator={<UXSmallPulse/>} spinning={!props.healthOverviewData}>
      <Card bodyStyle={{ padding: 0 }} bordered={false}>
        <Row>
          <Col span={24}>
            <WidgetHeader title="Health" label={props.is5xx ?"":populateZones()} />
          </Col>
        </Row>
        {props.is5xx ? <DataConnectionIssue/>:
        <ZoneHealthChart
            fiscalWeek = {props.fiscalWeek}
            healthOverviewData={props.healthOverviewData}
            selectedZoneValue={selectedZoneValue}
        />}
      </Card>
    </Spin>
  );
};





export default HealthWidget;