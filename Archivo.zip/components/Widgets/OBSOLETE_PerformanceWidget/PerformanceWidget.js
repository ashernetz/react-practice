import {Card, Col, Row, Typography, Radio, Empty, Spin, Select} from "antd";
import WidgetHeader from "../WidgetHeader";
import React, {useState, Fragment,useEffect} from "react";
import { Chart, Tooltip, Axis, Legend, Line } from 'viser-react';
import {trackEvent} from '../../Utils/mixpanel';
import "./PerformanceWidget.scss";
import UXSmallPulse
  from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import {formatNumberToCompact} from "../../Utils/CommonUtil";
import DataConnectionIssue from '../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue';
const {Text} = Typography;
const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const {Option} = Select;

const PerformanceWidget = (props) => {

  const [selectedType, setSelectedType] = useState("rawSalesAmount");
  const [selectedZoneValue, setSelectedZoneValue] = useState("0");

  useEffect(() => {
    if (Object.keys(props.hierarchyDetails).length > 0) {
      setSelectedZoneValue("0");
    }
  }, [props.hierarchyDetails]);

  function populatePerformanceZones() {
    let zonesMap = {};
    if (props.performanceData) {
      zonesMap[0]= {"zoneId": "0", "zoneName": "All Zones"};
      
    if (props.performanceData.zonePerformanceDetails) {
        props.performanceData.zonePerformanceDetails.forEach(zoneData => {
            if(!Object.keys(zonesMap).includes(zoneData.zoneId)){
              zonesMap[zoneData.zoneId]= {"zoneId":zoneData.zoneId,"zoneName":zoneData.zoneName}
            }
    });
  }
 }

    const getPerformanceZoneDropdownMenu = () => {
      return Object.values(zonesMap).map(
          (k) => <Option value={k.zoneId} key={k.zoneId}>{k.zoneName}</Option>);
    };

    if (Object.keys(props.performanceData).length>0){ 
    return (
        <Select
            showSearch
            size="small"
            style={{ width: 200 }}
            optionFilterProp="children"
            onChange={setSelectedZoneValue}
            onSearch={()=>{}}
            bordered={false}
            value={selectedZoneValue}
            filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
        >
          {getPerformanceZoneDropdownMenu()}
        </Select>
    )}else{
      return (
        <Select size="small" style={{ width: 200 }} value="No Zones" disabled bordered={false}/>
    )

    }    
  }

  function populatePerformanceGraphData (){

    let graphData =selectedZoneValue === "0"?props.performanceData:props.performanceData.zonePerformanceDetails.find(data => data.zoneId ===selectedZoneValue);
    let {currentYearPerformance=[],lastYearPerformance=[]}= graphData?graphData:{};
    return [...(currentYearPerformance||[]),...(lastYearPerformance||[])].sort((a, b) => getFwNum(a.fiscalWeek).localeCompare(getFwNum(b.fiscalWeek), undefined, {numeric: true}));
  }

  function changeChartType (value){
    trackEvent("CHANGED_PERFORMANCE_WIDGET_CHART_TYPE", {"chart_type": value});
    setSelectedType(value);
  }

  function getFwNum(fwString) {
    return fwString.split("FW")[1]
  }
  const toolTipRender = (title, items) => {

    let toolTip =  '<div class="performance-tooltip"><div class="g2-tooltip-title" style="margin-bottom: 4px;">' + title + '</div>';
    items.forEach(item=>{
      let formattedValue = (selectedType==="rawSalesAmount"? "$":"")+ formatNumberToCompact(item.value);
      toolTip = toolTip+ '<li data-index={index}><span style="background-color:'+item.color+';width:4px;height:4px;border-radius:50%;display:inline-block;margin-right:8px;"></span>'+item.name+' : '+formattedValue+'</li>'});
    toolTip = toolTip+ '</div>';
    return toolTip;
  };

  
  return (
      <Spin indicator = {<UXSmallPulse/>} spinning={!props.performanceData}>
     
        <Card  bordered={false} bodyStyle={{padding: 0}}>
        
          <Row>
            <Col span={24}>
              <WidgetHeader title="Performance" label={props.is5xx ?"":populatePerformanceZones()}/>
            </Col>
          </Row>
          {props.is5xx ?  <DataConnectionIssue/> :
        <Fragment>
          {Object.keys(props.performanceData).length>0?
              <Row type="flex" justify="space-between" align="middle" className="performance-sales-unit">
                <Col span={12}><Text >{`Trending ${selectedType==="rawSalesAmount"?"Sales":"Units"}`}</Text ></Col>
                <Col span={12} className="performanceToggle">
                  <RadioGroup onChange={(e)=>changeChartType(e.target.value)} value={selectedType} buttonStyle="solid">
                    <RadioButton  value="rawSalesAmount">Sales</RadioButton>
                    <RadioButton value="rawUnitsSold">Units</RadioButton>
                  </RadioGroup>
                </Col>
              </Row>:null}
          {Object.keys(props.performanceData).length>0?
              <Row>
                <Col span={24}>
                  <Chart forceFit data={populatePerformanceGraphData()} height={396}>
                    <Tooltip crosshairs="y" htmlContent={toolTipRender}/>
                    <Axis dataKey="fiscalWeek"/>
                    <Axis dataKey= {selectedType} label={{formatter: val => (selectedType==="rawSalesAmount"? "$":"")+ formatNumberToCompact(val) }}/>
                    <Legend clickable={false} hoverable={false}/>
                    <Line
                        position={`fiscalWeek*${selectedType}`}
                        color={['fiscalYear', ['#FFBF94','#fa6302']]}
                        shape={['fiscalYear', ['dash','line']]}
                    />
                  </Chart>
                </Col>
              </Row>
              :
              props.performanceData && <Row className="performance-no-data"><Col span={24}><Empty image={Empty.PRESENTED_IMAGE_SIMPLE}/></Col></Row>
          }</Fragment>}
          </Card>
      </Spin>
  )
};

export default PerformanceWidget;