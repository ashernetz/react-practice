import React from 'react'
import '@testing-library/jest-dom'
import {render, screen} from "@testing-library/react";
import WidgetHeader from "./WidgetHeader";

describe('WidgetHeader', () => {

  it('render WidgetHeader without selling channel dropdown', () => {
    render(<WidgetHeader title="Discounts"/>)
    expect(screen.queryByText("Discounts")).toBeInTheDocument();
    expect(screen.queryByText("Core and Online")).not.toBeInTheDocument();
  })

  // it('render WidgetHeader with selling channel dropdown', () => {
  //   render(<WidgetHeader title="Discounts" sellingChannel="ALL"/>)
  //   expect(screen.queryByText("Discounts")).toBeInTheDocument();
  //   expect(screen.queryByText("Core and Online")).toBeInTheDocument();
  // })

})
