import React, {useRef} from 'react'
import { Line } from '@ant-design/charts';

// import ColorConstants from '../../../constants/ColorConstants';

export default function AntVChart(props) {

    let data = props.data && Array.isArray(props.data) ? props.data : [];
    const ref = useRef(null);

    // function defaultLineColorFormatter() {
    //     return ColorConstants.thdPrimaryColor;
    // }

    function getStepType() {
        // hv | vh | hvh | vhv
        switch(props.chartType) {
            case "ladder":
                return "hv";
            default:
                return props.chartType;
        }
    }

    let config = {
        data,
        xField: props.xField,
        yField: props.yField,
        legend: { position: 'bottom' },
        seriesField: props.dataKey,
        stepType: getStepType(),
        height: 300,
        loading: props.loadingData,
        yAxis: {
            label: {
                formatter: (val) => {return `$${parseFloat(val).toFixed(2)}`}
            }
        },
        tooltip: {
            shared: true,
            formatter: (datum) => {
                let val = datum[props.yField]
                if (val) {
                    val = `$${parseFloat(val).toFixed(2)}`
                } else {
                    val = "No Data"
                }
                return {name: datum[props.dataKey], value: val}
            }
        },
        color: (obj) => {return props.formatLineColor(obj[props.dataKey])},
        connectNull: props.connectNull ? props.connectNull : true,
        padding: 'auto'
    };

    if (props.customTooltip) {
        config.tooltip = {
            customContent: (title, data) => {
                return <props.customTooltip title={title} data={data}/>
            }
        }
    }

    return (
        <Line {...config} chartRef={ref} />
    )
}
