import {useContext, useEffect} from "react";
import axios from "axios";

import SkuContext from "../../../context/SkuContext";
const UNAUTHORIZED = 401;
const myInterceptor = {"id":undefined};

const AxiosInterceptor = ({accessToken , logout}) => {
  const skuContext = useContext(SkuContext);
  useEffect(() =>{
    axios.interceptors.response.use(req => req,error =>{
      if(error.response.status === UNAUTHORIZED || error.response.message =="Pingfed unauthorized error"){
          console.error("Unauthorized! Logging Out ");
       logout();
      }else {
          return Promise.reject(error);
      }
    });
    },[])

  useEffect(()=>{  
    if(myInterceptor.id !== undefined){
      axios.interceptors.request.eject(myInterceptor.id);
    }
    myInterceptor.id = axios.interceptors.request.use(req => {
    
      if(req.url.includes("/api/dataConnect")||req.url.includes("/api/security/readPerformersForDCS")||
              req.url.includes("/api/sku-groups/dcsPerformance")|| req.url.includes("/api/sku-groups/closerLookDCSPerformance"))
              {
              let timeTransformValues = skuContext.timeTransformType.split("|");
              let locationFilter = skuContext.locationDetails;
              req.headers["time-transform-type"] = timeTransformValues[1];
              req.headers["comps_year"] = timeTransformValues[0];
              if(locationFilter.locationType && locationFilter.locationValues){
                  req.headers["location_type"] = locationFilter.locationType;
                  req.headers["location_values"] = locationFilter.locationValues;
              }
              }
          // else if (req.url.includes("/api/security/onlinePreviewChanges") ||
          //     req.url.includes("/api/security/previewChanges") ||
          //     req.url.includes("/api/security/tempRetailExecutionChanges") ||
          //     req.url.includes("/api/multi-sku/recommendations") ||
          //     req.url.includes("/api/multi-sku/rcw-generation") ||
          //     req.url.includes("/api/multi-sku/sku-inquiry/download") ||
          //     req.url.includes("/api/recommendation/zone-group-recommendations") ||
          //     req.url.includes("/api/price-ending-rules/custom-rules/sku"))
          // {
          //    // req.headers["access-token"] = accessToken;
          // }
          return req;
        },error=>{
          console.log("Error while adding token in axios " , error);
          return Promise.reject(error);
        }  
    );
  },[skuContext.timeTransformType,skuContext.locationDetails,accessToken]);
  return null;
};

export default AxiosInterceptor;