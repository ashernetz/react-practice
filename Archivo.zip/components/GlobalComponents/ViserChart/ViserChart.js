import React from 'react'
import { Chart, Tooltip, Axis, Line, Legend } from 'viser-react';

export default function ViserChart(props) {

    let data = props.data && Array.isArray(props.data) ? props.data : [];

    const label = {
        
        // textStyle: {
        //   fill: '#aaaaaa'
        // }
    }

    function getShape() {
        // hv | vh | hvh | vhv
        switch(props.chartType) {
            case "ladder":
                return "hv";
            default:
                return props.chartType;
        }
    }
    
    return (
        <Chart 
            forceFit 
            data={data} 
            height={300} 
            scale={[{
                dataKey: props.xField,
                nice: true,
                mask: "MM/DD/YY",
                type: 'timeCat'
            }]}
        >
            <Tooltip 
                crosshairs='y' 
                shared={true} 
                itemTpl= {`
                    <li data-index={index} style="margin-bottom:4px;">
                    <span style="background-color:{color};" class="g2-tooltip-marker"></span>
                    {name} <span>$</span>{value}
                    </li>
                `}
            />
            <Axis 
                dataKey={props.xField} 
                label={label}
            />
            <Axis 
                dataKey={props.yField} 
                label={{formatter: (val) => {return `$${parseFloat(val).toFixed(2)}`}}}
                autoRotate={true}
            />
            <Legend 
                position={"bottom-center"}
            />
            <Line 
                position={`${props.xField}*${props.yField}`} 
                shape={getShape()} 
                color={[props.dataKey, (dataKey) => {
                    return props.formatLineColor(dataKey)
                }]}
            />
        </Chart>
    )
}
