import React, {useEffect, useState,Fragment} from 'react';
import { Row, Col, Typography, Select, Spin } from "antd";
import Moment from 'moment';
import { extendMoment } from 'moment-range';
import SvgUtil from '../../Utils/SvgUtil';
import { formatThdData } from './PriceHistoryChartUtil';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import UXSmallPulse from '../GlobalReactComponents/UXComponents/UXSmallPulse';


const moment = extendMoment(Moment);
const {Text,Paragraph} = Typography;

const NoDataPriceHistory = () =>
    <Fragment>
        <Row justify="center" align="middle" type="flex">
            <Col className="noKVI">
                {SvgUtil.getNoData()}
            </Col>
        </Row>
        <Row justify="center" align="middle">
            <Col className="noKVI">
                <Text className="no-kvi">
                    No Price History Data Available
                </Text>
            </Col>
        </Row>
        <Paragraph/>
    </Fragment>

export default function THDPriceHistory(props){

    const [selectedNumberOfMonths, setSelectedNumberOfMonths] = useState(90);
    const [formDate, setFormDate] = useState([]);
    const [operatedData, setOperatedData] = useState([]);

    useEffect(() => {
        if (props.priceChangeHistory.length > 0) {

            const today = new Date();
            let startDate = '';
            if (selectedNumberOfMonths != null) {
                startDate = new Date(today);
                startDate.setDate(today.getDate() - selectedNumberOfMonths);
            } else {
                startDate = new Date(props.priceChangeHistory[0].changeDate)
            }

            const intervalDays = Math.ceil((today - startDate) / (1000 * 60 * 60 * 24)) / 5;
            let newDates = [moment(startDate, "MM/DD/YY").valueOf()];
            for (let i = 1; i < 6; i++) {
                const newDate = new Date(startDate);
                newDate.setDate(newDate.getDate() + (i * intervalDays));
                newDates.push(moment(newDate, "MM/DD/YY").valueOf());
            }
            setFormDate(newDates)
            setOperatedData(formatThdData(props.priceChangeHistory, startDate).map(k => ({
                ...k,
                changeDateInMillis: moment(k.changeDate, "MM/DD/YY").valueOf()
            })));

        }
    }, [selectedNumberOfMonths, props.priceChangeHistory]);


    return(
        <>
            <Row justify="space-between"  style={{paddingBottom: '10px'}}>
                <Col>
                    <Text className="modalHeading">THD Price History</Text>
                </Col>
                <Col>
                    <Select
                        defaultValue="3 Months"
                        style={{width: 120}}
                        onChange={(value) => setSelectedNumberOfMonths(value)}
                        options={[
                            {label: '3 Months', value: 90},
                            {label: '6 Months', value: 120},
                            {label: '12 Months', value: 360},
                            {label: 'All History', value: null},
                        ]}/>
                </Col>
            </Row>
            <Row>
                <Col span={24}>
                    {operatedData.length === 0 && !props.isLoading ? <NoDataPriceHistory/> :
                        <Spin indicator={<UXSmallPulse />} spinning={props.isLoading}>
                            <LineChart
                                className="priceHistoryGraph"
                                width={700}
                                height={300}
                                data={operatedData}
                                margin={{top: 20, right: 30, left: 10, bottom: 10}}
                                value={() => {}}
                            >
                                <CartesianGrid strokeDasharray="3 3"/>
                                <XAxis dataKey="changeDateInMillis"
                                       type="number"
                                       domain={['dataMin', 'dataMax']}
                                       tickFormatter={(k) => moment(k).format("MM/DD/YY")}
                                       ticks={formDate}/>
                                <YAxis dataKey="retail" tickFormatter={(k) => '$' + k}/>
                                <Tooltip
                                    formatter={(value, name, props) => {
                                        if (name === 'retail') {
                                            return '$' + value;
                                        } else {
                                            return value;
                                        }
                                    }}
                                    labelFormatter={(value)=>{return moment(value).format("MM/DD/YY");}}
                                />
                                <Legend/>
                                <Line
                                    type="stepAfter"
                                    dataKey="retail"
                                    dot={false}
                                    stroke={props.pricePointColor}
                                />
                            </LineChart>
                        </Spin>}
                </Col>
            </Row>
        </>
    );
}
