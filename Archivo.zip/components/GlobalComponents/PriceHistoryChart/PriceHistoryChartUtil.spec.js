import {
    formatThdData,
    formatCompData,
    combinePriceHistories,
    getDataForAllPriceChangeDates
} from './PriceHistoryChartUtil';
import {getUniqueList} from "../../Utils/CommonUtil";
import moment from 'moment';

describe("PriceHistoryChartUtil", () => {
    let selectedStartingDate = "08/01/20";
    let expectedEndDate;

    beforeAll(() => {
        expectedEndDate = moment(new Date().toISOString()).format("MM/DD/YY")
    })

    describe("formatThdData()", () => {
        describe("with THD price change available on selected start date", () => {
            it("has a price change object as the starting date object for THD", () => {
                const fakeThdData = [
                    {
                        companyId: "THD",
                        changeDate: "08/01/20",
                        retail: 5.43
                    },
                    {
                        companyId: "THD",
                        changeDate: "08/05/20",
                        retail: 5.54
                    },
                    {
                        companyId: "THD",
                        changeDate: "10/08/20",
                        retail: 5.32
                    }
                ]
                let expected = [{"changeDate": "08/01/20", "companyId": "THD", "retail": 5.43}, {"changeDate": "08/05/20", "companyId": "THD", "retail": 5.54}, {"changeDate": "10/08/20", "companyId": "THD", "retail": 5.32}, {"changeDate": expectedEndDate, "companyId": "THD", "retail": 5.32}]
                let actual = formatThdData(fakeThdData, selectedStartingDate)
                expect(actual).toEqual(expected);
                expect(actual[actual.length - 1].retail).toEqual(actual[actual.length - 2].retail);
                expect(actual[0].retail).toEqual(fakeThdData[0].retail);
                expect(actual[0].changeDate).toEqual(selectedStartingDate);
            })
        })
        describe("with THD price change available prior to selected start date", () => {
            it("has a starting date object for THD at the retail prior to the selected starting date", () => {
                const fakeThdData = [
                    {
                        companyId: "THD",
                        changeDate: "07/01/20",
                        retail: 5.43
                    },
                    {
                        companyId: "THD",
                        changeDate: "08/05/20",
                        retail: 5.54
                    },
                    {
                        companyId: "THD",
                        changeDate: "10/08/20",
                        retail: 5.32
                    }
                ]
                let expected = [{"changeDate": "08/01/20", "companyId": "THD", "retail": 5.43}, {"changeDate": "08/05/20", "companyId": "THD", "retail": 5.54}, {"changeDate": "10/08/20", "companyId": "THD", "retail": 5.32}, {"changeDate": expectedEndDate, "companyId": "THD", "retail": 5.32}];
                let actual = formatThdData(fakeThdData, selectedStartingDate)
                expect(actual).toEqual(expected);
                expect(actual[actual.length - 1].retail).toEqual(actual[actual.length - 2].retail);
                expect(actual[0].retail).toEqual(fakeThdData[0].retail);
                expect(actual[0].changeDate).toEqual(selectedStartingDate);
            })
        })
        describe("with THD price change only available later than selected start date", () => {
            it("has a null starting date retail @ the selected starting date", () => {
                const fakeThdData = [
                    {
                        companyId: "THD",
                        changeDate: "08/04/20",
                        retail: 5.43
                    },
                    {
                        companyId: "THD",
                        changeDate: "09/05/20",
                        retail: 5.54
                    },
                    {
                        companyId: "THD",
                        changeDate: "10/08/20",
                        retail: 5.32
                    }
                ]
                let expected = [{"changeDate": selectedStartingDate, "companyId": "THD", "retail": null}, {"changeDate": "08/04/20", "companyId": "THD", "retail": 5.43}, {"changeDate": "09/05/20", "companyId": "THD", "retail": 5.54}, {"changeDate": "10/08/20", "companyId": "THD", "retail": 5.32}, {"changeDate": expectedEndDate, "companyId": "THD", "retail": 5.32}];
                let actual = formatThdData(fakeThdData, selectedStartingDate);
                expect(actual).toEqual(expected);
                expect(actual[actual.length - 1].retail).toEqual(actual[actual.length - 2].retail);
                expect(actual[actual.length - 1].changeDate).toEqual(expectedEndDate);
                expect(actual[0].retail).toBe(null);
                expect(actual[0].changeDate).toEqual(selectedStartingDate);
            })
        })
        describe("with no selected starting date", () => {
            it("displays entire THD price change history, plus a price change for today at the prior retail val", () => {
                const fakeThdData = [
                    {
                        companyId: "THD",
                        changeDate: "08/04/18",
                        retail: 5.43
                    },
                    {
                        companyId: "THD",
                        changeDate: "09/05/19",
                        retail: 5.54
                    },
                    {
                        companyId: "THD",
                        changeDate: "10/08/19",
                        retail: 5.32
                    },
                    {
                        companyId: "THD",
                        changeDate: "04/27/20",
                        retail: 5.32
                    },
                    {
                        companyId: "THD",
                        changeDate: "07/08/20",
                        retail: 5.32
                    },
                    {
                        companyId: "THD",
                        changeDate: expectedEndDate,
                        retail: 5.32
                    }
                ]
                let actual = formatThdData(fakeThdData, null);
                let expected = [{"changeDate": "08/04/18", "companyId": "THD", "retail": 5.43}, {"changeDate": "09/05/19", "companyId": "THD", "retail": 5.54}, {"changeDate": "10/08/19", "companyId": "THD", "retail": 5.32}, {"changeDate": "04/27/20", "companyId": "THD", "retail": 5.32}, {"changeDate": "07/08/20", "companyId": "THD", "retail": 5.32}, {"changeDate": expectedEndDate, "companyId": "THD", "retail": 5.32}]
                expect(actual).toEqual(expected);
                expect(actual[actual.length - 1].retail).toEqual(fakeThdData[fakeThdData.length - 1].retail);
                expect(actual[actual.length - 1].changeDate).toEqual(expectedEndDate);
            })
        })
    })
    describe("formatCompData()", () => {
        describe("with competitor price change available on selected start date", () => {
            let priorYearStartDate = moment(selectedStartingDate).subtract(1, 'year').format("MM/DD/YY");
            const fakeCompData = [{"historyDate":"2020-11-22","priceHistory":[{"competitorId":18214,"scaledPricePennies":931,"scalingFactor":1.0}]},{"historyDate":"2020-11-18","priceHistory":[{"competitorId":527,"scaledPricePennies":937,"scalingFactor":1.0}]},{"historyDate":"2020-11-17","priceHistory":[{"competitorId":527,"scaledPricePennies":1064,"scalingFactor":1.0}]},{"historyDate":"2020-11-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-15","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-14","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-05","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-04","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-03","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-01","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-10-28","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-27","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-10-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-13","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-10-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-25","priceHistory":[{"competitorId":18214,"scaledPricePennies":1039,"scalingFactor":1.0}]},{"historyDate":"2020-09-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2020-09-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-11","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-10","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":moment(priorYearStartDate).format("YYYY-MM-DD"),"priceHistory":[{"competitorId":18214,"scaledPricePennies":1030,"scalingFactor":1.0}]}]
            it("has price change on that date @ that retail", () => {
                let actual = formatCompData(fakeCompData, priorYearStartDate);
                let expected = [{"changeDate": priorYearStartDate, "companyId": "Wal", "retail": null}, {"changeDate": priorYearStartDate, "companyId": "Amz", "retail": 10.3}, {"changeDate": "09/08/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/10/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/11/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "09/12/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/16/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/25/20", "companyId": "Amz", "retail": 10.39}, {"changeDate": "09/29/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/06/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/13/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/16/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/27/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "10/28/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/29/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/01/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/03/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/04/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/05/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/12/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/14/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/15/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/16/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/17/20", "companyId": "Wal", "retail": 10.64}, {"changeDate": "11/18/20", "companyId": "Wal", "retail": 9.37}, {"changeDate": "11/22/20", "companyId": "Amz", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Amz", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Wal", "retail": 9.37}]
                expect(actual).toEqual(expected);
                getUniqueList(expected, "companyId").forEach(companyId => {
                    let filtered = actual.filter(el => el.companyId === companyId);
                    expect(filtered[0].changeDate).toEqual(priorYearStartDate);
                    expect(filtered[filtered.length - 1].retail).toEqual(filtered[filtered.length - 2].retail);
                })
            })
        })
        describe("with competitor price changes only available later than selected start date", () => {
            const fakeCompData = [{"historyDate":"2020-11-22","priceHistory":[{"competitorId":18214,"scaledPricePennies":931,"scalingFactor":1.0}]},{"historyDate":"2020-11-18","priceHistory":[{"competitorId":6488,"scaledPricePennies":937,"scalingFactor":1.0}]},{"historyDate":"2020-11-17","priceHistory":[{"competitorId":6488,"scaledPricePennies":1064,"scalingFactor":1.0}]},{"historyDate":"2020-11-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-15","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-14","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-05","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-04","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-03","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-01","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-10-28","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-27","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-10-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-13","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-10-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-25","priceHistory":[{"competitorId":18214,"scaledPricePennies":1039,"scalingFactor":1.0}]},{"historyDate":"2020-09-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2020-09-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-11","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-10","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2020-09-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1030,"scalingFactor":1.0}]}]
            it("has a price change for the start date with a null retail", () => {
                let actual = formatCompData(fakeCompData, selectedStartingDate);
                let expected = [{"changeDate": selectedStartingDate, "companyId": "Men", "retail": null}, {"changeDate": selectedStartingDate, "companyId": "Amz", "retail": null}, {"changeDate": "09/06/20", "companyId": "Amz", "retail": 10.3}, {"changeDate": "09/08/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/10/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/11/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "09/12/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/16/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/25/20", "companyId": "Amz", "retail": 10.39}, {"changeDate": "09/29/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/06/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/13/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/16/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/27/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "10/28/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/29/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/01/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/03/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/04/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/05/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/12/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/14/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/15/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/16/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/17/20", "companyId": "Men", "retail": 10.64}, {"changeDate": "11/18/20", "companyId": "Men", "retail": 9.37}, {"changeDate": "11/22/20", "companyId": "Amz", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Amz", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Men", "retail": 9.37}]
                expect(actual).toEqual(expected);
                getUniqueList(expected, "companyId").forEach(companyId => {
                    let filtered = actual.filter(el => el.companyId === companyId);
                    expect(filtered[0].retail).toBe(null);
                    expect(filtered[0].changeDate).toEqual(selectedStartingDate);
                    expect(filtered[filtered.length - 1].retail).toEqual(filtered[filtered.length - 2].retail);
                })

            })
        })
        describe("with no selected starting date", () => {
            it("for each company, has whatever the first price change is as starting date, and also has a price change for today as the end date equal to prior retail", () => {
                const fakeCompData = [{"historyDate":moment(expectedEndDate).format("YYYY-MM-DD"),"priceHistory":[{"competitorId":527,"scaledPricePennies":931,"scalingFactor":1.0}]}, {"historyDate":"2020-11-23","priceHistory":[{"competitorId":588623,"scaledPricePennies":931,"scalingFactor":1.0}]}, {"historyDate":"2020-11-22","priceHistory":[{"competitorId":18214,"scaledPricePennies":931,"scalingFactor":1.0}]},{"historyDate":"2020-11-18","priceHistory":[{"competitorId":6488,"scaledPricePennies":937,"scalingFactor":1.0}]},{"historyDate":"2020-11-17","priceHistory":[{"competitorId":6488,"scaledPricePennies":1064,"scalingFactor":1.0}]},{"historyDate":"2020-11-16","priceHistory":[{"competitorId":588623,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-15","priceHistory":[{"competitorId":527,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-14","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-08","priceHistory":[{"competitorId":6488,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-05","priceHistory":[{"competitorId":6488,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-04","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-03","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-01","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-10-28","priceHistory":[{"competitorId":3141,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-27","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-10-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-13","priceHistory":[{"competitorId":3141,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-10-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-29","priceHistory":[{"competitorId":3141,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-25","priceHistory":[{"competitorId":527,"scaledPricePennies":1039,"scalingFactor":1.0}]},{"historyDate":"2020-09-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2019-09-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2019-09-11","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2019-09-10","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2018-09-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2018-09-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1030,"scalingFactor":1.0}]}]
                let actual = formatCompData(fakeCompData, null);
                let expected = [{"changeDate": "09/06/18", "companyId": "Amz", "retail": 10.3}, {"changeDate": "09/08/18", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/10/19", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/11/19", "companyId": "Amz", "retail": 10.66}, {"changeDate": "09/12/19", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/16/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/25/20", "companyId": "Wal", "retail": 10.39}, {"changeDate": "09/29/20", "companyId": "Low", "retail": 10.82}, {"changeDate": "10/06/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/13/20", "companyId": "Low", "retail": 10.66}, {"changeDate": "10/16/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/27/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "10/28/20", "companyId": "Low", "retail": 10.82}, {"changeDate": "10/29/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/01/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/03/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/04/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/05/20", "companyId": "Men", "retail": 10.54}, {"changeDate": "11/08/20", "companyId": "Men", "retail": 10.82}, {"changeDate": "11/12/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/14/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/15/20", "companyId": "Wal", "retail": null}, {"changeDate": "11/16/20", "companyId": "F&D", "retail": 10.82}, {"changeDate": "11/17/20", "companyId": "Men", "retail": 10.64}, {"changeDate": "11/18/20", "companyId": "Men", "retail": 9.37}, {"changeDate": "11/22/20", "companyId": "Amz", "retail": 9.31}, {"changeDate": "11/23/20", "companyId": "F&D", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Wal", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "F&D", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Amz", "retail": 9.31}, {"changeDate": expectedEndDate, "companyId": "Men", "retail": 9.37}, {"changeDate": expectedEndDate, "companyId": "Low", "retail": 10.82}]
                expect(actual).toEqual(expected);
                getUniqueList(expected, "companyId").forEach(companyId => {
                    let filtered = actual.filter(el => el.companyId === companyId);
                    let invalidDates = actual.filter(el => el.changeDate === "Invalid Date" || !el.changeDate);
                    expect(invalidDates.length).toEqual(0);
                    if (companyId !== "Wal") {
                        expect(filtered[filtered.length - 1].retail).toEqual(filtered[filtered.length - 2].retail);
                    } else {
                        expect(filtered[filtered.length - 1].retail).toEqual(9.31);
                    }
                    expect(filtered[filtered.length - 1].changeDate).toEqual(expectedEndDate)
                })
            })
        })
    })

    describe("getDataForAllPriceChangeDates()", () => {
        let data = [
            {companyId: "THD", changeDate: "08/24/20", retail: 15.84},
            {companyId: "Amz", changeDate: "09/06/20", retail: 10.3},
            {companyId: "Amz", changeDate: "09/08/20", retail: 10.19},
            {companyId: "Amz", changeDate: "09/10/20", retail: 10.82},
            {companyId: "Amz", changeDate: "09/11/20", retail: 10.66},
            {companyId: "Amz", changeDate: "09/12/20", retail: 10.82},
            {companyId: "Amz", changeDate: "09/16/20", retail: 10.19},
            {companyId: "Low", changeDate: "09/24/20", retail: 15.48},
            {companyId: "Amz", changeDate: "10/06/20", retail: 10.66},
            {companyId: "Amz", changeDate: "10/08/20", retail: 10.82},
            {companyId: "Amz", changeDate: "10/13/20", retail: 10.66},
            {companyId: "Amz", changeDate: "10/27/20", retail: 10.54},
            {companyId: "Amz", changeDate: "10/29/20", retail: null},
            {companyId: "Amz", changeDate: "11/01/20", retail: 10.82},
            {companyId: "Amz", changeDate: "11/03/20", retail: 10.54},
            {companyId: "Amz", changeDate: "11/04/20", retail: 10.82},
            {companyId: "Amz", changeDate: "11/05/20", retail: 10.54},
            {companyId: "THD", changeDate: "11/24/20", retail: 15.84},
            {companyId: "Amz", changeDate: "11/24/20", retail: 10.54},
            {companyId: "Low", changeDate: "11/24/20", retail: 15.48}
        ]
        let companies = getUniqueList(data, "companyId");
        let expected = [{"changeDate": "08/24/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/06/20", "companyId": "Amz", "retail": 10.3}, {"changeDate": "09/08/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/10/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/11/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "09/12/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "09/16/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "09/24/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "10/06/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/08/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "10/13/20", "companyId": "Amz", "retail": 10.66}, {"changeDate": "10/27/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "10/29/20", "companyId": "Amz", "retail": null}, {"changeDate": "11/01/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/03/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/04/20", "companyId": "Amz", "retail": 10.82}, {"changeDate": "11/05/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/24/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "11/24/20", "companyId": "Amz", "retail": 10.54}, {"changeDate": "11/24/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "08/24/20", "companyId": "Amz", "retail": null}, {"changeDate": "08/24/20", "companyId": "Low", "retail": null}, {"changeDate": "09/06/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/06/20", "companyId": "Low", "retail": null}, {"changeDate": "09/08/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/08/20", "companyId": "Low", "retail": null}, {"changeDate": "09/10/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/10/20", "companyId": "Low", "retail": null}, {"changeDate": "09/11/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/11/20", "companyId": "Low", "retail": null}, {"changeDate": "09/12/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/12/20", "companyId": "Low", "retail": null}, {"changeDate": "09/16/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/16/20", "companyId": "Low", "retail": null}, {"changeDate": "09/24/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "09/24/20", "companyId": "Amz", "retail": 10.19}, {"changeDate": "10/06/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "10/06/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "10/08/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "10/08/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "10/13/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "10/13/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "10/27/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "10/27/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "10/29/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "10/29/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "11/01/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "11/01/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "11/03/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "11/03/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "11/04/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "11/04/20", "companyId": "Low", "retail": 15.48}, {"changeDate": "11/05/20", "companyId": "THD", "retail": 15.84}, {"changeDate": "11/05/20", "companyId": "Low", "retail": 15.48}]
        it("creates a plot point for every price change date for every company at the appropriate retail amount", () => {
            getDataForAllPriceChangeDates(data, companies).forEach((el, index) => {
                expect(el.companyId).toEqual(expected[index].companyId);
                expect(el.changeDate).toEqual(expected[index].changeDate);
                expect(el.retail).toEqual(expected[index].retail);
            })
        })
    })
})
