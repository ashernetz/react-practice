import React, {useEffect, useState,Fragment} from 'react';
import {Row, Col, Typography, Select, Spin} from 'antd';
import ViserChart from '../ViserChart/ViserChart';
import {
    formatThdData,
    formatCompData,
    combinePriceHistories,
    formatLineColor
} from './PriceHistoryChartUtil';
import Moment from 'moment';
import { extendMoment } from 'moment-range';
import SvgUtil from '../../Utils/SvgUtil';
import UXSmallPulse from '../GlobalReactComponents/UXComponents/UXSmallPulse';

const moment = extendMoment(Moment);

const {Text,Paragraph} = Typography;
const {Option} = Select;

const NoDataPriceHistory = () => <Fragment>
    <Row justify="center" align="middle" type="flex">
        <Col className="noKVI">
            {SvgUtil.getNoData()}
        </Col>
    </Row>
    <Row justify="center" align="middle">
        <Col className="noKVI">
            <Text className="no-kvi">
                No Price History Data Available
            </Text>
        </Col>
    </Row>
    <Paragraph/>
</Fragment>

export default function PriceHistoryChart(props) {
    const [selectedNumberOfMonths, setSelectedNumberOfMonths] = useState(3);
    let selectedStartingDate = selectedNumberOfMonths ? moment().subtract(selectedNumberOfMonths, "months") : null;

    const [combinedPriceHistoryData, setCombinedPriceHistoryData] = useState([]);

    useEffect(() => {
        props.fetchCompetitorPriceHistory(selectedNumberOfMonths)
    }, [selectedNumberOfMonths])

    useEffect(() => {
        setCombinedPriceHistoryData(getCombinedPriceHistories())
    }, [props.competitorPriceHistory,props.thdStorePriceHistory])

    function getCombinedPriceHistories() {
        let thdHistoryData = formatThdData(props.thdStorePriceHistory, selectedStartingDate);
        let competitorHistoryData = formatCompData(props.competitorPriceHistory, selectedStartingDate);
        return combinePriceHistories(thdHistoryData, competitorHistoryData, selectedStartingDate)
    }

    const defaults = {
        containerName: "price-history-chart",
        xField: "changeDate",
        yField: "retail",
        dataKey: "companyId",
        selectOptions: [
            {label: "All History", value: null},
            {label: "3 Months", value: 3},
            {label: "6 Months", value: 6},
            {label: "1 Year", value: 12},
            {label: "2 Years", value: 24}
        ],
        initialSelectValue: 3,
        selectStyle:{ width: 110 }
    }

    let selectOptions = props.selectOptions ? props.selectOptions : defaults.selectOptions;

    return (
        <>
            <Row 
                id="price-history-tab-id" 
                className="storePriceHistory"
                justify={"space-between"}
                align={"middle"}
            >
                <Col>
                    <Text className="modalHeading" align="right">{props.headerTitle}</Text>
                </Col>
                {
                    props.showTimeToggle &&
                    <Col>
                        <Select 
                            onChange={(value) => setSelectedNumberOfMonths(value)}
                            style={props.selectStyle ? props.selectStyle : defaults.selectStyle}
                            defaultValue={props.defaultSelectValue ? props.defaultSelectValue : defaults.initialSelectValue}
                        >
                            {
                                selectOptions.map((option, index) => {
                                    return (
                                        <Option key={index} value={option.value}>{option.label}</Option>
                                    )
                                })
                            }
                        </Select>
                    </Col>
                }
            </Row>
            {/* <AntVChart
                chartType="ladder"
                xField={props.xField ? props.xField : defaults.xField}
                yField={props.yField ? props.yField : defaults.yField}
                dataKey={props.dateKey ? props.dataKey : defaults.dataKey}
                data={combinedPriceHistoryData}
                formatYAxisAsCurrency
                formatLineColor={formatLineColor}
                loadingData={props.loadingData}
                connectNull={false}
            /> */}
            {props.isNoData === "Y" ? <NoDataPriceHistory/> :
                <Spin indicator={<UXSmallPulse />} spinning={props.isLoading === "Y"}>
                    <ViserChart
                        chartType="ladder"
                        xField={props.xField ? props.xField : defaults.xField}
                        yField={props.yField ? props.yField : defaults.yField}
                        dataKey={props.dateKey ? props.dataKey : defaults.dataKey}
                        data={combinedPriceHistoryData}
                        formatYAxisAsCurrency
                        formatLineColor={formatLineColor}
                        loadingData={props.loadingData}
                    /></Spin>}
            
        </>
    );
};
