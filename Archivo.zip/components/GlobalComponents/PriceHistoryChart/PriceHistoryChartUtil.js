import CompetitorUtil from '../../Utils/CompetitorUtil';
import moment from 'moment';
import ColorConstants from '../../../constants/ColorConstants';
import {combineDataSets, getUniqueList, sortDataByValue} from "../../Utils/CommonUtil";
import {determineIfDateIsInDateRange} from '../../Utils/DateUtil';

function formatThdData(thdDates, selectedStartingDate) {
    if (!thdDates) {
        return [];
    }
    let thdDatesInRange = getThdHistoryForGivenDateRange(thdDates, selectedStartingDate);
    let endDate = moment().format("MM/DD/YY");
    let priorRetail = findPriorRetail(thdDates, selectedStartingDate);
    let currentRetail = priorRetail;
    if (thdDatesInRange.length === 0) {
        if (priorRetail) {
            thdDatesInRange.unshift(createChartDataObj({companyId: "THD", changeDate: selectedStartingDate, retail: priorRetail}));
        }
    } else {
        if (selectedStartingDate && !doesThdDataAlreadyIncludeDate(thdDates, selectedStartingDate)) {
            thdDatesInRange.unshift(createChartDataObj({companyId: "THD", changeDate: selectedStartingDate, retail: priorRetail}));
        }
        currentRetail = thdDatesInRange[thdDatesInRange.length - 1].retail;
    }
    if (!doesThdDataAlreadyIncludeDate(thdDates, endDate)) {
        thdDatesInRange.push(createChartDataObj({companyId: "THD", changeDate: endDate, retail: currentRetail}));
    }

    return thdDatesInRange.map(priceHistoryObj => {
        priceHistoryObj.companyId = "THD";
        return createChartDataObj(priceHistoryObj);
    })
}

function doesThdDataAlreadyIncludeDate(data, date) {
    return data.find(el => el.changeDate === date);
}

function findPriorRetail(data, comparisonDate) {
    let retail;
    if (comparisonDate) {
        let priorDates = data.filter(el => moment(el.changeDate).isSameOrBefore(moment(comparisonDate)));
        if (priorDates && priorDates.length > 0) {
            retail = priorDates[priorDates.length - 1].retail;
        }
    }
    return retail;
}

function formatCompData(competitorPriceHistory, selectedStartingDate) {
    let data = [];
    let currentCompanyRetails = {};
    if(competitorPriceHistory && Array.isArray(competitorPriceHistory)){
        competitorPriceHistory.forEach(compPriceDataObj => {
        compPriceDataObj.priceHistory.forEach(competitor => {
            competitor.changeDate = compPriceDataObj.historyDate;
            competitor.companyId = CompetitorUtil.getCompetitorName(competitor.competitorId, true);
            if (!currentCompanyRetails[competitor.companyId] && competitor.scaledPricePennies) {
                currentCompanyRetails[competitor.companyId] = competitor;
            }
            data.push(createChartDataObj(competitor));
        })
    });
}

    data = sortDates(data);
    extrapolateCompData(currentCompanyRetails, data, selectedStartingDate);
    return data;
}

function extrapolateCompData(currentCompanyRetails, data, selectedStartingDate) {
    let endDate = moment().format("MM/DD/YY");
    Object.keys(currentCompanyRetails).forEach(companyId => {
        if (selectedStartingDate && !doesCompDataIncludeDate(companyId, data, selectedStartingDate)) {
            data.unshift(createChartDataObj({companyId, changeDate: selectedStartingDate, retail: null}))
        }
        if (!doesCompDataIncludeDate(companyId, data, endDate)) {
            let extrapolated = {...currentCompanyRetails[companyId]};
            extrapolated.changeDate = endDate;
            data.push(createChartDataObj(extrapolated));
        }
    });
}

function doesCompDataIncludeDate(companyId, data, date) {
    return data.find(el => el.changeDate === date && el.companyId === companyId);
}

function combinePriceHistories(thdHistoryData, competitorHistoryData, selectedStartingDate) {
    selectedStartingDate = moment(selectedStartingDate).format("MM/DD/YY");
    let combinedData = combineDataSets(thdHistoryData, competitorHistoryData);
    if (combinedData && Array.isArray(combinedData) && combinedData.length > 0) {
        let companies = getUniqueList(combinedData, "companyId");
        combinedData = getDataForAllPriceChangeDates(combinedData, companies);
        combinedData = sortDates(combinedData);
        combinedData = combinedData.filter(row => (row.retail !== null));
    }

    return combinedData;
}

function sortDates(data) {
    let newData = data.map(priceChange => {
        priceChange.sortDate = new Date(priceChange.changeDate);
        return priceChange;
    })
    newData = sortDataByValue(newData, "sortDate");
    newData.forEach(priceChange => {
        delete priceChange.sortDate
    })
    return newData;
}

function getCompetitorNamesFromHistory(competitorHistoryData) {
    competitorHistoryData.forEach(compHistObj => {
        compHistObj.companyId = CompetitorUtil.getCompetitorName(compHistObj.companyId, true);
    })
}

function createChartDataObj(priceChangeObj) {
    return {
        companyId: priceChangeObj.companyId,
        changeDate: moment(priceChangeObj.changeDate).format("MM/DD/YY"),
        retail: handleRetailValueOfZero(priceChangeObj)
    }
}

function handleRetailValueOfZero(priceChangeObj) {
    if (priceChangeObj) {
        if (priceChangeObj.retail) {
            return priceChangeObj.retail;
        } else {
            return (priceChangeObj.scaledPricePennies && priceChangeObj.scaledPricePennies > 0) ? priceChangeObj.scaledPricePennies / 100 : null;
        }
    }
    return null;
}

function getDataForAllPriceChangeDates(allData, companies) {
    let newData = [...allData];
    let currentCompanyRetails = {};
    getUniqueList(allData, "changeDate").sort((a,b)=>new Date(a)-new Date(b)).forEach(date => {
        companies.forEach(companyId => {
            let priceChangeAtDateForCompany = findPriceChangeAtDateForCompany(date, allData, companyId);
            if (priceChangeAtDateForCompany) {
                currentCompanyRetails[companyId] = priceChangeAtDateForCompany.retail;
            } else {
                newData.push(createChartDataObj({companyId: companyId, changeDate: date, retail: currentCompanyRetails[companyId]}))
            }
        })
    })
    return newData
}

function findPriceChangeAtDateForCompany(date, allData, companyId) {
    return allData.find(el => {
        return el.companyId === companyId && el.changeDate === date
    })
}

function formatLineColor(companyId) {
    if (companyId === "THD") {
        return ColorConstants.thdPrimaryColor;
    }
    return CompetitorUtil.getCompetitorPrimaryColor(companyId);
}

function getThdHistoryForGivenDateRange(thdStorePriceHistory, selectedStartingDate) {
    if (selectedStartingDate) {
        return thdStorePriceHistory.filter((priceChange) => {
            return determineIfDateIsInDateRange(moment(selectedStartingDate), moment(), moment(priceChange.changeDate));
        })
    } 
    return thdStorePriceHistory
}

// function formatDataForAntVDataSet(data) {
//     let tempObj = {}
//     let flattenedData = [];
//     let dates = [...new Set(data.map(item => item.changeDate))];
//     flattenedData = dates.map(date => {
//         let filtered = data.filter(el => {return el.changeDate === date});
//         tempObj = {changeDate: date}
//         filtered.forEach(el => {tempObj[el.companyId] = el.retail});
//         return tempObj
//     })
//     return flattenedData;
// }

export {
    formatThdData,
    formatCompData,
    combinePriceHistories,
    getCompetitorNamesFromHistory,
    createChartDataObj,
    getDataForAllPriceChangeDates,
    findPriceChangeAtDateForCompany,
    formatLineColor,
    getThdHistoryForGivenDateRange
}
