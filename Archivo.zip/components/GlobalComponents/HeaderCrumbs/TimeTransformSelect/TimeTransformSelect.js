import React, { useContext, useEffect, useState } from "react";
import { Select, Typography, Row, Col, Space} from 'antd';
import "./TimeTransformSelect.scss"
import TimeTransformUtil from "../../../Utils/TimeTransformUtil";
import SkuContext from "../../../../context/SkuContext";
import HeaderServices from "../../../../services/HeaderServices";
import {trackEvent} from "../../../Utils/mixpanel";

const { Option } = Select;
const {Text} = Typography;

const getTimeTransformTitle = (input, lastFiscalWeek) => {
  let timeTransformObject = TimeTransformUtil.TIME_TRANSFORM_TYPES.find(k => k.key === input);
  return timeTransformObject.key === TimeTransformUtil.FISCAL_WEEK_TIME_TRANSFORM ? timeTransformObject.title
      + lastFiscalWeek : timeTransformObject.title;
};

const getMetricsTitle = (input) => {
  let metricsObject = TimeTransformUtil.TIME_TRANSFORM_YEARS.find(k => k.key === input);
  return  metricsObject.title;
};

const TimeTransformSelect = () => {
  const skuContext = useContext(SkuContext);
  const [isDropdownOpen,setIsDropdownOpen] = useState(false);
  const [metricsValue, setMetricsValue] = useState(false);

  useEffect(() => {
    if (!skuContext.lastFiscalWeek) {
      HeaderServices.getFiscalWeek().then(response => {
        if (response && response.data && response.data.fiscalWeek) {
          skuContext.updateStateFields({ lastFiscalWeek: response.data.fiscalWeek });
        }
      }).catch(err => console.log(err))
    }
  }, []);

  const onTimeTransformChange = (value) => {
    skuContext.updateTimeTransformType(skuContext.timeTransformType.split("|")[0]+"|"+value);
    let title =getTimeTransformTitle(value,"");
    title = title?title.trim().replaceAll(" ","_").toUpperCase():value;
    trackEvent("SELECT_TIME_TRANSFORM_TYPE_"+title,{value:title});

  };

  const onMetricsTransformChange = (value) => {
    skuContext.updateTimeTransformType(value + "|" +skuContext.timeTransformType.split("|")[1]);
    let title =getMetricsTitle(value);
    title = title?title.trim().replaceAll(" ","_").toUpperCase():value;
    trackEvent("SELECT_METRICS_TYPE_"+title,{value:title});

  };

  let compYear = skuContext.timeTransformType.split("|")[0];
  let timeTransformValue = skuContext.timeTransformType.split("|")[1];

  return (
  <Row align="middle" gutter={[20,0]}>
    <Col>
      <Space direction="vertical" className="time-slice-space">
        <Text className="time-slice-text">Time Period</Text>
        <Select
            open = {isDropdownOpen}
            className="time-transform-select"
            value={getTimeTransformTitle(timeTransformValue,skuContext.lastFiscalWeek)}
            // onClick = {() =>{trackEvent("CLICK_TIME_TRANSFORM_DROPDOWN",{value:"TIME_TRANSFORM_DROPDOWN"});}}
            onChange={onTimeTransformChange}
            onDropdownVisibleChange={isOpen => setIsDropdownOpen(isOpen)}
        >
          {TimeTransformUtil.TIME_TRANSFORM_TYPES.map(
              k => <Option key={k.key} value={k.key}>
                <Text type="secondary">{k.key === TimeTransformUtil.FISCAL_WEEK_TIME_TRANSFORM ? k.title + skuContext.lastFiscalWeek : k.title}</Text>
              </Option>)}
        </Select>
      </Space>
    </Col>

    <Col>
      <Space direction="vertical" className="time-slice-space">
        <Text className="time-slice-text">Metrics Comparison</Text>
        <Select
            open = {metricsValue}
            className="time-transform-select"
            value={getMetricsTitle(compYear)}
            // onClick = {() =>{trackEvent("CLICK_METRICS_DROPDOWN",{value:"METRICS_DROPDOWN"});}}
            onChange={onMetricsTransformChange}
            onDropdownVisibleChange={isOpen => setMetricsValue(isOpen)}
        >
          {TimeTransformUtil.TIME_TRANSFORM_YEARS.map(
              k => <Option key={k.key} value={k.key}>
                <Text type="secondary">{k.title}</Text>
              </Option>)}
        </Select>
      </Space>
    </Col>
</Row>
  )
};

export default TimeTransformSelect;
