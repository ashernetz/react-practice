import React , {Fragment} from  "react";
import { Col, Row, Typography, Divider, Space} from "antd";
import { ArrowLeftOutlined } from '@ant-design/icons';
import * as PropTypes from "prop-types";
import "./HeaderCrumbs.scss"
import TimeTransformSelect from "./TimeTransformSelect/TimeTransformSelect";

const { Text } = Typography;

const HeaderCrumbs = (props) => {
  return (
      <Fragment>
        <Row align="middle" gutter={[12,0]}>
          <Col>
            <Row align="middle" gutter={[16,0]}>
             {props.backArrowClick && <Col>
                <ArrowLeftOutlined style={{fontSize:'25px',fontWeight:750}} onClick={() => {props.backArrowClick(true)}}/>
              </Col>}
              <Col>
                <Space direction="vertical" className="page-heading-space">
                  {props.headerData.subHeading && <Text className="sub-heading-text">{props.headerData.subHeading?props.headerData.subHeading:""}</Text>}
                  <Text className="main-heading-text">{props.headerData.mainHeading?props.headerData.mainHeading:""}</Text>
                </Space>
              </Col>
            </Row>
          </Col>
          {!props.isOnlyTitle &&
          <><Col><Divider type="vertical" style={{height:'40px'}}/></Col>
          <Col style={{padding:0}}><TimeTransformSelect/></Col></>
          }
        </Row>


      </Fragment>);
};



HeaderCrumbs.propTypes = {
  breadcrumbsList:PropTypes.array,
  currentPath:PropTypes.any,
  showDCS:PropTypes.bool
};

export default HeaderCrumbs;
