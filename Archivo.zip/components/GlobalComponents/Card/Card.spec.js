import React from 'react';
import { screen, render } from '@testing-library/react';

import { Card } from './Card';

const getProps = (props = {}) => ({
  title: 'Test Title',
  ...props,
});

describe('Card component', () => {
  it('renders default state', () => {
    render(<Card {...getProps()}>Test Content</Card>);

    expect(screen.queryByText('Test Title')).toBeInTheDocument();
    expect(screen.queryByText('Test Content')).toBeInTheDocument();
  });
});
