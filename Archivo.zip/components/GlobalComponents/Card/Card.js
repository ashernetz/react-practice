import React from 'react';
import styled from 'styled-components';
import { Card as BaseCard, Typography } from 'antd';

const StyledCard = styled(BaseCard)`
  width: 320px;
  height: 250px;

  .ant-card-body {
    padding: 20px;
    height: calc(100% - 62px);
  }
`;

const Content = styled.div`
  height: 100%;
  overflow-y: scroll;
  padding: 4px;

  ::-webkit-scrollbar {
    display: none;
  }
`;

const CardTitle = styled(Typography.Text)`
  font-size: 18px;
  font-weight: 600;
  color: #767676;
`

export function Card({ title, children }) {
  const cardTitle = <CardTitle>{title}</CardTitle>

  return (
    <StyledCard bordered={false} title={cardTitle}>
      <Content>{children}</Content>
    </StyledCard>
  );
}
