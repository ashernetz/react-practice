import React from 'react'
import { Resizable } from 'react-resizable'
import 'react-resizable/css/styles.css'

const ResizeHandle = () => {
  return (
    <span
      className={`react-resizable-handle react-resizable-handle-e`}
      onClick={(e) => e.stopPropagation()}
    />
  )
}

const ResizableTitle = (props) => {
  const { onResize, width, isCustom,...restProps } = props;
  if (!isCustom) {
    return <th {...restProps} />;
  }
  return (
    <Resizable
     width={width}
     height={0}
     handle={ResizeHandle()}
     onResize={onResize}
     resizeHandles={['e']}>
      <th {...restProps} />
    </Resizable>
  )
}
export default ResizableTitle;