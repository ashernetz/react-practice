import React, {Component} from 'react';
import {SearchOutlined} from '@ant-design/icons';
import {Table, Input, Button} from 'antd';
import Highlighter from 'react-highlight-words';


export default class AdvancedTable extends Component {
    state = {
        searchText: '',
    };

    getColumnSearchProps = (dataIndex, placeholder = dataIndex) => ({

        filterDropdown: ({setSelectedKeys, selectedKeys, confirm, clearFilters}) => (
            <div style={{padding: 8}}>
                <Input
                    ref={node => {
                        this.searchInput = node;
                    }}
                    placeholder={`Search ${placeholder}`}
                    value={selectedKeys[0]}
                    onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => this.handleSearch(selectedKeys, confirm)}
                    style={{width: 188, marginBottom: 15, display: 'block'}}
                />
                <Button
                    type="primary"
                    onClick={() => this.handleSearch(selectedKeys, confirm)}
                    icon={<SearchOutlined/>}
                    size="small"
                    style={{width: 90, marginRight: 8}}
                >
                    Search
                </Button>
                <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{width: 90}}>
                    Reset
                </Button>
            </div>
        ),
        filterIcon: filtered => (
            <SearchOutlined style={{color: filtered ? 'rgba (250,99,4,0.5)' : undefined}}/>
        ),
        onFilter: (value, record) => {
            let rowValue = Array.isArray(dataIndex) ? dataIndex.reduce((total, current) => {
                return total[current]
            }, record) : record[dataIndex];
            return rowValue.toString()
                .toLowerCase()
                .includes(value.toLowerCase())
        },
        onFilterDropdownVisibleChange: visible => {
            if (visible) {
                setTimeout(() => this.searchInput.select());
            }
        },
        render: text => (
            <Highlighter
                highlightStyle={{backgroundColor: '#fdb689', padding: 0}}
                searchWords={[this.state.searchText]}
                autoEscape
                textToHighlight={text.toString()}
            />
        ),
    });

    handleSearch = (selectedKeys, confirm) => {
        confirm();
        this.setState({searchText: selectedKeys[0]});
    };

    handleReset = clearFilters => {
        clearFilters();
        this.setState({searchText: ''});
    };

    render() {      
        let columns = this.props.columns.map(column => {
            if (column.isCustomFilter) {
                let newColumnSearchProps = this.getColumnSearchProps(column.dataIndex, column.filterPlaceholder);
                if (column.retainColumnRender) {
                    delete (newColumnSearchProps.render);
                }
                return {...column, ...newColumnSearchProps};
            } else {
                return column;
            }
        });

        return <Table
            {...this.props.extraTableProps}
            columns={columns}
            dataSource={this.props.dataSource}
            pagination={this.props.pagination}
            onRow={this.props.onRow}
            locale={this.props.locale}
            className={this.props.tableClassName}
        />
    }
}

AdvancedTable.defaultProps = {
    locale: {},
    tableClassName: "",
    extraTableProps: {}
};


