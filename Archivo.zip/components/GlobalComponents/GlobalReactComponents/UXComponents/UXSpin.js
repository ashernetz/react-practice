import React from "react";
import { LoadingOutlined } from '@ant-design/icons';
import { Spin } from "antd";

export const UXSpin = (props) => {
  const antIcon = <LoadingOutlined style={{color: '#f96302', fontSize: props.fontSize?props.fontSize:24}} spin />;

  return (

      <Spin indicator={antIcon}/>

  );
};