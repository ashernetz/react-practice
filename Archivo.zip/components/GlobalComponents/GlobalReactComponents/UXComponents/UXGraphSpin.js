
import React from "react";
import { LoadingOutlined } from '@ant-design/icons';
import { Spin} from 'antd';
import { AreaChart, Area,  XAxis, YAxis, CartesianGrid, Tooltip} from "recharts"

export const UXGraphSpin = (props) => {
  const antIcon = <LoadingOutlined
    style={{color: '#f96302', fontSize: 100 , bottom:'200px' , left:'300px'}}
    spin />;

  return (
    <div>
    <AreaChart className="salesHistoryGraph" width={700} height={300} date={null}
            margin={{top: 20, right: 30, left: 10, bottom: 10}}>
            <CartesianGrid strokeDasharray="3 3"/>
            <XAxis height={60}/>
            <YAxis/>
            <Tooltip/>
            <Area dataKey=''/>
            </AreaChart>
      <Spin indicator={antIcon}/>
      </div>

  );
};
