/*global RadioGroup */
/*eslint no-undef: "error"*/
import React, { Component } from 'react';
import PropTypes from 'prop-types';

let classNames = require('classnames');

export default class RadioButtons extends Component {

    componentDidMount() {
        new RadioGroup(this.props.groupId).init();
    }

    render() {
        let isChecked = false;
        let radioButtons = this.props.radioButtons.map((radioButton, index) => {
            if (isChecked === true) {
                radioButton.checked = false;
            }
            if (radioButton.checked === true) {
                isChecked = true;
            }

            return (
                <div key={index} role="radio" aria-checked={radioButton.checked} aria-disabled={this.props.disabled} aria-invalid={this.props.error}
                    tabIndex="-1" onClick={() => this.props.setValue(radioButton.value)}
                    onKeyUp={() => this.props.setValue(radioButton.value)}>
                    <label>{radioButton.label}</label>
                </div>
            );
        });

        const groupClass = classNames({
            'vertical': this.props.isVertical
        });

        return (
            <div role="radiogroup" aria-labelledby={this.props.groupId + "_label"} id={this.props.groupId} className={groupClass}>
                {this.props.title && <h4 id={this.props.groupId + "_label"}>{this.props.title}</h4>}
                {radioButtons}
            </div>
        );
    }
}

RadioButtons.propTypes = {
    title: PropTypes.string,
    groupId: PropTypes.string.isRequired,
    radioButtons: PropTypes.array.isRequired,
    setValue: PropTypes.func,
    isVertical: PropTypes.bool,
    disabled: PropTypes.bool,
    error: PropTypes.bool
};