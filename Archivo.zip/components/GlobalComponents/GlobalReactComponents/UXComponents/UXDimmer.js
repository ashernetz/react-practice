import React from 'react';
import styled from "styled-components";
import './LoadingPulse.scss';


const Dimmer = styled.div`
  height: 100%;
  width: 100%;
  padding-top: 20%;
  padding-left: 45%;
  top: 0;
  left: 0;
  z-index: 1000;
  text-align: center;
  background:  rgba(0,0,0,.6);
  position: fixed;
  vertical-align: middle;
  
  & .ant-spin {
  color:#f96302;
  position: absolute;
  top: 45%;
  left: 45%;
  margin: 0;
  font-size: 1.7em;
}

& .anticon {
  font-size: 1.7em!important;
}
`

export const UXDimmer = (props) => {
    return (

        props.showDimmer ? <Dimmer className="spinner">
             <div className="pulse"></div>
        </Dimmer> : null


  );
};