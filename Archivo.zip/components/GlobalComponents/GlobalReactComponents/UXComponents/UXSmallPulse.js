import React from "react";
import "./SmallPulse.scss";

const UXSmallPulse = () => {
  return <div>
    <div className="small-pulse"/>
  </div>
};

export default UXSmallPulse;