import React, {Component, Fragment} from "react";
import {UXSpin} from "./UXSpin";

export default class UXImage extends Component {
   render() {

    return <Fragment>
      {
      this.props.imageUrl?
          <img alt="sku-data" src={this.props.imageUrl}
                className={this.props.classNames}/>
          : <UXSpin/>
    }</Fragment>

  }

};