import SingleAndMultiSkuServices from "../../services/SingleAndMultiSkuServices";
import {
  dcsFormatter,
  dcsFormatterWithoutHyphen,
  getSubClassDescription,
  mergeAndRemoveDuplicates,
  minMaxRetailFormatter,
  findNewMinMax
} from '../Utils/CommonUtil';
import DCSUtil from '../Utils/DCSUtil';
import CPIUtil from "../Utils/CPIUtil";

export default class MultiSkuApiHelper {

  static fetchMultiSkuOnlineData(initialState, sellingChannelData, setOnlineMultipleSkuData,
                                 context, onlineMultiSkuApiTriggers, setMultiSkuHeaderData, isDiverseSearch, vendor) {

    let dcsSet = new Set();

    SingleAndMultiSkuServices.onlineSearch(Object.keys(sellingChannelData.onlineSkus).map(k => parseInt(k)), vendor).then(response => {
      response.data.onlineSkuDetailList.forEach(skuObject => {
        let {
          department,
          classNumber,
          subClass,
          omsId,
          skuDescription
        } = sellingChannelData.onlineSkus[skuObject.skuNumber];
        let hyphenatedDcs = DCSUtil.getHyphenatedDCS(department, classNumber, subClass);
        skuObject.department = department;
        skuObject.classNumber = classNumber;
        skuObject.subClass = subClass;
        skuObject.formattedDCS = dcsFormatterWithoutHyphen(department, classNumber, subClass);
        skuObject.omsIdAndVendorData.omsIdList = omsId;
        skuObject.skuDescription = skuDescription;
        skuObject.hyphenatedDcs = hyphenatedDcs;
        dcsSet.add(hyphenatedDcs);

      });
      setOnlineMultipleSkuData(k => {
        response.data.onlineSkuDetailList = [...response.data.onlineSkuDetailList, ...k.onlineSkuDetailList];
        return {...response.data, isLoaded: true, distinctDCSSet: new Set([...dcsSet, ...k.distinctDCSSet])}
      });
      let skuList = response.data.onlineSkuDetailList.map(k => k.skuNumber);
      if (skuList.length > 0) {
        onlineMultiSkuApiTriggers(skuList);

        setMultiSkuHeaderData(multiSkuHeaderData => {
              let dcs = sellingChannelData.onlineDcs.split("-");
              multiSkuHeaderData.online.productCount = skuList.length;
              multiSkuHeaderData.online.dcsTitle = sellingChannelData.onlineDcs;
              multiSkuHeaderData.online.formattedDCS = dcsFormatter(dcs[0], dcs[1], dcs[2]);
              multiSkuHeaderData.online.skuTitle = skuList.length === 1 ? "SKU " + skuList[0] : "MULTIPLE SKUS";
              multiSkuHeaderData.online.omsIdTitle = skuList.length === 1 ? (sellingChannelData.onlineSkus[skuList[0]].omsId.length === 1
                  ? "OMSID " + sellingChannelData.onlineSkus[skuList[0]].omsId[0] : "MULTIPLE OMSIDS") : "MULTIPLE OMSIDS";
              if (!isDiverseSearch) {
                multiSkuHeaderData.online.minMaxRetail = {minMaxRetail:minMaxRetailFormatter(response.data.minimumRetail, response.data.maximumRetail)};
              }

              return multiSkuHeaderData;
            }
        )
      }
      context.updateShowDimmer(false);

    }).catch(err => {
      setOnlineMultipleSkuData({...initialState.onlineMultiSkuData, isLoaded: false});
      //let alertMessage = AlertUtil.getErrorMessage("performing online Multi-Sku Search");
      // if (err.response.status === 422) {
      //   alertMessage = <div>No valid SKus or OMSId present</div>;
      //   console.log(err.response.data);
      // }
      //AlertUtil.showAlert("error", "Error", alertMessage);
      //updateShowNewDashboardView(true);
      console.log(err);
    });
  }


  static fetchInStoreDetails(userId, sellingChannelData, setInStoreMultiSkuData, inStoreMultiSkuApiTriggers, setMultiSkuHeaderData, isDiverseSearch) {
    let inputSkus = Object.keys(sellingChannelData.coreSkus);
    if (inputSkus.length > 0) {
      let skuList = [];
      let dcsSet = new Set();
      let skuRetailList = [];
      Object.values(sellingChannelData.coreSkus).forEach(skuData => {
        let {department, classNumber, subClass, omsId: omsIdList, skuDescription, skuNumber, isAnchorSku} = skuData;
        let hyphenatedDcs = DCSUtil.getHyphenatedDCS(department, classNumber, subClass);
        let formattedDCS = dcsFormatterWithoutHyphen(department, classNumber, subClass);
        let mostCommonRetail = "-";
        let minRetail = "-";
        let maxRetail = "-";
        let aur = "-";
        let rank = "-";
        // let minCost = "-";
        // let maxCost = "-";
        // let modeCost = "-";
        let currentCost = "-";
        let vendors =null;
        skuRetailList.push({
          skuNumber,
          skuDescription,
          department,
          classNumber,
          subClass,
          formattedDCS,
          mostCommonRetail,
          omsIdList,
          aur,
          minRetail,
          maxRetail,
          hyphenatedDcs,
          isAnchorSku,
          // minCost:'20.987',
          // maxCost:'30.678',
          // modeCost:'35.987',
          vendors,
          currentCost,
          rank
        });
        skuList.push(skuNumber);
        dcsSet.add(hyphenatedDcs);
      });
      inStoreMultiSkuApiTriggers(skuList);
      setMultiSkuHeaderData(multiSkuHeaderData => {
        let dcs = sellingChannelData.coreDcs.split("-");
        multiSkuHeaderData.inStore.productCount = skuList.length;
        multiSkuHeaderData.inStore.dcsTitle = sellingChannelData.coreDcs;
        multiSkuHeaderData.inStore.formattedDCS = dcsFormatter(dcs[0], dcs[1], dcs[2]);
        multiSkuHeaderData.inStore.skuTitle = skuList.length === 1 ? "SKU " + skuList[0] : "MULTIPLE SKUS";
        multiSkuHeaderData.inStore.omsIdTitle = skuList.length === 1 ? (sellingChannelData.coreSkus[skuList[0]].omsId.length === 1
            ? "OMSID " + sellingChannelData.coreSkus[skuList[0]].omsId[0] : "MULTIPLE OMSIDS") : "MULTIPLE OMSIDS";
        // if(!isDiverseSearch) {
        //   multiSkuHeaderData.inStore.minMaxRetail = minMaxRetailFormatter(response.data.minRetail, response.data.maxRetail);
        // }

        return multiSkuHeaderData;
      });
      setInStoreMultiSkuData(k => {
        return {
          skuRetailList: [...skuRetailList, ...k.skuRetailList],
          isLoaded: true,
          distinctDCSSet: new Set([...dcsSet, ...k.distinctDCSSet])
        }
      });
      let retailModeMap = skuList.reduce((total, current) => {
        total[current] = "NA";
        return total
      }, {});
      SingleAndMultiSkuServices.fetchInStoreRetailMode(inputSkus).then(
          response => {
            let inStoreMultiSkuData = response.data;

            inStoreMultiSkuData.skuRetailList.forEach(skuRetailData => {
              retailModeMap[skuRetailData.skuNumber] = skuRetailData;
            });

          }).catch(err => {
        //let alertMessage = AlertUtil.getErrorMessage("performing inStore Multi-Sku Search");

        //AlertUtil.showAlert("error", "Error", alertMessage);
        console.log(err);
      }).finally(() => {
        setInStoreMultiSkuData(k =>
            ({
              ...k, skuRetailList: k.skuRetailList.map(skuData => {
                if (retailModeMap.hasOwnProperty(skuData.skuNumber)) {
                  return {
                    ...skuData,
                    mostCommonRetail: retailModeMap[skuData.skuNumber].mostCommonRetail,
                    minRetail: retailModeMap[skuData.skuNumber].minRetail,
                    maxRetail: retailModeMap[skuData.skuNumber].maxRetail,
                    assortedStore: retailModeMap[skuData.skuNumber].assortedStore,
                  }
                } else {
                  return skuData
                }
              })
            }));

        setMultiSkuHeaderData(k => {
              let minMaxRetail = this.calculateInStoreMinMaxRetail(Object.values(retailModeMap), null,false);

              if (k.inStore.minMaxRetail.minMaxRetail) {
                minMaxRetail = findNewMinMax(k.inStore.minMaxRetail, minMaxRetail);
              }
              return {
                ...k,
                "inStore": {...k.inStore, minMaxRetail}
              }
            }
        );
      });
    }
  }

  static fetchOnlineOhQuantity(skuList, setMultiSkuHeaderData) {
    let ohQuantity = "-";
    SingleAndMultiSkuServices.fetchOnHandQuantity(skuList)
        .then(response => {
          ohQuantity = response.data ?
              Object.values(response.data).reduce((a, b) => a + b, 0)
              : "-";
        })
        .catch(err => console.error(err))
        .finally(
            () => setMultiSkuHeaderData(multiSkuHeaderData => {
              multiSkuHeaderData.online.onHandQuantity = ohQuantity;
              return multiSkuHeaderData;
            })
        );
  }


  static fetchMultiSkuPerformance(skuList, userId, isOnline, headerCommonFunction, rowDataCommonFunction, isDiverseSearch, searchedVendorNumber) {
    let resultantResponse = {};
    SingleAndMultiSkuServices.fetchMultiSKUPerformance(skuList, userId, isOnline, searchedVendorNumber)
        .then(k => {
          resultantResponse = k.data;
        })
        .catch(err => {
          console.log(err);
        }).finally(() =>
        this.fillCompAndUnitsForEachSku(resultantResponse, rowDataCommonFunction, headerCommonFunction,
            isOnline, isDiverseSearch, skuList));
  }


  static fillCompAndUnitsForEachSku(skuPerformanceData, multiSkuCommonFunction, headerCommonFunction,
                                    isOnline, isDiverseSearch, inputSkuList) {
    let tableRowDatIndex = isOnline ? "onlineSkuDetailList" : "skuRetailList";
    if (!isDiverseSearch) {
      let headerDataIndex = isOnline ? "online" : "inStore";
      headerCommonFunction(multiSkuHeaderData => ({
        ...multiSkuHeaderData, [headerDataIndex]: {
          ...multiSkuHeaderData[headerDataIndex],
          totalCompPercentage: skuPerformanceData.totalCompPercentage ? skuPerformanceData.totalCompPercentage : "-",
          totalUnitsPercentage: skuPerformanceData.totalUnitsPercentage ? skuPerformanceData.totalUnitsPercentage : "-",
          totalThisYearSales: skuPerformanceData.totalThisYearSales ? skuPerformanceData.totalThisYearSales : "-",
          totalThisYearUnits: skuPerformanceData.totalThisYearUnits ? skuPerformanceData.totalThisYearUnits : "-"
        }
      }));
    }
    multiSkuCommonFunction(data => {
      let skuDetails = {...data};

      let skuCompMap = skuPerformanceData.skuCompMap
          ? skuPerformanceData.skuCompMap : {};

      skuDetails[tableRowDatIndex].forEach(skuData => {
        if (inputSkuList.includes(skuData.skuNumber)) {
          let compData = skuCompMap.hasOwnProperty(skuData.skuNumber);
          let compPercentage = compData ? skuCompMap[skuData.skuNumber].compPercentage : "-";
          let unitsPercentage = compData ? skuCompMap[skuData.skuNumber].unitsPercentage : "-";
          let rawUnits = compData ? skuCompMap[skuData.skuNumber].rawUnits : "-";
          let rawSales = compData ? skuCompMap[skuData.skuNumber].rawSales : "-";
          skuData.compPercentage = compPercentage ? compPercentage : "-";
          skuData.unitsPercentage = unitsPercentage ? unitsPercentage : "-";
          skuData.rawUnits = rawUnits ? rawUnits : "-";
          skuData.rawSales = rawSales ? rawSales : "-";
        }
      });
      return skuDetails;

    })

  };

  static determineArrowIndicator(timeline, checkKey) {
    let runningAmount = 0;
    timeline.sort((a, b) => a.beginDate - b.beginDate);

    timeline.forEach(k => {
      let arrowIndicator;
      if (runningAmount === 0 || runningAmount === k[checkKey]) {
        arrowIndicator = "";
      } else if (k[checkKey] > runningAmount) {
        arrowIndicator = "arrow-up";
      } else {
        arrowIndicator = "arrow-down";
      }
      k.arrowIndicator = arrowIndicator;
      runningAmount = k[checkKey];

    });
  };

  static formatHistoryTimestamp = (inputTime) => {
    let destructuredTime;
    try {
      let input = inputTime.replace('T', ' ');
      let date = input.split(' ')[0].split('-');
      let formattedTime = input.split(' ')[1].trim();
      let formattedDate = date[0] === "9999" ? "No End" : date[1] + '/' + date[2] + '/' + date[0].slice(-2);
      let tooltipData = date[0] === "9999" ? "No End" : formattedDate + " " + formattedTime;
      destructuredTime = {
        formattedDate,
        formattedTime,
        tooltipData
      };
    } catch {
      destructuredTime = {formattedDate: '', formattedTime: '', tooltipData: ''};

    } finally {
      return destructuredTime;
    }
  };

  static getOnlineRetailTimelineData = (skuNumber, omsIdVendorObject, setSkuTimelineMap) => {

    let vendorNumber = omsIdVendorObject.vendorList.length === 1 ? omsIdVendorObject.vendorList[0].vendorNumber : 0;
    let key = 0;
    Promise.all(
        [
          SingleAndMultiSkuServices.fetchRetailTimeline(skuNumber).catch(err => {
            console.log(err);
            return {data: []}
          }),
          SingleAndMultiSkuServices.fetchCostTimeline(skuNumber, vendorNumber).catch(err => {
            console.log(err);
            return {data: []}
          })
        ])
        .then(response => {
          let retailTimeline = [];
          response[0].data.forEach(k => {
            let formattedBeginTime = this.formatHistoryTimestamp(k.EFFECTIVEBEGINDATE);
            let formattedEndTime = this.formatHistoryTimestamp(k.EFFECTIVEENDDATE);
            retailTimeline.push({
              beginDate: new Date(k.EFFECTIVEBEGINDATE),
              endDate: new Date(k.EFFECTIVEENDDATE),
              displayDate: formattedBeginTime.formattedDate + " - " + formattedEndTime.formattedDate,
              tooltipTime: formattedBeginTime.tooltipData + " - " + formattedEndTime.tooltipData,
              event: k.PROMOTIONTYPE ? k.PROMOTIONTYPE : "Perm Retail",
              vendorNumber: 0,
              retail: k.EFFECTIVERETAIL,
              cost: null,
              requestid: k.REQUESTID,
              submitter: k.SUBMITTER,
              key: key++
            });
          });
          this.determineArrowIndicator(retailTimeline, "retail");

          let costTimeline = [];
          response[1].data.forEach(k => {
            let vendorObject = omsIdVendorObject.vendorList.find(s => s.vendorNumber === k.MVNDR_NBR);
            let formattedBeginTime = this.formatHistoryTimestamp(k.SRC_EFF_BGN_TS);
            let formattedEndTime = this.formatHistoryTimestamp(k.SRC_EFF_END_TS);
            if (vendorObject) {
              costTimeline.push({
                beginDate: new Date(k.SRC_EFF_BGN_TS),
                endDate: new Date(k.SRC_EFF_END_TS),
                displayDate: formattedBeginTime.formattedDate + " - " + formattedEndTime.formattedDate,
                tooltipTime: formattedBeginTime.tooltipData + " - " + formattedEndTime.tooltipData,
                event: k.IS_PROMO_FLG === true ? "Promo Cost" : "Perm Cost",
                vendorNumber: k.MVNDR_NBR,
                vendorName: vendorObject.vendorName,
                formattedVendor: vendorObject ? `#${vendorObject.vendorNumber} - ${vendorObject.vendorType} (${vendorObject.vendorName})` : `#${k.MVNDR_NBR}`,
                retail: null,
                cost: k.EFF_COST_AMT,
                requestid: k.REQUESTID,
                submitter: k.SUBMITTER,
                key: key++
              });
            }

          });
          this.determineArrowIndicator(costTimeline, "cost");

          let timeline = [...retailTimeline, ...costTimeline];
          timeline.sort((a, b) => b.beginDate - a.beginDate);


          setSkuTimelineMap(skuTimelineMap => {
            let tempSkuTimelineMap = {...skuTimelineMap};
            tempSkuTimelineMap[skuNumber] = timeline;
            return tempSkuTimelineMap;
          });

        })

  };

  static formInputDataUsingSearchType = (isOnline, multiSearchData, userId, dcsDataMap) => {
    let inputSearchData = multiSearchData && multiSearchData.input;
    let inputData = {};
    inputData.onlineOnly = isOnline;
    if (userId) {
      inputData.userId = userId;
    }
    if (inputSearchData.searchType === "FAV" || inputSearchData.searchType === "KVI") {
      inputData = {...inputData, skuNumbers: multiSearchData.skuList}
    } else if (inputSearchData.searchType === "VNDR") {
      inputData = {...inputData, merchandisingVendor: inputSearchData.vendorNumber}
    } else {
      inputData = {
        ...inputData, classNumber: inputSearchData.classNumber,
        department: inputSearchData.department,
        subClassNumber: inputSearchData.subClassNumber,
        subClassDescription: dcsDataMap ? getSubClassDescription(dcsDataMap, inputSearchData.department, inputSearchData.classNumber, inputSearchData.subClassNumber) : ""
      };
    }


    return inputData
  };


  static fetchMultiSearchPerformanceData = (multiSearchData, userId, isOnline, headerCommonFunction, dcsDataMap) => {
    let headerDataIndex = isOnline ? "online" : "inStore";
    let inputData = this.formInputDataUsingSearchType(isOnline, multiSearchData, userId, dcsDataMap);
    let skuPerformanceData = {};
    SingleAndMultiSkuServices.fetchMultiSearchPerformance(inputData).then(response => {
      skuPerformanceData = response.data;
    }).catch((e) => console.log(e)).finally(() => {
      headerCommonFunction(multiSkuHeaderData => ({
        ...multiSkuHeaderData, [headerDataIndex]: {
          ...multiSkuHeaderData[headerDataIndex],
          totalCompPercentage: skuPerformanceData.totalCompPercentage ? skuPerformanceData.totalCompPercentage : "-",
          totalUnitsPercentage: skuPerformanceData.totalUnitsPercentage ? skuPerformanceData.totalUnitsPercentage : "-",
          totalThisYearSales: skuPerformanceData.totalThisYearSales ? skuPerformanceData.totalThisYearSales : "-",
          totalThisYearUnits: skuPerformanceData.totalThisYearUnits ? skuPerformanceData.totalThisYearUnits : "-"
        }
      }));
    });
  };


  static fetchMinMaxRetailRange = (multiSearchData, isOnline, headerCommonFunction, dcsDataMap) => {
    let inputData = this.formInputDataUsingSearchType(isOnline, multiSearchData, "", dcsDataMap);
    let headerDataIndex = isOnline ? "online" : "inStore";
    let minMaxRetail = "";
    SingleAndMultiSkuServices.fetchMinMaxRetail(inputData)
        .then(response => minMaxRetail = minMaxRetailFormatter(response.data.minRetail, response.data.maxRetail))
        .catch(e => console.log(e))
        .finally(() =>
            headerCommonFunction(multiSkuHeaderData => ({
              ...multiSkuHeaderData,
              [headerDataIndex]: {...multiSkuHeaderData[headerDataIndex], minMaxRetail:{minMaxRetail}}
            })));
  };

  static  fetchMultiVendorData = (multiSearchData, isOnline, headerCommonFunction, skuList) => {
    let inputData = null;

    if (skuList) {
      inputData = {onlineOnly: isOnline, skuNumbers: skuList}
    } else {
      let inputSearchData = multiSearchData && multiSearchData.input;
      if (inputSearchData.searchType !== "VNDR") {
        inputData = this.formInputDataUsingSearchType(isOnline, multiSearchData, "", "");
      }
    }

    if (inputData) {
      let headerDataIndex = isOnline ? "online" : "inStore";
      let multiVendorList = [];

      SingleAndMultiSkuServices.fetchMultiSearchVendorList(inputData)
          .then(response => {
            multiVendorList = response.data;
          })
          .catch(e => console.log(e))
          .finally(() => {
            headerCommonFunction(multiSkuHeaderData => ({
              ...multiSkuHeaderData,
              [headerDataIndex]: {
                ...multiSkuHeaderData[headerDataIndex],
                multiVendorList: mergeAndRemoveDuplicates(multiSkuHeaderData[headerDataIndex].multiVendorList, multiVendorList, "vendorNumber")
              }
            }))
          });
    }
  };

  static fetchInStoreCPIDetails = (skuList, userId, setInStoreMultiSkuData) => {

    let inStoreCPIData = {};
    SingleAndMultiSkuServices.fetchCPIResponse(skuList, userId).then(
        response => {
          inStoreCPIData = response.data;
        }).catch(err => {
      console.log(err);
    }).finally(() => {
      setInStoreMultiSkuData(k =>
          ({
                ...k, skuRetailList: k.skuRetailList.map(skuData => {
                  let sku = skuData.skuNumber;
                  let cpiData = inStoreCPIData.hasOwnProperty(sku) ? CPIUtil.mergeCPIData("-", inStoreCPIData[sku]) : CPIUtil.defaultCPIData();
                  let primaryCompetitorData = Object.values(cpiData).find(k => k !== "-" && k.primaryCompetitor === "Y");
                  // primaryCompetitorData = primaryCompetitorData ? primaryCompetitorData : Object.values(cpiData).find(k => k !== "-" && k.primaryCompetitor !== "Y" && k.cpiDaily);

                  return {
                    ...skuData,
                    cpiData,
                    primaryCpiValue: primaryCompetitorData ? {
                      id: primaryCompetitorData.competitorId,
                      cpiDaily: primaryCompetitorData.cpiDaily
                    } : {}
                  };
                })
              }
          ));
    });
  }

  static fetchInstoreAggregatedCPI = (multiSearchData, skuList, userId, setMultiSkuHeaderData, dcsDataMap) => {
    let responseData = [];
    let frameResponseData = (promiseResponse, isSubClass) => {
      promiseResponse.then(
          response => {
            if (isSubClass) {
              responseData = response.data && Object.keys(response.data).length === 1 ? Object.values(response.data)[0] : [];
            } else {
              responseData = response.data;
            }
          }).catch(err => {
        console.log(err);
      }).finally(() => {

        setMultiSkuHeaderData(k => ({
          ...k,
          "inStore": {...k.inStore, aggregatedCPI: CPIUtil.mergeCPIData("-", responseData)}
        }));

      });
    }

    let isDiverseSearch = multiSearchData && Object.keys(multiSearchData).length > 0;
    let searchType = isDiverseSearch ? multiSearchData.input.searchType : "";

    if (isDiverseSearch && searchType === "DCS") {
      let inputSearchData = multiSearchData.input;
      let subClassDescription = dcsDataMap ? getSubClassDescription(dcsDataMap, inputSearchData.department, inputSearchData.classNumber, inputSearchData.subClassNumber) : "";
      let dcsFormat = inputSearchData.department.toString().padStart(3, "0") + "-" + inputSearchData.classNumber.toString().padStart(3, "0") + "-" + inputSearchData.subClassNumber.toString().padStart(3, "0");

      frameResponseData(SingleAndMultiSkuServices.fetchSubClassLevelCPI({
            "formattedSubClassName": dcsFormat + "-" + subClassDescription,
            "userId": userId
          }
      ), true);
    } else if ((isDiverseSearch && searchType !== "VNDR") || !isDiverseSearch) {
      frameResponseData(SingleAndMultiSkuServices.fetchAggregatedCPI(skuList, userId), false);
    }
  }

  static fetchInStoreAverageUnitRetail = (skuList, userId, setInStoreMultiSkuData) => {
    let inStoreAurData = {}
    SingleAndMultiSkuServices.fetchAverageUnitRetail(skuList, userId).then(
        response => {
          inStoreAurData = response.data;
        }).catch(err => {
          console.log(err);
    }).finally(() => {
      setInStoreMultiSkuData(k => ({
            ...k, skuRetailList: k.skuRetailList.map(skuData => {
              if (skuList.includes(skuData.skuNumber)) {
                return {...skuData, aur: inStoreAurData[skuData.skuNumber]}
              } else {
                return skuData
              }

            })
          }
      ));
    });
  }

  static fetchInStoreSkuRank = (skuList, setInStoreMultiSkuData) => {
    const inStoreRankDataFormatted = {}
    SingleAndMultiSkuServices.fetchSkuRank(skuList).then(
        response => {
          response.data.forEach(item => {
            inStoreRankDataFormatted[item.sku] = item.rank
          })
        }).catch(err => {
          console.log(err);
    }).finally(() => {
      setInStoreMultiSkuData(k => ({
            ...k, skuRetailList: k.skuRetailList.map(skuData => {
                return {...skuData, rank: inStoreRankDataFormatted[skuData.skuNumber]}
             })
      }))
  })
}

static fetchOnlineSkuRank = (skuList, setOnlineMultiSkuData) => {
  const onlineRankDataFormatted = {}
  SingleAndMultiSkuServices.fetchSkuRank(skuList).then(
      response => {
        response.data.forEach(item => {
          onlineRankDataFormatted[item.sku] = item.rank
        })
      }).catch(err => {
        console.log(err);
  }).finally(() => {
      setOnlineMultiSkuData(k => ({
            ...k, onlineSkuDetailList: k.onlineSkuDetailList.map(skuData => {
                  return {...skuData, rank: onlineRankDataFormatted[skuData.skuNumber]}
            })
      }))
})
}

  static updateFilterAggregate = (headerCommonFunction, headerDataIndex, data) => {
    headerCommonFunction(k => ({
      ...k, [headerDataIndex]: {
        ...k[headerDataIndex],
        filterHeaderData: {
          ...k[headerDataIndex].filterHeaderData,
          ...data
        }
      }
    }));
  }

  static filterAggregateCPI = (skuList, userId, setMultiSkuHeaderData) => {
    if (skuList.length > 0) {
      this.updateFilterAggregate(setMultiSkuHeaderData, "inStore", {aggregatedCPI: {}})
      let responseData = [];
      SingleAndMultiSkuServices.fetchAggregatedCPI(skuList.slice(0, 2000), userId)
          .then(response => responseData = response.data)
          .catch(err => console.log(err))
          .finally(() => {
            this.updateFilterAggregate(setMultiSkuHeaderData, "inStore", {aggregatedCPI: CPIUtil.mergeCPIData("-", responseData)});

          });
    } else {
      this.updateFilterAggregate(setMultiSkuHeaderData, "inStore", {aggregatedCPI: CPIUtil.mergeCPIData("-", [])});
    }
  }

  static filterAggregatePerformance(skuList, userId, isOnline, headerCommonFunction) {
    let headerDataIndex = isOnline ? "online" : "inStore";
    if (skuList.length > 0) {
      this.updateFilterAggregate(headerCommonFunction, headerDataIndex,
          {
            totalThisYearSales: "",
            totalCompPercentage: "",
            totalThisYearUnits: "",
            totalUnitsPercentage: ""
          });


      let skuPerformanceData = {};
      SingleAndMultiSkuServices.fetchMultiSKUPerformance(skuList.slice(0, 2000), userId, isOnline, null)
          .then(k => {
            skuPerformanceData = k.data;
          })
          .catch(err => {
            console.log(err);
          }).finally(() => {
        this.updateFilterAggregate(headerCommonFunction, headerDataIndex,
            {
              totalCompPercentage: skuPerformanceData.totalCompPercentage ? skuPerformanceData.totalCompPercentage : "-",
              totalUnitsPercentage: skuPerformanceData.totalUnitsPercentage ? skuPerformanceData.totalUnitsPercentage : "-",
              totalThisYearSales: skuPerformanceData.totalThisYearSales ? skuPerformanceData.totalThisYearSales : "-",
              totalThisYearUnits: skuPerformanceData.totalThisYearUnits ? skuPerformanceData.totalThisYearUnits : "-"
            });
      });
    } else {
      this.updateFilterAggregate(headerCommonFunction, headerDataIndex,
          {
            totalThisYearSales: "-",
            totalCompPercentage: "-",
            totalThisYearUnits: "-",
            totalUnitsPercentage: "-"
          });
    }
  }

  static filteredMinMaxRetailOnline = (filteredOnlineData, setMultiSkuHeaderData) => {
    let output = "-";
    if (filteredOnlineData.length !== 0) {
      let minAndMaxRetail = filteredOnlineData.filter(k => k.effectiveRetail).map(k => k.effectiveRetail);
      let minRetail = Math.min(...minAndMaxRetail);
      let maxRetail = Math.max(...minAndMaxRetail);

      output = minMaxRetailFormatter(minRetail, maxRetail);
    }

    this.updateFilterAggregate(setMultiSkuHeaderData, "online",
        {minMaxRetail: {minMaxRetail:output}});
  }

  static calculateInStoreMinMaxRetail = (inStoreTableData, setMultiSkuHeaderData,isUpdate) => {
    let output = "-";
    let minRetail = "-";
    let maxRetail = "-";
    if (inStoreTableData.length !== 0) {
      let minAndMaxRetail = new Set();
      inStoreTableData.forEach(k => {
        if(k.minRetail && !isNaN(k.minRetail)){
          minAndMaxRetail.add(k.minRetail);
        }
        if(k.maxRetail && !isNaN(k.maxRetail)){
          minAndMaxRetail.add(k.maxRetail);
        }});
      minRetail = Math.min(...[...minAndMaxRetail]);
      maxRetail = Math.max(...[...minAndMaxRetail]);

      output = minMaxRetailFormatter(minRetail, maxRetail);
    }

    if(isUpdate) {
      this.updateFilterAggregate(setMultiSkuHeaderData, "inStore",
          {minMaxRetail: {minMaxRetail: output}});
    }
    return {minRetail,maxRetail,minMaxRetail:output}
  }

  // static fetchInStoreMaxCost = (skuList, userId, setInStoreMultiSkuData) => {
  //   let inStoreMaxCostData = {}
  //   SingleAndMultiSkuServices.fetchMaxCost(skuList, userId).then(
  //       response => {
  //         inStoreMaxCostData = response.data;
  //       }).catch(err => {
  //     console.log(err);
  //   }).finally(() => {
  //     setInStoreMultiSkuData(k => ({
  //           ...k, skuRetailList: k.skuRetailList.map(skuData => {
  //             if (skuList.includes(skuData.skuNumber)) {
  //               return {...skuData, maxCost: inStoreMaxCostData[skuData.skuNumber]}
  //             } else {
  //               return skuData
  //             }
  //
  //           })
  //         }
  //     ));
  //   });
  // }

  // static fetchInStoreMinCost = (skuList, userId, setInStoreMultiSkuData) => {
  //   let inStoreMinCostData = {}
  //   SingleAndMultiSkuServices.fetchMinCost(skuList, userId).then(
  //       response => {
  //         inStoreMinCostData = response.data;
  //       }).catch(err => {
  //     console.log(err);
  //   }).finally(() => {
  //     setInStoreMultiSkuData(k => ({
  //           ...k, skuRetailList: k.skuRetailList.map(skuData => {
  //             if (skuList.includes(skuData.skuNumber)) {
  //               return {...skuData, minCost: inStoreMinCostData[skuData.skuNumber]}
  //             } else {
  //               return skuData
  //             }
  //
  //           })
  //         }
  //     ));
  //   });
  // }

  // static fetchInStoreModeCost = (skuList, userId,onlineOnly, setInStoreMultiSkuData) => {
  //   let inStoreModeCostData = {}
  //   SingleAndMultiSkuServices.fetchModeCost(skuList, userId,onlineOnly).then(
  //       response => {
  //         inStoreModeCostData = response.data;
  //       }).catch(err => {
  //     console.log(err);
  //   }).finally(() => {
  //     setInStoreMultiSkuData(k => ({
  //           ...k, skuRetailList: k.skuRetailList.map(skuData => {
  //             if (skuList.includes(skuData.skuNumber)) {
  //               return {...skuData, modeCost: inStoreModeCostData[skuData.skuNumber]}
  //             } else {
  //               return skuData
  //             }
  //
  //           })
  //         }
  //     ));
  //   });
  // }

  static fetchVendorsBySkus = (skuList,onlineOnly, setInStoreMultiSkuData) => {
    let vendorsBySkusData = {}
    SingleAndMultiSkuServices.vendorsBySkus(skuList,onlineOnly).then(
        response => {
          vendorsBySkusData = response.data;
        }).catch(err => {
      console.log(err);
    }).finally(() => {
      setInStoreMultiSkuData(k => ({
            ...k, skuRetailList: k.skuRetailList.map(skuData => {
              if (skuList.includes(skuData.skuNumber)) {
                return {...skuData, vendors: vendorsBySkusData[skuData.skuNumber]}
              } else {
                return skuData
              }

            })
          }
      ));
    });
  }

  static fetchCurrentCostBySku =(skuList,setInStoreMultiSkuData) => {
    SingleAndMultiSkuServices.currentCostBySku(skuList).then(
        response => {
          let currentCost = response.data;
          let finalData = currentCost.reduce((total,current) => ({...total,[current.sku]:current.cost}),{})
          setInStoreMultiSkuData( k => ({
            ...k, skuRetailList: k.skuRetailList.map(data => {
              if(skuList.includes(data.skuNumber)){
                return {...data, currentCost: finalData[data.skuNumber] / 100}
              } else {
                return data;
              }
            })
          }))
        }
    ).catch(err => {
      console.log(err);
    })
  }

}

