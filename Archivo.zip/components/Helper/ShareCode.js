export const encryptSharedCode = (shareableData) => {
  const stringifyObj = JSON.stringify(shareableData);
  return btoa(stringifyObj);
};
export const decryptSharedCode = (base64String) => {
  const bufferData = atob(base64String);
  return JSON.parse(bufferData);
};
