import React from 'react';
import { decryptSharedCode, encryptSharedCode } from './ShareCode';
import {shareCodeResponse} from "../Pages/EditPricePage/__fixtures__/shareCodeResponse";

describe('ShareCode', () => {
    const shareCodeObject = {
        skuGroupId: 'b86b37d5-9b82-4bee-9c5e-655fb899027d',
        skuGroupName: 'ABS Only Pipe',
        skus: [
            193801, 193798,
            193828, 193836,
            372764, 372813,
            373226, 373249,
            649323, 649337
        ],
        zoneGroupMultiplierId: '323e5e5b-f350-4cc9-b91f-64e07e055482',
    }
    const base64String = 'eyJza3VHcm91cE5hbWUiOiIiLCJza3VzIjpbMzAxMzI5LDE5MTM5Nl0sInpvbmVHcm91cE11bHRpcGxpZXJJZCI6IjdjMGI3ODM0LTAzYzgtNDc4My1iNTU3LWY0ZWQ5ODdmZjdkNSIsImNvc3RzIjp7IjE5MTM5NiI6IjIuMDAiLCIzMDEzMjkiOiIxLjAwIn0sInJldGFpbHMiOnsiMTkxMzk2Ijp7ImVjYjE1MTZmLWE2ZTktNDYzMC04MTllLTIzMmYzMDgxMGU3YiI6eyJyZXRhaWwiOiIwLjQ5IiwiaXNNYW51YWxFZGl0IjpmYWxzZX0sIjRmMWRiNzJmLTgyMzEtNGQ1Zi1hZGJlLTVhY2ZhZjE5NTM1ZSI6eyJyZXRhaWwiOiIwLjQ3IiwiaXNNYW51YWxFZGl0IjpmYWxzZX0sIjExZjkwMDljLTFhOTYtNDcxOC04YjY5LTQzNzg4ODFiZDU5OSI6eyJyZXRhaWwiOiIwLjM0IiwiaXNNYW51YWxFZGl0IjpmYWxzZX0sIjBjMjhmZDc0LTYyMTQtNGRkNi1iMGVhLTEzMThhMTY3ODlmNyI6eyJyZXRhaWwiOiIwLjQzIiwiaXNNYW51YWxFZGl0IjpmYWxzZX19LCIzMDEzMjkiOnsiMGMyOGZkNzQtNjIxNC00ZGQ2LWIwZWEtMTMxOGExNjc4OWY3Ijp7InJldGFpbCI6IjEuMDAiLCJpc01hbnVhbEVkaXQiOmZhbHNlfSwiZWNiMTUxNmYtYTZlOS00NjMwLTgxOWUtMjMyZjMwODEwZTdiIjp7InJldGFpbCI6IjEuMTUiLCJpc01hbnVhbEVkaXQiOmZhbHNlfSwiNGYxZGI3MmYtODIzMS00ZDVmLWFkYmUtNWFjZmFmMTk1MzVlIjp7InJldGFpbCI6IjEuMTAiLCJpc01hbnVhbEVkaXQiOmZhbHNlfSwiMTFmOTAwOWMtMWE5Ni00NzE4LThiNjktNDM3ODg4MWJkNTk5Ijp7InJldGFpbCI6IjAuODAiLCJpc01hbnVhbEVkaXQiOmZhbHNlfX19fQ==';
  it('decode base64 string to object', () => {
    const res = decryptSharedCode(base64String);
    expect(res).toEqual(shareCodeResponse);
  });
  it('encode object to base 64 string', () => {
    const res = encryptSharedCode(shareCodeResponse);
    expect(res).toEqual(base64String);
  });
  it('decodes successfully without optional cost and retails',()=>{
    const shareCode='eyJza3VHcm91cElkIjoiYjg2YjM3ZDUtOWI4Mi00YmVlLTljNWUtNjU1ZmI4OTkwMjdkIiwic2t1R3JvdXBOYW1lIjoiQUJTIE9ubHkgUGlwZSIsInNrdXMiOlsxOTM4MDEsMTkzNzk4LDE5MzgyOCwxOTM4MzYsMzcyNzY0LDM3MjgxMywzNzMyMjYsMzczMjQ5LDY0OTMyMyw2NDkzMzddLCJ6b25lR3JvdXBNdWx0aXBsaWVySWQiOiIzMjNlNWU1Yi1mMzUwLTRjYzktYjkxZi02NGUwN2UwNTU0ODIifQ==';
    const res = decryptSharedCode(shareCode);
    expect(res).toEqual(shareCodeObject);
  });

  it('test for mandatory fields in json', () => {
    const base64Str_noZoneGroup = encryptSharedCode({...shareCodeObject,zoneGroupMultiplierId:''});
      const result_noZoneGroup = decryptSharedCode(base64Str_noZoneGroup);
      expect(result_noZoneGroup).toEqual({...shareCodeObject,zoneGroupMultiplierId:''});
      const base64Str_noSkus = encryptSharedCode({...shareCodeObject,skus:[]});
      const result_noSkus = decryptSharedCode(base64Str_noSkus);
      expect(result_noSkus).toEqual({...shareCodeObject,skus:[]});
  });
});
