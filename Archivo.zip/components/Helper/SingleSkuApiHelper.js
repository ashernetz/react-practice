import {
  dcsFormatter,
  isErroredResponse,
  minMaxRetailFormatter
} from "../Utils/CommonUtil";
import SingleAndMultiSkuServices from "../../services/SingleAndMultiSkuServices";
import MultiSkuApiHelper from "./MultiSkuApiHelper";
import CPIUtil from "../Utils/CPIUtil";

export default class SingleSkuApiHelper {

  static fetchSingleSkuOnlineData(sellingChannelData,onlineSingleSkuApiTriggers,setSingleSkuHeaderData,setSingleSkuLoadInfo) {

    let isOnlineLoaded = false;
    SingleAndMultiSkuServices.onlineSearch(Object.keys(sellingChannelData.onlineSkus).map(k=>parseInt(k)) ).then(response => {

      let skuList = response.data.onlineSkuDetailList.map(k => k.skuNumber);

      if(skuList.length>0){
        isOnlineLoaded = true;
        let singleSkuHeaderObject = sellingChannelData.onlineSkus[skuList[0]];
        response.data.onlineSkuDetailList[0].omsIdAndVendorData.omsIdList =  sellingChannelData.onlineSkus[skuList[0]].omsId;

        setSingleSkuHeaderData(singleSkuHeaderData => {
            let vendorList =  response.data.onlineSkuDetailList[0].omsIdAndVendorData.vendorList;
            let omsIdList = response.data.onlineSkuDetailList[0].omsIdAndVendorData.omsIdList;
            singleSkuHeaderData.online.skuDescription = singleSkuHeaderObject.skuDescription;
            singleSkuHeaderData.online.dcsTitle = dcsFormatter(singleSkuHeaderObject.department,singleSkuHeaderObject.classNumber,singleSkuHeaderObject.subClass);
            singleSkuHeaderData.online.skuTitle =  skuList[0];
            singleSkuHeaderData.online.omsIdList =  omsIdList;
            singleSkuHeaderData.online.omsIdTitle = omsIdList.length === 0 ? " ": (omsIdList.length === 1? "OMSID "+ omsIdList[0]: omsIdList.length + " OMSIDs");
            singleSkuHeaderData.online.vendorName = vendorList.length === 0 ?"NO ACTIVE VENDORS": (vendorList.length === 1? vendorList[0].vendorName:"MULTIPLE VENDORS");
            singleSkuHeaderData.online.minMaxRetail = minMaxRetailFormatter(response.data.minimumRetail, response.data.maximumRetail);
            singleSkuHeaderData.online.effectiveRetail = response.data.onlineSkuDetailList[0].effectiveRetail;
            singleSkuHeaderData.online.effectiveCost = response.data.onlineSkuDetailList[0].effectiveCost;
            singleSkuHeaderData.online.vendorNumber = vendorList.length === 0 ?0: (vendorList.length === 1? vendorList[0].vendorNumber:0);
            singleSkuHeaderData.online.permRetail = response.data.onlineSkuDetailList[0].permRetail;
            singleSkuHeaderData.online.retailType = response.data.onlineSkuDetailList[0].retailType;

          return singleSkuHeaderData;
            });

        onlineSingleSkuApiTriggers(skuList,response.data.onlineSkuDetailList[0].omsIdAndVendorData);


      }

    }).catch(err => {
      // let alertMessage = AlertUtil.getErrorMessage("performing online search");
      // if (err.response.status === 422) {
      //   alertMessage = <div>No valid SKus or OMSId present</div>;
      //   console.log(err.response.data);
      // }

      console.log(err);
    }).finally(()=>setSingleSkuLoadInfo(data => {
      let singleSkuLoadData = {...data};
      singleSkuLoadData.isOnlineLoaded = isOnlineLoaded;
      return singleSkuLoadData;
    }));
  }

  static fetchOnlineOhQuantity(skuList, setSingleSkuHeaderData) {
    let ohQuantity = "-";
    SingleAndMultiSkuServices.fetchOnHandQuantity(skuList)
        .then(response => {
          ohQuantity = response.data ?
              Object.values(response.data).reduce((a, b) => a + b,0)
              : "-";
        })
        .catch(err => console.error(err))
        .finally(
            () => setSingleSkuHeaderData(singleSkuHeaderData => {
            singleSkuHeaderData.online.onHandQuantity = ohQuantity;
          return singleSkuHeaderData;
        })
    );
  }


  static fetchSingleSkuPerformance(skuList,userId,isOnline,headerCommonFunction,updateInStoreSkuPerformance){
    let resultantResponse = {};
    if(!isOnline){
      updateInStoreSkuPerformance({});
    }
    SingleAndMultiSkuServices.fetchMultiSKUPerformance(skuList, userId, isOnline)
        .then(k => {
          resultantResponse = k.data;
        })
        .catch(err => {
          console.log(err);
        }).finally(()=>
        this.fillCompAndUnitsForEachSku(resultantResponse,headerCommonFunction,
        isOnline,skuList[0],updateInStoreSkuPerformance));
  }


  static fillCompAndUnitsForEachSku(skuPerformanceData,headerCommonFunction,
      isOnline,sku,updateInStoreSkuPerformance) {
    let headerDataIndex = isOnline?"online":"inStore";
    let skuCompMap = skuPerformanceData && skuPerformanceData.skuCompMap && skuPerformanceData.skuCompMap.hasOwnProperty(sku)? skuPerformanceData.skuCompMap[sku]:{};

    let perfData = {totalCompPercentage : skuCompMap.compPercentage ? skuCompMap.compPercentage : "-",
      totalUnitsPercentage : skuCompMap.unitsPercentage ? skuCompMap.unitsPercentage : "-",
      totalThisYearSales : skuPerformanceData.totalThisYearSales ? skuPerformanceData.totalThisYearSales : "-",
      totalThisYearUnits : skuPerformanceData.totalThisYearUnits ? skuPerformanceData.totalThisYearUnits : "-"}
    headerCommonFunction(singleSkuHeaderData => ({...singleSkuHeaderData,[headerDataIndex]:{...singleSkuHeaderData[headerDataIndex],
         ...perfData}
    }));
    if(!isOnline){
      updateInStoreSkuPerformance({...perfData});
    }

  };


  static getOnlineRetailTimelineData = (skuList, omsIdVendorObject,setSkuTimelineMap) => {

    MultiSkuApiHelper.getOnlineRetailTimelineData(skuList[0], omsIdVendorObject,setSkuTimelineMap);

  };

  static determineArrowIndicator  (timeline, checkKey) {
    let runningAmount = 0;
    timeline.sort((a, b) => a.beginDate - b.beginDate);

    timeline.forEach(k => {
      let arrowIndicator;
      if (runningAmount === 0 || runningAmount === k[checkKey]) {
        arrowIndicator = "";
      } else if (k[checkKey] > runningAmount) {
        arrowIndicator = "arrow-up";
      } else {
        arrowIndicator = "arrow-down";
      }
      k.arrowIndicator = arrowIndicator;
      runningAmount = k[checkKey];

    });
  };

  static getZonePerformanceData = (skuNumber,userId,setSkuZonePerformance) => {
  
    SingleAndMultiSkuServices.fetchSkuZonePerformanceData(skuNumber,userId)
        .then(k => {
          let resultantResponse = k.data;
          if(resultantResponse.zonePerformanceData && (resultantResponse.zonePerformanceData).length>0){
            resultantResponse.zonePerformanceData.forEach(zoneData=>{
              zoneData.storeCount = zoneData.storePerformanceData.length
            });
            setSkuZonePerformance({is5xx:false,data:{...resultantResponse}});
          }               
        })
        .catch(err => {
          setSkuZonePerformance({is5xx:isErroredResponse(err),data:{}});
          console.log(err);
        });

  };

  static fillSkuRatingData = (skuObject, setSingleSkuLoadInfo) => {
    if (skuObject && skuObject.omsId && skuObject.omsId.length > 0) {
      let omsId = skuObject.omsId[0];
      SingleAndMultiSkuServices.fetchProductRating(omsId).then(k => {
        let resultantResponse = k.data;
        if (resultantResponse) {
          setSingleSkuLoadInfo(skuInfo => ({
            ...skuInfo,
            skuRatingCount: resultantResponse.totalReviewCount ? resultantResponse.totalReviewCount : 0,
            skuRatingValue: resultantResponse.averageOverallRating ? resultantResponse.averageOverallRating : 0
          }));
        }
      }).catch(err => {
        console.log(err);
      })
     
    }
  };

  static fetchSalesPerformanceData=(skuNumber,userId,onlineOnly,setSalesPerformanceData) =>{
    SingleAndMultiSkuServices.fetchSkuSalesPerformance(skuNumber,userId,onlineOnly).then(response =>{
      let performanceData = {
        "currentYearPerformance": [...response.data.currentYearPerformance],
        "lastYearPerformance": [...response.data.lastYearPerformance],
        //"totalData": [...response.data.currentYearPerformance,...response.data.lastYearPerformance]
      };
    let checkUpOrDown = (current,last)=>((current && last) ?((current>last?"arrow-up": current < last?"arrow-down":"")):"");
      performanceData.currentYearPerformance.forEach(k=>{
        let lastYearData = performanceData.lastYearPerformance.find(v=>v.fiscalWeek===k.fiscalWeek);
            k.unitsUpOrDown = lastYearData?checkUpOrDown(k.rawUnitsSold,lastYearData.rawUnitsSold):"";
            k.salesUpOrDown =lastYearData?checkUpOrDown(k.rawSalesAmount,lastYearData.rawSalesAmount):"";
      });
      performanceData.currentYearPerformance.sort((a, b) => b.fiscalWeek.localeCompare(a.fiscalWeek));
      //performanceData.totalData.sort((a, b) => a.fiscalWeek.localeCompare(b.fiscalWeek));
      performanceData.currentYear = performanceData.currentYearPerformance[0]?performanceData.currentYearPerformance[0].fiscalYear:"";
      performanceData.lastYear = performanceData.lastYearPerformance[0]?performanceData.lastYearPerformance[0].fiscalYear:"";
      setSalesPerformanceData({is5xx:false,data:performanceData});
        }).catch(error => {
      setSalesPerformanceData({is5xx:isErroredResponse(error),data:{}});
            console.log(error);
        });

  };

  static fetchDailyInStockSalesData = (skuNumber, setSingleSkuHeaderData) => {
    let dailyISS = "-";
    SingleAndMultiSkuServices.fetchDailyISS(skuNumber)
        .then(response => {
          if (response && response.data && response.data.istsPercentage) {
            dailyISS = response.data.istsPercentage;
          }
        })
        .catch(error => console.log("Error occurred while calling dailyISS API" + error))
        .finally(() => {
          setSingleSkuHeaderData(k => ({...k,inStore:{...k.inStore,dailyISS}}));
        });
  };

  static checkForMultipleOMSScenario = (sellingChannelResponse,setOnlineMultiOMSIdData, setSingleSkuLoadInfo,onMultiOMSIdSkuClick,selectedType) => {
    let fetchKeysOrder=selectedType === "online" ? ["onlineSkus","coreSkus"]:["coreSks","onlineSks"];
    let isOnlineOrInStoreLoad = selectedType === "online"? "isOnlineLoaded": "isInStoreLoaded";
    let onlineMultipleOmsIdData = {data: {}, isOnlineLoaded:false,isInStoreLoaded:false};

    let defaultConditionalMethod = (tempData) => {
      setOnlineMultiOMSIdData(k=>({...k,...tempData}));
      setSingleSkuLoadInfo(k => ({...k,[isOnlineOrInStoreLoad]: false}));
    };

    if (Object.keys(sellingChannelResponse[fetchKeysOrder[0]]).length === 0 && Object.keys(sellingChannelResponse[fetchKeysOrder[1]]).length > 0) {
      let omsIdList = Object.values(sellingChannelResponse[fetchKeysOrder[1]])[0].omsId;
      if (omsIdList && omsIdList.length > 0) {
        SingleAndMultiSkuServices.determineSellingChannel([],omsIdList.map(k => Number.parseInt(k)))
            .then(responseData => {
              if (responseData && responseData.data && responseData.data[fetchKeysOrder[0]] && Object.keys(responseData.data[fetchKeysOrder[0]]).length > 0) {
                onlineMultipleOmsIdData = { data: responseData.data, [isOnlineOrInStoreLoad]: true };

              }
            })
            .catch(err => console.log(err))
            .finally(() => {

              if(onlineMultipleOmsIdData[isOnlineOrInStoreLoad]===true && Object.keys(onlineMultipleOmsIdData.data[fetchKeysOrder[0]]).length===1){
                onMultiOMSIdSkuClick(Object.keys(onlineMultipleOmsIdData.data[fetchKeysOrder[0]])[0],onlineMultipleOmsIdData.data,selectedType,true)
              }else{
                if(onlineMultipleOmsIdData[isOnlineOrInStoreLoad]===true){
                  SingleAndMultiSkuServices.fetchVendorNames(Object.keys(onlineMultipleOmsIdData.data[fetchKeysOrder[0]]).map(k=>Number.parseInt(k)),selectedType === "online"?true:false)
                      .then(response => {
                        if(response && response.data){
                          Object.values(onlineMultipleOmsIdData.data[fetchKeysOrder[0]]).forEach(skuObject => {
                            skuObject.vendorName=response.data[skuObject.skuNumber]?response.data[skuObject.skuNumber][0]:"-"
                          })
                        }
                      })
                      .catch(err=>console.log(err))
                      .finally(()=>{
                        defaultConditionalMethod(onlineMultipleOmsIdData);
                  })
                }else {
                  defaultConditionalMethod(onlineMultipleOmsIdData);
                }
              }
            });
      }else {
        defaultConditionalMethod(onlineMultipleOmsIdData);
      }
    }else {
      defaultConditionalMethod(onlineMultipleOmsIdData);
    }

  };

  static fetchMultipleVendor(sku,isOnline, headerCommonFunction) {
    let multiVendorList = [];
    let headerDataIndex = isOnline?"online":"inStore";

    SingleAndMultiSkuServices.fetchMultipleVendor(sku,isOnline)
    .then(response => {
      multiVendorList = response.data;
    })
    .catch(err => console.error(err))
    .finally(
        () => headerCommonFunction(singleSkuHeaderData => ({...singleSkuHeaderData,[headerDataIndex]:{...singleSkuHeaderData[headerDataIndex],
            multiVendorList}}))
    );
  }

  static getInStoreCPIDataForSKU = (sku,userId,setSingleSkuHeaderData) => {

    let inStoreCPIData = [];
    SingleAndMultiSkuServices.fetchCPIResponse([sku], userId).then(
        response => {
          if(response.data && response.data[sku] && response.data[sku].length >0) {
              inStoreCPIData = response.data[sku];
          }
        }).catch(err => {
      console.log(err);
    }).finally(() => {

      setSingleSkuHeaderData(k =>
          ({
                ...k,"inStore":{ ...k.inStore,cpiData:CPIUtil.mergeCPIData("-",inStoreCPIData)}
              }
          ));
    });

  };

    static fetchLocalizedRetailStores(skuNumber,setStoreList) {
        SingleAndMultiSkuServices.localizedRetailStores(parseInt(skuNumber))
            .then(resp => {
                if (resp.status === 200 && resp.data.storeDetail) {
                    resp.data.storeDetail.forEach(row =>{
                        row['storeName'] = row.storeName +", "+row.stateCode;
                    })
                    setStoreList(resp.data.storeDetail);
                }else
                    setStoreList([]);

            })
            .catch(err => {
                console.log(err);
                setStoreList([]);
            });
    }



}
