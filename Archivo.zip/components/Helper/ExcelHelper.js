import {formatNumberToCompact} from "../Utils/CommonUtil";
import CompUtil from "../Utils/CompUtil";
import CPIUtil from "../Utils/CPIUtil";

function onlineMultiSKUExcelDataMapper (filteredOnlineData,tempOnlineHeaderData,isFilterApplied) {
  let onlineHeaderData = JSON.parse(JSON.stringify(tempOnlineHeaderData));
  if(isFilterApplied){
    onlineHeaderData = {...onlineHeaderData,...onlineHeaderData.filterHeaderData};
  }
  let HEADER_DATA = {
    "0":{
      "TOTAL_PRODUCTS": filteredOnlineData.length + " Products",
      "MIN_MAX_RETAIL": onlineHeaderData.minMaxRetail ? onlineHeaderData.minMaxRetail : " ",
      "SALES": onlineHeaderData.totalThisYearSales ? onlineHeaderData.totalThisYearSales : " ",
      "SALES_PERCENTAGE": onlineHeaderData.totalCompPercentage ? CompUtil.formatPrice(onlineHeaderData.totalCompPercentage)/100 : " ",
      "UNITS": onlineHeaderData.totalThisYearUnits ? onlineHeaderData.totalThisYearUnits : " ",
      "UNITS_PERCENTAGE": onlineHeaderData.totalUnitsPercentage ? CompUtil.formatPrice(onlineHeaderData.totalUnitsPercentage)/100 : " ",
      "OH_QUANTITY": onlineHeaderData.onHandQuantity ? onlineHeaderData.onHandQuantity : " "
    }
  };
  let totalRows =[];

  const vendorData = (each) => {
    let vendorObject = {VENDOR_NO:"",VENDOR_NAME:"",VENDOR_TYPE:""};
    if(each.omsIdAndVendorData.vendorList.length > 0){
      let vendorData = each.omsIdAndVendorData.vendorList[0];
      vendorObject = each.omsIdAndVendorData.vendorList.length > 1?
          {VENDOR_NO:"MULTIPLE",VENDOR_NAME:"MULTIPLE",VENDOR_TYPE:"MULTIPLE"}:
          {VENDOR_NO:vendorData.vendorNumber,VENDOR_NAME:vendorData.vendorName,VENDOR_TYPE:vendorData.vendorType};
    }
    return vendorObject;
  };

  filteredOnlineData.forEach(each=> {
    let rowData = {
      "OMS_ID": each.omsIdAndVendorData.omsIdList.length > 0
          ? (each.omsIdAndVendorData.omsIdList.length > 1
              ? each.omsIdAndVendorData.omsIdList.toString()
              : each.omsIdAndVendorData.omsIdList[0]) : " ",
      "STORE_SKU":each.skuNumber ? each.skuNumber : " ",
      "EFF_RETAIL":each.effectiveRetail ? each.effectiveRetail : " ",
      "RETAIL_TYPE":each.retailType ? each.retailType : " ",
      "PROMOTION_BEGIN_DATE": each.effectiveBeginDate ? each.effectiveBeginDate : " ",
      "PROMOTION_END_DATE": each.effectiveEndDate ? each.effectiveEndDate : " ",
      "PERM_RETAIL":each.permRetail ? each.permRetail : " ",
      "PROMO_MAP":each.mapRetail ? each.mapRetail:"",
      "EFF_COST":each.effectiveCost ? each.effectiveCost : " ",
      "COST_TYPE":each.costType ? each.costType :" ",
      "PERM_COST":each.permCost ? each.permCost :" ",
      "COMP":each.compPercentage === "-" ? " ":CompUtil.formatPrice(each.compPercentage)/100,
      "RAW_SALES": each.rawSales === "-" ? " ": CompUtil.formatMuMdPrice(each.rawSales, true),
      "UNITS":each.unitsPercentage === "-" ? " ": CompUtil.formatPrice(each.unitsPercentage)/100,
      "RAW_UNITS": each.rawUnits === "-" ? " ": formatNumberToCompact(each.rawUnits),
     ...vendorData(each),
      "DCS" : [each.department,each.classNumber,each.subClass].join("-")
    };
    totalRows.push(rowData);
  });

  return {HEADER_DATA,ROW_DATA:{0:totalRows}}

}

function inStoreMultiSKUExcelDataMapper (filteredInStoreData,tempInStoreHeaderData,isFilterApplied) {
  let inStoreHeaderData = JSON.parse(JSON.stringify(tempInStoreHeaderData));
  if(isFilterApplied){
    inStoreHeaderData = {...inStoreHeaderData,...inStoreHeaderData.filterHeaderData};
  }
  let lowSalesCoverage = (inStoreHeaderData.aggregatedCPI[3141] === "-" ||  !inStoreHeaderData.aggregatedCPI[3141]) ? "NA" : CompUtil.formatPrice(inStoreHeaderData.aggregatedCPI[3141].cpiSalesCovDlyPercentage)+"%";
  let menSalesCoverage = (inStoreHeaderData.aggregatedCPI[6488] === "-" ||  !inStoreHeaderData.aggregatedCPI[6488]) ? "NA" : CompUtil.formatPrice(inStoreHeaderData.aggregatedCPI[6488].cpiSalesCovDlyPercentage)+"%";
  let fdSalesCoverage =  (inStoreHeaderData.aggregatedCPI[588623] === "-" ||  !inStoreHeaderData.aggregatedCPI[588623]) ? "NA" : CompUtil.formatPrice(inStoreHeaderData.aggregatedCPI[588623].cpiSalesCovDlyPercentage)+"%";
  let amzSalesCoverage = (inStoreHeaderData.aggregatedCPI[18214] === "-" ||  !inStoreHeaderData.aggregatedCPI[18214]) ? "NA" : CompUtil.formatPrice(inStoreHeaderData.aggregatedCPI[18214].cpiSalesCovDlyPercentage)+"%";
  let walSalesCoverage = (inStoreHeaderData.aggregatedCPI[527] === "-" ||  !inStoreHeaderData.aggregatedCPI[527]) ? "NA" : CompUtil.formatPrice(inStoreHeaderData.aggregatedCPI[527].cpiSalesCovDlyPercentage)+"%";

  let lowSales = (inStoreHeaderData.aggregatedCPI[3141] === "-" ||  !inStoreHeaderData.aggregatedCPI[3141]) ? "NA" : CompUtil.formatMuMdPrice(inStoreHeaderData.aggregatedCPI[3141].cpiSalesCovDollarDlyDenom,true);
  let menSales= (inStoreHeaderData.aggregatedCPI[6488] === "-" ||  !inStoreHeaderData.aggregatedCPI[6488]) ? "NA" : CompUtil.formatMuMdPrice(inStoreHeaderData.aggregatedCPI[6488].cpiSalesCovDollarDlyDenom,true);
  let fdSales = (inStoreHeaderData.aggregatedCPI[588623] === "-" ||  !inStoreHeaderData.aggregatedCPI[588623]) ? "NA" : CompUtil.formatMuMdPrice(inStoreHeaderData.aggregatedCPI[588623].cpiSalesCovDollarDlyDenom,true);
  let amzSales =(inStoreHeaderData.aggregatedCPI[18214] === "-" ||  !inStoreHeaderData.aggregatedCPI[18214]) ? "NA" : CompUtil.formatMuMdPrice(inStoreHeaderData.aggregatedCPI[18214].cpiSalesCovDollarDlyDenom,true);
  let walSales = (inStoreHeaderData.aggregatedCPI[527] === "-" ||  !inStoreHeaderData.aggregatedCPI[527]) ? "NA" : CompUtil.formatMuMdPrice(inStoreHeaderData.aggregatedCPI[527].cpiSalesCovDollarDlyDenom,true);


  let HEADER_DATA = {
    "0":{
      "SEARCH_TYPE": inStoreHeaderData.dcsTitle,
      "TOTAL_PRODUCTS": filteredInStoreData.length + " Products",
      "SALES": inStoreHeaderData.totalThisYearSales ? inStoreHeaderData.totalThisYearSales : " ",
      "SALES_PERCENTAGE": inStoreHeaderData.totalCompPercentage ? CompUtil.formatPrice(inStoreHeaderData.totalCompPercentage)/100 : " ",
      "UNITS": inStoreHeaderData.totalThisYearUnits ? inStoreHeaderData.totalThisYearUnits : " ",
      "UNITS_PERCENTAGE": inStoreHeaderData.totalUnitsPercentage ? CompUtil.formatPrice(inStoreHeaderData.totalUnitsPercentage)/100 : " "
    },
    "1": {
      "SEARCH_TYPE": inStoreHeaderData.dcsTitle,
      "TOTAL_PRODUCTS": filteredInStoreData.length + " Products"
    },
    "2": {
      "SEARCH_TYPE": inStoreHeaderData.dcsTitle,
      "TOTAL_PRODUCTS": filteredInStoreData.length + " Products",

      "LOW_CPI": (inStoreHeaderData.aggregatedCPI[3141] === "-" ||  !inStoreHeaderData.aggregatedCPI[3141]) ? "NA" : CPIUtil.formatCPI(inStoreHeaderData.aggregatedCPI[3141].cpiDaily),
      "LOW_SALES_COVERAGE": lowSalesCoverage ? lowSalesCoverage : "NA",
      "LOW_SALES": lowSales ? lowSales.toString() : "NA",

      "MEN_CPI": (inStoreHeaderData.aggregatedCPI[6488] === "-" ||  !inStoreHeaderData.aggregatedCPI[6488]) ? "NA" : CPIUtil.formatCPI(inStoreHeaderData.aggregatedCPI[6488].cpiDaily),
      "MEN_SALES_COVERAGE": menSalesCoverage ? menSalesCoverage : "NA",
      "MEN_SALES": menSales ? menSales.toString() : "NA",

      "F&D_CPI": (inStoreHeaderData.aggregatedCPI[588623] === "-" ||  !inStoreHeaderData.aggregatedCPI[588623]) ? "NA" : CPIUtil.formatCPI(inStoreHeaderData.aggregatedCPI[588623].cpiDaily),
      "F&D_SALES_COVERAGE": fdSalesCoverage ? fdSalesCoverage : "NA",
      "F&D_SALES": fdSales ? fdSales.toString() : "NA",

      "AMZ_CPI": (inStoreHeaderData.aggregatedCPI[18214] === "-" ||  !inStoreHeaderData.aggregatedCPI[18214]) ? "NA" : CPIUtil.formatCPI(inStoreHeaderData.aggregatedCPI[18214].cpiDaily),
      "AMZ_SALES_COVERAGE": amzSalesCoverage ? amzSalesCoverage : "NA",
      "AMZ_SALES": amzSales ? amzSales.toString() : "NA",

      "WAL_CPI": (inStoreHeaderData.aggregatedCPI[527] === "-" ||  !inStoreHeaderData.aggregatedCPI[527]) ? "NA" :CPIUtil.formatCPI(inStoreHeaderData.aggregatedCPI[527].cpiDaily),
      "WAL_SALES_COVERAGE": walSalesCoverage ? walSalesCoverage: "NA",
      "WAL_SALES": walSales ? walSales.toString() : "NA"
    }

  };
  let coreRows =[];
  let retailRows =[];
  let cpiRows =[];

  filteredInStoreData.forEach(each=> {
    let coreTabData = {
      "OMS_ID": each.omsIdList.length>1?each.omsIdList.toString():each.omsIdList[0],
      "STORE_SKU": each.skuNumber ? each.skuNumber : " ",
      "DESCRIPTION": each.skuDescription ? each.skuDescription : " ",
      "MODE_RETAIL": each.mostCommonRetail ? each.mostCommonRetail : " ",
      "COMP": each.compPercentage ? CompUtil.formatPrice(each.compPercentage)/100 : " ",
      "RAW_SALES": each.rawSales === "-" ? " ": CompUtil.formatMuMdPrice(each.rawSales,true),
      "UNITS": each.unitsPercentage ? CompUtil.formatPrice(each.unitsPercentage)/100 : " ",
      "RAW_UNITS": each.rawUnits === "-" ? " ": formatNumberToCompact(each.rawUnits),
      "DCS" : [each.department,each.classNumber,each.subClass].join("-")
    };
    let retailTabData = {
      "OMS_ID": each.omsIdList.length>1?each.omsIdList.toString():each.omsIdList[0],
      "STORE_SKU": each.skuNumber ? each.skuNumber : " ",
      "DESCRIPTION": each.skuDescription ? each.skuDescription : " ",
      "MIN_RETAIL": each.minRetail ? each.minRetail: " ",
      "MAX_RETAIL":each.maxRetail ? each.maxRetail : " ",
      "AUR": each.aur ? each.aur : "",
      "MODE_RETAIL":each.mostCommonRetail ? each.mostCommonRetail : " ",
      "MODE_RETAIL_ASSORTED_STORES": each.assortedStore
    };
    let cpiTabData = {
      "OMS_ID": each.omsIdList.length>1?each.omsIdList.toString():each.omsIdList[0],
      "STORE_SKU": each.skuNumber ? each.skuNumber : " ",

      "LOW_CPI": each.cpiData[3141] === "-" ? " " : CPIUtil.formatCPI(each.cpiData[3141].cpiDaily),
      "LOW_SALES_COVERAGE": each.cpiData[3141] === "-" ? " " :each.cpiData[3141].cpiSalesCovDlyPercentage? each.cpiData[3141].cpiSalesCovDlyPercentage/100:" ",
      "LOW_SALES": each.cpiData[3141] === "-" ? " " : CompUtil.formatMuMdPrice(each.cpiData[3141].cpiSalesCovDollarDlyDenom, true),

      "MEN_CPI": each.cpiData[6488] === "-" ? " " : CPIUtil.formatCPI(each.cpiData[6488].cpiDaily),
      "MEN_SALES_COVERAGE": each.cpiData[6488] === "-" ? " " :each.cpiData[6488].cpiSalesCovDlyPercentage? each.cpiData[6488].cpiSalesCovDlyPercentage/100:" ",
      "MEN_SALES": each.cpiData[6488] === "-" ? " " : CompUtil.formatMuMdPrice(each.cpiData[6488].cpiSalesCovDollarDlyDenom,true),

      "F&D_CPI" : each.cpiData[588623] === "-" ? " " : CPIUtil.formatCPI(each.cpiData[588623].cpiDaily),
      "F&D_SALES_COVERAGE": each.cpiData[588623] === "-" ? " " : each.cpiData[588623].cpiSalesCovDlyPercentage? each.cpiData[588623].cpiSalesCovDlyPercentage/100:" ",
      "F&D_SALES": each.cpiData[588623] === "-" ? " " : CompUtil.formatMuMdPrice(each.cpiData[588623].cpiSalesCovDollarDlyDenom, true),

      "AMZ_CPI": each.cpiData[18214] === "-" ? " " : CPIUtil.formatCPI(each.cpiData[18214].cpiDaily),
      "AMZ_SALES_COVERAGE":each.cpiData[18214] === "-" ? " " : each.cpiData[18214].cpiSalesCovDlyPercentage?each.cpiData[18214].cpiSalesCovDlyPercentage/100:" ",
      "AMZ_SALES":each.cpiData[18214] === "-" ? " " : CompUtil.formatMuMdPrice(each.cpiData[18214].cpiSalesCovDollarDlyDenom, true),

      "WAL_CPI":each.cpiData[527] === "-" ? " " : CPIUtil.formatCPI(each.cpiData[527].cpiDaily),
      "WAL_SALES_COVERAGE": each.cpiData[527] === "-" ? " " : each.cpiData[527].cpiSalesCovDlyPercentage? each.cpiData[527].cpiSalesCovDlyPercentage/100:" ",
      "WAL_SALES": each.cpiData[527] === "-" ? " " : CompUtil.formatMuMdPrice(each.cpiData[527].cpiSalesCovDollarDlyDenom,true)
    };
    coreRows.push(coreTabData);
    retailRows.push(retailTabData);
    cpiRows.push(cpiTabData);
  });

  return {HEADER_DATA,ROW_DATA:{0:coreRows,1:retailRows,2:cpiRows}}

}

export {onlineMultiSKUExcelDataMapper,inStoreMultiSKUExcelDataMapper}
