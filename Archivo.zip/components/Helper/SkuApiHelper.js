import PriceDataServices from "../../services/PriceDataServices";
import PricePointUtil from "../Utils/PricePointUtil";
import CompetitorUtil from "../Utils/CompetitorUtil";
import thdStores from "../MapComponent/CompetitorLocations/THDstores";
import floorsAndDecors from "../MapComponent/CompetitorLocations/FloorAndDecor";
import * as turf from "@turf/turf";
import { findOffsideValue } from "../Utils/CompetitorOffsideUtil";
import DashboardServices from '../../services/DashboardServices';
import SingleAndMultiSkuServices from "../../services/SingleAndMultiSkuServices";

export default class SkuApiHelper {
  static fetchSkuImage(skuNumber, context) {
    PriceDataServices.fetchSkuImageSource(skuNumber)
      .then((skuImageSourcePath) => {
        let skuImage = "no-sku-image";
        if (skuImageSourcePath.data) {
          skuImage = skuImageSourcePath.data;
        }

        context.updateSkuImageUrl(skuImage);
      })
      .catch((error) => {
        context.updateSkuImageUrl("no-sku-image");
        console.log(error);
      });
  }

  static fetchSkuRank(skuNumber, context) {
    SingleAndMultiSkuServices.fetchSkuRank([skuNumber]).then((skuRankResponse) => {
      if (skuRankResponse.data.length != 0) {
        context.updateSkuRank(skuRankResponse.data[0].rank);
      } else {
        context.updateSkuRank("");
      }
  })
  .catch((error) => {
    console.log(error);
    context.updateSkuRank("");
  });
}

  static fetchVendors(skuNumber, context) {
    PriceDataServices.getVendors(skuNumber)
      .then((skuVendorsResponse) => {
        //response may send back more than one vendor for a sku so
        //if more than vendor it will display as a comma delimieted list on the UI
        context.updateSkuVendors(skuVendorsResponse.data.join(", "));
      })
      .catch((error) => {
        console.log(error);
        context.updateSkuVendors("");
      });
  }

  static fetchPriceChangeHistory(skuNumber, context) {
    let thdPriceHistoryMap = {};
    PriceDataServices.getThdSkuPriceChangeHistory(skuNumber)
      .then((response) => {
      if (response.status === 200) {
        thdPriceHistoryMap = response.data||{};
      }
      }).catch((error) => {
        console.log(error);
      }).finally(()=>{
      context.updateSkuPriceChangeHistoryMap(thdPriceHistoryMap||{})
    });
  }

  static fetchThdSkuStorePriceChangeHistory(skuNumber,storeNumber, context) {
    let storeAndThdPriceHistory = [];
    PriceDataServices.getThdSkuStorePriceChangeHistory(skuNumber,storeNumber)
        .then((response) => {
          if (response.status === 200) {
            storeAndThdPriceHistory = response.data||[];
          }
        }).catch((error) => {
      console.log(error);
    }).finally(()=>{
      context.updateSkuStorePriceChangeHistoryMap({[storeNumber]:storeAndThdPriceHistory});
    });
  }

  static fetchSkuStorePerformanceData(skuNumber, context,userId) {
    PriceDataServices.getSkuStorePerformanceData(skuNumber,userId)
      .then((response) => {
        let skuStorePerformanceData = response.data;
        skuStorePerformanceData.storeLevelPerformance = PricePointUtil.fillStoreCompData(
          response.data.currentYearPerformanceMap,
          response.data.lastYearPerformanceMap,
          response.data.storeSet
        );

        context.updatePerformanceData(skuStorePerformanceData);
        context.updateStateFields({ isPerformanceDataLoaded: true });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  static fetchOHQuantityDetails(skuNumber, storeList, context) {
    PriceDataServices.getOHQuantityDetails(skuNumber, storeList)
      .then((response) => {
        if (response.status === 200) {
          context.updateOnHandQuantityMap(response.data);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  static fetchUnitsOnHandDetails(skuNumber, storeList, context) {
    PriceDataServices.getUnitsOnHandDetails(skuNumber, storeList)
      .then((response) => {
        if (response.status === 200) {
          let unitsOnHandMap = response.data;
          context.updateStateFields({ unitsOnHandMap });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }

  static fetchPendingPriceChangeDetails(skuNumber, isPacManSKU, context) {
    PriceDataServices.getPendingPriceChangeDetails(skuNumber, isPacManSKU)
      .then((response) => {
        let storeDetailMap = new Map();
        let pendingPriceChangeData = response.data;
        if (pendingPriceChangeData.storeDetails !== undefined) {
          pendingPriceChangeData.storeDetails.forEach((store) => {
            if (
              store.hasOwnProperty("pendingRetailAmount") ||
              store.hasOwnProperty("promotionRetailAmount")
            ) {
              if (storeDetailMap.has(store.storeNumber)) {
                storeDetailMap.get(store.storeNumber).count =
                  storeDetailMap.get(store.storeNumber).count + 1;
                let effBgnTimestamp = store.hasOwnProperty(
                  "promotionRetailBgnTimestamp"
                )
                  ? store.promotionRetailBgnTimestamp
                  : store.pendingRetailBgnTimestamp;
                if (
                  effBgnTimestamp >
                  storeDetailMap.get(store.storeNumber).pendingDate
                ) {
                  storeDetailMap.get(
                    store.storeNumber
                  ).pendingDate = effBgnTimestamp;
                }
              } else {
                storeDetailMap.set(store.storeNumber, {
                  count: 1,
                  pendingDate: store.hasOwnProperty(
                    "promotionRetailBgnTimestamp"
                  )
                    ? store.promotionRetailBgnTimestamp
                    : store.pendingRetailBgnTimestamp,
                });
              }
            }
          });
        }
        context.updatePendingStoreDetailsMap(storeDetailMap);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  static fetchSalesMetricsDetails(skuNumber, context) {
    let salesMetricsMap = {
      salesMetricBoxPlotList: [],
      storeKVIPricePointData: {},
    };
    PriceDataServices.getSalesMetrics(skuNumber)
      .then((response) => {
        salesMetricsMap = response.data;
        context.updateStateFields({ salesMetricsMap });
      })
      .catch((error) => {
        context.updateStateFields({ salesMetricsMap });
        console.log(error);
      });
  }

  static fetchCompetitorPriceDetails(
    skuNumber,
    competitorUrl,
    updateContextStates,
    thdAllStoreRetailMap,
    offsideStoreConsideration,
    updateDefaultFilterValue
  ) {
    let thdStoreRetailMap = new Map();

    [...thdAllStoreRetailMap.keys()]
      .filter((k) => offsideStoreConsideration.includes(Number.parseInt(k)))
      .forEach((v) => thdStoreRetailMap.set(v, thdAllStoreRetailMap.get(v)));

    PriceDataServices.getCompetitorPrices(skuNumber, competitorUrl)
      .then((response) => {
        let resultantData = {};
        let competitorAggregatedDataMap = {};
        let competitors = response.data ? response.data.competitors : {};
        let offsideMap = {
          Lowes: new Map(),
          Menards: new Map(),
          "Floor & Decor": new Map(),
        };
        //used for offside comparison in competitiveTab
        this.fetchCompetitorZonePriceDetails(skuNumber,Object.keys(competitors),updateContextStates);
        Object.keys(competitors).forEach((competitorId) => {
          let retailAmountCountMap = {};
          let storeCount = 0;
          let latestScrapeDateInMillis = 0;
          let competitorName = CompetitorUtil.getCompetitorName(competitorId);
          let nameToBeReplaced = CompetitorUtil.getStoreNameReplaceString(
            competitorId
          );
          let oneToManySkuDetails = {};

          if (competitorName) {
            resultantData[competitorName] = {};

            Object.values(competitors[competitorId]).forEach((store) => {
              let storeData = { ...store };

              // Competitor stores only exist for localized competitors.
              // So adding safety checks around the "store" usage to support nationalized competitors.
              storeData.name =
                storeData.name && storeData.name.replace("FnD", "F&D").trim();

              storeData.storeName =
                storeData.storeName &&
                storeData.storeName.replace(nameToBeReplaced, "").trim();

              resultantData[competitorName][storeData.store] = storeData;

              /*AggregatedData Calculation*/
              let retailAmount = (storeData.scaledPricePennies / 100).toFixed(
                2
              );

              if (store && store.store) {
                findOffsideValue(
                  offsideMap,
                  thdStoreRetailMap,
                  retailAmount,
                  store.store,
                  competitorName
                );
              }

              if (storeData.scrapeType === "actual") {
                storeCount = storeCount + 1;
                retailAmountCountMap[
                  retailAmount
                ] = retailAmountCountMap.hasOwnProperty(retailAmount)
                  ? retailAmountCountMap[retailAmount] + 1
                  : 1;

                let tempDateInMillis = CompetitorUtil.convertDateStringToMillis(
                  storeData.scrapeDate
                );
                latestScrapeDateInMillis =
                  tempDateInMillis > latestScrapeDateInMillis
                    ? tempDateInMillis
                    : latestScrapeDateInMillis;

                if (oneToManySkuDetails.hasOwnProperty(storeData.sku)) {
                  let retailCountObject =
                    oneToManySkuDetails[storeData.sku].retailCountMap;
                  retailCountObject[
                    retailAmount
                  ] = retailCountObject.hasOwnProperty(retailAmount)
                    ? retailCountObject[retailAmount] + 1
                    : 1;
                } else {
                  oneToManySkuDetails[storeData.sku] = {
                    retailCountMap: { [retailAmount]: 1 },
                    skuNumber: storeData.sku,
                    skuDescription: storeData.skuName,
                    skuImageUrl: storeData.skuImageUrl,
                  };
                }
              }
            });
            Object.values(oneToManySkuDetails).forEach((k) => {
              k.mostCommonRetail = Number.parseFloat(
                PricePointUtil.getMostCommonRetail(k.retailCountMap)[0]
              );
              delete k.retailCountMap;
            });
            competitorAggregatedDataMap[competitorName] = {
              competitorId,
              competitorName,
              totalStoreCount: CompetitorUtil.getCompetitorData(competitorName)
                .length,
              mostCommonRetails: PricePointUtil.getMostCommonRetail(
                retailAmountCountMap
              ),
              storeCount,
              inStoreCompetitorTabDetails: Object.values(oneToManySkuDetails),
              latestScrapeDateInMillis,
            };
          }
        });

        let competitorData = {
          storeLevelDataMap: resultantData,
          aggregatedDataMap: competitorAggregatedDataMap,
          isLoaded: true,
        };

        updateContextStates({ competitorData });
        updateDefaultFilterValue(offsideMap);
      })
      .catch((err) => {
        console.log("err==>", err);
        updateContextStates({
          competitorData: {
            storeLevelDataMap: {},
            aggregatedDataMap: {},
            isLoaded: false,
          },
        });
        updateDefaultFilterValue({});
      });
  }

  static findOneToOneMapping() {
    let oneToOneMap = {};
    floorsAndDecors.forEach((compStore) => {
      let storeId;
      let distance;

      thdStores.forEach((thdStore) => {
        if (thdStore.longitudeNumber && thdStore.latitudeNumber) {
          let from = turf.point([
            compStore.longitudeNumber,
            compStore.latitudeNumber,
          ]);
          let to = turf.point([
            thdStore.longitudeNumber,
            thdStore.latitudeNumber,
          ]);
          let options = { units: "miles" };
          let currentDistance = turf.distance(from, to, options);

          if (!distance || currentDistance < distance) {
            distance = currentDistance;
            storeId = thdStore.storeId;
          }
        }
      });

      oneToOneMap[compStore.storeId] = { distance, storeId };
    });

    console.log("testtt=" + JSON.stringify(oneToOneMap));
  }

  static fetchCompetitorZonePriceDetails(skuNumber,competitorIds,updateContextStates){
    if(competitorIds.length>0){
      let competitorZonePriceData = {};
      Promise.all(competitorIds.map(
          k => DashboardServices.getCompetitorZonePriceDetails(skuNumber, k)
          .catch(err => {
                console.log(err);
                return {data: []};
              }))).then(response=>{
        competitorIds.forEach((value,index)=>{
          competitorZonePriceData[value]=response[index].data
        });
        updateContextStates({competitorZonePriceData});
      });

    }
  }
}
