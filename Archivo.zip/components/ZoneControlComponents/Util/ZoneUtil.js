import ZoneConstants from "../Constants/ZoneConstants";
import DCSUtil from "../../Utils/DCSUtil";

export default class ZoneUtil {
  static availableZoneDefinitions = [ZoneConstants.DEFAULT_LEVEL,
    ZoneConstants.SUB_DEPT_LEVEL, ZoneConstants.CLASS_LEVEL,
    ZoneConstants.SUB_CLASS_LEVEL];

  static getHierarchyLevel(sdcs) {
    let hierarchyLevel = ZoneConstants.EMPTY_LEVEL;
    if (sdcs) {
      let sdcsKey = sdcs.split("-");
      if (sdcsKey.length === 4 || sdcsKey[0] !== "0") {
        hierarchyLevel = sdcsKey[2] === "0" ? ZoneConstants.SUB_DEPT_LEVEL
            : sdcsKey[3] === "0" ? ZoneConstants.CLASS_LEVEL
                : ZoneConstants.SUB_CLASS_LEVEL;
      }
    }

    return hierarchyLevel;
  }

  static getZoneDefinitionLevel(zoneDefinitionLevel) {
    let level = zoneDefinitionLevel ? zoneDefinitionLevel.trim().toUpperCase()
        : "";
    return this.availableZoneDefinitions.includes(level) ? level
        : ZoneConstants.EMPTY_LEVEL;

  }

  static zoneDataFill(data) {
    let zoneData = data && data.response ? data.response : ZoneConstants.ZONE_DEFAULT_DATA;
    let zoneDefinitionLevel = ZoneConstants.EMPTY_LEVEL;
    if (zoneData) {
      zoneDefinitionLevel = this.getZoneDefinitionLevel(
          zoneData.zoneDefinitionLevel);
    }

    zoneData.traits.forEach(trait=>{
      trait.storeTraits.forEach(store =>{
        if(!store.storeName){
          store.storeName="";
        }
      })

    });
    return {zoneData, zoneDefinitionLevel};

  }

  static getZoneInheritAlertMessage(zoneDefinitionLevel, hierarchyLevel,
      hierarchyName, zoneHierarchyName,
      zoneCount) {

    let level = level => level === ZoneConstants.SUB_DEPT_LEVEL
        ? "Sub Department" : level === ZoneConstants.CLASS_LEVEL ? "Class"
            : "Sub Class";
    let excludedLevels = [ZoneConstants.DEFAULT_LEVEL,
      ZoneConstants.EMPTY_LEVEL];
    let zoneInheritMessage = "";

    if (!(excludedLevels.includes(zoneDefinitionLevel)
        || excludedLevels.includes(hierarchyLevel)) && zoneDefinitionLevel !== hierarchyLevel ) {
      zoneInheritMessage = `This ${level(
          hierarchyLevel)} is inheriting ${zoneCount} Zones from ${level(
          zoneDefinitionLevel)} ${zoneHierarchyName}.`

    }
    return zoneInheritMessage;

  }

  static getZoneHierarchyName(subDept, clsNbr, subClsNbr, dcsDataMap, subDeptMap) {
    let hierarchyName = "";

    let subDeptStr = subDept ? subDept : "0";
    let clsNbrInt = isNaN(clsNbr) ? 0 : Number.parseInt(clsNbr);
    let subClsNbrInt = isNaN(subClsNbr) ? 0 : Number.parseInt(subClsNbr);
    if (subDeptMap.hasOwnProperty(subDeptStr)) {
      hierarchyName = subDeptMap[subDeptStr]["description"];

      if (clsNbrInt !== 0) {
        let deptNbr;
        subDeptMap[subDeptStr].deptClassMap.forEach((value, key) => {
          if (value.find((cls) => clsNbrInt === cls)) {
            deptNbr = key;
          }
        });

        hierarchyName = deptNbr ? DCSUtil.getHierarchyName(dcsDataMap,
            deptNbr + "-" + clsNbrInt + "-" + subClsNbrInt, "")
            : hierarchyName;
      }

    }

    return hierarchyName;
  }

  static zoneNameFormat = (inputText) => {
    let outputString = "";
    if(inputText){
      outputString = inputText.toLowerCase()
          .split(' ')
          .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
          .join(' ');
      outputString = outputString
          .split('/')
          .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
          .join('/');
    }

    let lastCommaIndex = outputString.lastIndexOf(",");
    if(lastCommaIndex > 0){
      let firstPart = outputString.slice(0,lastCommaIndex);
      let secondPart = outputString.slice(lastCommaIndex).toUpperCase();
      outputString = firstPart+secondPart;

    }
    return outputString;
  };

}