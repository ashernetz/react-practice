import React, { Component } from "react";
import "./ZoneNotesViewModal.scss";
import { Typography, Modal, Row, Col } from "antd";

const { Text } = Typography;

export default class ZoneNotesViewModal extends Component {

  formattedNotesDate = (inputTime) => {
    let formattedDate = "";
    if (inputTime) {
      let numberFormat = n => n + (["st", "nd", "rd"][((n + 90) % 100 - 10) % 10 - 1] || "th");
      let monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"];
      let inputDate = new Date(inputTime);
      formattedDate = monthNames[inputDate.getMonth()] + " " + numberFormat(
        inputDate.getDate()) + " " + inputDate.getFullYear();
    }
    return formattedDate;
  };

  NoteCard = (props) => {
    return (
      <Row className="notes-row">
        <Col span={24}>
          <Text className="notes-header">{props.userName} </Text><br />
          <Text className="notes-date">{this.formattedNotesDate(props.date)} </Text><br />
          <Text className="notes-desc">{props.description} </Text>
        </Col>
      </Row>
    )
  };
  render() {
    return (
      <Modal
          open={this.props.isOpen}
        onCancel={this.props.onClose}
        title="Notes"
        destroyOnClose={true}
        className="notes-view-modal"
        okButtonProps={{ size: 'large' }}
        cancelButtonProps={{ style: { display: 'none' } }}
        okText="Close"
        onOk={this.props.onClose}
      >
        <div className="notes-overflow" >
          <Row gutter={[0, 24]}>
            <Col>
              {this.props.zoneNotes.map(note => <this.NoteCard key={note.createdTimestamp} userName={note.firstName + " " + note.lastName} date={note.createdTimestamp} description={note.notes} />)}

            </Col>
          </Row>
        </div>
      </Modal>

    );

  }

}


