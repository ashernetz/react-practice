export default class ZoneConstants {
  static SUB_DEPT_LEVEL = "SDPT";
  static CLASS_LEVEL = "CLS";
  static SUB_CLASS_LEVEL = "SCLS";
  static DEFAULT_LEVEL = "DEFAULT";
  static EMPTY_LEVEL = "EMPTY";
  static ZONE_DEFAULT_DATA = {traits:[]};
}