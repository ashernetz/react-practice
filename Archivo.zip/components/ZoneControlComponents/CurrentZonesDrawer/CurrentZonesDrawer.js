import React, {Component} from "react";
import {isMobile} from "react-device-detect";
import {Drawer, Layout} from "antd";
import ZoneActionPanel from "./ZoneActionPanel/ZoneActionPanel";
import ZoneListView from "./ZoneListView/ZoneListView";
import SkuContext from "../../../context/SkuContext";
import ZoneStoresViewModal
  from "../ZoneStoresViewModal/ZoneStoresViewModal";
import "./CurrentZonesDrawer.scss";
import ZoneNotesViewModal from "../ZoneNotesViewModal/ZoneNotesViewModal";
import ZoneModifyModal from "../ZoneModifyModal/ZoneModifyModal";

const {Content} = Layout;
export default class CurrentZonesDrawer extends Component {

  state = {
    selectedZoneNotes: [],
    selectedStores: [],
    selectedZone: "",
    selectedEditRow:{}
  };

  onStoreCountClick = (selectedStores, selectedZone) => {
    this.setState({selectedStores, selectedZone});
  };
  onNotesCountClick = selectedZoneNotes =>
      this.setState({selectedZoneNotes});

  onEditRowClick = selectedEditRow=> {
    this.setState({selectedEditRow});
  };

  render() {
    return (
        <Drawer
            placement='left'
            closable={false}
            keyboard={true}
            open={true}
            style={{zIndex: 'auto', marginTop: '125px',}}
            width={isMobile ? 380 : 560}
            className='dcs-zones-drawer'
            mask={false}
        >
          <Content>
            <SkuContext.Consumer>
              {skuContext => (
                  <ZoneActionPanel
                      userDCS={skuContext.profileData.subClassDetails}
                      subDeptDataMap={skuContext.subDeptDataMap}
                      dcsDataMap={skuContext.dcsDataMap}
                  />)}
            </SkuContext.Consumer>
            <ZoneListView onStoreCountClick={this.onStoreCountClick}
                          onNotesCountClick={this.onNotesCountClick}
                          onEditRowClick={this.onEditRowClick}
                          updateHoveredTrait={this.props.updateHoveredTrait}/>

            <ZoneStoresViewModal stores={this.state.selectedStores}
                                 zone={this.state.selectedZone}
                                 isOpen={this.state.selectedStores.length>0}
                                 onClose={() => this.setState({selectedStores: []})}/>

            <ZoneNotesViewModal zoneNotes = {this.state.selectedZoneNotes}
                                isOpen={this.state.selectedZoneNotes.length>0}
                                onClose={() => this.setState({selectedZoneNotes: []})}/>

            {Object.keys(this.state.selectedEditRow).length !== 0 ? <ZoneModifyModal
                isOpen={Object.keys(this.state.selectedEditRow).length !== 0}
                onClose={() => this.setState(
                    {selectedEditRow: {}})}
                traitId={this.state.selectedEditRow.traitId}
                traitDescription={this.state.selectedEditRow.traitDescription}
                storesCount = {this.state.selectedEditRow.storeTraits? this.state.selectedEditRow.storeTraits.length :0}/>:null}
          </Content></Drawer>);
  }
}
