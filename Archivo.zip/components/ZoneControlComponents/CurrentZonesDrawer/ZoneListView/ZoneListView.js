import React, {Component} from "react";
import AdvancedTable from "../../../GlobalComponents/AdvancedTable/AdvancedTable";
import "./ZoneListView.scss";
import {Col, Row, Typography} from "antd";
import SvgUtil from "../../../Utils/SvgUtil";
import ZoneContext from "../../../../context/ZoneContext";
import ZoneConstants from "../../Constants/ZoneConstants";

const {Text} = Typography;

export default class ZoneListView extends Component {

static contextType = ZoneContext;

headerFormatter = (input) => <Text strong>{input}</Text>;

  noZoneData = () =>
      <Row justify="center" align="middle" type="flex"className="no-zone-found">
        <Col>
          <Row><Col>{SvgUtil.getNoData()}</Col></Row>
          <Row><Col><Text>No Zones Found </Text></Col></Row>
        </Col>
      </Row>

  getColumns = (onStoreCountClick,onNotesCountClick,onEditRowClick) => {
    return  [
      {
        title: this.headerFormatter('Zone Name'),
        dataIndex: 'traitDescription',
        key: 'traitDescription',
        width: '50%',
        isCustomFilter: true,
        filterPlaceholder : "Zone Name"

      },

      {
        title: this.headerFormatter('Stores'),
        dataIndex: 'storeTraitsCount',
        key: 'storeTraitsCount',
        render: (text, record) => {
          return <Text onClick={() => {
            onStoreCountClick(record.storeTraits, record.traitDescription)
          }} className="clickable-value allowed-style">{text}</Text>
        }
      }
      // {
      //   title: this.headerFormatter('Notes'),
      //   dataIndex: 'zoneNotesCount',
      //   key: 'zoneNotesCount',
      //   render: (text, record) => {
      //     return <Text className={"clickable-value " + (text ? "allowed-style":"not-allowed-style")}
      //                  onClick={()=>onNotesCountClick(record.zoneNotes)}>{text}
      //            </Text>;
      //   }
      // },
      // {
      //   title: this.headerFormatter('Actions'),
      //   dataIndex: 'actions',
      //   key: 'actions',
      //   render: (text, record) => {
      //     return <Text className="clickable-value not-allowed-style">{text}</Text>
      //   }
      //
      // },
    ];
  };

  formZoneData = () => {
    let zoneData = this.context.zoneData;
    let zoneDefinitionLevel = this.context.zoneDefinitionLevel;
    let hierarchyLevel = this.context.hierarchyLevel;
    let zoneRowData = [];
    if (zoneDefinitionLevel !== ZoneConstants.EMPTY_LEVEL && zoneDefinitionLevel
        === hierarchyLevel) {
      zoneRowData = zoneData.traits.map(trait => {
        let zoneNotes = trait.zoneNotes?trait.zoneNotes:[];
        return {
          key:trait.traitId,
          traitDescription: trait.traitDescription,
          storeTraitsCount: trait.storeTraits.length,
          storeTraits:trait.storeTraits.map(store=> {return {key:store.storeNumber,storeNumber:store.storeNumber,storeName:store.storeName}}),
          traitId: trait.traitId,
          zoneNotesCount: zoneNotes.length,
          zoneNotes,
          actions: "Edit"
        }
      });
    }
    return zoneRowData;
  };


  render() {
    return (<AdvancedTable
        key={this.context.zoneSelectedSDCS}
        onRow={(record,rowIndex) => ({
          onMouseOver : () => {this.props.updateHoveredTrait(record.traitId)},
          onMouseLeave: () => {this.props.updateHoveredTrait(0)}
        })}
        pagination={{ pageSize: 50 ,showSizeChanger:false}} scroll={{ y: 460,scrollToFirstRowOnChange:true }}
        dataSource = {this.formZoneData()}
        tableClassName="zone-list-table"
        columns={this.getColumns(this.props.onStoreCountClick, this.props.onNotesCountClick, this.props.onEditRowClick)}
        locale={{emptyText: this.noZoneData()}}/>);
  }
}
