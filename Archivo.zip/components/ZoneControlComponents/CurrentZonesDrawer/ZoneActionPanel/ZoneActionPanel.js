import React, {Component} from "react";
import {Alert, Badge, Card, Col, Row, Tooltip, Typography} from "antd";
import './ZoneActionPanel.scss';
import ZoneDCSModal from "../../ZoneDCSModal/ZoneDCSModal";
import DCSUtil from "../../../Utils/DCSUtil";
import ZoneContext from "../../../../context/ZoneContext";
import ZoneServices from "../../../../services/ZoneServices";
import ZoneUtil from "../../Util/ZoneUtil";
import ZoneConstants from "../../Constants/ZoneConstants";
import AlertUtil from "../../../Utils/AlertUtil";

const {Text} = Typography;

export default class ZoneActionPanel extends Component {

  static contextType = ZoneContext;
  state={
    isZoneDCSModalOpen:false,
    zoneInheritMessage:""
  };

  componentDidMount() {
    this.getSubDeptAndFetchZones(this.props.userDCS);
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    if(this.props.userDCS && (prevProps.userDCS !== this.props.userDCS)){
      this.getSubDeptAndFetchZones(this.props.userDCS);
    }
  }

  getToolTipData = (subDept,deptNumber,classNumber,subClassNumber) => {

    let dcsKey = deptNumber + "-" + classNumber + "-" + subClassNumber;
    let hierarchyName = DCSUtil.getHierarchyName(
        this.props.dcsDataMap,
        dcsKey,
        ""
    );

   let tooltipData = "SD" + subDept.replace(/\b0+/g, '');

    if (classNumber !== "0") {
      tooltipData = tooltipData + " C" + classNumber;
    }
    if (subClassNumber !== "0") {
      tooltipData = tooltipData + " S" + subClassNumber;
    }

    return {tooltipData,hierarchyName};
  };

  getSubClassesListForDisaster = (dept, cls, subCls) => {
    let subClassList = [];
    let deptNumber = Number.parseInt(dept);
    let classNumber = Number.parseInt(cls);
    let subClassNumber = Number.parseInt(subCls);
    if (subClassNumber === 0) {
      try {
        subClassList = [...this.props.dcsDataMap.get(deptNumber).get(
            "classes").get(classNumber).get(
            "subclasses").keys()]
      } catch (e) {
      }
    } else {
      subClassList.push(subClassNumber);
    }

    return subClassList;
  };

  readZoneDefinition = (sdcs) => {

    if (sdcs !== "0-0-0-0") {
      this.context.updateZoneDimmer(true);
      let sdcsKey = sdcs.split("-");
      let hierarchyLevel = ZoneUtil.getHierarchyLevel(sdcs);
      let subClassesListForDisaster = this.getSubClassesListForDisaster(sdcsKey[1],sdcsKey[2],sdcsKey[3]);
      let {tooltipData,hierarchyName} = this.getToolTipData(sdcsKey[0], sdcsKey[1], sdcsKey[2],sdcsKey[3]);
      ZoneServices.readZoneByDCS(sdcsKey[0], Number.parseInt(sdcsKey[1]),Number.parseInt(sdcsKey[2]), subClassesListForDisaster, 1,)
          .then(response => {
            this.context.updateZoneDimmer(false);
            this.context.updateHierarchy(sdcs,tooltipData,hierarchyName,hierarchyLevel);

            let {zoneData, zoneDefinitionLevel} = ZoneUtil.zoneDataFill(response.data);

            let zoneHierarchyName = [ZoneConstants.DEFAULT_LEVEL,
              ZoneConstants.EMPTY_LEVEL].includes(zoneDefinitionLevel) ? ""
                : zoneDefinitionLevel === hierarchyLevel ? hierarchyName
                    : ZoneUtil.getZoneHierarchyName(zoneData.subDepartment,
                        zoneData.classNumber, zoneData.subClassNumber,
                        this.props.dcsDataMap, this.props.subDeptDataMap);

            let zoneInheritMessage = ZoneUtil.getZoneInheritAlertMessage(zoneDefinitionLevel, hierarchyLevel,
                hierarchyName, zoneHierarchyName,
                zoneData.traits.length);
            this.context.updateZoneProvider(
                {zoneData, zoneDefinitionLevel,zoneHierarchyName});

            this.setState({zoneInheritMessage});

          }).catch(error => {
        AlertUtil.showAlert("error", "Error", AlertUtil.getErrorMessage("retrieving zone data"));
        this.context.resetZoneState();
        this.setState({zoneInheritMessage:""});

        this.context.updateZoneDimmer(false);
        console.log(error);
      });
    }

  };

  getSubDeptAndFetchZones = (userDCS) => {
   if(userDCS && userDCS.split("-")[0] !== 0 ) {
     let dcs = userDCS.split("-");
     let deptNumber = Number.parseInt(dcs[0]);
     let classNumber = Number.parseInt(dcs[1]);
     let subDeptMap = this.props.subDeptDataMap;

     let subDept = Object.keys(subDeptMap).find(k => {
       let deptClassMap = subDeptMap[k].deptClassMap;
       return deptClassMap.has(deptNumber) && deptClassMap.get(
           deptNumber).includes(classNumber);
     });
     this.readZoneDefinition(subDept + "-" + userDCS);
   }
  };


  render() {
    return (<Card className="card-no-border">
      <Row type="flex" justify="space-between" gutter={[0, 8]}>
        <Col>
          <Row><Col><Text className="modalHeader"> Current
            Zones</Text></Col></Row>
          <Row type="flex" gutter={[8, 0]}>
            <Col>
              <Text className="zone-overview"> List of zones for </Text>
              <Text className="zone-dcs-select" onClick={()=>{this.setState({isZoneDCSModalOpen:true})}}>{DCSUtil.getHierarchyName(
                  this.props.dcsDataMap, this.context.zoneSelectedSDCS.slice(
                      this.context.zoneSelectedSDCS.indexOf("-") + 1),
                  "Choose Heirarchy")}</Text>
              <Badge
                  offset={[15, -5]}
                  count={
                    <div>
                      <Tooltip title={`Hierarchy ${this.context.toolTipData}`} placement="bottom">
                        <i className="material-icons-outlined subclassInfoIcon">info</i>
                      </Tooltip>
                    </div>
                  }
              ></Badge>
            </Col>
          </Row>
        </Col>

        {/*<Col>*/}
        {/*  <Dropdown.Button*/}
        {/*      className="zone-dropdown-button"*/}
        {/*      type="primary"*/}
        {/*      size='large'*/}
        {/*      trigger={["click"]}*/}
        {/*      overlay={*/}
        {/*        <Menu><Menu.Item key="1">Import Template</Menu.Item>*/}
        {/*          <Menu.Item key="2">Revert Markets</Menu.Item></Menu>}>*/}
        {/*    Create New*/}
        {/*  </Dropdown.Button>*/}
        {/*</Col>*/}

      </Row>

      <Row align="middle" >
        <Col>
          {this.state.zoneInheritMessage &&
          <Alert className="zone-alert"
                 message={this.state.zoneInheritMessage}
                 type="warning"
                 onClose= {()=> {this.setState({zoneInheritMessage:""})}}
                 showIcon
                 closable/> }
        </Col>
      </Row>
      {this.state.isZoneDCSModalOpen &&
      <ZoneDCSModal
          isOpen={this.state.isZoneDCSModalOpen}
          onClose={() => this.setState({isZoneDCSModalOpen: false})}
          selectedSDCS={this.context.zoneSelectedSDCS}
          readZoneDefinition={this.readZoneDefinition}/>}

    </Card>);
  }

}
