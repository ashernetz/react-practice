import React, {Component} from 'react';
import { Col, Row, Typography} from "antd";
import './ZoneBarLayout.scss';
import ZoneContext from "../../../context/ZoneContext";

const {Text} = Typography;


export default class ZoneBarLayout extends Component {

    static contextType = ZoneContext;

    render() {
        return (
            <Row type='flex'  className='zoneSubHeader'><Col>
                <Text className="zoneControlFont">Zone Control</Text>
            </Col></Row>
        )
    }
}
