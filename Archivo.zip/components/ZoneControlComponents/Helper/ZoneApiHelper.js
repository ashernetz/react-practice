import ZoneServices from "../../../services/ZoneServices";

export default class ZoneApiHelper {
  static fetchZoneDefinition = (sdcs,zoneContext) => {
    zoneContext.updateZoneDimmer(true);

    let sdcsKey = sdcs.split("-");
    ZoneServices.readZoneByDCS(sdcsKey[0],sdcsKey[2],sdcsKey[3],1)
        .then( response => {
          let zoneData = response.data;
          let zoneSelectedSDCS = sdcs;
          zoneContext.updateZoneDimmer(false);
          zoneContext.updateZoneProvider({zoneData,zoneSelectedSDCS});

        }).catch(error => {
      zoneContext.updateZoneDimmer(false);
      console.log(error);
    });
  };
}