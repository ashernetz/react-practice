import React, { Component } from "react";
import {
  Row,
  Col,
  Modal,
  Select,
  Typography
} from "antd";
import "./ZoneDCSModal.scss";
import SkuContext from "../../../context/SkuContext";

const { Text } = Typography;
const { Option } = Select;

export default class ZoneDCSModal extends Component {
  static contextType = SkuContext;
  sdcsKey = (this.props.selectedSDCS ? this.props.selectedSDCS : "0-0-0-0").split("-");

  state = {
    subDept: this.sdcsKey[0],
    departmentNumber: Number.parseInt(this.sdcsKey[1]),
    classNumber: Number.parseInt(this.sdcsKey[2]),
    subclassNumber: Number.parseInt(this.sdcsKey[3]),
    classKey: this.sdcsKey[1] + "-" + this.sdcsKey[2]
  };

  getDropdownData = () => {
    let subDeptObject = this.context.subDeptDataMap;
    let dcsDataMap = this.context.dcsDataMap;
    let deptClassMap = subDeptObject[this.state.subDept] ? subDeptObject[this.state.subDept].deptClassMap : new Map();
    let trimmedSubDept = this.state.subDept.replace(/^0+/, "");
    let classDropdownData = [];

    let subDeptDropdownData = Object.keys(this.context.subDeptDataMap).map(subDept =>
      <Option key={subDept} value={subDept}>{subDeptObject[subDept].name}</Option>
    );
    let subClassDropdownData = [<Option key={0} value={0}>{"None"}</Option>];

    deptClassMap.forEach((classList, deptNumber) => {
      if (dcsDataMap.has(deptNumber)) {
        dcsDataMap.get(deptNumber).get("classes").forEach(

          (value, key) => {
            if (classList.includes(key)) {
              classDropdownData.push(<Option key={deptNumber + "-" + key} value={deptNumber + "-" + key}>{`${trimmedSubDept} | ${key}-${value.get(
                "description")}`}</Option>);
              if (this.state.classNumber !== 0 && this.state.classNumber === key && this.state.departmentNumber === deptNumber) {

                value.get("subclasses").forEach(
                  (subclassValue, subclassKey) => {
                    subClassDropdownData.push(<Option key={subclassKey} value={subclassKey}>{`${trimmedSubDept} | ${key} | ${subclassKey}-${subclassValue.get(
                      "description")}`}</Option>);
                  });
              }
            }

          });
      }
    }

    );
    return { subDeptDropdownData, classDropdownData, subClassDropdownData };
  };

  getHyphenatedString = (...values) => {
    return values.join("-");
  };

  onSaveChanges = () => {
    this.props.readZoneDefinition(this.getHyphenatedString(this.state.subDept, this.state.departmentNumber, this.state.classNumber, this.state.subclassNumber));
    this.props.onClose();
  };

  isUpdateDisabled = () => {
    return this.state.classNumber === 0 || this.getHyphenatedString(
      this.state.subDept, this.state.departmentNumber, this.state.classNumber,
      this.state.subclassNumber) === this.props.selectedSDCS;
  };
  render() {
    let { subDeptDropdownData, classDropdownData, subClassDropdownData } = this.getDropdownData();
    return <Modal
      title="Product Hierarchy"
      open={this.props.isOpen}
      className="dcs-modal"
      onCancel={this.props.onClose}
      okButtonProps={{ size: 'large', disabled: this.isUpdateDisabled() }}
      cancelButtonProps={{ size: 'large' }}
      okText="Update"
      cancelText="Cancel"
      onOk={this.onSaveChanges}
    >
      <Row align="middle" type="flex" gutter={[30, 16]}>
        <Col className="modalHeaderTextCont">        
          <Text className="modalSubHeader">Select your Class or Subclass from the Options Below </Text>
        </Col>
      </Row>

      <Row type="flex" justify="space-between" align="middle" gutter={[16, 16]}>
        <Col span={12}>
          <Row gutter={[0, 8]}>
            <Col><Text className="dcs-text">Sub Department*</Text></Col></Row>
          <Row>
            <Col span={24}><Select
              showSearch
              size={"large"}
              placeholder={"Select SubDept"}
              style={{ width: "100%" }}
              optionFilterProp="children"
              value={this.state.subDept === "0" ? [] : this.state.subDept}
              onChange={(value) => this.setState(
                { subDept: value, subclassNumber: 0, classNumber: 0 })}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(
                  input.toLowerCase()) >= 0
              }
            >
              {subDeptDropdownData}
            </Select>
            </Col>
          </Row>
        </Col>
        <Col span={12}>
          <Row gutter={[0, 8]}>
            <Col><Text className="dcs-text" >Class*</Text></Col></Row>
          <Row>
            <Col span={24}><Select
              size={"large"}
              showSearch
              disabled={this.state.subDept === "0"}
              placeholder={"Select Class"}
              style={{ width: "100%" }}
              optionFilterProp="children"
              value={this.state.classNumber === 0 ? []
                : this.state.classKey}
              onChange={(value, key) => this.setState(
                { departmentNumber: Number.parseInt(key.key.split("-")[0]), classNumber: Number.parseInt(value.split("-")[1]), classKey: value, subclassNumber: 0 })}
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(
                  input.toLowerCase()) >= 0
              }
            >
              {classDropdownData}
            </Select>
            </Col>
          </Row>
        </Col>
      </Row>
      <Row type="flex" justify="start" align="middle" gutter={[0, 8]}>
        <Col><Text className="dcs-text" >Sub Class</Text></Col></Row>
      <Row type="flex" justify="start" align="middle" gutter={[0, 16]}><Col
        span={24}><Select
          size={"large"}
          showSearch
          disabled={this.state.classNumber === 0}
          placeholder={"Select Subclass"}
          style={{ width: "100%" }}
          optionFilterProp="children"
          value={this.state.subclassNumber === 0 ? []
            : this.state.subclassNumber}
          onChange={(value) => this.setState({ subclassNumber: value })}
          filterOption={(input, option) =>
            option.props.children.toLowerCase().indexOf(input.toLowerCase())
            >= 0
          }
        >{subClassDropdownData}
        </Select>
      </Col>
      </Row>

     
    </Modal>
  }
}