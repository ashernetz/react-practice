import React, {Component} from "react";
import ZoneMapView from "./ZoneMapView";
import ZoneContext from "../../../context/ZoneContext";

export default class ZoneMapViewWrapper extends Component {
  static contextType=ZoneContext;
getMarkerData = () => {
  let markerData=[];
  if(this.props.hoveredTraitId) {
    let trait = this.context.zoneData.traits.find(trait=>trait.traitId===this.props.hoveredTraitId);

    trait.storeTraits.forEach(store => {
      let type = store.disaster ? "dashboard" : "store";
      let shape = store.disaster ? "disaster" : "pin-point";
      let pointerColor = store.disaster ? "red" : "#fa6304";
      if (store.latitudeNumber && store.longitudeNumber) {
        markerData.push(
            {
              store: {...store, type, pointerColor, shape},
              id: store.storeNumber + "dashboard",
              lat: store.latitudeNumber,
              lng: store.longitudeNumber,
              shape,
              pointerColor
            });
      }
    });
  }

    return markerData;
};
  render() {
    let markersData =this.getMarkerData();
    return <ZoneMapView
        zoneSelectedSDCS={this.context.zoneSelectedSDCS}
        markersData={markersData}
        isMapClusteringChecked={markersData.length > 99}
        apiKey={this.props.apiKey}
        mapDivStyle={{
          height: 'calc(100vh - 130px',
          width: '100%',
          marginTop: '60px'
        }}

    />

  }
}