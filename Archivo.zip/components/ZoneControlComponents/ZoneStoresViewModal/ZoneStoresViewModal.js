import React, { Component } from "react";
import "./ZoneStoresViewModal.scss";
import { Typography, Modal, Row, Col } from "antd";
import AdvancedTable from "../../GlobalComponents/AdvancedTable/AdvancedTable";
import ZoneContext from "../../../context/ZoneContext";
import TableUtil from "../../Utils/TableUtil";

const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;
const columns = [
  {
    title: headerFormatter('Store#'),
    dataIndex: 'storeNumber',
    key: 'storeNumber',
    width: '20%',
    isCustomFilter: true,
    filterPlaceholder: "Store Number",
    sorter: (a, b) => a.storeNumber - b.storeNumber
  }, {
    title: headerFormatter('Store Name'),
    dataIndex: 'storeName',
    key: 'storeName',
    width: '50%',
    isCustomFilter: true,
    filterPlaceholder: "Store Name",
    sorter: (a, b) => TableUtil.alphabetSort(a.storeName, b.storeName)


  }
];

export default class ZoneStoresViewModal extends Component {

  static contextType = ZoneContext;

  render() {
    return (
      <Modal
          open={this.props.isOpen}
        title="Stores"
        onCancel={this.props.onClose}
        className='store-view-modal'
        destroyOnClose={true}
        okButtonProps={{ size: 'large' }}
        cancelButtonProps={{ style: { display: 'none' } }}
        okText="Close"
        onOk={this.props.onClose}
      >
        <Row type="flex" justify="space-between" align="bottom">
          <Col><Text >Zone Name:</Text ></Col>
          <Col><Text className="store-view-count">{this.props.stores.length} Stores</Text></Col>
        </Row>
        <Row type="flex" justify="space-between" align="bottom">
          <Col><Text className="store-view-zone-name">{this.props.zone}</Text></Col>
          <Col><Text >{`in ${this.context.hierarchyName} (${this.context.toolTipData})`}</Text></Col>
        </Row>

        <Row>
          <Col span={24}>
            <AdvancedTable
              pagination={{ showSizeChanger: false }}
              columns={columns}
              dataSource={this.props.stores}
            />
          </Col>
        </Row>

      </Modal>
    );
  }
}