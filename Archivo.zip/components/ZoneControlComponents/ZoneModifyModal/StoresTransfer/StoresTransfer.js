// import React,{Component} from "react";
// import Transfer from 'react-virtualized-transfer';
// import ZoneContext from "../../../../context/ZoneContext";
// import './StoresTransfer.scss';
// require('react-virtualized-transfer/lib/less');
//
//
// export default class StoresTransfer extends Component {
//   static contextType = ZoneContext;
//   state = {
//     storeListObject: {},
//     targetKeys: [],
//     selectedKeys: []
//   };
//   handleChange = (nextTargetKeys, direction, moveKeys) => {
//     this.setState({ targetKeys: nextTargetKeys });
//     this.props.updateSummaryDetails(
//         Object.values(this.state.storeListObject).filter(
//             store => nextTargetKeys.includes(store.key) && store.traitId
//                 !== this.props.traitId),nextTargetKeys.length);
//
//     console.log('targetKeys: ', nextTargetKeys);
//     console.log('direction: ', direction);
//     console.log('moveKeys: ', moveKeys);
//   };
//
//   handleSelectChange = (sourceSelectedKeys, targetSelectedKeys) => {
//     this.setState({ selectedKeys: [...sourceSelectedKeys, ...targetSelectedKeys] });
//
//     console.log('sourceSelectedKeys: ', sourceSelectedKeys);
//     console.log('targetSelectedKeys: ', targetSelectedKeys);
//   };
//
//   componentDidMount() {
//     let targetKeys = [];
//     let storeListObject = {};
//     this.context.zoneData.traits.forEach(trait => {
//
//       trait.storeTraits.forEach(storeTrait => {
//         let disabled = this.props.traitId===storeTrait.traitId;
//         let storeNumber = storeTrait.storeNumber.toString();
//         let storeName = storeTrait.storeName;
//
//         if(disabled){
//           targetKeys.push(storeNumber);
//         }
//         storeListObject[storeNumber] = {
//           storeNumber,
//           storeName,
//           storeDescription:`#${storeNumber} ${storeName}`,
//           key: storeNumber,
//           disabled,
//           traitId: storeTrait.traitId,
//           traitDescription: trait.traitDescription
//         };
//       });
//     });
//     this.setState({storeListObject,targetKeys});
//     //this.props.updateOnTransferLoad();
//   }
//
//
//   render() {
//     return (
//         <Transfer
//             dataSource={Object.values(this.state.storeListObject)}
//             showSearch
//             listStyle={{width:"45%", height:292,marginBottom:'12px'}}
//             operations={["From","To"]}
//             className="stores-transfer-view"
//             onChange={this.handleChange}
//             onSelectChange={this.handleSelectChange}
//             targetKeys={this.state.targetKeys}
//             selectedKeys={this.state.selectedKeys}
//             render={item => item.storeDescription}
//             filterOption={(inputValue,option)=>  option.storeDescription.toLowerCase().indexOf(inputValue.toLowerCase()) >= 0}
//             footer={()=>{}}
//             rowHeight={30}
//             searchPlaceholder={'Find Stores'}
//             titles = {["",this.props.traitDescription]}
//             operationStyle={{flexDirection: 'column',display: 'inline-flex'}}
//             locale={{
//               itemUnit: "store",
//               itemsUnit: "stores"
//             }}
//
//         />
//     );
//   }
// }
