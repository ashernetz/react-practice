import React, { Component, Fragment } from "react";
import { Col, Row, Typography, Modal, Input } from "antd";
import './ZoneModifyModal.scss';
import AdvancedTable from "../../GlobalComponents/AdvancedTable/AdvancedTable";
//import StoresTransfer from "./StoresTransfer/StoresTransfer";
import SvgUtil from "../../Utils/SvgUtil";
import ZoneContext from "../../../context/ZoneContext";


const { Text } = Typography;
const { TextArea } = Input;
const headerFormatter = (input) => <Text>{input}</Text>;

const columns = [
  {
    title: headerFormatter('Store#'),
    dataIndex: 'storeNumber',
    width: '20%',
    isCustomFilter: true,
    sorter: (a, b) => a.storeNumber - b.storeNumber,

  },

  {
    title: headerFormatter('Store Name'),
    dataIndex: 'storeName',
    width: '40%',
    sorter: (a, b) => a.storeName.toLowerCase().localeCompare(b.storeName.toLowerCase()),
    isCustomFilter: true,

  },
  {
    title: headerFormatter('From'),
    dataIndex: 'traitDescription',
    width: '30%',
    sorter: (a, b) => a.traitDescription.toLowerCase().localeCompare(b.traitDescription.toLowerCase()),

  },

];


export default class ZoneModifyModal extends Component {
  static contextType = ZoneContext;
  state = {
    storesCount: this.props.storesCount,
    traitDescription: this.props.traitDescription,
    summaryDetails: []
  };

  updateSummaryDetails = (summaryDetails, storesCount) => {
    this.setState({ summaryDetails, storesCount })
  };

  noZoneData = () => <Fragment>
    <Row justify="center" align="middle" type="flex" className='zone-list-table-no-data'>
      <Col>
        {SvgUtil.getNoData()}
      </Col>
    </Row>
    <Row justify="center" align="middle" type="flex">
      <Col>
        <Text className="no-zone-text">
          No Zone Changes
        </Text>
      </Col>
    </Row>
  </Fragment>;


  render() {

    return (


      <Modal
          open={this.props.isOpen}
        onCancel={this.props.onClose}
        title="Modify Zone"
        className="zone-modify-modal"
        destroyOnClose={true}
        okButtonProps={{ size: 'large', disabled: !this.state.traitDescription || this.state.summaryDetails.length === 0 }}
        cancelButtonProps={{ size: 'large' }}
        okText="Save"
        cancelText="Cancel"
        
>
{/* onOk={this.onSaveChanges} */}

        {/* footer={[
          <Row type="flex" justify="end">
            <Col>
              <Button key="back" onClick={() => { this.props.onClose() }} className="zone-dcs-select" ghost="false" >Cancel</Button>
              <Button key="submit" disabled={!this.state.traitDescription || this.state.summaryDetails.length === 0} type="primary"> Save</Button>

            </Col>
          </Row>
        ]}
      > */}

        <Row type="flex" gutter={[0, 40]} align="bottom">
          <Col span={11}>
            <Row type="flex" justify="start" gutter={[0, 16]} >
              <Col>
                <Text className="zone-modify-zone-title">Zone Name:</Text>
              </Col>
            </Row>
            <Row type="flex" justify="start" gutter={[0, 16]}>
              <Col span={24}>
                <Input size="default" onChange={(e) => this.setState({ traitDescription: e.target.value })} value={this.state.traitDescription} />
              </Col>
            </Row>
          </Col>
          <Col span={13}>
            <Row type="flex" justify="end">
              <Col>
                <Text className="zone-modify-zone-head">{this.state.storesCount} Stores</Text>
              </Col>
            </Row>
            <Row type="flex" justify="end" >
              <Col>
                <Text >{`in ${this.context.hierarchyName} (${this.context.toolTipData})`}</Text>
              </Col>
            </Row>
          </Col>
        </Row>

        <Row type="flex" justify="start" align="middle" gutter={[0, 40]} >
          <Col>
            <Text className="zone-overview">Add Stores</Text>
          </Col>
        </Row>
        <Row gutter={[0, 40]} >
          <Col>
            {/*<StoresTransfer updateSummaryDetails={this.updateSummaryDetails} traitId={this.props.traitId} traitDescription={this.state.traitDescription} />*/}

          </Col>
        </Row>

        <Row type="flex" justify="start" gutter={[0, 48]} >
          <Col>
            <Text className="zone-overview">Summary</Text>
          </Col>
        </Row>
        <Row gutter={[0, 32]} >
          <Col span={24}>
            <AdvancedTable
              columns={columns}
              dataSource={this.state.summaryDetails}
              tableClassName="zone-summary-table"
              pagination={{ pageSize: 5 }}
              locale={{ emptyText: this.noZoneData() }} />
          </Col>
        </Row>



        <Row justify="start" gutter={[0, 40]} >
          <Col>
            <Text className="zoneStoreModal-zoneName">Notes (Optional)</Text>
          </Col>
        </Row>
        <Row type="flex" justify="space-between" align="middle" gutter={[0, 40]}>
          <Col span={24}>
            <TextArea rows={4} placeholder="Enter Notes About this Zones" />
          </Col>
        </Row>


      </Modal>

    );
  }
}
