import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { renderHook, act } from '@testing-library/react-hooks';

import { getDCs, getStores } from '../../../services/locationService';
import {
  DCAssortmentProvider,
  useLoading,
  useDCAssortment,
} from '../DCAssortmentProvider';

jest.mock('../../../services/locationService');

const dcs = [
  { dcNumber: '1', dcName: 'Atlanta', dcType: 'FDC' },
  { dcNumber: '2', dcName: 'Tampa', dcType: 'DFC' },
  { dcNumber: '3', dcName: 'Houston', dcType: 'MDC' },
];
const stores = [
  { dc: '1', stores: ['s1.1', 's1.2', 's1.3'] },
  { dc: '2', stores: ['s2.1', 's2.2'] },
];

const wrapper = ({ children }) => (
  <DCAssortmentProvider skuId={42}>{children}</DCAssortmentProvider>
);

beforeEach(() => {
  getDCs.mockResolvedValue(dcs);
  getStores.mockResolvedValue(stores);
});

describe('DCAssortmentProvider component', () => {
  it('renders default state', async () => {
    render(
      <DCAssortmentProvider skuId={42}>Test Content</DCAssortmentProvider>
    );

    await waitFor(() => {
      expect(getStores).toHaveBeenCalled();
    });

    expect(screen.queryByText('Test Content')).toBeInTheDocument();
    expect(getDCs).toHaveBeenCalledWith([42]);
    expect(getStores).toHaveBeenCalledWith(['1', '2', '3']);
  });

  it('does not request stores if dcs is empty', async () => {
    getDCs.mockResolvedValueOnce([]);
    render(
      <DCAssortmentProvider skuId={42}>Test Content</DCAssortmentProvider>
    );

    await waitFor(() => {
      expect(getDCs).toHaveBeenCalled();
    });

    expect(screen.queryByText('Test Content')).toBeInTheDocument();
    expect(getDCs).toHaveBeenCalledWith([42]);
    expect(getStores).not.toHaveBeenCalled();
  });
});

describe('useLoading() hook', () => {
  it('returns sequential loading state', async () => {
    const { result, waitForNextUpdate } = renderHook(() => useLoading(), {
      wrapper,
    });

    expect(result.current).toEqual({
      isDCSLoading: true,
      isVendorsLoading: true,
      isStoresLoading: true,
    });

    await waitForNextUpdate();

    expect(result.current).toEqual({
      isDCSLoading: false,
      isVendorsLoading: false,
      isStoresLoading: false,
    });
  });
});

describe('useDCAssortment() hook', () => {
  it('returns DC assortment data', async () => {
    const { result, waitForNextUpdate } = renderHook(() => useDCAssortment(), {
      wrapper,
    });

    await waitForNextUpdate();

    expect(result.current).toEqual([
      {
        dcNumber: '1',
        dcName: 'Atlanta',
        dcType: 'FDC',
        displayName: '1 - Atlanta',
        deliveryType: 'Scheduled Only',
        stores: ['s1.1', 's1.2', 's1.3'],
      },
      {
        dcNumber: '2',
        dcName: 'Tampa',
        dcType: 'DFC',
        displayName: '2 - Tampa',
        deliveryType: 'Scheduled/Unscheduled',
        stores: ['s2.1', 's2.2'],
      },
      {
        dcNumber: '3',
        dcName: 'Houston',
        dcType: 'MDC',
        displayName: '3 - Houston',
        deliveryType: 'Scheduled/Unscheduled',
        stores: [],
      },
    ]);
  });
});
