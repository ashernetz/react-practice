import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useMemo,
} from 'react';
import keyBy from 'lodash/keyBy';

import { getDCs, getVendors, getStores } from '../../services/locationService';

const getLoadingDefault = () => ({
  isDCSLoading: true,
  isVendorsLoading: true,
  isStoresLoading: true,
});

const dcTypeToDeliveryType = {
  FDC: 'Scheduled Only',
  DFC: 'Scheduled/Unscheduled',
  MDC: 'Scheduled/Unscheduled',
};

const DCAssortmentContext = createContext({
  dcs: [],
  vendors: [],
  stores: [],
  loading: getLoadingDefault(),
});

export function useDCAssortment() {
  const { dcs, stores } = useContext(DCAssortmentContext);
  const storesByDC = keyBy(stores, 'dc');

  const dcAssortment = useMemo(
    () =>
      dcs.map(({ dcNumber, dcName, dcType }) => ({
        dcNumber,
        dcName,
        dcType,
        displayName: `${dcNumber} - ${dcName}`,
        deliveryType: dcTypeToDeliveryType[dcType],
        stores: storesByDC[dcNumber]?.stores || [],
      })),
    [dcs, stores]
  );

  return dcAssortment;
}

export function useLoading() {
  const { loading } = useContext(DCAssortmentContext);

  return loading;
}

export function DCAssortmentProvider({ skuId, children }) {
  const [dcs, setDcs] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(getLoadingDefault());

  useEffect(() => {
    if (!skuId) {
      return;
    }

    const updateLoading = (partial) =>
      setLoading((prevState) => ({
        ...prevState,
        ...partial,
      }));

    async function fetchData() {
      setLoading(getLoadingDefault());

      try {
        const dcs = await getDCs([skuId]);
        const dcIds = dcs.map(({ dcNumber }) => dcNumber);

        updateLoading({ isDCSLoading: false });

        setDcs(dcs);

        if (!dcs.length) {
          return;
        }

        const [storesResult, vendorsResult] = await Promise.allSettled([
          getStores(dcIds),
          // getVendors([skuId]),
        ]);

        if (storesResult.value) {
          setStores(storesResult.value);
        }

        // if (vendorsResult.value) {
        //   setVendors(vendorsResult.value)
        // }

        updateLoading({ isVendorsLoading: false, isStoresLoading: false });
      } catch (error) {
        console.log('Error during fetching DC Assortment data', error);
      } finally {
        setLoading({
          isDCSLoading: false,
          isVendorsLoading: false,
          isStoresLoading: false,
        });
      }
    }

    fetchData();
  }, [skuId]);

  const value = {
    dcs,
    vendors,
    stores,
    loading,
  };

  return (
    <DCAssortmentContext.Provider value={value}>
      {children}
    </DCAssortmentContext.Provider>
  );
}
