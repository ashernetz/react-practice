import DashboardServices from '../../services/DashboardServices';
import PriceDataServices from '../../services/PriceDataServices';
import PricePointUtil from '../Utils/PricePointUtil';
import NoSkuImage from '../SkuDetailComponent/SkuCard/no-sku-image.jpg';
import CompUtil from '../Utils/CompUtil';

export default class CompetitorComparisonHelper {

  static findColor = (firstValue,secondValue) => {
    let color = "";
    if(firstValue && secondValue){
      if (firstValue > secondValue) {
        color = "green";
      } else if (firstValue < secondValue) {
        color = "red"
      }}
    return color;
  };

  static fetchCompetitorData = (thdSku,competitorId,setCompetitorApiData) => {
    PriceDataServices.getCompetitorPrices(thdSku).then(response => {
      let competitors = response.data ? response.data.competitors : {};

      const competitorScrape = competitors[competitorId] ? competitors[competitorId][0] : null;

      competitorScrape ?
          setCompetitorApiData({
            skuImage: competitorScrape.skuImageUrl ? competitorScrape.skuImageUrl : NoSkuImage,
            skuDesc: competitorScrape.skuName,
            skuNumber: competitorScrape.sku
          }) :
          setCompetitorApiData({
            skuImage: NoSkuImage,
            skuDesc: "",
            skuNumber: ""
          });

    }).catch(err => {
      setCompetitorApiData({
        skuImage: NoSkuImage,
        skuDesc: "",
        skuNumber: ""
      });
      console.log('err==>', err);
    });
  };
  static fetchCompetitorZoneData = (
      skuNumber, competitorId, setCompetitorZoneData) => {

    DashboardServices.getCompetitorZonePriceDetails(skuNumber, competitorId)
    .then(response => {
          setCompetitorZoneData(response.data);
        })
    .catch(error => {
          setCompetitorZoneData([]);
        });

  };

  static fetchThdSkuPriceDetails = (skuNumber, setThdZoneStoreData) => {

    PriceDataServices.fetchSkuDetails(skuNumber, null, null).then(skuData => {
      let storeRetailObject = new Map();
      let zoneDetails = skuData.data.zoneDetails;
      let pricePointDetails = skuData.data.pricePointDetails;

      Object.values(pricePointDetails).forEach(pricePointDetail => {
        Object.values(pricePointDetail.storeDetails).forEach(store => {
          storeRetailObject.set(store.storeId.toString(), store.retail);
        });
      });

      setThdZoneStoreData({storeRetailObject, zoneDetails});

    }).catch(error => {
      setThdZoneStoreData({});
      console.log(error);
    });
  };

  static formThdZoneData = (thdZoneStoreData)=>{
    let thdZonePriceDetails = {};
    Object.values(thdZoneStoreData.zoneDetails).forEach(zone => {
      let priceRangeCountMap = {};

      zone.storeList.forEach(store => {
        let currentRetail=0;
        if (thdZoneStoreData.storeRetailObject.has(store.toString())) {
          currentRetail = thdZoneStoreData.storeRetailObject.get(store.toString());
          priceRangeCountMap[currentRetail] = priceRangeCountMap.hasOwnProperty(currentRetail) ?  priceRangeCountMap[currentRetail]+1 : 1;
        }
      });
      let thdRetail =Object.keys(priceRangeCountMap).length>0?PricePointUtil.getMostCommonRetail(priceRangeCountMap)[0]:null;
      thdZonePriceDetails[zone.zoneId]={
        zoneName: zone.zoneName,
        zoneId: zone.zoneId,
        thdRetail: thdRetail?Number.parseFloat(thdRetail):null
      };
    });

    return thdZonePriceDetails;
  };

  static formAggregatedData = (competitorZoneData,thdZonePriceDetails) => {

    let competitorZone = competitorZoneData.reduce((r, newValue) => {
      let a = {...newValue};

      if(thdZonePriceDetails.hasOwnProperty(newValue.zoneId)){
        a = {...a,...thdZonePriceDetails[newValue.zoneId]};
      }

      r.set(a.modeCompetitorPrice, [...(r.get(a.modeCompetitorPrice) || []), a]);
      return r;
    }, new Map());

    return competitorZone;
  };

  static formComparisonTableData = (competitorThdAggregatedPriceMap)=>{
    let count = 0;
    let tableData = [];
    competitorThdAggregatedPriceMap.forEach((value,key)=>{

        if(value.length ===1){
          let formattedCompetitorPrice =  value[0].modeCompetitorPrice?CompUtil.formatMuMdPrice(value[0].modeCompetitorPrice):"-";
          let formattedThdRetail = value[0].thdRetail?CompUtil.formatMuMdPrice(value[0].thdRetail):"-";
          tableData.push({...value[0],
            formattedCompetitorPrice,
            formattedThdRetail,
            isParent:false,
            thdColor:this.findColor(value[0].modeCompetitorPrice,value[0].thdRetail),
            key:++count});
        }else {
          let children = [];
          let retailRange = new Set();
          value.forEach((child)=>{
            let formattedCompetitorPrice =  child.modeCompetitorPrice?CompUtil.formatMuMdPrice(child.modeCompetitorPrice):"-";
            let formattedThdRetail = child.thdRetail?CompUtil.formatMuMdPrice(child.thdRetail):"-";
            if(child.thdRetail){
              retailRange.add(child.thdRetail)
            }
            children.push({
              ...child,
              formattedThdRetail,
              formattedCompetitorPrice,
              thdColor:this.findColor(child.modeCompetitorPrice,child.thdRetail),
              key: ++count,
              isParent:false

            });
          });
          children.sort((a,b)=>b.thdRetail - a.thdRetail);
          retailRange = [...retailRange];

          let formattedCompetitorPrice =  key?CompUtil.formatMuMdPrice(key):"No Scrapes";

          retailRange.sort();
          tableData.push({
            formattedCompetitorPrice,
            modeCompetitorPrice:key,
            zoneName: children.length + ' Zones',
            thdRetail : null,
            formattedThdRetail: null,
            thdRetailRange:retailRange,
            children,
            key: ++count,
            isParent:true
          });

        }


    });
    return tableData.sort((a,b)=>(b.modeCompetitorPrice - a.modeCompetitorPrice));
  };


}
