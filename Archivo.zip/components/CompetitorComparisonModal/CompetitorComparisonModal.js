import React, {useEffect, useState} from 'react';
import {Card, Col, Divider, Modal, Row, Typography} from 'antd';
import './CompetitorComparisonModal.scss';
// import ZoneBreakdownTable from "./ZoneBreakdownTable";
import CompetitorComparisonHelper from './CompetitorComparisonHelper';
import {UXSpin} from '../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import CompUtil from '../Utils/CompUtil';
import CompetitorUtil from '../Utils/CompetitorUtil';
import ZoneAggregatedTable from './ZoneAggregatedTable';
//import {formatNumberToCompact} from "../../../Utils/CommonUtil";


const { Text, Paragraph } = Typography;

const CompetitorComparisonModal =(props) => {
  const  [competitorApiData, setCompetitorApiData]= useState("");
  const [competitorZoneData,setCompetitorZoneData] = useState();
  const [thdZoneStoreData,setThdZoneStoreData]=useState();
  const [aggregateTableData,setAggregateTableData] = useState();
  let offsideData = props.offsideComparisonData;
  let competitorName = CompetitorUtil.getCompetitorName(offsideData.competitorId);

  useEffect(() => {
    if(competitorZoneData && thdZoneStoreData){
      if(competitorZoneData.length > 0 && Object.keys(thdZoneStoreData).length > 0){
      let thdZonePriceDetails = CompetitorComparisonHelper.formThdZoneData(thdZoneStoreData);
      let aggregatedPriceMap = CompetitorComparisonHelper.formAggregatedData(competitorZoneData,thdZonePriceDetails);
      let tableData = CompetitorComparisonHelper.formComparisonTableData(aggregatedPriceMap);

      setAggregateTableData(tableData);
      }else {
        setAggregateTableData([]);
      }
    }
  }, [competitorZoneData, thdZoneStoreData]);

  useEffect(() => {
    if (props.isOffside) {
      CompetitorComparisonHelper.fetchCompetitorData(offsideData.SKU_NBR,offsideData.competitorId,setCompetitorApiData);
      CompetitorComparisonHelper.fetchCompetitorZoneData(offsideData.SKU_NBR, offsideData.competitorId,setCompetitorZoneData);
      CompetitorComparisonHelper.fetchThdSkuPriceDetails(offsideData.SKU_NBR,setThdZoneStoreData);
    }else {
      setCompetitorZoneData(props.loadedCompetitorZoneData?props.loadedCompetitorZoneData:null);
      setThdZoneStoreData(props.loadedThdZoneStoreData?props.loadedThdZoneStoreData:null );
      setCompetitorApiData(props.loadedCompetitorApiData);
    }
  }, [props.isOffside,props.loadedCompetitorZoneData]);

  return (
      <Modal
          open={true}
          title={`${competitorName} Comparison`}
          onCancel={props.onClose}
          onOk={props.onClose}
          className='offside-comparison-modal'
          destroyOnClose={true}
          okText="Close"
          okButtonProps={{ size: 'large' }}
          cancelButtonProps={{ style: { display: 'none' } }}
      >


        <Row style={{marginBottom: "40px"}} justify="space-around" >
          <Col span={11} style={{ padding: "12px" }}>
            <ComparisonCard
                heading="The Home Depot"
                skuImage={offsideData.skuImage}
                skuDesc={offsideData.skuDesc}
                skuNumber={offsideData.SKU_NBR}
            />
          </Col>
          <Col span={2} style={{ textAlign: "center" }}>
            <Divider type="vertical" className="vertical-divider" /></Col>
          <Col span={11} style={{ padding: "12px" }}>
            {competitorApiData ? <ComparisonCard
                heading={competitorName}
                skuImage={competitorApiData.skuImage}
                skuDesc={competitorApiData.skuDesc}
                skuNumber={competitorApiData.skuNumber}
            /> : <div id="offside-competitor-spin"><UXSpin/></div>}

          </Col>
        </Row>
        <Row justify="start" align="middle" style={{marginBottom: "8px"}}>
          <Col><Text className="offside-comparison-header">Most Common Retail</Text></Col>
        </Row>
        <Row justify="space-around" align="middle" style={{marginBottom: "40px"}}>
          <Col>
            <PriceCard price={CompUtil.formatMuMdPrice(offsideData["THD_PRICE"])} name="THD" textColor={CompetitorComparisonHelper.findColor(offsideData.competitorPrice,offsideData["THD_PRICE"])} />
          </Col>
          <Col>
            <PriceCard  price={CompUtil.formatMuMdPrice(offsideData.competitorPrice)} name={competitorName} textColor=""/>
          </Col>
          {/*<Col>*/}
          {/*  <PriceCard  price={CompUtil.formatMuMdPrice(netMUMDAmount,true)} textColor={findColor(netMUMDAmount,0)} name="MUMD Impact"/>*/}
          {/*</Col>*/}
        </Row>
        <Row justify="start" align="bottom" style={{marginBottom: "8px"}}>
          <Col><Text className="offside-comparison-header">Zone Breakdown</Text></Col>
        </Row>
        <Row style={{marginBottom: "8px"}}>
          <Col span={24}>
            <ZoneAggregatedTable
                aggregateTableData={aggregateTableData}
            competitorId={offsideData.competitorId}/>
          </Col>
        </Row>


      </Modal>
  );

};

export const ComparisonCard = props => {
  return (
      <Row type="flex" align="middle" gutter={[16,0]}>
        <Col span = {24}>
          <Row type="flex" justify="start" align="middle" style={{marginBottom: "24px"}}>
            <Col><Text className="offside-comparison-header">{props.heading}</Text></Col>
          </Row>
          <Row type="flex" justify="space-around" align="middle" style={{marginBottom: "24px",minHeight:"150px"}}>
            <Col> <img alt="sku-data" className="offside-comparison-image" src={props.skuImage}/> </Col>
            {/* <UXImage classNames ="rowCompetitorImgSize" imageUrl={props.skuImage}/> */}
          </Row>
          <Row style={{marginBottom: "24px"}}>
            <Col>
              {/*<Text type='secondary'>{props.vendorName}</Text>*/}
              <Paragraph ellipsis className="sku-name">{props.skuDesc}</Paragraph>
              <Text type="secondary">SKU {props.skuNumber}</Text>
            </Col>
          </Row>
        </Col>
      </Row>
  );
};

export const PriceCard = props => {
  return (<Card className="comparison-price-card">
    <Row justify="space-around" align="middle">
      <Col>
        <Row justify="center" align="middle">
          <Col>{props.price?<Text className={"most-common-price" +(props.textColor?" most-common-"+props.textColor :"")}>{props.price}</Text>:<UXSpin/>}</Col>
        </Row>
        <Row justify="center" align="middle">
          <Col><Text  type="secondary" className="most-common-competitor">{props.name}</Text></Col>
        </Row>
      </Col>
    </Row>
  </Card>);
}

export default CompetitorComparisonModal;
