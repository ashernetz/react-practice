import React,{Fragment} from 'react';
import {Typography} from 'antd';
import AdvancedTable from '../GlobalComponents/AdvancedTable/AdvancedTable';
import CompetitorUtil from '../Utils/CompetitorUtil';
import './CompetitorComparisonModal.scss';
import UXSmallPulse
  from '../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse';
import CompUtil from '../Utils/CompUtil';
import CompetitorComparisonHelper from './CompetitorComparisonHelper';

const {Text}= Typography;

const ThdRangeFormatter = ({retailRange,compPrice}) => {
  if(retailRange.length > 0){
   let minRange = CompUtil.formatMuMdPrice(retailRange[0]);
    let maxRange = CompUtil.formatMuMdPrice(retailRange[retailRange.length - 1]);
    let minColor = CompetitorComparisonHelper.findColor(compPrice,retailRange[0]);
    let maxColor =  CompetitorComparisonHelper.findColor(compPrice,retailRange[retailRange.length - 1]);
    let MinRangeText = ()=><Text strong className={minColor?"most-common-"+minColor :""}>{minRange}</Text>;
    let MaxRangeText = ()=><Text strong className={maxColor?" most-common-"+maxColor :""}>{maxRange}</Text>;
    // return  <Text>-</Text> ;
    return retailRange.length === 1 ? <MinRangeText/> : <Fragment><MinRangeText/><Text strong> - </Text><MaxRangeText/></Fragment>;
  }else {
    return <Text strong>-</Text>
  }
};

const customStringSorter=(a,b)=> {
  return (a ? a : "").localeCompare(b ? b : "");
};
const ZoneAggregatedTable = (props) => {
  const columns = [
    {
      title: <Text strong>{CompetitorUtil.getCompetitorName(props.competitorId, false)}</Text>,
      dataIndex:"formattedCompetitorPrice",
      sorter:(a,b)=>customStringSorter(a.formattedCompetitorPrice,b.formattedCompetitorPrice),


    },
    {
      title: <Text strong>Zones</Text>,
      dataIndex: 'zoneName',
      align:"left",
      sorter: (a, b) =>customStringSorter(a.zoneName,b.zoneName)
    },
    {
      title: <Text strong>THD</Text>,
      dataIndex: 'formattedThdRetail',
      render:(record,row)=> row.isParent?
          <ThdRangeFormatter retailRange={row.thdRetailRange} compPrice={row.modeCompetitorPrice}/>
          :<Text strong className={row.thdColor?" most-common-"+row.thdColor :""}>{record}</Text>,
      sorter:(a,b)=>customStringSorter(a.formattedThdRetail,b.formattedThdRetail),
      align:"right",

    }
  ];


  return (<AdvancedTable
      extraTableProps={{rowKey: "key",
        loading :{spinning:!props.aggregateTableData, indicator:<UXSmallPulse/>}
      }}
      tableClassName="zone-breakdown-table"
      columns={columns}
      pagination = {{showSizeChanger:false}}
      dataSource={props.aggregateTableData}
  />);

};

export default ZoneAggregatedTable;