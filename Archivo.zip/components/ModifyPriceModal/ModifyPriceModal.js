import React, { Component } from 'react';
import {
  Row,
  Col,
  Typography,
  Modal,
  Select,
  Input,
  DatePicker,
  Divider,Table
} from 'antd';
import './ModifyPriceModal.scss';
import SkuContext from "../../context/SkuContext";
import SkuCard from "../SkuDetailComponent/SkuCard/SkuCard";
import PriceDataServices from "../../services/PriceDataServices";
import AlertUtil from "../Utils/AlertUtil";
import CompUtil from'../Utils/CompUtil';
import moment from 'moment';
import {trackEvent} from '../Utils/mixpanel'

const { Text } = Typography;
const { Option } = Select;
const { RangePicker } = DatePicker;

const findColor=(input)=>{
  let color = "";
  if(input.includes("up")){
    color="green";
  }else if(input.includes("down")){
    color="red";
  }
  return color;
};
const affectedStorecolumns = [
  {
    title: 'Store#',
    dataIndex: 'storeId',

  },
  {
    title: 'Store Name',
    dataIndex: 'storeName',
  },
  {
    title: 'Mark Up',
    dataIndex: 'markup',
    render:(markup)=> <Text style={{color:findColor(CompUtil.findCompDataUpOrDown(markup))}}>{CompUtil.formatMuMdPrice(markup)}</Text>,
  },
{
    title: 'Mark Down',
    dataIndex: 'markdown',
    render:(markdown)=> <Text style={{color:findColor(CompUtil.findCompDataUpOrDown(markdown?-markdown:0))}}>{CompUtil.formatMuMdPrice(markdown?-markdown:0)}</Text>,
  },

];

export default class ModifyPriceModal extends Component {

  static contextType = SkuContext;
  state = {
    selectedZones : this.props.zone ? [this.props.zone.split("-")[0]]:[],
    storeId: this.props.store?this.props.store.split("-")[0]:null,
    affectedStoresMap:{},
    tempRetailBeginDate:"",
    tempRetailEndDate:"",
    price : this.props.storeRetail? this.props.storeRetail : "",
    retail:this.props.storeRetail? this.props.storeRetail : "",
    isAllZones : false,
    selectedZoneValue : this.props.zone ? [this.props.zone.split("-")[0]]:[]
  };

  onOk = () => {
    this.props.onClose();
  };

  onChange=(dates, dateStrings) => {
    this.setState({
      tempRetailBeginDate:  dateStrings[0],
      tempRetailEndDate: dateStrings[1]
    })
  };

  onZoneChange = (value, zoneDetails) => {
    let zones = [];
    if (value.includes("All Zones")) {
      if (this.state.selectedZones.length > 0) {
        value = ["All Zones"];
      }
      zones = zoneDetails.map(item => item.zoneId);
      this.setState({ selectedZones: zones, isAllZones: true, selectedZoneValue: value })
    } else {
      this.setState({ selectedZones: value, isAllZones: false, selectedZoneValue: value })
    }
  };

  handleClickingSendToPacmanButton = () => {
    trackEvent("CLICKED_SEND_TO_PACMAN_BUTTON", {
      'sku': this.context.skuNumber, 
      'STORE_ID': this.state.storeId,
      'PRICE': this.state.price,
      'SELECTED_ZONES': this.state.selectedZones,
      'TEMP_BEGIN_DATE': this.state.tempRetailBeginDate,
      'TEMP_END_DATE': this.state.tempRetailEndDate
    });
    this.state.storeId !== null ? this.onTempRetailExecutionClick() : this.onPreviewChangesClick();
  };

  onPreviewChangesClick = () => {
    this.context.updateShowDimmer(true);
    let stockProductUrl = this.context.config.stockProductUrl;
    PriceDataServices.performPreviewChanges(
      this.context.skuNumber,
      Number.parseFloat(this.state.price),
      this.state.selectedZones,
      this.context.userId
    ).then((response) => {
      if (response.status === 200) {
        window.open(stockProductUrl+"/check/21/"+response.data.RequestId);
        this.props.onClose();
        this.context.updateShowDimmer(false);
      }
    }).catch(e => {
      let alertMessage = AlertUtil.getErrorMessage("executing price change");
      if (e.response.status === 422) {
        //alertMessage = <div>{e.response.data}</div>
        console.log(e.response.data);
      }
      this.context.updateShowDimmer(false);
      AlertUtil.showAlert("error","Error",alertMessage)
    });
  };

  onTempRetailExecutionClick = () => {
    this.context.updateShowDimmer(true);
    let stockProductUrl = this.context.config.stockProductUrl;
    PriceDataServices.executeTempRetailChanges(this.context.skuNumber,
        Number.parseFloat(this.state.price),
         this.state.storeId,
        this.context.userId,this.state.tempRetailBeginDate,this.state.tempRetailEndDate).then((response) => {
     if (response.status === 200) {
         window.open(
             stockProductUrl+"/check/22/"
             +response.data.RequestId);
          this.props.onClose();
          this.context.updateShowDimmer(false);
       }
     }).catch(e => {
      let alertMessage = AlertUtil.getErrorMessage("executing temp price change");
      if (e.response.status === 422) {
      //alertMessage = <div>{e.response.data}</div>
      console.log(e.response.data);
      }
      this.context.updateShowDimmer(false);
      AlertUtil.showAlert("error","Error",alertMessage)
    });
  };

  disableCheck = () => {
    let storeRetailDates = this.state.tempRetailBeginDate!=="" && this.state.tempRetailEndDate!==""
    let allowPriceCheck = this.state.price > 0;
    let allowZonesCheck = this.state.selectedZones.length>0;
    return this.state.storeId!=null?!(allowPriceCheck && storeRetailDates):!(allowPriceCheck && allowZonesCheck);
  };

  showMarkUpDownData = (retailPrice, onHandQuantity) => {
    let markUpAmount = 0;
    let markDownAmount = 0;
    let impactData= [];

    if(!isNaN(this.state.price)&&this.state.price !== ""){
      let newRetail= Number.parseFloat(this.state.price);
      let currentRetail= Number.parseFloat(retailPrice);
    if (newRetail >  currentRetail) {
      markUpAmount = (newRetail - currentRetail) * onHandQuantity;
    } else if (currentRetail >  newRetail) {
      markDownAmount = (currentRetail - newRetail) * onHandQuantity;
    }
  }
    impactData = {
      markUpAmount: markUpAmount,
      markDownAmount: markDownAmount,
    };
    return impactData;
  }

  populateAfftectedStoresData=(retail,zone,affectedStoresMap)=>{
    let pricePointData = this.context.skuData.pricePointDetails[retail];
    let storeDetails = Object.values(pricePointData.storeDetails);
    storeDetails.forEach(store=>{
      if(store.zoneId === zone){
        let onHandQuantity = this.context.onHandQuantityMap[store.storeId]?this.context.onHandQuantityMap[store.storeId.toString()]:0
        let data =this.showMarkUpDownData(retail,onHandQuantity)
        affectedStoresMap[store.storeId]={key: store.storeId,
          storeId:store.storeId,
          storeName:store.storeName,
          markup:data.markUpAmount,
          markdown:data.markDownAmount     
        };
      }    
    });    
   return Object.values(affectedStoresMap);
  }

  calculateMarkUpDownValues=(markUpAmountList,markDownAmountList)=>{
    let totalMarkUpAmount=0;
    let netAmount =0;
    let totalMarkDownAmount =0;
    let markUpDownData=[];

    totalMarkUpAmount = markUpAmountList.reduce((a,b) => a + b, 0)
    totalMarkDownAmount = markDownAmountList.reduce((a,b) => a + b, 0)
    netAmount = totalMarkUpAmount - totalMarkDownAmount;

    markUpDownData = {
      totalMarkUpAmount: totalMarkUpAmount,
      totalMarkDownAmount:totalMarkDownAmount,
      netAmount: netAmount,
    };
    return markUpDownData;
  }

  disabledDate = (current) => {
    let currentDate = moment();
    return current && current < moment(currentDate);
  }
  
  render() {
 
    let zoneDetails = Object.values(this.context.skuData.zoneDetails);
    let markUpAmountList=[];
    let  markDownAmountList= [];
    let affectedStoreData = [];
    let markUpDownValue=[];
    let noRetailStoresList=[];
    
    if ((this.props.zone || this.props.isAddNew) && this.state.selectedZones.length > 0) {
      let affectedStoresMap = {};
        this.state.selectedZones.forEach(zone => {
          this.context.skuData.zoneDetails[zone].storeList.forEach(store => {
            let currentRetail = 0;
            let storeOnHand = 0;
            if (this.context.skuData.storeRetailMap.has(store.toString())) {
              currentRetail = this.context.skuData.storeRetailMap.get(store);
              if (Object.keys(this.context.onHandQuantityMap).includes(store.toString())) {
                storeOnHand = this.context.onHandQuantityMap[store.toString()];
              }
              affectedStoreData = this.populateAfftectedStoresData(currentRetail, zone, affectedStoresMap);
              let impactData = this.showMarkUpDownData(currentRetail, storeOnHand);
              markUpAmountList.push(impactData.markUpAmount);
              markDownAmountList.push(impactData.markDownAmount);
            } else {
              noRetailStoresList.push(store);
            }

          });
        });      
      console.log("Stores With No retail Price" + noRetailStoresList);
      markUpDownValue = this.calculateMarkUpDownValues(markUpAmountList, markDownAmountList);
    }

      // }else {
      // if (this.state.storeId !== null && Object.keys(this.context.onHandQuantityMap).includes(this.state.storeId.toString())) {
      //   totalOnHandQuantity = this.context.onHandQuantityMap[this.state.storeId.toString()]
      // }

    return (
      <Modal
          title="Modify Price"
          className="modifyPrice"
          open={this.props.isOpen}
          onCancel={this.props.onClose}
          destroyOnClose={true}
          okButtonProps={{ size: 'large', disabled:this.disableCheck() }}
          cancelButtonProps={{size: 'large'}}
          okText="Send to PacMan"
          cancelText="Cancel"
          onOk={this.handleClickingSendToPacmanButton}

      >
        <SkuCard retail = {this.state.retail}/>
        <Divider/>
        <Row style={{ marginBottom: 18, padding:"10px 40px" }}>
          <Col span={11}>
            <Row className="inputLabel">
              <Text >Price </Text>
            </Row>
            <Row>
            <Input 
                value={this.state.price }
                    id ='price'
                    size ="large"
                    prefix = "$"
                    placeholder="Enter Price"
            onChange={(e)=>
            {let price = e.target.value;
              //const re = /^[0-9\b]+$/;
              this.setState({price});
              // if (price === '' || re.test(price)) {
              //   this.setState({price});}
              }} />
            </Row>
          </Col>
          <Col span={1}></Col>
          { 
            this.state.storeId == null ?
              <Col span = {12}>
                <Row className="inputLabel"><Text>Zone </Text></Row>
                <Row>
                  {/* { this.props.zone ? <Text className="modifyReadOnlyText">{this.props.zone}</Text>: */}
                  <Select 
                    size="large"
                    mode="multiple"
                    placeholder = {this.props.isAddNew? "Choose Zone":null}
                    value={this.state.selectedZoneValue}
                    onChange = {(value)=>{this.onZoneChange(value,zoneDetails)
                      }}
                    filterOption={(input, option) =>
                        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    getPopupContainer={trigger => trigger.parentNode}
                    style={{ zIndex:'auto', width: '100%' }} >                  
                    <Option key={0} value="All Zones">All Zones</Option>
                    {zoneDetails.map(item => (<Option key={item.zoneId} value={item.zoneId} disabled = {this.state.isAllZones}>{item.zoneId+"-"+item.zoneName}</Option>))}                  
                  </Select>
                  {/* } */}
                </Row>
              </Col>
            :
              <Col span = {10}>
                <Row className="inputLabel"><Text>Store </Text></Row>
                <Row className="modifyReadOnlyRow"><Text className="modifyReadOnlyText">{this.props.store}</Text></Row>
              </Col>
          }
        </Row>
        {
          this.props.store ?
            <Row style={{ padding:"10px 40px"}}>
              <Col>
                <Row type='flex' className="inputLabel"><Text>Effective Dates</Text></Row>
                <Row type='flex' style={{ marginBottom: 18 }}> <RangePicker block
                size="large"
                    disabledDate={this.disabledDate}
                  ranges={{
                    Tomorrow: [moment().add(1, 'days'), moment().add(1, 'days')]
                  }}
                  onChange={this.onChange}
                />
                </Row>
          </Col>
        </Row>
        :
        null
      }
      
      {/* <Row><Col><Divider/></Col></Row> */}
      {/* <Row type="flex" justify="end" align="middle" gutter = {[32,0]}>
        <Col >
          <Button className="alternative-button buttonGroup" key="back" onClick={this.props.onClose}>
            Cancel
          </Button>
        </Col>
        <Col>
          <Button className="modal-submit-button buttonGroup" key="submit" type="primaIry" size="large"
                  onClick={this.state.storeId !== null?this.onTempRetailExecutionClick:this.onPreviewChangesClick}
                  disabled={this.disableCheck()}>
            Send To PacMan
          </Button>
        </Col>
      </Row> */}
      {
        (this.props.zone || this.props.isAddNew) && this.state.selectedZones.length> 0 ?
        <Row  style={{ padding: "2px", marginBottom: 12, marginTop: 25 }}>
          <Col span={24}>
            <Row gutter={[0,8]}><Col><Text className="modalHeading">Impact Summary </Text></Col></Row>
            <Row gutter={[0,8]} justify="space-around" style={{ marginBottom: 18 }}>
              <Col>
                <Row  justify="center">
                  <Col className="impactNumbersUD"><Text className={CompUtil.findCompDataUpOrDown(markUpDownValue.netAmount)}>{CompUtil.formatMuMdPrice(markUpDownValue.netAmount)}</Text></Col></Row>
                <Row  justify="center"><Col><Text>Net Markup/Down </Text></Col></Row>
              </Col>

              <Col><Row  justify="center">
                <Col className="impactNumbersUD"><Text className={CompUtil.findCompDataUpOrDown(markUpDownValue.totalMarkUpAmount)}>{CompUtil.formatMuMdPrice(markUpDownValue.totalMarkUpAmount)}</Text></Col></Row>
                <Row  justify="center"><Col><Text >Markup amount</Text></Col></Row></Col>

              <Col ><Row  justify="center">
                <Col className="impactNumbersUD">
                  <Text className={CompUtil.findCompDataUpOrDown(markUpDownValue.totalMarkDownAmount?-markUpDownValue.totalMarkDownAmount:0)}>
                    {CompUtil.formatMuMdPrice(markUpDownValue.totalMarkDownAmount?-markUpDownValue.totalMarkDownAmount:0)}</Text></Col></Row>
              <Row><Col><Text >Markdown amount</Text></Col></Row></Col>
            </Row>
          </Col>
          </Row>
        :
          null
      }
      {
        (this.props.zone || this.props.isAddNew) && this.state.selectedZones.length > 0 ?
          <Row style={{ padding: "2px", marginBottom: 12, marginTop: 25 }}>
            <Col span={24} className="modalHeadingSpacer">
              <Text className="modalHeading">Affected Stores</Text><br />
            </Col>

            <Col span={24}>
              <Table columns={affectedStorecolumns} dataSource={affectedStoreData} />
            </Col>
          </Row>
        :
          null 
      }
    </Modal>
    );
  }
}
