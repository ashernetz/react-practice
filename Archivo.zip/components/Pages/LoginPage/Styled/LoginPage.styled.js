import styled from 'styled-components';

const LoginPageContainer = styled.div`
    text-align: center;
   display: flex;
  justify-content: center;
`


export {
    LoginPageContainer
}