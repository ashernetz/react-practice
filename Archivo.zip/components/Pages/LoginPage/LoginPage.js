import React,{useState,useEffect,Fragment,useContext, useRef} from 'react';
import './LoginPage.scss';
import {Button, Card, Col, Form, Input, Row, Typography,Alert} from "antd";
import logoColor from "./MPulseLogo4White900.png";
import bgLogo from "./BackgroundMapLogo.jpg";
import {
  getUserProfile,
  verifyUserAccess
} from "../../../services/SecurityServices";
import SkuContext from "../../../context/SkuContext";
import axios from 'axios';
import PingFedUtil from '../../Utils/PingFedUtil';

const {Text} = Typography;

const VERIFIED = "VERIFIED";
const NOT_VERIFIED = "NOT_VERIFIED";
const IN_PROGRESS = "IN_PROGRESS";
const NO_ACCESS = "NO_ACCESS";

const IN_VALID_CRED = "IN_VALID_CRED";
const ACCESS_DENIED = "ACCESS_DENIED";

const NoAccessCard = ()=> {
    return (<Card bordered={true} className="security-access-card">
        <Row><Col><Text className="security-access-text">Security Access Needed</Text></Col></Row>
        <Row gutter={[0, 16]}>
            <Col><Text>Looks like you need security approval to access the information provided in MPulse.   This can be tricky to navigate so we’ve provided a walkthrough.</Text></Col>
        </Row>
        <Row justify="space-between" gutter={[0, 8]}>
            <Col><Button type="default" target="_blank" href="https://onedrive.homedepot.com/:v:/g/personal/elliott_j_politte_homedepot_com/EWPscoNAh_RFo26erVWFYuQBjXyDIdEhk9wS7TNFWwFb8w">Video Walkthrough</Button></Col>
            <Col><Button type="default" target="_blank" href="https://tim1.homedepot.com:9448/SAFEWeb/newlogin.html"> Request Access</Button></Col>
        </Row>
    </Card>);
};

const LoginAlert = ({loginAlert,setLoginAlert}) => {
    let message = loginAlert === IN_VALID_CRED
        ? "Invalid Credentials: The username and/or password you provided are incorrect. Please try again."
        : "Access Denied: No Privilege to access the requested page.";
    return (<Alert
        message={message}
        type="error"
        closable
        afterClose={()=>setLoginAlert("")}
    />)
};

const disableSubmitButton = (loginLevel,{username,password},showNoAccess)=> {
    let disableSubmit = true;
    if(showNoAccess){
        disableSubmit = true
    }else if(loginLevel === NOT_VERIFIED){
        disableSubmit =  username.trim()? false:true;
    } else if(loginLevel === VERIFIED){
        if(password){
            password = password.trim();
        }
        disableSubmit = (username.trim() && password) ? false:true;
    }
    return disableSubmit;
};

const userNameFieldHighlights = (loginLevel) => {
    if(loginLevel===IN_PROGRESS){
        return{validateStatus:"validating",
            help:"Checking Security Credentials ...",
            hasFeedback:true}
    }else if(loginLevel === NO_ACCESS){
      return{validateStatus:"error"}
    }else if(loginLevel === VERIFIED){
      return{validateStatus:"success",hasFeedback:true}
    }
    else {return {}}
};

const closeButtonProps =(loginLevel) => {
  if(loginLevel === NO_ACCESS){
    return{allowClear:true}
  }else{return{}}
};


const LoginPage = (props) => {

    const context = useContext(SkuContext);
    const [userCredentials,setUserCredentials] = useState({username:"",password:undefined,fullName:"", jobTitleCode: ""});
    const [loginLevel,setLoginLevel] = useState(NOT_VERIFIED);
    const [loginAlert,setLoginAlert] = useState("");

    const usernameInputRef = useRef();
    const focusUsernameInput = () => usernameInputRef.current.focus();

    const passwordInputRef = useRef();
    // const focusPasswordInput = () => passwordInputRef.current.focus();

    useEffect(()=>{
        if(loginLevel === NO_ACCESS){
            setLoginLevel(NOT_VERIFIED);
        }
        focusUsernameInput();
    },[userCredentials.username]);

    const onSubmitButtonClick = () => {
        if(loginLevel === NOT_VERIFIED){
            setLoginLevel(IN_PROGRESS);
            //call initial dapper validation

              verifyUserAccess(userCredentials.username).then(k=>{
                if(k.allowUser){
                  setUserCredentials(creds => ({...creds, fullName: k.fullName, jobTitleCode: k.jobTitleCode}));
                  //setLoginLevel(VERIFIED)
                  //focusPasswordInput();
                  PingFedUtil.redirectToLoginPingFed(
                      props.config.pingFederate.auth_domain,
                      {
                        redirect_uri: props.config.pingFederate.redirect_uri,
                        client_id: props.config.pingFederate.client_id,
                      });

                }else {
                  setLoginLevel(NO_ACCESS);
                }
              });
            }
        if(loginLevel ===VERIFIED){
            axios.post('/api/security/ssoLogin', {
                    credentials: 'include',
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: {
                        callingProgram: "FlexiblePricingUI",
                        j_storenumber: '9100',
                        j_username: userCredentials.username,
                        j_password: userCredentials.password
                    }
                })
                .then(authResp => {
                    if (authResp.status === 200) {
                        getUserProfile(userCredentials.username).then(userResp => {
                            if (userResp && userResp.statusCode === 0) {
                                userResp.loggedIn = true;
                                context.updateShowDimmer(true);
                                props.handleAddingJobTitle(userCredentials, userResp);
                            } else {
                                setLoginAlert(ACCESS_DENIED);
                            }
                        }).catch(err => {
                            console.log("Error while getting UserProfile" +err)
                        });
                    }

                }).catch(err => {
                console.log("Error while Authenticating" +err);
                setLoginAlert(IN_VALID_CRED);
            });

        }
    };

    return (
        <Row className="loginLayout">
            <Col className="ant-col-sm-24 ant-col-md-12 ant-col-xl-10 loginSide">
                <div className="loginLogo">
                <img src={logoColor} alt="MPulse" style={{width: '100%', maxWidth: '500px'}}/>
                </div>
                <p className="login-desc">Welcome to MPulse. A tool built "ground-up" to drive proactive Merchandising Strategy through data driven insights.</p>
                <Form className="login-form" layout={"vertical"}>
                {loginAlert && <LoginAlert loginAlert={loginAlert} setLoginAlert={setLoginAlert}/>}
                    <Form.Item>
                        <Text className="login-label">Please login to continue.</Text>
                    </Form.Item>
                    

                    {loginLevel!==VERIFIED && <Form.Item {...userNameFieldHighlights(loginLevel)}>
                        <Input
                            ref={usernameInputRef}
                            placeholder="Enter LDAP"
                            size="large"
                            value={userCredentials.username}
                            {...closeButtonProps(loginLevel)}
                            className="ldap-input"
                            onChange={({target:{value:username}})=>setUserCredentials(creds => ({...creds,username}))}
                            onKeyPress={(event)=>{if(event.key === 'Enter' && !disableSubmitButton(loginLevel,userCredentials)){onSubmitButtonClick()}}}
                        />
                    </Form.Item>}

                    {loginLevel === VERIFIED &&
                    <Fragment>
                        <Form.Item>
                            <Row align="middle" gutter={[8,0]}>
                                <Col>
                                    <Text className="login-label">{userCredentials.fullName} ({userCredentials.username.toUpperCase()})</Text>
                                </Col>
                                <Col>
                                    <Text className="login-change-label"
                                          onClick={() => {
                                              setUserCredentials(creds => ({...creds, password:undefined}));
                                              setLoginLevel(NOT_VERIFIED)
                                          }}>Change</Text>
                                </Col>
                            </Row>
                        </Form.Item>
                        <Form.Item>

                            <Input
                                ref={passwordInputRef}
                                type="password"
                                placeholder="Enter Your Password"
                                size="large"
                                value={userCredentials.password}
                                onChange={({target:{value:password}})=>setUserCredentials(creds => ({...creds,password}))}
                                onKeyPress={(event)=>{if(event.key === 'Enter' && !disableSubmitButton(loginLevel,userCredentials)){onSubmitButtonClick()}}}
                            />

                        </Form.Item>
                    </Fragment>}
                    {loginLevel === NO_ACCESS && <Form.Item><NoAccessCard/></Form.Item>}
                    <Form.Item>
                        <Button disabled = {disableSubmitButton(loginLevel,userCredentials)} className="login-btn" size="large" type="primary" block
                                onClick={()=>{onSubmitButtonClick()}}>
                            {loginLevel===VERIFIED?"Login":"Next"}
                        </Button>
                    </Form.Item>
                </Form>

            </Col>
            <Col className="ant-col-sm-24 ant-col-md-12 ant-col-xl-14">
                <div className="slidingImageCont">
                    <div className="imageSlider" style={{backgroundImage: `url(${bgLogo})`}}></div>
                </div>
            </Col>
        </Row>);
};

export default LoginPage;