export const stock_sku_perm_req_user = "560";
export const stock_sku_perm_req_admin = "561";
export const stock_sku_perm_req_approver = "562";
export const roleCreate = "1";
export const roleRead = "2";
export const roleUpdate = "3";
export const roleDelete = "4";