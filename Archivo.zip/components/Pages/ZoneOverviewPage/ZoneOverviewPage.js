import React from 'react';
import {Row, Col} from 'antd';

const ZoneOverviewPage = (props) => {
    return (
        <Row>
            <Col>
            <div style={{height: '200px', border: '2px solid #CCC'}}>Hello from Zone Overview</div>

            </Col>
        </Row>
    );
};

export default ZoneOverviewPage;