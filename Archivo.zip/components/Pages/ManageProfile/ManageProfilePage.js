import React, { Component } from "react";
import { Table,Layout,Input,Button, Tooltip,Typography } from "antd";
import SkuContext from "../../../context/SkuContext";
import Axios from "axios";
import "./ManageProfilePage.scss";
import Highlighter from 'react-highlight-words';
import { SearchOutlined } from '@ant-design/icons';
import UXSmallPulse
  from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
const { Content } = Layout;
const {Text}= Typography;

export class ManageProfilePage extends Component {
  static contextType = SkuContext;
  state = {
    profiles:  "",
    searchText: '',
    searchedColumn: '',
    expand: false,
  };

  componentDidMount () {
    this.context.updateShowDimmer(false);
    Axios.get('/api/security/readAllMPulseUserProfile')
        .then(res=>{
          this.setState({profiles: res.data});
          this.context.updateShowDimmer(false);

        }).catch(err => {console.log(err);this.setState({profiles:[]})});
  }

  getColumnSearchProps = dataIndex => ({
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
        <div style={{ padding: 8 }}>
          <Input
              ref={node => {
                this.searchInput = node;
              }}
              placeholder={`Search ${dataIndex}`}
              value={selectedKeys[0]}
              onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
              onPressEnter={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
              style={{ width: 188, marginBottom: 8, display: 'block' }}
          />
          <Button
              type="primary"
              onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
              icon="search"
              size="small"
              style={{ width: 90, marginRight: 8 }}
          >
          </Button>
          <Button onClick={() => this.handleReset(clearFilters)} size="small" style={{ width: 90 }}>
            Reset
          </Button>
        </div>
    ),
    filterIcon: filtered => (
        <SearchOutlined  style={{ color: filtered ? '#1890ff' : undefined }} />
    ),
    onFilter: (value, record) =>
        record[dataIndex]
            .toString()
            .toLowerCase()
            .includes(value.toLowerCase()),
    onFilterDropdownVisibleChange: visible => {
      if (visible) {
        setTimeout(() => this.searchInput.select());
      }
    },
    render: text =>
        this.state.searchedColumn === dataIndex ? (
            <Highlighter
                highlightStyle={{ backgroundColor: '#ffc069', padding: 0 }}
                searchWords={[this.state.searchText]}
                autoEscape
                textToHighlight={text.toString()}
            />
        ) : (
            text
        ),
  });

  handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    this.setState({
      searchText: selectedKeys[0],
      searchedColumn: dataIndex,
    });
  };

  handleReset = clearFilters => {
    clearFilters();
    this.setState({ searchText: '' });
  };


  render(){
    const columns =[{
      title: 'UserId',
      dataIndex: 'userId',
      key: 'userId',
      ...this.getColumnSearchProps('userId'),
    },{
      title: 'First Name',
      dataIndex: 'firstName',
      key: 'firstName',
      ...this.getColumnSearchProps('firstName'),
    },{
      title: 'Last Name',
      dataIndex: 'lastName',
      key: 'lastName',
      ...this.getColumnSearchProps('lastName'),
    },{
      title: 'User Title',
      dataIndex: 'userTitle',
      key: 'userTitle',
      ...this.getColumnSearchProps('userTitle'),
    },{
      title: 'Department',
      dataIndex: 'departmentNumber',
      key: 'departmentNumber',
      defaultSortOrder: 'ascend',
      sorter: (a, b) => a.departmentNumber - b.departmentNumber,
      ...this.getColumnSearchProps('departmentNumber'),
    },{
      title: 'Class',
      dataIndex: 'classNumber',
      key: 'classNumber',
      sortDirections: ['ascend','descend'],
      sorter: (a, b) => a.classNumber - b.classNumber,
      ...this.getColumnSearchProps('classNumber'),
    },{
      title: 'SubClass',
      dataIndex: 'subClassNumber',
      key: 'subClassNumber',
      sortDirections: ['ascend','descend'],
      sorter: (a, b) => a.subClassNumber - b.subClassNumber,
    },
    {
      title: 'MLA SuperCube',
      dataIndex: 'enabledMLASuperCube',
      key: 'enabledMLASuperCube',
      sortDirections: ['ascend','descend'],
      sorter: (a, b) => a.enabledMLASuperCube - b.enabledMLASuperCube,
      render: (txt,row) => (
        <Tooltip placement="topLeft" title ={row.groups?row.groups.toString():""}>
          <Text>{txt ? 'True' : 'False'}</Text>
          </Tooltip>),
    },
    {
      title: 'FavSKU',
      dataIndex: 'favouriteSku',
      width:200,
      align:"left",
      key: 'favouriteSku',
      ellipsis:{showTitle:true},
      render: (txt) => txt.length > 0 ? txt.toString() : "No Favorite SKU",
    }]


    return (
        <Content style={{ padding: '0 50px' }} >
          <div style={{marginTop:'90px'}}>
            <h1>Manage User Profile</h1>
          </div>
          <div className="site-layout-content">
            <Table className="manage-profile-table"
                   columns={columns}
                   rowKey="userId"
                   loading = {{spinning:!this.state.profiles, indicator:<UXSmallPulse style={{top:'10%'}}/>}}
                   dataSource={this.state.profiles?this.state.profiles:[]} />
          </div>

        </Content>


    );
  }
}
export default ManageProfilePage;