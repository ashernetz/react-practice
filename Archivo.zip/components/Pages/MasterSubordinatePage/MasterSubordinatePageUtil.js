import MasterSubordinateServices from '../../../services/MasterSubordinateServices';
import { ERROR_TYPE, MARKET_STATUS } from './Constants';

export default class MasterSubordinatePageUtil {
  static fetchSkusDetails(
    searchInput,
    setSkuDataResponse,
    setSkuDates,
    setErrorType
  ) {
    MasterSubordinateServices.fetchSkusDetails([searchInput])
      .then((response) => {
        if (response.data.length < 1) {
          throw new Error('No results');
        }
        const results = response.data[0];
        setSkuDataResponse(results);
      })
      .catch((e) => {
        console.log(e);
        console.log(e.toString());
        if (e.toString() === 'Error: No results') {
          setErrorType(ERROR_TYPE.INVALID_SKU);
        } else {
          setErrorType(ERROR_TYPE.SKU_DETAILS);
        }
        setSkuDataResponse([]);
      });
    MasterSubordinateServices.fetchSeasonClearenceDates([searchInput])
      .then((response) => {
        if (response && response.data) {
          setSkuDates(response.data);
        }
      })
      .catch((e) => {
        setErrorType(ERROR_TYPE.DATES);
        setSkuDates([]);
      });
  }

  static fetchByoMarkets(skuList, updateMasterSubordinateData) {
    MasterSubordinateServices.fetchByoMarkets(skuList)
      .then((response) => {
        const newByoMarkets = {};
        response?.data?.forEach(
          ({ byo, byoName, market, marketName, store }) => {
            if (!newByoMarkets[byo]) {
              newByoMarkets[byo] = {
                byoName,
                markets: {},
              };
            }

            if (!newByoMarkets[byo].markets[market]) {
              newByoMarkets[byo].markets[market] = {
                marketName,
                stores: [],
              };
            }

            if (
              newByoMarkets[byo].markets[market].stores.indexOf(store) === -1
            ) {
              newByoMarkets[byo].markets[market].stores.push(store);
            }
          }
        );
        updateMasterSubordinateData('byoMarkets', newByoMarkets);
      })
      .catch((error) => {
        console.log('Error with fetchByoMarkets', error);
      });
  }
  static fetchAssortmentMarkets(
    searchInput,
    setSkuMarketsDataResponse,
    setMarketsAndStatus,
    setErrorType
  ) {
    MasterSubordinateServices.fetchAssortmentMarkets([searchInput])
      .then((response) => {
        setMarketsAndStatus(response.data);
        const results = response.data.map((eachEl) => eachEl.market);
        setSkuMarketsDataResponse(results);
      })
      .catch((e) => {
        console.log('Error with fetchAssortmentMarkets:', e);
        setSkuMarketsDataResponse([]);
        setErrorType(ERROR_TYPE.ASSORTMENT);
      });
  }

  static fetchMasterSubordinateRelationship(
    sku,
    setMasterSubordinateResponse,
    setIsMasterSubordinateLoading,
    setErrorType
  ) {
    setIsMasterSubordinateLoading(true);
    MasterSubordinateServices.fetchMasterSubordinateRelationship([sku])

      .then((response) => {
        const results = response.data.map((el) => {
          return {
            market: el.market,
            masterSku: el.masterSku,
            subordinateSku: el.subordinateSku,
            isMasterSku: el.masterSku === Number(sku),
          };
        });
        setMasterSubordinateResponse(results);
      })
      .catch(() => {
        setErrorType(ERROR_TYPE.SKU_RELATIONSHIP);
        setMasterSubordinateResponse([]);
      })
      .finally(() => setIsMasterSubordinateLoading(false));
  }
  static getStoresByMarket(market) {
    return market.store ? market.store : [];
  }

  static getMarketsByState(markets, state) {
    return markets.filter(({ status }) => status.includes(state));
  }

  static getMaxStoresNo(markets) {
    return markets.reduce((acc, market) => {
      const currentMarketStores = this.getStoresByMarket(market).length;
      return currentMarketStores > acc ? currentMarketStores : acc;
    }, 0);
  }
  static filterMarketsById(markets, currentMarket) {
    return markets
      .filter((unit) => unit.market === currentMarket.market)
      .map((item) => {
        return {
          ...item,
          byoName: currentMarket.byoName,
        };
      });
  }

  static filterMarketsByState(markets) {
    let filteredMarketsByStatus = [];
    for (let state of Object.keys(MARKET_STATUS)) {
      const filteredByStatus = this.getMarketsByState(
        markets,
        MARKET_STATUS[state]
      );
      filteredByStatus.forEach((market) => {
        if (Object.keys(market).length > 0) {
          filteredMarketsByStatus.push({
            ...market,
            status: MARKET_STATUS[state],
          });
        }
      });
      if (filteredByStatus.length > 0) break;
    }
    return filteredMarketsByStatus;
  }
  static filterMarketsWithMoreStores(markets) {
    const maxStores = this.getMaxStoresNo(markets);
    return markets.filter((market) => market.store.length == maxStores);
  }

  static filterMarketWithLowerRetail(markets) {
    if (markets.length === 0) return {};
    return markets.reduce((acc, market) => {
      return acc.retail < market?.retail ? acc : market;
    }, markets[0]);
  }
  static filterMarketsForTable(markets, currentMarket) {
    return this.filterMarketWithLowerRetail(
      this.filterMarketsWithMoreStores(
        this.filterMarketsByState(
          this.filterMarketsById(markets, currentMarket)
        )
      )
    );
  }

  static getFormattedByos(byoMarkets) {
    const byoMarketsBySelectedSku = {};
    if (byoMarkets) {
      Object.keys(byoMarkets).forEach((el, index) => {
        const indexName = byoMarkets[el]?.byoName;
        byoMarketsBySelectedSku[indexName] = {
          ...byoMarkets[el],
          byoMarket: el,
        };
      });
    }
    return byoMarketsBySelectedSku;
  }

  static formatRetail(num) {
    const noLength = num.toString().length;
    const dividedNo = num / 100;
    const dividedNoLength = dividedNo.toString().length;
    if (noLength < 4) {
      return dividedNo.toString().length > noLength
        ? dividedNo
        : parseFloat(dividedNo + '.0').toFixed(2);
    }
    if (noLength === dividedNoLength - 1) {
      return dividedNo;
    } else {
      let formattedRetail = dividedNo + '.';
      for (let i = 0; i < noLength - dividedNoLength; i++) {
        formattedRetail = `${formattedRetail}0`;
      }
      return parseFloat(formattedRetail).toFixed(2);
    }
  }
  static updateMasterSubordinate(
    skus,
    searchedSku,
    updatedMarketMasterSku,
    setMarketStatus,
    setIsValidateBtnLoading,
    setIsSaveBtnLoading,
    isSaving,
    setSkuMarketErrorData,
    setIsWriteEndpointFailing
  ) {
    MasterSubordinateServices.fetchMasterSubordinateRelationship(skus)
      .then((response) => {
        return response.data;
      })
      .then((results) => {
        const masterSubResponse = [...results];
        Object.keys(updatedMarketMasterSku).forEach((key) => {
          const marketObj = masterSubResponse.find((el) => el.market === +key);
          if (marketObj) {
            marketObj.subordinateSku = marketObj.subordinateSku.filter(
              (el) => el != searchedSku
            );
            const newMasterSub = {};
            newMasterSub['market'] = +marketObj.market;
            newMasterSub['masterSku'] = +updatedMarketMasterSku[key];
            newMasterSub['subordinateSku'] = [searchedSku];
            masterSubResponse.push(newMasterSub);
          } else {
            const newMasterSub = {};
            newMasterSub['market'] = +key;
            newMasterSub['masterSku'] = +updatedMarketMasterSku[key];
            newMasterSub['subordinateSku'] = [searchedSku];
            masterSubResponse.push(newMasterSub);
          }
        });
        const masterSubResponsePayload = masterSubResponse.filter(
          (el) => el.masterSku != 0
        );
        const masterSubResponseUpdatePayload = masterSubResponsePayload.reduce(
          (result, item) => {
            const existingItem = result.find(
              (i) => i.market === item.market && i.masterSku === item.masterSku
            );

            if (existingItem) {
              existingItem.subordinateSku = [
                ...existingItem.subordinateSku,
                ...item.subordinateSku,
              ];
            } else {
              result.push({ ...item });
            }
            return result;
          },
          []
        );

        MasterSubordinateServices.updateMasterSubordinateRelationship(
          masterSubResponseUpdatePayload,
          isSaving
        )
          .then((response) => {
            if (response) {
              setMarketStatus((prevState) => {
                return {
                  ...prevState,
                  market: '',
                  status: 'success',
                };
              });
            }
          })
          .catch((err) => {
            console.log(err);
            if (err.response?.status === 500) {
              setIsWriteEndpointFailing(true);
            } else {
              setSkuMarketErrorData(err.response?.data);
              setMarketStatus((prevState) => {
                return {
                  ...prevState,
                  market: '',
                  status: 'warning',
                };
              });
            }
          })
          .finally(() => {
            setIsValidateBtnLoading(false);
            setIsSaveBtnLoading(false);
          });
      })
      .catch((err) => {
        setIsValidateBtnLoading(false);
        setIsSaveBtnLoading(false);
      });
  }
}
