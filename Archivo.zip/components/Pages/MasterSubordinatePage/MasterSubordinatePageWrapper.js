import React from 'react';
import { MasterSubordinateProvider } from './Context/MasterSubordinateContext';

const MasterSubordinatePageWrapper =
  (Component) =>
  ({ ...props }) =>
    (
      <MasterSubordinateProvider>
        <Component {...props} />
      </MasterSubordinateProvider>
    );

export default MasterSubordinatePageWrapper;
