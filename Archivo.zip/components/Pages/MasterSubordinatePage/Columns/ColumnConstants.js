export const MSTR_SUB_COL_KEYS = {
  BYO: 'byoColumn',
  MKT: 'marketColumn',
  STS: 'statusColumn',
  RTL: 'retailColumn',
  MSTR: 'masterSkuColumn',
  IN_SESN: 'inSeasDateColumn',
  OUT_SESN: 'outSeasDateColumn',
  CLRNC: 'clearanceColumn',
  VALIDATION: 'validationColumn',
};

export const MSTR_SUB_COL_N = {
  BYO: 'BYO',
  MKT: 'Market',
  STS: 'Status',
  RTL: 'Retail',
  MSTR: 'Master SKU',
  IN_SESN: 'In Season',
  OUT_SESN: 'Out Season',
  CLRNC: 'Clearance',
  VALIDATION: 'Validation',
};

export const SKU_HEADER_COL_N = {
  SKU_NBR: 'SKU Number',
  SKU_DESC: 'SKU Description',
  SKU_TYPE: 'SKU Type',
  DEPT: 'Department',
  CLASS: 'Class',
  SUBCLASS: 'Subclass',
};

export const SKU_HEADER_COL_KEYS = {
  SKU_NBR: 'sku',
  DESC: 'description',
  TYPE: 'type',
  DPT_NAME: 'departmentName',
  DPT_NBR: 'departmentNumber',
  CLASS_NAME: 'className',
  CLASS_NBR: 'classNumber',
  SUBCLASS_NAME: 'subClassName',
  SUBCLASS_NBR: 'subClassNumber',
};

export const SKU_HEADER_COLUMNS = [
  { label: SKU_HEADER_COL_N.SKU_NBR, key: SKU_HEADER_COL_KEYS.SKU_NBR },
  { label: SKU_HEADER_COL_N.SKU_DESC, key: SKU_HEADER_COL_KEYS.DESC },
  { label: SKU_HEADER_COL_N.SKU_TYPE, key: SKU_HEADER_COL_KEYS.TYPE },
  {
    label: SKU_HEADER_COL_N.DEPT,
    name: SKU_HEADER_COL_KEYS.DPT_NAME,
    key: SKU_HEADER_COL_KEYS.DPT_NBR,
  },
  {
    label: SKU_HEADER_COL_N.CLASS,
    name: SKU_HEADER_COL_KEYS.CLASS_NAME,
    key: SKU_HEADER_COL_KEYS.CLASS_NBR,
  },
  {
    label: SKU_HEADER_COL_N.SUBCLASS,
    name: SKU_HEADER_COL_KEYS.SUBCLASS_NAME,
    key: SKU_HEADER_COL_KEYS.SUBCLASS_NBR,
  },
];

export const MasterSubordinateTemplate = [
  {
    templateKey: MSTR_SUB_COL_KEYS.BYO,
    name: MSTR_SUB_COL_N.BYO,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.MKT,
    name: MSTR_SUB_COL_N.MKT,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.STS,
    name: MSTR_SUB_COL_N.STS,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.RTL,
    name: MSTR_SUB_COL_N.RTL,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.MSTR,
    name: MSTR_SUB_COL_N.MSTR,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.IN_SESN,
    name: MSTR_SUB_COL_N.IN_SESN,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.OUT_SESN,
    name: MSTR_SUB_COL_N.OUT_SESN,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.CLRNC,
    name: MSTR_SUB_COL_N.CLRNC,
  },
  {
    templateKey: MSTR_SUB_COL_KEYS.VALIDATION,
    name: MSTR_SUB_COL_N.VALIDATION,
  },
];

export const InitialMasterSubordinateColumnsTemplate =
  MasterSubordinateTemplate;
