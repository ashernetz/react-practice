import React from 'react';
import { Input, Tag, Typography } from 'antd';
import MasterSubordinatePageUtil from '../MasterSubordinatePageUtil';
import { customGenericDateFormatter } from '../../../Utils/CommonUtil';
import { CloseCircleOutlined } from '@ant-design/icons';
const { Text } = Typography;

const titleFormatter = (input) => (
  <Text className={'table-header'}>{input}</Text>
);

const customStringSorter = (a, b) => {
  return (a ? a : '').localeCompare(b ? b : '');
};

const sortByDates = (a, b) => {
  if (a && b) {
    return new Date(a) - new Date(b);
  }
  if (!a && !b) {
    return 0;
  }
  if (a) {
    return -1;
  }
  if (b) {
    return 1;
  }
};

const byoColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'byoColumn',
    sorter: (a, b) => a.byo - b.byo,
    width: 64,
    render(text, row) {
      return <>{row.byo}</>;
    },
  };
};

const marketColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'marketColumn',
    sorter: (a, b) => a.market - b.market,
    width: 100,
    render(text, row) {
      return <>{row.market}</>;
    },
  };
};

const statusColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'statusColumn',
    sorter: (a, b) => customStringSorter(a.status, b.status),
    width: 280,
    render(text, row) {
      return <>{row.status}</>;
    },
  };
};

const retailColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'retailColumn',
    width: 150,
    sorter: (a, b) => a.retail - b.retail,
    render(text, row) {
      return <>{MasterSubordinatePageUtil.formatRetail(row.retail)}</>;
    },
  };
};

const masterSkuColumn = (name, handleMasterSkuChange) => {
  const handleMasterSkuInputChange = (newMasterSku, { masterSku, market }) => {
    handleMasterSkuChange(newMasterSku, market);
  };

  return {
    title: titleFormatter(name),
    dataIndex: 'masterSku',
    width: 150,
    render(text, row) {
      return (
        <Input
          type="number"
          data-testid={`market-${row.market}-master-sku-input`}
          onChange={(e) => handleMasterSkuInputChange(e.target.value, row)}
          value={row.updatedMasterSku ? row.updatedMasterSku : text}
        />
      );
    },
  };
};

const inSeasonColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'inSeason',
    width: 150,
    sorter: (a, b) => sortByDates(a.inSeasonDate, b.inSeasonDate),
    render(text, row) {
      const date = row?.inSeasonDate
        ? new Date(row.inSeasonDate).toDateString()
        : '';
      return <>{customGenericDateFormatter(date)}</>;
    },
  };
};

const outSeasonColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'outSeason',
    width: 150,
    sorter: (a, b) => sortByDates(a.outSeasonDate, b.outSeasonDate),
    render(text, row) {
      const date = row?.outSeasonDate
        ? new Date(row.outSeasonDate).toDateString()
        : '';
      return <>{customGenericDateFormatter(date)}</>;
    },
  };
};

const clearanceColumn = () => {
  return {
    title: titleFormatter('Clearance Date'),
    dataIndex: 'clearanceDate',
    width: 150,
    sorter: (a, b) => new Date(a.clearanceDate) - new Date(b.clearanceDate),
    render(text, row) {
      const date = row?.clearanceDate
        ? new Date(row.clearanceDate).toDateString()
        : '';
      return <>{customGenericDateFormatter(date)}</>;
    },
  };
};

const validationColumn = (name) => {
  return {
    title: titleFormatter(name),
    dataIndex: 'Validation',
    width: 150,
    sorter: (a, b) => (a.isInvalid === b.isInvalid ? 0 : a.isInvalid ? -1 : 1),
    render(text, row) {
      return (
        <>
          {row.isInvalid ? (
            <Tag icon={<CloseCircleOutlined />} color="error">
              Error
            </Tag>
          ) : (
            ''
          )}
        </>
      );
    },
  };
};

export {
  byoColumn,
  marketColumn,
  statusColumn,
  retailColumn,
  masterSkuColumn,
  inSeasonColumn,
  outSeasonColumn,
  clearanceColumn,
  validationColumn,
  sortByDates,
};
