import { sortByDates } from './Columns';

describe('Master Sub Page Columns', () => {
  describe('Date sorting', () => {
    test('Same date', () => {
      expect(sortByDates('12/25/2023', '12/25/2023')).toEqual(0);
    });
    test('Different dates', () => {
      expect(sortByDates('12/24/2023', '12/25/2023')).toEqual(-86400000);
      expect(sortByDates('12/25/2023', '12/24/2023')).toEqual(86400000);
    });
    test('Null dates', () => {
      expect(sortByDates(null, '12/25/2023')).toEqual(1);
      expect(sortByDates('12/25/2023', null)).toEqual(-1);
      expect(sortByDates(null, null)).toEqual(0);
    });
  });
});
