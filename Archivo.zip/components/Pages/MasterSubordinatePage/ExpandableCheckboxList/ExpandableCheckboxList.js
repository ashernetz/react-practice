import { useState, useMemo, useEffect } from 'react';
import { Button, Checkbox, List } from 'antd';
import {
  ExclamationCircleOutlined,
  MinusOutlined,
  PlusOutlined,
  StopOutlined,
} from '@ant-design/icons';

import { useMasterSubordinateData } from '../Context/MasterSubordinateContext';
import PropTypes from 'prop-types';
import './ExpandableCheckboxList.scss';
import { ASSORTMENT_STATUS } from '../Constants';
export const ExpandableCheckboxList = ({
  skuMarketsDataResponse,
  validByoMarketMap,
}) => {
  const [expandedKeys, setExpandedKeys] = useState([]);

  const status = {
    [ASSORTMENT_STATUS.DISABLED]: <StopOutlined />,
    [ASSORTMENT_STATUS.SUCCESS]: '',
    [ASSORTMENT_STATUS.WARNING]: <ExclamationCircleOutlined />,
  };
  const { masterSubordinateData, updateMasterSubordinateData } =
    useMasterSubordinateData();
  const { byoMarkets, selectedByoMarketMap } = masterSubordinateData;

  useEffect(() => {
    closeToggles();
  }, [skuMarketsDataResponse, byoMarkets]);

  const closeToggles = () => {
    setExpandedKeys([]);
  };

  const getStatuses = (markets) => {
    if (
      Object.keys(markets).every((marketNumber) =>
        skuMarketsDataResponse.includes(+marketNumber)
      )
    ) {
      return ASSORTMENT_STATUS.SUCCESS;
    }
    if (skuMarketsDataResponse?.some((el) => markets[el])) {
      return ASSORTMENT_STATUS.WARNING;
    }
    return ASSORTMENT_STATUS.DISABLED;
  };

  const toggleExpanded = (key) => {
    const index = expandedKeys.indexOf(key);
    const newExpandedKeys = [...expandedKeys];
    if (index === -1) {
      newExpandedKeys.push(key);
    } else {
      newExpandedKeys.splice(index, 1);
    }

    setExpandedKeys((prevState) => {
      return newExpandedKeys;
    });
  };

  const hasPartialMarketsChecked = (byoNum) => {
    return (
      !byoHasEveryMarketChecked(byoNum) && byoHasSomeMarketsChecked(byoNum)
    );
  };

  const byoHasEveryMarketChecked = (byoNum) => {
    if (validByoMarketMap.has(byoNum)) {
      return (
        selectedByoMarketMap.has(byoNum) &&
        selectedByoMarketMap.get(byoNum).size ===
          validByoMarketMap.get(byoNum).markets.size
      );
    }
    return false;
  };

  const byoHasSomeMarketsChecked = (byoNum) => {
    return (
      validByoMarketMap.has(byoNum) &&
      [...validByoMarketMap.get(byoNum).markets].some(
        (market) =>
          selectedByoMarketMap.has(byoNum) &&
          selectedByoMarketMap.get(byoNum).has(market)
      )
    );
  };

  const getByoMarketClass = (byoNum) => {
    return hasPartialMarketsChecked(byoNum) ? 'partially-selected' : '';
  };

  const isMarketChecked = (byoNum, marketNum) => {
    return (
      selectedByoMarketMap.get(byoNum) &&
      selectedByoMarketMap.get(byoNum).has(marketNum)
    );
  };

  const handleCheckingByo = (e, byoNum) => {
    const newSelectedLocations = new Map(selectedByoMarketMap);
    if (e.target.checked) {
      newSelectedLocations.set(byoNum, validByoMarketMap.get(byoNum).markets);
    } else {
      newSelectedLocations.delete(byoNum);
    }
    updateMasterSubordinateData('selectedByoMarketMap', newSelectedLocations);
  };

  const handleCheckingMarket = (e, byoNum, marketNum) => {
    const newSelectedLocations = new Map(selectedByoMarketMap);
    const updatedMarkets = new Set(
      newSelectedLocations.has(byoNum) ? newSelectedLocations.get(byoNum) : []
    );
    if (e.target.checked) {
      updatedMarkets.add(marketNum);
      newSelectedLocations.set(byoNum, updatedMarkets);
    } else {
      updatedMarkets.delete(marketNum);
      if (!updatedMarkets.size) {
        newSelectedLocations.delete(byoNum);
      } else {
        newSelectedLocations.set(byoNum, updatedMarkets);
      }
    }
    updateMasterSubordinateData('selectedByoMarketMap', newSelectedLocations);
  };

  const getTreeData = () => {
    const byoMarketsBySelectedSku = {};
    for (const [byoNum, byo] of Object.entries(byoMarkets)) {
      byoMarketsBySelectedSku[byoNum] = {
        ...byo,
        statuses: getStatuses(byo.markets),
      };
    }
    return byoMarketsBySelectedSku;
  };

  const treeData = useMemo(
    () => getTreeData(),
    [
      skuMarketsDataResponse,
      masterSubordinateData.byoMarkets,
      masterSubordinateData.selectedByoMarketMap,
    ]
  );

  return (
    <List
      className="expandable-checkbox-list"
      data-testid="byos-container"
      dataSource={Object.entries(treeData)}
      renderItem={([byoNum, byoData]) => (
        <List.Item
          disabled={byoData.statuses === ASSORTMENT_STATUS.DISABLED}
          className={
            byoData.statuses === ASSORTMENT_STATUS.DISABLED ? 'disabled' : ''
          }
          data-testid="location-list-item"
        >
          <Button
            type="link"
            className="expandable-checkbox-list__expand-btn"
            onClick={() => toggleExpanded(byoNum)}
            size="small"
            data-testid={`byo-${byoNum}-expand-btn`}
            icon={
              expandedKeys.includes(byoNum) ? (
                <MinusOutlined />
              ) : (
                <PlusOutlined />
              )
            }
          ></Button>
          <div className="expandable-checkbox-list__status-icon">
            {status[byoData.statuses]}
          </div>
          <Checkbox
            disabled={byoData.statuses === ASSORTMENT_STATUS.DISABLED}
            className={getByoMarketClass(byoNum)}
            checked={byoHasEveryMarketChecked(byoNum)}
            onChange={(e) => handleCheckingByo(e, byoNum)}
            data-testid={`byo-${byoNum}-check-btn`}
          >
            {byoNum} {byoData.byoName}
          </Checkbox>
          {expandedKeys.includes(byoNum) && (
            <div className="expandable-checkbox-list__details">
              <div className="expandable-checkbox-list__details__divider"></div>
              <div className="expandable-checkbox-list__details__divider"></div>
              <div className="expandable-checkbox-list__markets">
                {Object.entries(byoData.markets).map(([marketId, market]) => (
                  <Checkbox
                    data-testid={`market-checkbox-${marketId}`}
                    key={`${byoNum}-${marketId}`}
                    disabled={!skuMarketsDataResponse.includes(+marketId)}
                    onChange={(e) => handleCheckingMarket(e, byoNum, marketId)}
                    checked={isMarketChecked(byoNum, marketId)}
                  >
                    {`${marketId} ${market.marketName}`}
                  </Checkbox>
                ))}
              </div>
            </div>
          )}
        </List.Item>
      )}
    />
  );
};

ExpandableCheckboxList.propTypes = {
  skuMarketsDataResponse: PropTypes.arrayOf(PropTypes.string).isRequired,
};
