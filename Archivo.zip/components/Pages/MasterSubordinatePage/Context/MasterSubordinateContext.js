import React, { createContext, useContext, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import noop from 'lodash/noop';

export const MasterSubordinateContext = createContext({
  masterSubordinateData: {
    byoMarkets: {},
    selectedByoMarketMap: new Map(),
  },
  updateMasterSubordinateData: noop,
});

export function useMasterSubordinateData() {
  const { masterSubordinateData, updateMasterSubordinateData } = useContext(
    MasterSubordinateContext
  );
  return {
    masterSubordinateData,
    updateMasterSubordinateData,
  };
}

export function MasterSubordinateProvider({ children }) {
  const [masterSubordinateData, setMasterSubordinateData] = useState({
    byoMarkets: {},
    selectedByoMarketMap: new Map(),
  });

  const updateMasterSubordinateData = useCallback((dataType, dataValue) => {
    setMasterSubordinateData((prevState) => ({
      ...prevState,
      [dataType]: dataValue,
    }));
  }, []);

  return (
    <MasterSubordinateContext.Provider
      value={{ masterSubordinateData, updateMasterSubordinateData }}
    >
      {children}
    </MasterSubordinateContext.Provider>
  );
}

MasterSubordinateProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
