import React from 'react';
import { Button, Col, Layout, Row } from 'antd';
const { Footer } = Layout;

const MasterSubordinatePageFooter = ({
  isValidateBtnLoading,
  isSaveBtnLoading,
  handleValidate,
  handleSave,
}) => {
  return (
    <Footer id="master-sub-footer">
      <Row align="middle" justify="end" gutter={[36, 0]}>
        <Col>
          <Button
            type={'secondary'}
            size="middle"
            loading={isValidateBtnLoading}
            onClick={handleValidate}
            data-testid={'validate-master-sub-btn'}
          >
            Validate
          </Button>
        </Col>
        <Col>
          <Button
            type={'primary'}
            size="middle"
            loading={isSaveBtnLoading}
            onClick={handleSave}
            data-testid={'save-master-sub-btn'}
          >
            Save
          </Button>
        </Col>
      </Row>
    </Footer>
  );
};

export default MasterSubordinatePageFooter;
