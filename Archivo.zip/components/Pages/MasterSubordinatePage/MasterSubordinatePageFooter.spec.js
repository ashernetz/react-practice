import React, { createContext } from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import MasterSubordinatePageFooter from './MasterSubordinatePageFooter';
import '@testing-library/jest-dom';
import { act } from 'react-dom/test-utils';

describe('MasterSubordinatePageFooter', () => {
  test('render footer buttons', () => {
    render(
      <MasterSubordinatePageFooter
        handleValidate={() => {}}
        isValidateBtnLoading="false"
      />
    );

    expect(screen.getByText('Validate')).toBeInTheDocument();
    expect(screen.getByText('Save')).toBeInTheDocument();
  });
});
