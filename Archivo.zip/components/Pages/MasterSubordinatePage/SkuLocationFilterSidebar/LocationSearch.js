import { useMemo, useState } from 'react';
import { Button, Col, Input, Row, Select, Typography } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { useMasterSubordinateData } from '../Context/MasterSubordinateContext';
import { ASSORTMENT_STATUS, LOCATION_TYPES } from '../Constants';

const { Text } = Typography;
const LocationSearch = (props) => {
  const LOCATION_DROPDOWN_OPTIONS = [
    { value: LOCATION_TYPES.BYO, label: LOCATION_TYPES.BYO },
    { value: LOCATION_TYPES.MKT, label: LOCATION_TYPES.MKT },
  ];

  const [type, setType] = useState(LOCATION_DROPDOWN_OPTIONS[0].value);
  const { masterSubordinateData, updateMasterSubordinateData } =
    useMasterSubordinateData();
  const { byoMarkets, selectedByoMarketMap } = {
    ...masterSubordinateData,
  };

  const handleDropdownSelect = (val) => {
    setType(val);
  };

  const handleLocationInput = (e) => {
    props.setLocationInputText(e.target.value);
  };

  const handleClickingLocationSelectButton = () => {
    const newSelectedLocations = getValidLocationsFromSearch();
    if (newSelectedLocations) {
      updateMasterSubordinateData('selectedByoMarketMap', newSelectedLocations);
    }
  };

  const getValidLocationsFromSearch = () => {
    let newSelectedLocations = new Map(selectedByoMarketMap);
    if (!byoMarkets || !props.locationInputText.length) {
      return;
    }

    const isAllNumeric = /^[ \d,;\r\n\t]+$/.test(props.locationInputText);
    const isAllNonNumeric = /^[^0-9]*$/.test(props.locationInputText);
    if (!(isAllNumeric || isAllNonNumeric)) {
      return;
    }

    const splitInput = props.locationInputText
      .trim()
      .toUpperCase()
      .split(isAllNumeric ? /[ ;,\r\n\t]+/ : /[;,\r\n\t]+/)
      .map((val) => val.trim());

    if (type === LOCATION_TYPES.BYO) {
      getByoSelections(
        isAllNumeric,
        isAllNonNumeric,
        splitInput,
        newSelectedLocations
      );
    }
    if (type === LOCATION_TYPES.MKT) {
      getMarketSelections(
        isAllNumeric,
        isAllNonNumeric,
        splitInput,
        newSelectedLocations
      );
    }
    return newSelectedLocations;
  };

  const getByoSelections = (
    isAllNumeric,
    isAllNonNumeric,
    splitInput,
    newSelectedLocations
  ) => {
    if (isAllNumeric) {
      Array.from(props.validByoMarketMap)
        .filter(([byoNum, byo]) => splitInput.includes(byoNum))
        .forEach(([byoNum, byo]) => {
          newSelectedLocations.set(byoNum, byo.markets);
        });
    }
    if (isAllNonNumeric) {
      for (const byoNum of props.validByoMarketMap.keys()) {
        if (
          splitInput.some(
            (inputVal) => byoMarkets[byoNum].byoName.toUpperCase() === inputVal
          )
        ) {
          newSelectedLocations.set(
            byoNum,
            props.validByoMarketMap.has(byoNum)
              ? props.validByoMarketMap.get(byoNum).markets
              : []
          );
        }
      }
    }
  };

  const getMarketSelections = (
    isAllNumeric,
    isAllNonNumeric,
    splitInput,
    newSelectedLocations
  ) => {
    if (isAllNumeric) {
      for (const [byoNum, validByo] of props.validByoMarketMap) {
        const newSelectedMarkets = new Set(
          selectedByoMarketMap.has(byoNum)
            ? selectedByoMarketMap.get(byoNum)
            : []
        );
        splitInput
          .filter((inputVal) => validByo.markets.has(inputVal))
          .forEach((matchingMarketNum) => {
            newSelectedMarkets.add(matchingMarketNum);
          });
        newSelectedLocations.set(byoNum, newSelectedMarkets);
      }
    }
    if (isAllNonNumeric) {
      for (const [byoNum, validByo] of props.validByoMarketMap) {
        const newSelectedMarkets = new Set(
          selectedByoMarketMap.has(byoNum)
            ? selectedByoMarketMap.get(byoNum)
            : []
        );
        Array.from(validByo.markets)
          .filter((marketNum) =>
            splitInput.some(
              (inputVal) =>
                byoMarkets[byoNum].markets[marketNum].marketName === inputVal
            )
          )
          .forEach((matchingMarketNum) => {
            newSelectedMarkets.add(matchingMarketNum);
          });
        newSelectedLocations.set(byoNum, newSelectedMarkets);
      }
    }
  };

  return (
    <Row>
      <Col span={24}>
        <Row>
          <Col>
            <Text strong className="master-sub__aside__label">
              Choose Locations
            </Text>
          </Col>
        </Row>
        <Row className="master-sub__aside__section">
          <Col span={7}>
            <Select
              className={'master-sub__aside__location__select'}
              data-testid={'location-dropdown'}
              defaultValue={'BYO'}
              options={LOCATION_DROPDOWN_OPTIONS}
              onChange={handleDropdownSelect}
            />
          </Col>
          <Col flex={'auto'}>
            <Input
              className={'master-sub__aside__location__input'}
              type={'text'}
              data-testid={'location-search-input'}
              onChange={handleLocationInput}
              value={props.locationInputText}
            />
          </Col>
          <Col>
            <Button
              className={'master-sub__aside__location__plus-button'}
              data-testid={'location-plus-button'}
              icon={<PlusOutlined />}
              onClick={() => handleClickingLocationSelectButton()}
            />
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default LocationSearch;
