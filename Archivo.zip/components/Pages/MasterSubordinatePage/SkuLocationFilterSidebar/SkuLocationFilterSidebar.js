import React, { useEffect, useMemo, useState } from 'react';
import {
  Layout,
  Alert,
  Button,
  Col,
  Input,
  Row,
  Typography,
  Divider,
} from 'antd';
import { ExpandableCheckboxList } from '../ExpandableCheckboxList/ExpandableCheckboxList';
import LocationSearch from './LocationSearch';
import SkuSearch from './SkuSearch';
import { ASSORTMENT_STATUS } from '../Constants';
import { useMasterSubordinateData } from '../Context/MasterSubordinateContext';
import SelectAllMarkets from './SelectAllMarkets';

const { Sider } = Layout;
const { Title, Text } = Typography;

const SkuLocationFilterSidebar = (props) => {
  const [locationInputText, setLocationInputText] = useState('');
  const { masterSubordinateData, updateMasterSubordinateData } =
    useMasterSubordinateData();
  const { byoMarkets } = masterSubordinateData;

  const handleSkuSearch = () => {
    props.searchNewSku(props.skuInputText);
    setLocationInputText('');
  };

  const selectAllMarkets = (validByoMap) => {
    const newSelectedList = new Map();
    for (const [byoNum, byo] of validByoMap.entries()) {
      newSelectedList.set(byoNum, byo.markets);
    }
    updateMasterSubordinateData('selectedByoMarketMap', newSelectedList);
  };

  const clearAllSelected = () => {
    updateMasterSubordinateData('selectedByoMarketMap', new Map());
  };

  const getValidByoMarketMap = () => {
    let byoMap = new Map();
    for (const [byoNum, byo] of Object.entries(byoMarkets)) {
      if (
        Object.keys(byo.markets).every((marketNum) =>
          props.skuMarketsDataResponse?.includes(+marketNum)
        )
      ) {
        byoMap.set(byoNum, {
          status: ASSORTMENT_STATUS.SUCCESS,
          markets: new Set(Object.keys(byo.markets)),
        });
      } else if (
        Object.keys(byo.markets).some((marketNum) =>
          props.skuMarketsDataResponse?.includes(+marketNum)
        )
      ) {
        byoMap.set(byoNum, {
          status: ASSORTMENT_STATUS.WARNING,
          markets: new Set(
            Object.keys(byo.markets).filter((marketNum) =>
              props.skuMarketsDataResponse?.includes(+marketNum)
            )
          ),
        });
      }
    }
    if (byoMap.size) {
      selectAllMarkets(byoMap);
    }
    return byoMap;
  };

  const validByoMarketMap = useMemo(
    () => getValidByoMarketMap(),
    [byoMarkets, props.skuMarketsDataResponse]
  );

  return (
    <Sider className="master-sub__aside" width={360}>
      <Row>
        <Col span={24}>
          <Row>
            <Col span={24}>
              <Title level={4} className="master-sub__aside__header">
                Master Subordinate Maintenance
              </Title>
            </Col>
          </Row>
          <Row>
            <Col className="master-sub__aside__content" span={24}>
              <SkuSearch
                handleSkuSearch={handleSkuSearch}
                skuInputText={props.skuInputText}
                setSkuInputText={props.setSkuInputText}
                errorType={props.errorType}
                setErrorType={props.setErrorType}
              />
              <LocationSearch
                locationInputText={locationInputText}
                setLocationInputText={setLocationInputText}
                skuMarketsDataResponse={props.skuMarketsDataResponse}
                validByoMarketMap={validByoMarketMap}
              />
              <SelectAllMarkets
                validByoMarketMap={validByoMarketMap}
                selectAllMarkets={selectAllMarkets}
                clearAllSelected={clearAllSelected}
                skuMarketsDataResponse={props.skuMarketsDataResponse}
              />
              <Row className="master-sub__aside__section">
                <div className="master-sub__aside__byos">
                  <ExpandableCheckboxList
                    skuMarketsDataResponse={props.skuMarketsDataResponse}
                    validByoMarketMap={validByoMarketMap}
                  />
                </div>
              </Row>
            </Col>
          </Row>

          <Row className="master-sub__action-btns" justify={'end'}>
            <Col>
              <Button
                onClick={() => props.cleanUp()}
                data-testid="clear-byo-selectors"
              >
                Reset
              </Button>
            </Col>
            <Col>
              <Button
                onClick={() => props.setIsGridBeingUpdated(true)}
                data-testid="grid-update"
              >
                Update Grid
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Sider>
  );
};

export default SkuLocationFilterSidebar;
