import { Alert, Button, Col, Input, Row, Typography } from 'antd';
import { SearchOutlined } from '@ant-design/icons';

const { Text } = Typography;
const SkuSearch = (props) => {
  const handleSkuInputChange = (e) => {
    props.setSkuInputText(e.target.value);
  };

  const invalidSkuErrorMsg = () => {
    return (
      <div>
        <span>{`Error: ${props.skuInputText} is not a valid SKU`}</span>
      </div>
    );
  };

  const assortmentErrorMsg = () => {
    return (
      <div>
        <span>{`Error: ${props.skuInputText} Failed to get Assortment/Retail data“`}</span>
      </div>
    );
  };

  const skuRelationshipErrorMsg = () => {
    return (
      <div>
        <span>{`Error: ${props.skuInputText} Failed to get Master-Subordinate data`}</span>
      </div>
    );
  };

  const datesErrorMsg = () => {
    return (
      <div>
        <span>{`Error: ${props.skuInputText} Failed to get Seasonal/Clearance data`}</span>
      </div>
    );
  };

  const skuDetailsErrorMsg = () => {
    return (
      <div>
        <span>{`Error: ${props.skuInputText} Failed to get Sku details`}</span>
      </div>
    );
  };

  const determineErrorMessage = () => {
    if (props.errorType === 'Invalid Sku') {
      return invalidSkuErrorMsg();
    }
    if (props.errorType === 'Assortment') {
      return assortmentErrorMsg();
    }
    if (props.errorType === 'Sku Relationship') {
      return skuRelationshipErrorMsg();
    }
    if (props.errorType === 'Dates') {
      return datesErrorMsg();
    }
    if (props.errorType === 'Sku Details') {
      return skuDetailsErrorMsg();
    }
    return null;
  };
  return (
    <Row>
      <Col span={24}>
        {props.errorType && (
          <Row>
            <Col>
              <Alert
                message={determineErrorMessage()}
                type="error"
                closable={true}
                banner={true}
                afterClose={() => props.setErrorType('')}
              />
            </Col>
          </Row>
        )}
        <Row>
          <Col>
            <Text strong className="master-sub__aside__label sku-search-title">
              Search SKU:
            </Text>
          </Col>
        </Row>
        <Row className="master-sub__aside__section">
          <Col span={22} className="master-sub__aside__search">
            <Input
              type="text"
              data-testid="sku-input-text"
              value={props.skuInputText}
              onChange={handleSkuInputChange}
              onKeyPress={(e) => e.key === 'Enter' && props.handleSkuSearch()}
            />
          </Col>
          <Col span={2} className="sku-search-btn">
            <Button
              icon={<SearchOutlined />}
              data-testid="sku-search-button"
              onClick={() => props.handleSkuSearch()}
              type="primary"
            />
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default SkuSearch;
