import { Row, Col, Checkbox } from 'antd';
import { useMasterSubordinateData } from '../Context/MasterSubordinateContext';
import { useMemo } from 'react';

const SelectAllMarkets = ({
  selectAllMarkets,
  clearAllSelected,
  validByoMarketMap,
  skuMarketsDataResponse,
}) => {
  const { masterSubordinateData, updateMasterSubordinateData } =
    useMasterSubordinateData();
  const { selectedByoMarketMap } = masterSubordinateData;
  const handleCheckingSelectAllMarkets = (e) => {
    if (e.target.checked) {
      selectAllMarkets(validByoMarketMap);
    } else {
      clearAllSelected();
    }
  };

  const checkIfAllMarketsChecked = () => {
    if (
      validByoMarketMap.size &&
      selectedByoMarketMap.size &&
      selectedByoMarketMap.size === validByoMarketMap.size
    ) {
      return Array.from(selectedByoMarketMap.entries()).every(
        ([byoNum, selectedMarkets]) => {
          return (
            validByoMarketMap.get(byoNum).markets.size === selectedMarkets.size
          );
        }
      );
    }
    return false;
  };

  const checkIfPartiallyChecked = () => {
    let someMarketsAreChecked = false;
    if (!allMarketsAreChecked) {
      someMarketsAreChecked = Array.from(selectedByoMarketMap.entries()).some(
        ([byoNum, selectedMarkets]) => {
          return (
            validByoMarketMap.get(byoNum).markets.size === selectedMarkets.size
          );
        }
      );
    }
    return someMarketsAreChecked ? 'partially-selected' : '';
  };

  const checkIfDisabled = () => {
    return !(skuMarketsDataResponse && skuMarketsDataResponse.length);
  };

  const allMarketsAreChecked = useMemo(() => {
    return checkIfAllMarketsChecked();
  }, [skuMarketsDataResponse, validByoMarketMap, selectedByoMarketMap]);

  return (
    <Row>
      <Col>
        <Checkbox
          data-testid={'select-all-markets-btn'}
          onChange={handleCheckingSelectAllMarkets}
          checked={allMarketsAreChecked}
          className={checkIfPartiallyChecked()}
          disabled={checkIfDisabled()}
        >
          Select All
        </Checkbox>
      </Col>
    </Row>
  );
};

export default SelectAllMarkets;
