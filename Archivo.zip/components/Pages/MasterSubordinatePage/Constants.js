export const ASSORTMENT_STATUS = {
  SUCCESS: 'success',
  WARNING: 'warning',
  DISABLED: 'disabled',
};

export const LOCATION_TYPES = {
  BYO: 'BYO',
  MKT: 'Market',
};

export const MARKET_STATUS = {
  ACTIVE: 'Active',
  IN_SEASON: 'In Season',
  OUT_SEASON: 'Out Season',
  INACTIVE: 'Inactive',
  CLEARANCE: 'Clearance',
};

export const ERROR_TYPE = {
  INVALID_SKU: 'Invalid Sku',
  ASSORTMENT: 'Assortment',
  SKU_RELATIONSHIP: 'Sku Relationship',
  DATES: 'Dates',
  SKU_DETAILS: 'Sku Details',
};
