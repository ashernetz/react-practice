import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Button,
  Col,
  Input,
  Layout,
  Row,
  Space,
  Typography,
} from 'antd';
import './MasterSubordinatePage.scss';
import { SearchOutlined } from '@ant-design/icons';
import MasterSubordinatePageUtil from './MasterSubordinatePageUtil';
import {
  MSTR_SUB_COL_KEYS,
  MSTR_SUB_COL_N,
  InitialMasterSubordinateColumnsTemplate,
  SKU_HEADER_COLUMNS,
  SKU_HEADER_COL_KEYS,
  MasterSubordinateTemplate,
} from './Columns/ColumnConstants';
import {
  byoColumn,
  clearanceColumn,
  validationColumn,
  inSeasonColumn,
  marketColumn,
  masterSkuColumn,
  outSeasonColumn,
  retailColumn,
  statusColumn,
} from './Columns/Columns';
import MasterSubordinatePageWrapper from './MasterSubordinatePageWrapper';
import { useMasterSubordinateData } from './Context/MasterSubordinateContext';
import { UXDimmer } from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXDimmer';
import SkuLocationFilterSidebar from './SkuLocationFilterSidebar/SkuLocationFilterSidebar';
import AdvancedTable from '../../GlobalComponents/AdvancedTable/AdvancedTable';
import _ from 'lodash';
import MasterSubordinatePageFooter from './MasterSubordinatePageFooter';
import { CSVLink, CSVDownload } from 'react-csv';
const { Content } = Layout;

const MasterSubordinatePage = () => {
  const [skuInputText, setSkuInputText] = useState('');
  const [isGridBeingUpdated, setIsGridBeingUpdated] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [skuDataResponse, setSkuDataResponse] = useState({});
  const [errorType, setErrorType] = useState('');

  const [skuDates, setSkuDates] = useState([]);
  const [isMasterSubordinateLoading, setIsMasterSubordinateLoading] =
    useState(false);

  const { masterSubordinateData, updateMasterSubordinateData } =
    useMasterSubordinateData();
  const [skuMarketsDataResponse, setSkuMarketsDataResponse] = useState([]);
  const [marketsAndStatus, setMarketsAndStatus] = useState([]);
  const [masterSubordinateResponse, setMasterSubordinateResponse] = useState(
    []
  );
  const [updatedMarketMasterSku, setUpdatedMarketMasterSku] = useState({});
  const [marketStatus, setMarketStatus] = useState({ market: '', status: '' });
  const [isValidateBtnLoading, setIsValidateBtnLoading] = useState(false);
  const [isSaveBtnLoading, setIsSaveBtnLoading] = useState(false);
  const [skuMarketErrorData, setSkuMarketErrorData] = useState([]);
  const [isSave, setIsSave] = useState(false);
  const [isWriteEndpointFailing, setIsWriteEndpointFailing] = useState(false);
  const [enteredMasterSku, setEnteredMasterSku] = useState('');
  const { byoMarkets, selectedByoMarketMap } = masterSubordinateData;

  useEffect(() => {
    MasterSubordinatePageUtil.fetchByoMarkets([], updateMasterSubordinateData);
  }, []);

  useEffect(() => {
    if (isGridBeingUpdated) {
      filterDataBasedOnSku();
      setUpdatedMarketMasterSku({});
      setIsGridBeingUpdated(false);
      setMarketStatus({});
      setEnteredMasterSku('');
    }
  }, [isGridBeingUpdated]);

  useEffect(() => {
    if (isValidateBtnLoading || isSaveBtnLoading) {
      handleMasterSkuValidation();
    }
  }, [isValidateBtnLoading, isSaveBtnLoading]);

  useEffect(() => {
    if (skuMarketErrorData?.length > 0) {
      const errorRecords = formatCsvData();
      const existingTableData = [...tableData];
      errorRecords.forEach((record) => {
        const invalidItem = existingTableData.find(
          (item) => item.market === record.market
        );
        if (invalidItem) {
          invalidItem['isInvalid'] = true;
        }
      });
      setTableData([...existingTableData]);
    }
  }, [skuMarketErrorData]);

  useEffect(() => {
    if (marketStatus.status === 'success') {
      setUpdatedMarketMasterSku({});
      MasterSubordinatePageUtil.fetchMasterSubordinateRelationship(
        skuInputText,
        setMasterSubordinateResponse,
        setIsMasterSubordinateLoading
      );
    }
  }, [marketStatus]);

  const searchNewSku = (skuInputText) => {
    resetPageForNewSearch();
    getSkuMarketDetails(skuInputText);
    setEnteredMasterSku('');
  };

  const cleaningSkusAndGrid = () => {
    setTableData([]);
  };

  const getSkuMarketDetails = (skuInputText) => {
    if (errorType) {
      setErrorType('');
    }
    MasterSubordinatePageUtil.fetchSkusDetails(
      skuInputText,
      setSkuDataResponse,
      setSkuDates,
      setErrorType
    );
    MasterSubordinatePageUtil.fetchAssortmentMarkets(
      skuInputText,
      setSkuMarketsDataResponse,
      setMarketsAndStatus,
      setErrorType
    );
    MasterSubordinatePageUtil.fetchMasterSubordinateRelationship(
      skuInputText,
      setMasterSubordinateResponse,
      setIsMasterSubordinateLoading,
      setErrorType
    );
  };

  const resetPageForNewSearch = () => {
    if (errorType) {
      setErrorType('');
    }
    updateMasterSubordinateData('selectedByoMarketMap', new Map());
    setTableData([]);
    setUpdatedMarketMasterSku({});
  };

  const handleMasterSkuChange = (newMasterSku, market) => {
    updateExistingMasterSku(newMasterSku, market);
    setUpdatedMarketMasterSku((prevState) => {
      return {
        ...prevState,
        [market]: newMasterSku,
      };
    });
  };

  const columnDefinitions = {
    [MSTR_SUB_COL_KEYS.BYO]: useMemo(() => byoColumn(MSTR_SUB_COL_N.BYO), []),
    [MSTR_SUB_COL_KEYS.MKT]: useMemo(
      () => marketColumn(MSTR_SUB_COL_N.MKT),
      []
    ),
    [MSTR_SUB_COL_KEYS.STS]: useMemo(
      () => statusColumn(MSTR_SUB_COL_N.STS),
      []
    ),
    [MSTR_SUB_COL_KEYS.RTL]: useMemo(
      () => retailColumn(MSTR_SUB_COL_N.RTL),
      []
    ),
    [MSTR_SUB_COL_KEYS.MSTR]: useMemo(
      () => masterSkuColumn(MSTR_SUB_COL_N.MSTR, handleMasterSkuChange),
      [tableData]
    ),
    [MSTR_SUB_COL_KEYS.IN_SESN]: useMemo(
      () => inSeasonColumn(MSTR_SUB_COL_N.IN_SESN),
      []
    ),
    [MSTR_SUB_COL_KEYS.OUT_SESN]: useMemo(
      () => outSeasonColumn(MSTR_SUB_COL_N.OUT_SESN),
      []
    ),
    [MSTR_SUB_COL_KEYS.CLRNC]: useMemo(
      () => clearanceColumn(MSTR_SUB_COL_N.CLRNC),
      []
    ),
    [MSTR_SUB_COL_KEYS.VALIDATION]: useMemo(
      () => validationColumn(MSTR_SUB_COL_N.VALIDATION),
      [tableData]
    ),
  };

  const tableColumns = MasterSubordinateTemplate.map((template) => {
    return columnDefinitions[template.templateKey];
  });

  const formatColumnValue = (value) => {
    return (
      value && value.charAt(0).toUpperCase() + value.slice(1).toLowerCase()
    );
  };

  const getMarketsFromByos = () => {
    let selectedMarkets = [];
    for (const [byoNum, markets] of selectedByoMarketMap.entries()) {
      markets.forEach((market) => {
        selectedMarkets.push({
          ...byoMarkets[byoNum].markets[market],
          market: +market,
          byoName: byoMarkets[byoNum].byoName,
        });
      });
    }
    return selectedMarkets;
  };

  const mergeMarketsAndDates = () => {
    return filterMarketsByState().map((item) => {
      const date = filterDatesByMarkets().filter(
        (date) => date.market === item.market
      )[0];
      return date?.inSeasonDate
        ? {
            ...item,
            inSeasonDate: date?.inSeasonDate,
            outSeasonDate: date?.outSeasonDate,
            clearanceDate: date?.clearanceDate,
          }
        : item;
    });
  };

  const mergeRelationshipsAndMarkets = () => {
    return mergeMarketsAndDates().map((item) => {
      const relation = masterSubordinateResponse.filter(
        (sku) => sku.market === item.market
      );
      let relationedMarket = relation[0];
      if (relation.length > 1) {
        relationedMarket = relation.reduce((acc, market) => {
          const hasSubordinate = market.subordinateSku.find(
            (sku) => sku === skuInputText
          );
          return market;
        }, {});
      }
      //const currentMarket = relation.length===1 ?relation[0] : relation.find((item.subordinateSku)=>)
      return relationedMarket?.market
        ? {
            ...item,
            isMasterSku: relationedMarket.isMasterSku,
            masterSku: relationedMarket.masterSku,
            subordinateSku: relationedMarket?.subordinateSku,
          }
        : item;
    });
  };

  const filterStatesByMarketSelection = () => {
    const byosData = MasterSubordinatePageUtil.getFormattedByos(byoMarkets);

    const filteredMarkets = [];
    mergeRelationshipsAndMarkets().reduce((acc, item) => {
      const isSkuIncluded = item?.subordinateSku?.join().includes(skuInputText);
      const market = {
        ...item,
        byo: byosData[item.byoName]?.byoMarket,
        masterSku: isSkuIncluded ? item.masterSku : '',
      };
      filteredMarkets.push(market);
      return acc;
    }, []);
    setTableData(filteredMarkets);
  };

  const filterMarketsByState = () => {
    return getMarketsFromByos().reduce((acc, market) => {
      const filteredRow = MasterSubordinatePageUtil.filterMarketsForTable(
        marketsAndStatus,
        market
      );
      if (Object.keys(filteredRow).length > 0) acc.push(filteredRow);
      return acc;
    }, []);
  };
  const filterDatesByMarkets = () => {
    const filteredMarkets = getMarketsFromByos();
    let filteredDates = [];
    filteredMarkets.reduce((acc, currentMarket) => {
      const filtered = skuDates.filter(
        (date) => date.market === currentMarket.market
      );
      filteredDates = [...filteredDates, ...filtered];
    }, []);
    return filteredDates;
  };
  const filterDataBasedOnSku = () => {
    if (!_.isEmpty(skuDataResponse)) {
      filterStatesByMarketSelection();
    }
  };

  const handleMasterSkuValidation = () => {
    const existingMasterSkus = masterSubordinateResponse.map(
      (el) => el.masterSku
    );
    const newMasterSkus = Object.keys(updatedMarketMasterSku).map(
      (key) => +updatedMarketMasterSku[key]
    );
    const skus = [...existingMasterSkus, ...newMasterSkus, +skuInputText];
    const uniqueSkus = [...new Set(skus)];
    MasterSubordinatePageUtil.updateMasterSubordinate(
      uniqueSkus,
      +skuInputText,
      updatedMarketMasterSku,
      setMarketStatus,
      setIsValidateBtnLoading,
      setIsSaveBtnLoading,
      isSave,
      setSkuMarketErrorData,
      setIsWriteEndpointFailing
    );
  };

  const handleValidateMasterSubordinateRelationship = () => {
    setIsWriteEndpointFailing(false);
    setIsValidateBtnLoading(true);
    setIsSave(false);
  };

  const handleUpdateMasterSubordinateRelationship = () => {
    setIsWriteEndpointFailing(false);
    setIsSaveBtnLoading(true);
    setIsSave(true);
  };

  const updateExistingMasterSku = (newMasterSku, market) => {
    setTableData((prevData) => {
      const marketData = prevData.find((el) => el.market === Number(market));
      if (marketData) {
        marketData.masterSku = newMasterSku;
      }
      return [...prevData];
    });
  };
  const handleSearchInput = (searchInput) => {
    if (searchInput !== skuInputText) {
      setMarketStatus({});
    }
    setSkuInputText(searchInput);
  };

  const csvHeaders = [
    { label: 'SKU', key: 'sku' },
    { label: 'Market', key: 'market' },
    { label: 'Errors', key: 'errors' },
  ];

  const formatCsvData = () => {
    if (skuMarketErrorData.length) {
      const updatedData = skuMarketErrorData.map((item) => ({
        ...item,
        errors: item.errors.map((error) => '\n' + error),
      }));
      return updatedData;
    }
  };

  const addAll = () => {
    const tableDataCopy = [...tableData];
    const autoFilledMarketMasterSku = {};
    const updatedTableData = tableDataCopy.map((el) => {
      autoFilledMarketMasterSku[el.market] = +enteredMasterSku;
      return { ...el, masterSku: +enteredMasterSku };
    });

    setTableData(updatedTableData);
    setUpdatedMarketMasterSku(() => {
      return {
        ...autoFilledMarketMasterSku,
      };
    });
  };
  const removeAll = () => {
    const tableDataCopy = [...tableData];
    const autoFilledMarketMasterSku = {};
    const updatedTableData = tableDataCopy.map((el) => {
      if (el.masterSku) {
        autoFilledMarketMasterSku[el.market] = '';
      }
      return { ...el, masterSku: '' };
    });
    setTableData(updatedTableData);
    setUpdatedMarketMasterSku(autoFilledMarketMasterSku);
    setEnteredMasterSku('');
  };

  const getMarketMasterMap = () => {
    const mktMstrMap = new Map();
    for (const mktMstrRelationship of masterSubordinateResponse) {
      if (
        mktMstrRelationship.masterSku &&
        mktMstrRelationship.subordinateSku.includes(+skuInputText)
      ) {
        mktMstrMap.set(
          mktMstrRelationship.market,
          mktMstrRelationship.masterSku
        );
      }
    }
    return mktMstrMap;
  };

  const removeErrors = () => {
    const copyOfUpdatedMarketMasterSku = { ...updatedMarketMasterSku };
    const copyOfTableData = [...tableData];
    const marketMasterMap = getMarketMasterMap();
    for (const skuMktErrs of skuMarketErrorData) {
      delete copyOfUpdatedMarketMasterSku[skuMktErrs.market];
      const invalidatedRecord = copyOfTableData.findIndex(
        (row) => row.market == skuMktErrs.market
      );
      if (marketMasterMap.has(skuMktErrs.market)) {
        copyOfTableData[invalidatedRecord].masterSku = marketMasterMap.get(
          skuMktErrs.market
        );
        copyOfTableData[invalidatedRecord].isInvalid = false;
      }
      if (!marketMasterMap.has(skuMktErrs.market) && invalidatedRecord !== -1) {
        copyOfTableData[invalidatedRecord].isInvalid = false;
        delete copyOfTableData[invalidatedRecord].masterSku;
      }
    }

    setTableData(copyOfTableData);
    setUpdatedMarketMasterSku(copyOfUpdatedMarketMasterSku);
    setSkuMarketErrorData([]);
    setMarketStatus({ market: '', status: '' });
  };

  const WarningBannerActions = () => (
    <Space>
      <Button
        type={'text'}
        className={'banner-action-button-text'}
        data-testid={'download-csv-btn'}
      >
        <CSVLink
          data={skuMarketErrorData ? formatCsvData() : ''}
          headers={csvHeaders}
          filename={'MasterSubordinateError_' + new Date().toString()}
        >
          Download CSV
        </CSVLink>
      </Button>
      <Button
        type={'text'}
        className={'banner-action-button-text'}
        data-testid={'remove-errors-btn'}
        onClick={() => removeErrors()}
      >
        Remove Errors
      </Button>
    </Space>
  );

  const handleMasterSkuInputChange = (e) => {
    setEnteredMasterSku(e.target.value);
  };
  const cleanUpElements = () => {
    updateMasterSubordinateData('selectedByoMarketMap', new Map());
    setSkuInputText('');
    setTableData([]);
    setSkuMarketsDataResponse([]);
    setSkuDataResponse({});
    setErrorType('')
    setIsWriteEndpointFailing(false);
    setIsValidateBtnLoading(false);
    setIsSave(false);
  };
  return (
    <>
      <Content className="master-sub">
        <UXDimmer showDimmer={isMasterSubordinateLoading} />
        <SkuLocationFilterSidebar
          searchNewSku={searchNewSku}
          skuMarketsDataResponse={skuMarketsDataResponse}
          setIsGridBeingUpdated={setIsGridBeingUpdated}
          setSkuInputText={handleSearchInput}
          skuInputText={skuInputText}
          errorType={errorType}
          setErrorType={setErrorType}
          cleanUp={cleanUpElements}
        />
        <section className="master-sub__content">
          {marketStatus.status === 'warning' &&
            !isSave &&
            !isValidateBtnLoading &&
            !isWriteEndpointFailing && (
              <Row>
                <Col span={24}>
                  <Alert
                    message="Warning!"
                    description={`Errors were found in validation. Please see the “Validation” column below or download the CSV error report. Errors must be removed to proceed with changes. `}
                    type="warning"
                    banner={true}
                    action={<WarningBannerActions />}
                    closable
                  />
                </Col>
              </Row>
            )}
          {marketStatus.status === 'success' &&
            !isSave &&
            !isValidateBtnLoading && (
              <Row>
                <Col span={24}>
                  <Alert
                    message={'Validation Complete'}
                    description={`No validation errors found.`}
                    type="success"
                    banner={true}
                    closable
                  />
                </Col>
              </Row>
            )}
          {marketStatus.status === 'warning' &&
            isSave &&
            !isSaveBtnLoading &&
            !isWriteEndpointFailing && (
              <Row>
                <Col span={24}>
                  <Alert
                    message="Warning!"
                    description={`Errors were found in validation. Please see the “Validation” column below or download the CSV error report. Errors must be removed to proceed with changes. `}
                    type="warning"
                    banner={true}
                    action={<WarningBannerActions />}
                    closable
                  />
                </Col>
              </Row>
            )}
          {marketStatus.status === 'success' && isSave && !isSaveBtnLoading && (
            <Row>
              <Col span={24}>
                <Alert
                  message={'Save Successful!'}
                  description={`The Master Subordinate relationship was successfully updated.`}
                  type="success"
                  banner={true}
                  closable
                />
              </Col>
            </Row>
          )}
          {isWriteEndpointFailing && (
            <Row>
              <Col span={24}>
                <Alert
                  message={'Error'}
                  description={`A temporary error has occurred. Please try again later or reach out to the mpulse team for assistance.`}
                  type="error"
                  banner={true}
                  closable
                />
              </Col>
            </Row>
          )}
          <div className={'master-sub-page-main'}>
            <div className="master-sub-page-body">
              <div className="sku-number-header">Search Results</div>
              <Row className="sku-columns search-results-table">
                {SKU_HEADER_COLUMNS.map((eachCol) => {
                  return (
                    <Col
                      key={eachCol.key}
                      className="sku-column-header"
                      data-testid={'sku-column-header'}
                    >
                      <div className="sku-column-title">{eachCol.label}:</div>
                      <div>
                        <span>
                          {eachCol.key === SKU_HEADER_COL_KEYS.TYPE
                            ? formatColumnValue(
                                skuDataResponse[SKU_HEADER_COL_KEYS.TYPE]
                              )
                            : skuDataResponse[eachCol.key]}
                        </span>
                        {eachCol.name && skuDataResponse[eachCol.name] && (
                          <span>{` - ${skuDataResponse[eachCol.name]}`}</span>
                        )}
                      </div>
                    </Col>
                  );
                })}
              </Row>
              <Row className="sku-column-mastersku">
                <Col span={3} className="sku-column-title">
                  Master SKU
                </Col>
                <Col span={22} className="master-sub__aside__search">
                  <Input
                    type="text"
                    data-testid="new-masterSku-input-text"
                    onChange={handleMasterSkuInputChange}
                    value={enteredMasterSku}
                  />
                </Col>
                <Col span={2} className="master-sub__addall__button">
                  <Button
                    type={'primary'}
                    onClick={addAll}
                    data-testid="add-all-button"
                    disabled={enteredMasterSku === ''}
                  >
                    Add All
                  </Button>
                </Col>

                <Col span={2}>
                  <Button
                    type={'Secondary'}
                    data-testid="remove-all-button"
                    onClick={removeAll}
                  >
                    Remove All
                  </Button>
                </Col>
              </Row>
            </div>
          </div>
          <Row data-testid="master-sub-page-table">
            <Col span={24}>
              <AdvancedTable
                columns={tableColumns}
                dataSource={tableData}
                tableClassName={'master-sub__table'}
                pagination
              />
            </Col>
          </Row>
          <MasterSubordinatePageFooter
            isValidateBtnLoading={isValidateBtnLoading}
            isSaveBtnLoading={isSaveBtnLoading}
            handleValidate={handleValidateMasterSubordinateRelationship}
            handleSave={handleUpdateMasterSubordinateRelationship}
          />
        </section>
      </Content>
    </>
  );
};
export default MasterSubordinatePageWrapper(MasterSubordinatePage);
