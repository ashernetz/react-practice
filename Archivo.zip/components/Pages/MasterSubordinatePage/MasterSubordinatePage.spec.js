import React from 'react';
import { fireEvent, render, screen, within } from '@testing-library/react';
import MasterSubordinatePage from './MasterSubordinatePage';
import axios from 'axios';
import { when } from 'jest-when';

import { act } from 'react-dom/test-utils';

import '@testing-library/jest-dom';
import MasterSubordinateServices from '../../../services/MasterSubordinateServices';
import { masterSubordinateSkuRelationship } from './__fixtures__/masterSubordinateResponse';
import { byoMarketResponse } from './__fixtures__/byoMarketResponse';
import { assortmentMarketsResponse } from './__fixtures__/assortmentMarketsResponse';
import userEvent from '@testing-library/user-event';

jest.mock('axios');
beforeEach(() => {
  when(axios.post)
    .calledWith(`/api/dataConnect/byo-markets`, expect.anything())
    .mockResolvedValue({ data: byoMarketResponse });
  when(axios.post)
    .calledWith(`/api/dataConnect/sku-market-status`, expect.anything())
    .mockResolvedValue({ data: assortmentMarketsResponse });
  when(axios.post)
    .calledWith(`/api/dataConnect/sku-description-details`, expect.anything())
    .mockResolvedValue({
      data: [
        {
          sku: 301329,
          type: 'NORMAL',
          description: '3/4"X10\' GAL PIPE',
          departmentNumber: 26,
          departmentName: 'PLUMBING',
          classNumber: 1,
          className: 'PIPE AND FITTINGS',
          subClassNumber: 6,
          subClassName: 'GALVANIZED PIPE',
        },
      ],
    });
  when(axios.post)
    .calledWith(
      `/api/sku-relationship/master-subordinate-relationship`,
      expect.anything()
    )
    .mockResolvedValue({
      data: masterSubordinateSkuRelationship,
    });
  when(axios.post)
    .calledWith(`/api/dataConnect/sku-market-date`, expect.anything())
    .mockResolvedValue({
      data: [
        {
          clearanceDate: null,
          inSeasonDate: '2023-12-25',
          market: 303,
          outSeasonDate: '2023-12-26',
          sku: 558262,
        },
        {
          clearanceDate: null,
          inSeasonDate: '2023-12-25',
          market: 303,
          outSeasonDate: '2023-12-26',
          sku: 558262,
        },
        {
          clearanceDate: null,
          inSeasonDate: '2023-12-25',
          market: 505,
          outSeasonDate: '2023-12-26',
          sku: 113156,
        },
        {
          clearanceDate: null,
          inSeasonDate: '2023-12-25',
          market: 479,
          outSeasonDate: '2023-12-26',
          sku: 113156,
        },
      ],
    });
});
afterEach(() => {
  jest.clearAllMocks();
});
describe('MasterSubordinatePage', () => {
  const searchSku = async (sku) => {
    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: sku,
        },
      });
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
  };

  const searchLocations = async (inputValue) => {
    await act(async () => {
      fireEvent.change(screen.getByTestId('location-search-input'), {
        target: {
          value: inputValue,
        },
      });
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('location-plus-button'));
    });
  };

  const clickByoMarketListExpandButton = async (byoNum) => {
    await act(async () => {
      fireEvent.click(screen.getByTestId(`byo-${byoNum}-expand-btn`));
    });
  };

  const clickElement = async (el) => {
    await act(async () => {
      fireEvent.click(el);
    });
  };

  const typeInput = async (el, val) => {
    await act(async () => {
      fireEvent.change(el, {
        target: {
          value: val,
        },
      });
    });
  };

  test('remove banners on changing the searched sku', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=true`,
        expect.anything()
      )
      .mockRejectedValue({
        data: [
          [
            {
              sku: 880700,
              market: 1,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
          ],
        ],
      });
    render(<MasterSubordinatePage />);
    const saveBtn = screen.getByText('Save');
    await act(async () => {
      fireEvent.click(saveBtn);
    });
    expect(screen.getByText('Warning!')).toBeInTheDocument();

    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: '880700',
        },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(screen.queryByText('Warning!')).not.toBeInTheDocument();
  });

  describe('testing the addAll and Remove all buttons ', () => {
    beforeEach(async () => {
      render(<MasterSubordinatePage />);
      await searchSku('606060');
    });

    test('test the add all delete all button ', async () => {
      await act(async () => {
        await userEvent.click(screen.getByTestId('sku-search-button'));
      });
      await act(async () => {
        await clickElement(screen.getByTestId('select-all-markets-btn'));
        await searchLocations('42');
        await clickElement(screen.getByTestId('location-plus-button'));
        await clickElement(screen.getByTestId('grid-update'));
      });
      const addAll = screen.getByTestId('add-all-button');
      expect(addAll).toBeDisabled();
      const removeAll = screen.getByTestId('remove-all-button');
      expect(removeAll).toBeEnabled();

      await typeInput(screen.getByTestId('new-masterSku-input-text'), 100021);
      await clickElement(screen.getByTestId('add-all-button'));
      expect(screen.getByTestId('market-467-master-sku-input')).toHaveValue(
        100021
      );
      await clickElement(screen.getByTestId('remove-all-button'));

      expect(screen.getByTestId('market-467-master-sku-input')).toHaveValue(
        null
      );
    });
  });
  describe('Location Filter', () => {
    describe('Selecting Locations', () => {
      beforeEach(async () => {
        render(<MasterSubordinatePage />);
        await searchSku('880700');
      });
      describe('Select/deselect all', () => {
        test('All selected by default on sku search', async () => {
          expect(screen.getByTestId('select-all-markets-btn')).toBeChecked();
          const allLocationCheckboxes =
            screen.queryAllByTestId('location-checkmark');
          for (const checkbox of allLocationCheckboxes) {
            expect(checkbox).toBeChecked();
          }
        });
        test('Deselect all', async () => {
          await clickElement(screen.getByTestId('select-all-markets-btn'));
          expect(
            screen.getByTestId('select-all-markets-btn')
          ).not.toBeChecked();
          const allLocationCheckboxes =
            screen.queryAllByTestId('location-checkmark');
          for (const checkbox of allLocationCheckboxes) {
            expect(checkbox).not.toBeChecked();
          }
        });
        test('Select all after clearing selections', async () => {
          await clickElement(screen.getByTestId('select-all-markets-btn'));
          await clickElement(screen.getByTestId('select-all-markets-btn'));
          expect(screen.getByTestId('select-all-markets-btn')).toBeChecked();
          const allLocationCheckboxes =
            screen.queryAllByTestId('location-checkmark');
          for (const checkbox of allLocationCheckboxes) {
            expect(checkbox).toBeChecked();
          }
        });
      });
      describe('From user manual selection', () => {
        test('Expand/collapse byo market lists', async () => {
          expect(screen.queryByTestId('market-checkbox-2')).toBeNull();
          await clickByoMarketListExpandButton(1);
          expect(screen.queryByTestId('market-checkbox-2')).toBeInTheDocument();
          await clickByoMarketListExpandButton(1);
          expect(screen.queryByTestId('market-checkbox-2')).toBeNull();
        });
        test('Displays market statuses', async () => {
          const enabledBox = screen.getByTestId('byo-1-check-btn');
          expect(enabledBox).not.toBeDisabled();
          const disabledBox = screen.getByTestId('byo-12-check-btn');
          expect(disabledBox).toBeDisabled();
        });
        test('Checks enabled markets', async () => {
          const enabledBox = screen.getByTestId('byo-1-check-btn');
          await clickElement(enabledBox); //unselect checkbox
          expect(enabledBox).not.toBeChecked();
          await clickElement(enabledBox); //reselect checkbox
          expect(enabledBox).toBeChecked();
        });
        test('Unable to check disabled markets', async () => {
          const disabledBox = screen.getByTestId('byo-12-check-btn');
          await clickElement(disabledBox);
          expect(disabledBox).not.toBeChecked();
        });
      });
      describe('From user entered location search', () => {
        test('Selects location by number', async () => {
          await searchLocations('1');
          const checkbox = screen.getByTestId('byo-1-check-btn');
          expect(checkbox.checked).toEqual(true);
        });
        test('Selects location by name', async () => {
          await searchLocations('Southeast');
          const checkbox = screen.getByTestId('byo-1-check-btn');
          expect(checkbox.checked).toEqual(true);
        });
        test('Selects locations split by commas', async () => {
          await searchLocations('Southeast, midwest');
          const checkbox1 = screen.getByTestId('byo-1-check-btn');
          expect(checkbox1.checked).toEqual(true);
          const checkbox2 = screen.getByTestId('byo-7-check-btn');
          expect(checkbox2.checked).toEqual(true);
        });
        test('Selects locations split by semi colons', async () => {
          await searchLocations('Southeast; midwest');
          const checkbox1 = screen.getByTestId('byo-1-check-btn');
          expect(checkbox1.checked).toEqual(true);
          const checkbox2 = screen.getByTestId('byo-7-check-btn');
          expect(checkbox2.checked).toEqual(true);
        });
        test('Selects locations split by tabs', async () => {
          await searchLocations('Southeast\tmidwest');
          const checkbox1 = screen.getByTestId('byo-1-check-btn');
          expect(checkbox1.checked).toEqual(true);
          const checkbox2 = screen.getByTestId('byo-7-check-btn');
          expect(checkbox2.checked).toEqual(true);
        });
        test('Selects locations split by spaces ONLY if searching by number', async () => {
          await searchLocations('1 7');
          const checkbox1 = screen.getByTestId('byo-1-check-btn');
          expect(checkbox1.checked).toEqual(true);
          const checkbox2 = screen.getByTestId('byo-7-check-btn');
          expect(checkbox2.checked).toEqual(true);
        });
      });
    });
  });

  describe('Remove errors', () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=false`,
        expect.anything()
      )
      .mockRejectedValue({
        response: {
          status: 400,
          data: [
            {
              sku: 880700,
              market: 505,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
            {
              sku: 880700,
              market: 427,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
          ],
        },
      });
    test('Reset error rows - master sku', async () => {
      await act(async () => {
        render(<MasterSubordinatePage />);
        await userEvent.type(screen.getByTestId('sku-input-text'), '880700');
        await userEvent.click(screen.getByTestId('sku-search-button'));
      });
      await act(async () => {
        await searchLocations('TEST BYO ONE; TEST BYO TWO');
        await clickElement(screen.getByTestId('grid-update'));
      });
      expect(screen.getByTestId('market-505-master-sku-input')).toHaveValue(
        113156
      );
      await typeInput(
        screen.getByTestId('market-505-master-sku-input'),
        100021
      );
      await clickElement(screen.getByTestId('validate-master-sub-btn'));
      await clickElement(screen.getByText('Remove Errors'));
      expect(screen.getByTestId('market-505-master-sku-input')).toHaveValue(
        113156
      );
    });
    test('Reset error rows - non master sku', async () => {
      await act(async () => {
        render(<MasterSubordinatePage />);
        await userEvent.type(screen.getByTestId('sku-input-text'), '880700');
        await userEvent.click(screen.getByTestId('sku-search-button'));
      });
      await act(async () => {
        await searchLocations('TEST BYO ONE; TEST BYO TWO');
        await clickElement(screen.getByTestId('grid-update'));
      });
      await typeInput(screen.getByTestId('market-427-master-sku-input'), '123');
      await clickElement(screen.getByTestId('validate-master-sub-btn'));
      await clickElement(screen.getByText('Remove Errors'));
      expect(screen.getByTestId('market-427-master-sku-input')).toHaveValue(
        null
      );
    });
  });

  test('render heading', () => {
    render(<MasterSubordinatePage />);
    expect(
      screen.getAllByText('Master Subordinate Maintenance')[0]
    ).toBeInTheDocument();
    expect(screen.getByText('Search Results')).toBeInTheDocument();
  });

  test('render sku description for entered sku', async () => {
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: '301329',
        },
      });
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(screen.getByText('3/4"X10\' GAL PIPE')).toBeInTheDocument();
    expect(screen.queryAllByTestId('sku-column-header').length).toBeGreaterThan(
      0
    );
    expect(screen.getByText('Normal')).toBeInTheDocument();
    expect(screen.getByText(/PLUMBING/)).toBeInTheDocument();
    expect(screen.getByText(/PIPE AND FITTINGS/)).toBeInTheDocument();
    expect(screen.getByText(/GALVANIZED PIPE/)).toBeInTheDocument();
  });

  describe('Master subordinate page table', () => {
    test('render table headers', async () => {
      const { getByTestId } = render(<MasterSubordinatePage />);
      const tableHeaderElement = getByTestId('master-sub-page-table');
      const { getByText } = within(tableHeaderElement);
      expect(getByText('BYO')).toBeInTheDocument();
      expect(getByText('Market')).toBeInTheDocument();
      expect(getByText('Status')).toBeInTheDocument();
      expect(getByText('Retail')).toBeInTheDocument();
      expect(getByText('Master SKU')).toBeInTheDocument();
      expect(getByText('In Season')).toBeInTheDocument();
      expect(getByText('Out Season')).toBeInTheDocument();
      expect(getByText('Clearance Date')).toBeInTheDocument();
    });
  });

  test('failure of the sku search', async () => {
    when(axios.post)
      .calledWith(`/api/dataConnect/sku-description-details`, expect.anything())
      .mockRejectedValueOnce({
        response: {
          status: 404,
        },
        message: 'Mocked error',
        name: 'AxiosError',
      });
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(screen.getByText(/Failed to get Sku details/)).toBeInTheDocument();
  });

  test('failure of the read endpoint', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/master-subordinate-relationship`,
        expect.anything()
      )
      .mockRejectedValueOnce({
        response: {
          status: 500,
        },
        message: 'Mocked error',
        name: 'AxiosError',
      });
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(
      screen.getByText(/Failed to get Master-Subordinate data/)
    ).toBeInTheDocument();
  });

  test('failure of the status endpoint', async () => {
    when(axios.post)
      .calledWith(`/api/dataConnect/sku-market-status`, expect.anything())
      .mockRejectedValueOnce({
        response: {
          status: 500,
        },
        message: 'Mocked error',
        name: 'AxiosError',
      });
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(
      screen.getByText(/Failed to get Assortment\/Retail data/)
    ).toBeInTheDocument();
  });

  test('failure of the date endpoint', async () => {
    when(axios.post)
      .calledWith(`/api/dataConnect/sku-market-date`, expect.anything())
      .mockRejectedValueOnce({
        response: {
          status: 500,
        },
        message: 'Mocked error',
        name: 'AxiosError',
      });
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(
      screen.getByText(/Failed to get Seasonal\/Clearance data/)
    ).toBeInTheDocument();
  });

  test('failure of the sku description endpoint', async () => {
    when(axios.post)
      .calledWith(`/api/dataConnect/sku-description-details`, expect.anything())
      .mockRejectedValueOnce({
        response: {
          status: 500,
        },
        message: 'Mocked error',
        name: 'AxiosError',
      });
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(screen.getByText(/Failed to get Sku details/)).toBeInTheDocument();
  });

  test('test the season and clearence date', async () => {
    const spiedFn = jest.spyOn(
      MasterSubordinateServices,
      'fetchSeasonClearenceDates'
    );

    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: '301329',
        },
      });
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(spiedFn).toBeCalled();
  });

  test('click on update grid', async () => {
    when(axios.post)
      .calledWith(`/api/dataConnect/sku-market-status`, expect.anything())
      .mockResolvedValue({
        data: [
          { market: 1, masterSku: 193801, subordinateSku: [193801, 193801] },
        ],
      });
    when(axios.post)
      .calledWith(
        `/api/dataConnect/master-subordinate-relationship`,
        expect.anything()
      )
      .mockResolvedValue({
        data: [],
      });
    const user = userEvent.setup();
    render(<MasterSubordinatePage />);
    // const mockedgetFormattedByos = jest
    //   .spyOn(MasterSubordinatePageUtil, 'getFormattedByos')
    //   .mockResolvedValueOnce({
    //     SOUTHEAST: {
    //       byoMarket: '1',
    //       byoName: 'SOUTHEAST',
    //       markets: { 1: { marketName: 'Atlanta' } },
    //     },
    //   });

    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: '880700',
        },
      });
      const input = screen.getByTestId('sku-input-text');
      await user.type(input, '880700');
      await user.tab(); // blur
      await act(async () => {
        fireEvent.click(screen.getByTestId('grid-update'));
      });
    });
    // expect(mockedgetFormattedByos).toBeCalled(); // What was this really testing?
  });
  test('render validation errors if not valid', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=true`,
        expect.anything()
      )
      .mockRejectedValue({
        data: [
          [
            {
              sku: 880700,
              market: 1,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
            {
              sku: 880740,
              market: 5,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
          ],
        ],
      });
    render(<MasterSubordinatePage />);
    const validateBtn = screen.getByText('Validate');
    await act(async () => {
      fireEvent.click(validateBtn);
    });
    expect(screen.getAllByText(/Error/)[0]).toBeInTheDocument();
    const removeErrorsBtn = screen.getByText('Remove Errors');

    await act(async () => {
      fireEvent.click(removeErrorsBtn);
    });
    expect(screen.queryByText(/Error/)).not.toBeInTheDocument();
  });
  test('renderbanners on validate', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=false`,
        expect.anything()
      )
      .mockResolvedValue({
        data: [],
      });

    render(<MasterSubordinatePage />);
    const validateBtn = screen.getByText('Validate');

    await act(async () => {
      fireEvent.click(validateBtn);
    });
    expect(screen.getByText('Validation Complete')).toBeInTheDocument();
  });

  test('render banners on validate for warning', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=false`,
        expect.anything()
      )
      .mockRejectedValue({
        data: [
          [
            {
              sku: 880700,
              market: 1,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
          ],
        ],
      });
    render(<MasterSubordinatePage />);
    const validateBtn = screen.getByText('Validate');

    await act(async () => {
      fireEvent.click(validateBtn);
    });
    expect(screen.getByText('Warning!')).toBeInTheDocument();
    expect(screen.getByText('Download CSV')).toBeInTheDocument();
  });

  test('render banners on save', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=true`,
        expect.anything()
      )
      .mockResolvedValue({
        data: [],
      });

    render(<MasterSubordinatePage />);
    const saveBtn = screen.getByText('Save');

    await act(async () => {
      fireEvent.click(saveBtn);
    });
    expect(screen.getByText('Save Successful!')).toBeInTheDocument();
  });
  test('render banners on save for warning', async () => {
    when(axios.post)
      .calledWith(
        `/api/sku-relationship/update-master-subordinate-relationship?isSaving=true`,
        expect.anything()
      )
      .mockRejectedValue({
        data: [
          [
            {
              sku: 880700,
              market: 1,
              errors: [
                'Master SKU 123 status must be A, I, O or S (Active, Inactive, Out of Season or In Season)',
              ],
            },
          ],
        ],
      });
    render(<MasterSubordinatePage />);
    const saveBtn = screen.getByText('Save');

    await act(async () => {
      fireEvent.click(saveBtn);
    });
    expect(screen.getByText('Warning!')).toBeInTheDocument();
    expect(screen.getByText('Download CSV')).toBeInTheDocument();
  });

  test('test the master sku relationship response', async () => {
    const mockedFn = jest.spyOn(
      MasterSubordinateServices,
      'fetchMasterSubordinateRelationship'
    );

    jest
      .spyOn(MasterSubordinateServices, 'fetchSeasonClearenceDates')
      .mockResolvedValueOnce('success');
    render(<MasterSubordinatePage />);
    await act(async () => {
      fireEvent.change(screen.getByTestId('sku-input-text'), {
        target: {
          value: '880700',
        },
      });
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('sku-search-button'));
    });
    expect(mockedFn).toBeCalled();
  });
});
