export const byoMarketResponse = [
  {
    store: 9999,
    market: 427,
    marketName: 'TEST MARKET ONE',
    byo: 99,
    byoName: 'TEST BYO ONE',
  },
  {
    store: 8888,
    market: 505,
    marketName: 'TEST MARKET TWO',
    byo: 88,
    byoName: 'TEST BYO TWO',
  },
  {
    store: 2708,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2708,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2702,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2707,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2740,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2776,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2711,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2758,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2706,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2718,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2734,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2727,
    market: 72,
    marketName: 'DETROIT',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1902,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1922,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1913,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1987,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1938,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1981,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 6981,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 8431,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1941,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1926,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1907,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 6887,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1939,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1957,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1910,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1975,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1921,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 6925,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1934,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 6923,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1962,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1977,
    market: 304,
    marketName: 'CENTRAL ILLINOIS',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2842,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2811,
    market: 262,
    marketName: 'OUTSTATE MN',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 3701,
    market: 262,
    marketName: 'OUTSTATE MN',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2817,
    market: 262,
    marketName: 'OUTSTATE MN',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2831,
    market: 583,
    marketName: 'FERGUS FALLS',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 3705,
    market: 551,
    marketName: 'MINOT, ND TEMP MKT',
    byo: 35,
    byoName: 'SMS NORTHERN',
  },
  {
    store: 2834,
    market: 584,
    marketName: 'GRAND RAPID, MN',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 2818,
    market: 262,
    marketName: 'OUTSTATE MN',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2821,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2830,
    market: 262,
    marketName: 'OUTSTATE MN',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2840,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3703,
    market: 551,
    marketName: 'MINOT, ND TEMP MKT',
    byo: 35,
    byoName: 'SMS NORTHERN',
  },

  {
    store: 1903,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1986,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1912,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 8598,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1950,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1911,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },
  {
    store: 1974,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1961,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1914,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1980,
    market: 234,
    marketName: 'METRO CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1976,
    market: 318,
    marketName: 'LINCOLN PARK',
    byo: 35,
    byoName: 'SMS NORTHERN',
  },

  {
    store: 4117,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4152,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4129,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4159,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4123,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4139,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4148,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4160,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 8433,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4135,
    market: 106,
    marketName: 'PITTSBURGH',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3034,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3003,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3009,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3001,
    market: 537,
    marketName: 'NE MISSOURI',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3013,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3025,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3022,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3015,
    market: 109,
    marketName: 'ST. LOUIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3036,
    market: 425,
    marketName: 'RURAL NORTHERN WEST',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3027,
    market: 537,
    marketName: 'NE MISSOURI',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 6919,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1983,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1906,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 8918,
    market: 589,
    marketName: 'CRAWFORDSVILLE',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1989,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1967,
    market: 590,
    marketName: 'MATTOON',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2034,
    market: 276,
    marketName: 'INDIANAPOLIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1984,
    market: 304,
    marketName: 'CENTRAL ILLINOIS',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 1932,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 6822,
    market: 75,
    marketName: 'CHICAGO',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2801,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2847,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2803,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2820,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2813,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2810,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4935,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2802,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2843,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2807,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 2828,
    market: 101,
    marketName: 'MINNESOTA',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3882,
    market: 139,
    marketName: 'CLEVELAND',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3830,
    market: 139,
    marketName: 'CLEVELAND',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 3860,
    market: 139,
    marketName: 'CLEVELAND',
    byo: 7,
    byoName: 'MIDWEST',
  },

  {
    store: 4714,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1537,
    market: 190,
    marketName: 'GRAND JUNCTION',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1525,
    market: 324,
    marketName: 'VAIL,CO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1550,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1507,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1513,
    market: 190,
    marketName: 'GRAND JUNCTION',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1522,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1535,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1514,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1549,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1520,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1526,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1508,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1523,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1501,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1509,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1505,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1528,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1547,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },
  {
    store: 1551,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },
  {
    store: 1519,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1504,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1518,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1538,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1531,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1510,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1516,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },
  {
    store: 1511,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1541,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 1540,
    market: 51,
    marketName: 'COLORADO',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3103,
    market: 204,
    marketName: 'WESTERN MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3105,
    market: 204,
    marketName: 'WESTERN MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3101,
    market: 195,
    marketName: 'BILLINGS, MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3104,
    market: 204,
    marketName: 'WESTERN MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3102,
    market: 204,
    marketName: 'WESTERN MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 3106,
    market: 204,
    marketName: 'WESTERN MONTANA',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4725,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4014,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4718,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4738,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4746,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4739,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },
  {
    store: 4031,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4004,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4026,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4013,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4721,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4727,
    market: 94,
    marketName: 'SPOKANE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4003,
    market: 542,
    marketName: 'EUGENE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4009,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4028,
    market: 542,
    marketName: 'EUGENE',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4008,
    market: 77,
    marketName: 'CENTRAL OREGON',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4020,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4034,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4032,
    market: 77,
    marketName: 'CENTRAL OREGON',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4029,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8557,
    market: 54,
    marketName: 'PORTLAND',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4019,
    market: 77,
    marketName: 'CENTRAL OREGON',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4715,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4745,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4713,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8561,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8563,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4233,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4712,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4726,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8998,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8566,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4406,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4415,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4414,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4419,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4462,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4411,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 6003,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4410,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4408,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 8583,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4401,
    market: 76,
    marketName: 'UTAH',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4701,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4737,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4728,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4720,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4703,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4722,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 4741,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },
  {
    store: 4716,
    market: 44,
    marketName: 'SEA/TAC',
    byo: 12,
    byoName: 'NORTHWEST',
  },

  {
    store: 446,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 423,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },

  { store: 403, market: 6, marketName: 'PHOENIX', byo: 5, byoName: 'PACIFIC' },

  {
    store: 421,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },
  { store: 442, market: 6, marketName: 'PHOENIX', byo: 5, byoName: 'PACIFIC' },

  {
    store: 482,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 416,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 452,
    market: 134,
    marketName: 'PRESCOTT',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 1006,
    market: 29,
    marketName: 'SACRAMENTO',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 6660,
    market: 29,
    marketName: 'SACRAMENTO',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 1842,
    market: 29,
    marketName: 'SACRAMENTO',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 1003,
    market: 29,
    marketName: 'SACRAMENTO',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 6601,
    market: 29,
    marketName: 'SACRAMENTO',
    byo: 5,
    byoName: 'PACIFIC',
  },

  {
    store: 6351,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6974,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 6890,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 227,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6369,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 272,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 275,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6921,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6346,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1324,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6935,
    market: 14,
    marketName: 'JACKSONVILLE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6348,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3119,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 268,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6950,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 8444,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 267,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 201,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 250,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 276,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6975,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6373,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 280,
    market: 25,
    marketName: 'FT.MYERS/NAPLES',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6851,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6350,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6869,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 265,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 266,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 232,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6375,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 261,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6367,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6328,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 8926,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6331,
    market: 3,
    marketName: 'ORL/MEL/DAYTONA',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 236,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 288,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 247,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6357,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 246,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6304,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6364,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 257,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6361,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 245,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 289,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 6321,
    market: 4,
    marketName: 'TAMPA/ST.PETE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3606,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3646,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3608,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3640,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3607,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3638,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3642,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3628,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3603,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3662,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3601,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3602,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 3639,
    market: 45,
    marketName: 'CHARLOTTE',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 141,
    market: 23,
    marketName: 'SAVANNAH/HILTON HEAD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1118,
    market: 392,
    marketName: 'CHARLESTON',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 179,
    market: 23,
    marketName: 'SAVANNAH/HILTON HEAD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 122,
    market: 23,
    marketName: 'SAVANNAH/HILTON HEAD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 170,
    market: 23,
    marketName: 'SAVANNAH/HILTON HEAD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1120,
    market: 392,
    marketName: 'CHARLESTON',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1103,
    market: 392,
    marketName: 'CHARLESTON',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1171,
    market: 392,
    marketName: 'CHARLESTON',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 1115,
    market: 23,
    marketName: 'SAVANNAH/HILTON HEAD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 704,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 737,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 727,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 2903,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 703,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 8916,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 729,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 8469,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 779,
    market: 541,
    marketName: 'COVINGTON, TN',
    byo: 39,
    byoName: 'NCD-SMALL MKT-SOUTHERN',
  },

  {
    store: 725,
    market: 327,
    marketName: 'MEMPHIS',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 875,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 866,
    market: 531,
    marketName: 'OXFORD',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 818,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },
  {
    store: 881,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 882,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 887,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 810,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 880,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 805,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 877,
    market: 89,
    marketName: 'BIRMINGHAM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6313,
    market: 344,
    marketName: 'KEY WEST MKT',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6343,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 211,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 207,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6378,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6302,
    market: 344,
    marketName: 'KEY WEST MKT',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6355,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6306,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 6856,
    market: 471,
    marketName: 'SMALL LAYOUT',
    byo: 39,
    byoName: 'NCD-SMALL MKT-SOUTHERN',
  },

  {
    store: 277,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 222,
    market: 2,
    marketName: 'MIAMI/FTL/WPALM',
    byo: 1,
    byoName: 'SOUTHEAST',
  },

  {
    store: 898,
    market: 467,
    marketName: 'GUAM',
    byo: 42,
    byoName: 'GUAM',
  },
];
