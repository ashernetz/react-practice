export const masterSubordinateSkuRelationship = [
  {
    market: 479,
    masterSku: 113156,
    subordinateSku: [880700],
  },
  {
    market: 427,
    subordinateSku: [998765],
  },
  {
    market: 467,
    subordinateSku: [880700],
  },
  {
    market: 505,
    masterSku: 113156,
    subordinateSku: [880700, 775789],
  },
];
