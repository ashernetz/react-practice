export const assortmentMarketsResponse = [
  { sku: 100021, market: 89, retail: 7100, store: [], status: 'Clearance' },
  { sku: 100021, market: 75, retail: 220000, store: [], status: 'Active' },
  { sku: 100021, market: 234, retail: 220000, store: [], status: 'Active' },
  { sku: 100021, market: 505, retail: 7100, store: [], status: 'Clearance' },
  { sku: 113156, market: 505, retail: 210000, store: [], status: 'Active' },
  { sku: 775789, market: 427, retail: 240000, store: [], status: 'Active' },
  { sku: 100021, market: 467, retail: 7100, store: [], status: 'Active' },
];
