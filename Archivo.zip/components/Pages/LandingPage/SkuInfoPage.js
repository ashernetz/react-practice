import React, {useContext, useEffect, useState} from 'react';
import {Row, Col, Layout} from 'antd';
import FilterComponent from '../../FilterComponent/FilterComponent'
import SkuDetailComponent from '../../SkuDetailComponent/SkuDetailComponent'
import SearchBarLayout from "../../SearchBarLayout/SearchBarLayout";
import PricePointDetailLayout from "../../PricePointDetailLayout/PricePointDetailLayout";
import PriceDataServices from "../../../services/PriceDataServices";
import SkuContext from "../../../context/SkuContext";
import FilterUtil from "../../Utils/FilterUtil";
import PricePointUtil from "../../Utils/PricePointUtil";
import AdvancedGMap from "../../MapComponent/AdvancedGMap";
import SkuApiHelper from "../../Helper/SkuApiHelper";
import MapContext from "../../../context/MapContext";
import '../../DashboardDrawer/DashboardDrawer.scss';
import '../../DashboardDrawer/DCSOverviewModal/DCSOverviewModal.scss';
import './LandingPage.scss';
import SingleSkuCardApiHelper from "../SkuPages/SingleSkuCards/SingleSkuCardApiHelper";

const {Content} = Layout;

const initialState =  {
  isFilterDrawerOpen: false,
  isPricePointDrawerOpen: false,
  distinctSkuStatusList:[],
  defaultMapFilterValues : FilterUtil.getInitialFilterValues(),
};

const SkuInfoPage= (props)=> {
  const mapContext = useContext(MapContext);
  const skuContext = useContext(SkuContext);

  const [isFilterDrawerOpen,setIsFilterDrawerOpen] = useState(initialState.isFilterDrawerOpen);
  const [isPricePointDrawerOpen,setIsPricePointDrawerOpen] = useState(initialState.isPricePointDrawerOpen);
  const [distinctSkuStatusList,setDistinctSkuStatusList] = useState(initialState.distinctSkuStatusList);
  const [defaultMapFilterValues,setDefaultMapFilterValues] = useState(initialState.defaultMapFilterValues);

  useEffect(
      () => {
        if(props.searchSku){
          onSearchClick(props.searchSku, props.searchSkuOrigin);

        }
      },
      [props.searchSku],
  );

  useEffect(()=>{
    skuContext.updateStateFields({skuCompSales:undefined,skuCompUnits:undefined, skuStorePerformanceData: {storeLevelPerformance:{},rawSalesAndUnitsMap:{}}, isPerformanceDataLoaded: false});
    SkuApiHelper.fetchSkuStorePerformanceData(props.searchSku,skuContext,props.user.userId);
  },[skuContext.timeTransformType]);

  useEffect(()=>{
    if(skuContext.skuNumber && skuContext.favSkuMap && Object.keys(skuContext.favSkuMap)){
      skuContext.updateStateFields({isFavorite:skuContext.favSkuMap? skuContext.favSkuMap.hasOwnProperty(skuContext.skuNumber):false});
    }
  },[skuContext.favSkuMap,skuContext.skuNumber]);

  const setDefaultOffsideFilterValue = (mapFilterDefaultValues,offsideMap,selectedSkuStatusList) => {
    skuContext.updateFilterSelection({offsideMap,selectedSkuStatusList});
    mapFilterDefaultValues.offsideMap = offsideMap;
    mapFilterDefaultValues.selectedSkuStatusList = selectedSkuStatusList;
    mapFilterDefaultValues.isFilterValuesLoaded = true;
    setDefaultMapFilterValues(mapFilterDefaultValues);
  };

  const onSearchClick =  (skunum, origin) => {
    mapContext.resetState();
    skuContext.resetState();
    skuContext.updateShowDimmer(true);
    skuContext.updateFilterSelection(FilterUtil.getInitialFilterValues());
    skuContext.updatePreviewData(props);
    setDefaultMapFilterValues(initialState.defaultMapFilterValues);
    //trackEvent("MPULSE_SKU_SEARCH", {'sku': skunum, 'ORIGIN': origin});
    let isInStoreLoaded = false;
    PriceDataServices.fetchSkuDetails(skunum,props.user.userId,skuContext.profileData.title)
        .then(skuData => {
          SkuApiHelper.fetchSkuImage(skunum,skuContext);
          SkuApiHelper.fetchVendors(skunum,skuContext);
          SkuApiHelper.fetchSkuStorePerformanceData(skunum,skuContext,props.user.userId);
          SkuApiHelper.fetchPriceChangeHistory(skunum,skuContext);
          SkuApiHelper.fetchPendingPriceChangeDetails(skunum,skuData.data.pacManSKU,skuContext);
          SkuApiHelper.fetchSkuRank(skunum, skuContext);
          // SkuApiHelper.fetchSalesMetricsDetails(skunum,skuContext);

          let distinctSkuStatusSet =
              Object.keys(skuData.data.skuStoreStatus).map(k => Number(k));
          let selectedSkuStatusList = FilterUtil.formDefaultSkuStatus(distinctSkuStatusSet);
          let uniqueSkuStatusList = [...FilterUtil.getSkuStoreStatusMap(distinctSkuStatusSet).values()];
          PricePointUtil.addExtraDetailsToPricePoint(skuData.data, props.user,distinctSkuStatusSet);

          let mapFilterDefaultValues = {...FilterUtil.getInitialFilterValues()};
          mapFilterDefaultValues.selectedSkuStatusList = selectedSkuStatusList;
          setDefaultMapFilterValues(mapFilterDefaultValues);
          skuContext.updateFilterSelection({selectedSkuStatusList});

          SkuApiHelper.fetchCompetitorPriceDetails(skunum,
              props.config.competitorDataUrl,
              skuContext.updateStateFields, skuData.data.storeRetailMap,skuData.data.offsideStoreConsideration,(offsideMap)=>setDefaultOffsideFilterValue(mapFilterDefaultValues,offsideMap,selectedSkuStatusList));
          skuContext.updateSkuData(skuData.data);

          setIsFilterDrawerOpen(false);
          setIsPricePointDrawerOpen(false);
          setDistinctSkuStatusList(uniqueSkuStatusList);

          //skuContext.updateShowDimmer(false);
          SingleSkuCardApiHelper.fetchInStoreCostData(skunum,skuData.data.availableStores,props.setCardData)
          SkuApiHelper.fetchOHQuantityDetails(skunum,skuData.data.availableStores,skuContext);
          SkuApiHelper.fetchUnitsOnHandDetails(skunum,skuData.data.availableStores,skuContext);
          isInStoreLoaded = true;
        }).catch(k => {
      // let alertMessage = AlertUtil.getErrorMessage("performing sku search");
      // if (k.response.status === 422) {
      //   if (k.response.data.includes("Invalid SKU")) {
      //     alertMessage =
      //         <div>SKU not found : <b>{skunum}</b></div>
      //
      //   } else {
      //     alertMessage = <div>{k.response.data}</div>
      //     console.log(k.response.data);
      //   }
      // }
      console.log(k.response.data);
      //AlertUtil.showAlert("error","Error",alertMessage);
      //skuContext.updateShowDimmer(false);
      props.updateShowNewDashboardView(true);
    }).finally(()=>{  props.setSingleSkuLoadInfo(info =>({...info,isInStoreLoaded}))});
  };

  const formPricePointRows = () => {
    let rows = {};
    let filteredStoreList = [];
    let filteredPricePoints = [];
    let pricePointCount = 0;
    let acrossStoreCount = 0;
    let skuData = skuContext.skuData;
    let pricePointDetails = skuData.pricePointDetails;
    let pendingStoreDetailsMap = skuContext.pendingStoreDetailsMap;
    let {allowedThdStores="",allowedCompetitorStores=""} = FilterUtil.offsideEligibleStores(
        skuContext.filterValues.selectedCompetitors,
        skuContext.filterValues.minMaxSelectedOffsideRange,
        skuContext.filterValues.minMaxDefaultOffsideRange,
        skuContext.filterValues.isOffsideRangeChecked,
        skuContext.filterValues.offsideMap);

    Object.keys(skuData.pricePointDetails).forEach(retail => {
      let selectedSkuStatusList = skuContext.filterValues.selectedSkuStatusList;
      let stores = [...Object.values(skuData.pricePointDetails[retail].storeDetails)].filter(k =>{
        let store = {...k};
        let allowStore = false;
        let performanceData = skuContext.skuStorePerformanceData.storeLevelPerformance[store.storeId];
        let {compSales = "-", compUnits = "-"} = performanceData ? performanceData : {};
        store.compSales = compSales;
        store.compUnits = compUnits;
        if (FilterUtil.filteredStoresBasedOnStatus(skuContext.filterValues.selectedSkuStatusList,store) &&
            FilterUtil.isAllowDisaster(skuContext.filterValues.selectedDisasterValue,store.disaster) &&
            FilterUtil.filteredStoresBasedOnCompData(skuContext.filterValues, store) &&
            FilterUtil.filteredStoresBasedOnMarket(skuContext.filterValues.selectedMarkets,store) &&
            FilterUtil.filteredStoresBasedOnZone(skuContext.filterValues.selectedZones,store) &&
            FilterUtil.filteredStoresBasedOnOffside(skuContext.filterValues.isOffsideRangeChecked,allowedThdStores,store.storeId) &&
            FilterUtil.filteredStoresBasedOnSkuAvailability(skuContext.filterValues.selectedSkuAvailability,skuContext.unitsOnHandMap[store.storeId])) {
          allowStore = true;
        }
        return allowStore;
      });
      if (stores.length>0) {
        acrossStoreCount = acrossStoreCount + stores.length;
        pricePointCount = pricePointCount + 1;
        filteredPricePoints.push(retail);
        let {compSales="-", compUnits="-",filteredStoreSet = [],rawSales=0,rawUnits=0} =
            Object.keys(skuContext.skuStorePerformanceData).length === 0
                ? {}
                : PricePointUtil.getCompDataForSkuAndRetailLevel(selectedSkuStatusList, stores, skuContext.skuStorePerformanceData);
        filteredStoreList = filteredStoreList.concat(filteredStoreSet);

        rows[retail]={
          isAllowed:true,
          color:pricePointDetails[retail].pointerColor,
          retail: retail,
          storeCount: stores.length,
          compSales,
          compUnits,
          pendingPriceChangeCount: PricePointUtil.getPendingCount(stores, pendingStoreDetailsMap),
          disasterCount: PricePointUtil.getDisasterCount(stores),
          endsOn: pricePointDetails[retail].effectiveEndDateForPending,
          filteredStoreSet,
          rawSales,
          rawUnits
        };
      } else {
        rows[retail] = {
          isAllowed: false,
          color: pricePointDetails[retail].pointerColor,
          retail: retail,
          filteredStoreSet: []
        }
      }
    });

    return {
      rows,
      mapFilteredData : {
        filteredStoreList,filteredPricePoints
      },
      acrossStoreCount,
      pricePointCount,
      allowedCompetitorStores

    };
  };


  let {rows,mapFilteredData,acrossStoreCount,pricePointCount,allowedCompetitorStores} = formPricePointRows();
  let mapPlacementStyles = isFilterDrawerOpen ? {width: 'calc(100vw - 400px)'} : {width: 'calc(100vw - 540px)', marginLeft: '540px'};


      if(props.isShowMap) {return ( <Content>
        <SearchBarLayout
            toggleFilterView={()=>setIsFilterDrawerOpen(!isFilterDrawerOpen)}
            isFilterOpen={isFilterDrawerOpen}
            backToHome = {()=>props.backToHome()}
            backToSkuDetails = {()=>props.backToSkuDetails()}
            defaultMapFilterValues={defaultMapFilterValues}
            headerData={props.headerData}
        />
        <Row>
          { !isFilterDrawerOpen  && <Col  >
            {isPricePointDrawerOpen ? <PricePointDetailLayout
                config={props.config}
                isOpen={true}
                togglePricePointView={()=>setIsPricePointDrawerOpen(!isPricePointDrawerOpen)}
                selectedPricePointRowData={rows[skuContext.selectedPricePoint]}
                defaultMapFilterValues = {defaultMapFilterValues}
                userId={props.user.userId}
                verifyAccessToken = {props.verifyAccessToken}

            /> : <SkuDetailComponent
                pricePointRowDetails={{rows,acrossStoreCount,pricePointCount}}
                isOpen={true}
                onPricePointRowClick={()=>setIsPricePointDrawerOpen(!isPricePointDrawerOpen)}
                defaultMapFilterValues = {defaultMapFilterValues}
                userId={props.user.userId}
                getAllSkusforDCSView={props.getAllSkusforDCSView}
                multiVendorList={props.multiVendorList}

            />}

          </Col>}
          <Col  style={mapPlacementStyles}>
            <AdvancedGMap
                config={props.config}
                mapFilteredData={mapFilteredData}
                isDashboardOpen={false}
                apiKey={props.config.apiKey}
                isFilterDrawerOpen={isFilterDrawerOpen}
                allowedCompetitorStores = {allowedCompetitorStores}
                userId={props.user.userId}
                verifyAccessToken = {props.verifyAccessToken}
            />
          </Col>
          <Col >
            <FilterComponent
                userId={props.user.userId}
                visible={isFilterDrawerOpen}
                distinctSkuStatusList={distinctSkuStatusList}
                acrossStoreCount = {acrossStoreCount}

            />
          </Col>
        </Row>
      </Content>
  )}else {return null;}

};


export default React.memo(SkuInfoPage)
