import styled from 'styled-components';

const LandingPageContainer = styled.div`
`

const PageTitleH1 = styled.h1`
`

const PageSubTitleH2 = styled.h2`
`

export {
    LandingPageContainer,
    PageTitleH1,
    PageSubTitleH2
}