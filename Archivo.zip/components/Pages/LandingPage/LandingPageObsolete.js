import React, {Component, Fragment} from 'react';
import './LandingPage.scss';
import {Row, Col, Layout} from 'antd';
import FilterComponent from '../../FilterComponent/FilterComponent'
import SkuDetailComponent from '../../SkuDetailComponent/SkuDetailComponent'
import SearchBarLayout from "../../SearchBarLayout/SearchBarLayout";
import PricePointDetailLayout from "../../PricePointDetailLayout/PricePointDetailLayout";
import PriceDataServices from "../../../services/PriceDataServices";
import SkuContext from "../../../context/SkuContext";
import FilterUtil from "../../Utils/FilterUtil";
import PricePointUtil from "../../Utils/PricePointUtil";
import AdvancedGMap from "../../MapComponent/AdvancedGMap";
import AlertUtil from "../../Utils/AlertUtil";
import DashboardDrawer from "../../DashboardDrawer/DashboardDrawer";
import SkuApiHelper from "../../Helper/SkuApiHelper";
import DCSUtil from "../../Utils/DCSUtil";
import {trackEvent} from "../../Utils/mixpanel";

const {Content} = Layout;

const defaultState =  {
  isDashboardOpen:true,
  isFilterDrawerOpen: false,
  isSkuLoaded: false,
  isPricePointDrawerOpen: false,
  distinctSkuStatusList:[],
  defaultMapFilterValues : FilterUtil.getInitialFilterValues(),
  competitorPriceDetails : {}
};

export class LandingPage extends Component {

  static contextType = SkuContext;
  state = defaultState;



  componentDidMount () {
    const { sku } = this.props.match.params;
    let isSkuPath = !isNaN(sku);
    if (this.context.profileData.subClassDetails) {
      this.readPerformersDCSDetails(this.context.profileData.subClassDetails,isSkuPath);
    }
    if(isSkuPath){
      this.onSearchClick(sku, "LANDING_PAGE_LOADING");
    }
    this.props.history.push('/');
  }

  readPerformersDCSDetails = (dcs,isSkuSearch)=> {
    this.context.updateShowDimmer(true);
    if(dcs) {
      this.setState(defaultState);
      this.updateSelectedDCSKey(dcs);
      let departmentNumber = dcs.split("-")[0];
      let classNumber = dcs.split("-")[1];
      let subclassNumber = dcs.split("-")[2];
      let subclassList = DCSUtil.getSubclassesList(this.context.dcsDataMap,
          dcs);
       
      PriceDataServices.readPerformersDCSDetails(departmentNumber, classNumber,
          subclassNumber, subclassList.join(',')).then(response => {
        if (response.status === 200) {
          this.context.updateStateFields({dashboardData: response.data});
        } else {
          this.context.updateStateFields({
            dashboardData: {
              "topPerformersSalesMap": {},
              "bottomPerformersSalesMap": {},
              "topPerformersUnitsMap": {},
              "bottomPerformersUnitsMap": {},
              "disasterStoreMap": {}
            }
          });
          this.updateSelectedDCSKey("", true);
        }
        this.context.updateShowDimmer(isSkuSearch ? true : false);
      }).catch(k => {
        let alertMessage = AlertUtil.getErrorMessage("fetching performers data for DCS");
        this.context.updateShowDimmer(isSkuSearch ? true : false);
        this.updateSelectedDCSKey("", true);
        this.context.updateStateFields({
          dashboardData: {
            "topPerformersSalesMap": {},
            "bottomPerformersSalesMap": {},
            "topPerformersUnitsMap": {},
            "bottomPerformersUnitsMap": {},
            "disasterStoreMap": {}
          }
        });
        console.log(k.response.data);
        AlertUtil.showAlert("error", "Error", alertMessage);
      });
    }else {
      this.context.updateShowDimmer(false);
    }
  };

  updateUserProfileAndReadDashboardData = (title,dcs,userProfile)=> {
    this.context.updateShowDimmer(true);
    PriceDataServices.updateUserProfileData(title,dcs,userProfile).then( response => {
      if(response.status === 200){
        let dcsKey = response.data.departmentNumber + '-' + response.data.classNumber + '-' +response.data.subClassNumber;
        this.context.updateProfileData({
          ...response.data,
          subClassDetails: dcsKey
        });
        this.readPerformersDCSDetails(dcsKey);
      } else {
        this.updateSelectedDCSKey("",true);
        this.context.updateStateFields({dashboardData: {"topPerformersSalesMap": {}, "bottomPerformersSalesMap": {}, "topPerformersUnitsMap": {}, "bottomPerformersUnitsMap": {}, "disasterStoreMap":{}}});
        this.context.updateShowDimmer(false);
      }
    }).catch(k => {
      let alertMessage = AlertUtil.getErrorMessage("updating user profile and DCS performers data");
      console.log(k.response.data);
      this.context.updateShowDimmer(false);
      this.updateSelectedDCSKey("",true);
      this.context.updateStateFields({dashboardData: {"topPerformersSalesMap": {}, "bottomPerformersSalesMap": {}, "topPerformersUnitsMap": {}, "bottomPerformersUnitsMap": {}, "disasterStoreMap":{}}});
      AlertUtil.showAlert("error", "Error",alertMessage);
    });
  };

  updateSelectedDCSKey = (dcs,reset) => {
    reset?    this.context.updateStateFields({selectedDCS: "" }):
    this.context.updateStateFields({showDimmer:true,selectedDCS: dcs});
  };

  toggleFilterView = () => {
    this.setState({isFilterDrawerOpen: !this.state.isFilterDrawerOpen});
  };

  togglePricePointView = () => {
    this.setState({isPricePointDrawerOpen: !this.state.isPricePointDrawerOpen});
  };

  toggleDashboardView = () => {
    let isDashboardOpen = !this.state.isDashboardOpen;
    isDashboardOpen ? this.setState(defaultState):
    this.setState({isDashboardOpen});

  };

  onPricePointRowClick = (selectedRow) => {
    this.togglePricePointView();
  };

  onSearchClick =  (sku, origin) => {
    this.context.updateShowDimmer(true);
    this.setState(defaultState);
    let skunum = this.state.skuNumber ;
    if(sku){
      skunum = sku;
    }
    this.context.updateFilterSelection(FilterUtil.getInitialFilterValues());
    this.context.updatePreviewData(this.props);
    trackEvent("MPULSE_SKU_SEARCH", {'sku': skunum, 'ORIGIN': origin});
    PriceDataServices.fetchSkuDetails(skunum,this.props.user.userId,this.context.profileData.title)
        .then(skuData => {
          this.context.updateStateFields({isFavorite:this.context.favSkuMap? this.context.favSkuMap.hasOwnProperty(skunum):false});
          SkuApiHelper.fetchCompetitorPriceDetails(skunum,this.props.config.competitorDataUrl, this.context.updateStateFields);
          SkuApiHelper.fetchSkuImage(skunum,this.context);
          SkuApiHelper.fetchVendors(skunum,this.context);
          SkuApiHelper.fetchSkuStorePerformanceData(skunum,this.context,this.props.user.userId);
          SkuApiHelper.fetchPriceChangeHistory(skunum,this.context);
          SkuApiHelper.fetchPendingPriceChangeDetails(skunum,skuData.data.pacManSKU,this.context);
          SkuApiHelper.fetchSalesMetricsDetails(skunum,this.context);

          let distinctSkuStatusSet =
              Object.keys(skuData.data.skuStoreStatus).map(k => Number(k));
          let selectedSkuStatusList = FilterUtil.formDefaultSkuStatus(distinctSkuStatusSet);
          let distinctSkuStatusList = [...FilterUtil.getSkuStoreStatusMap(distinctSkuStatusSet).values()];
          PricePointUtil.addExtraDetailsToPricePoint(skuData.data, this.props.user);

          this.context.updateSkuData(skuData.data);
          this.context.updateFilterSelection({selectedSkuStatusList});
          this.setState({
            isFilterDrawerOpen: false,
            isSkuLoaded: true,
            isPricePointDrawerOpen: false,
            distinctSkuStatusList,
            isDashboardOpen: false,
            defaultMapFilterValues: this.context.filterValues
          });
          this.context.updateShowDimmer(false);

          SkuApiHelper.fetchOHQuantityDetails(skunum,skuData.data.availableStores,this.context);
          SkuApiHelper.fetchUnitsOnHandDetails(skunum,skuData.data.availableStores,this.context);

        }).catch(k => {
          let alertMessage = AlertUtil.getErrorMessage("performing sku search");
          if (k.response.status === 422) {
            if (k.response.data.includes("Invalid SKU")) {
              alertMessage = 
                  <div>SKU not found : <b>{skunum}</b></div>

            } else {
              alertMessage =  <div>{k.response.data}</div>
              console.log(k.response.data);
            }
          }
          AlertUtil.showAlert("error","Error",alertMessage);
          this.context.updateShowDimmer(false);
        });
  };

  formPricePointRows = () => {
    let rows = {};
    let filteredStoreList = [];
    let filteredPricePoints = [];
    let pricePointCount = 0;
    let acrossStoreCount = 0;
    let skuData = this.context.skuData;
    let pricePointDetails = skuData.pricePointDetails;
    let pendingStoreDetailsMap = this.context.pendingStoreDetailsMap;

    Object.keys(skuData.pricePointDetails).forEach(retail => {
      let selectedSkuStatusList = this.context.filterValues.selectedSkuStatusList;
        let stores = [...Object.values(skuData.pricePointDetails[retail].storeDetails)].filter(k =>{
          let store = {...k};
          let allowStore = false;
          let performanceData = this.context.skuStorePerformanceData.storeLevelPerformance[store.storeId];
          let {compSales = "-", compUnits = "-"} = performanceData ? performanceData : {};
          store.compSales = compSales;
          store.compUnits = compUnits;
          if (FilterUtil.filteredStoresBasedOnStatus(this.context.filterValues.selectedSkuStatusList,store) &&
              FilterUtil.isAllowDisaster(this.context.filterValues.selectedDisasterValue,store.disaster) &&
              FilterUtil.filteredStoresBasedOnCompData(this.context.filterValues, store) &&
              FilterUtil.filteredStoresBasedOnMarket(this.context.filterValues.selectedMarkets,store) &&
              FilterUtil.filteredStoresBasedOnZone(this.context.filterValues.selectedZones,store)
          ) {
            allowStore = true;
          }
          return allowStore;
        });
      if (stores.length>0) {
        acrossStoreCount = acrossStoreCount + stores.length;
        pricePointCount = pricePointCount + 1;
        filteredPricePoints.push(retail);
        let {compSales="-", compUnits="-",filteredStoreSet = []} =
          Object.keys(this.context.skuStorePerformanceData).length === 0
              ? {} 
              : PricePointUtil.getCompDataForSkuAndRetailLevel(selectedSkuStatusList, stores, this.context.skuStorePerformanceData);
        filteredStoreList = filteredStoreList.concat(filteredStoreSet);
                        
        rows[retail]={
          isAllowed:true,
          color:pricePointDetails[retail].pointerColor,
          retail: retail,
          storeCount: stores.length,
          compSales,
          compUnits,
          pendingPriceChangeCount: PricePointUtil.getPendingCount(stores, pendingStoreDetailsMap),
          disasterCount: PricePointUtil.getDisasterCount(stores),
          endsOn: pricePointDetails[retail].effectiveEndDateForPending,
          filteredStoreSet
        };
      } else {
        rows[retail] = {
          isAllowed: false,
          color: pricePointDetails[retail].pointerColor,
          retail: retail,
          filteredStoreSet: []
        }
      }
    });

    return {
      rows, 
      mapFilteredData : {
        filteredStoreList,filteredPricePoints
      },
      acrossStoreCount,
      pricePointCount
    };
  };

  refillPointers = (thats, overrideFlag) => {
    let that = this;
    if (overrideFlag || that.state.allowRefill) {
      let storeData = [];
      let index = 0;
      if (that.state.pricePointDetails) {
        let pricePointCount = Object.keys(that.state.pricePointDetails).length;
        Object.keys(that.state.pricePointDetails).forEach(key => {
          storeData = storeData.concat(
              that.fillMapPointers(
                Object.values(that.state.pricePointDetails[key].storeDetails),
                PricePointUtil.getColorGradientForPrice(index, pricePointCount),
                key
              )
          )
          index = index + 1;
        });
        that.setState({ storeData });
      }
    }
  }

  fillMapPointers = (storeDataList, color, retailAmount) => {
    let storeData = [];
    storeDataList.forEach(store => {
      if (store.longitudeNumber && store.latitudeNumber) {
          storeData.push({
            retailAmount: retailAmount,
            store: store,
            coordinates: [store.longitudeNumber, store.latitudeNumber],
            pointerColor: color
          });
        }
    });
    return storeData;
  };

  render() {
    let {rows,mapFilteredData,acrossStoreCount,pricePointCount} = this.formPricePointRows();
    let mapPlacementStyles = {
      
      style: this.state.isFilterDrawerOpen ? {width: 'calc(100vw - 380px)'} : {width: 'calc(100vw - 540px)', marginLeft: '540px'}
    };
    return (
      <Content>
        <SearchBarLayout 
          key={this.context.skuNumber}
          toggleFilterView={this.toggleFilterView}
          isFilterOpen={this.state.isFilterDrawerOpen}
          onSearchClick={this.onSearchClick}
          defaultMapFilterValues={this.state.defaultMapFilterValues} 
          userId={this.props.user.userId}
        />
        <Row>
          <Col span={8} >
            {
              !this.state.isDashboardOpen ?
                <Fragment>
                  <SkuDetailComponent
                      toggleDashboardView={this.toggleDashboardView}
                      pricePointRowDetails={{rows,acrossStoreCount,pricePointCount}}
                      isOpen={!this.state.isFilterDrawerOpen
                      && !this.state.isPricePointDrawerOpen && !this.state.isDashboardOpen}
                      onPricePointRowClick={this.onPricePointRowClick}
                      isPerformanceDataLoaded={this.state.isPerformanceDataLoaded}
                      defaultMapFilterValues = {this.state.defaultMapFilterValues}
                      userId={this.props.user.userId}
                  />
                  <PricePointDetailLayout
                      config={this.props.config}
                      isOpen={!this.state.isFilterDrawerOpen
                      && this.state.isPricePointDrawerOpen}
                      togglePricePointView={this.togglePricePointView}
                      selectedPricePointRowData={rows[this.context.selectedPricePoint]}
                      defaultMapFilterValues = {this.state.defaultMapFilterValues}
                  />
                </Fragment>
              :
                <DashboardDrawer
                  selectedDCS={this.context.selectedDCS}
                  onSearchClick={this.onSearchClick}
                  onDCSChange={value => this.readPerformersDCSDetails(value)}
                  isOpen={!this.state.isFilterDrawerOpen && this.state.isDashboardOpen}
                  updateUserProfileAndReadDashboardData={this.updateUserProfileAndReadDashboardData}
                />
            }
          </Col>
          <Col  style={mapPlacementStyles.style}>
            <AdvancedGMap
              config={this.props.config}
              mapFilteredData={mapFilteredData}
              isDashboardOpen={this.state.isDashboardOpen}
              apiKey={this.props.config.apiKey}
              competitorPriceDetails={this.state.competitorPriceDetails}
              isFilterDrawerOpen={this.state.isFilterDrawerOpen} 
            />
          </Col>
          <Col span={4}> 
            <FilterComponent 
              userId={this.props.user.userId} 
              updateFilterSelection={(value)=>this.setState({fiterValues:value})}
              visible={this.state.isFilterDrawerOpen}
              distinctSkuStatusList={this.state.distinctSkuStatusList}
            />
          </Col>
        </Row>
      </Content>
    );
  }
}

// const RetailAmountFormatter = (props) => {

//   return (
//       <span>
//       <span style={{ fontWeight: 600 }}>{" $" + props.retailAmount.split('-')[0]}</span>
//     </span >

//   );
// };

export default LandingPage;
