import React from 'react'
import '@testing-library/jest-dom'
import {render, screen} from "@testing-library/react";
import ReportsUtil from './ReportsUtils';

describe('Reports Utils test',()=> {
  test('testing utility method :  Capitalize first letter', async () => {
    expect(ReportsUtil.capitalizeFirstLetter("sku")).toMatch("Sku");
    expect(ReportsUtil.capitalizeFirstLetter("multiple sku")).toMatch("Multiple sku");
    expect(ReportsUtil.capitalizeFirstLetter("SKU")).toMatch("SKU");
  });
});

describe('ReportsUtils test- testing for string sorter',()=> {
  test('testing utility method :  String sorter - I ', async () => {
    expect(ReportsUtil.reportTableStringSorter("name1","name1")).toEqual(0);
    expect(ReportsUtil.reportTableStringSorter("cool","alright")).toEqual(1);
    expect(ReportsUtil.reportTableStringSorter("name","pool1")).toEqual(-1);

  });

});

describe('ReportsUtils test - test for capital strings in string sorter',()=> {
  test('testing utility method :  String sorter - II - Caps', async () => {
    expect(ReportsUtil.reportTableStringSorter("Name1","name1")).toEqual(1);
    expect(ReportsUtil.reportTableStringSorter("cool","Alright")).toEqual(1);
    expect(ReportsUtil.reportTableStringSorter("Boolean","Egg")).toEqual(-1);

  });
});

describe('ReportsUtils test - test for date Formatter',()=> {
  test('testing utility method :  dateFormatter', async () => {
    expect(ReportsUtil.formattedDateYYYYMMDD("2016/06/23T09:07:21-07:00")).toEqual("2016/06/23");
    expect(ReportsUtil.formattedDateYYYYMMDD("2016-06-23T09:07:21")).toEqual("2016-06-23");

  });
});


