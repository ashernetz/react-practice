import React, {Fragment, useEffect, useState} from 'react';
import {Row, Col, Typography, Space, Layout } from 'antd';
import "./Reports.scss";
import ReportsFooter from "./ReportsFooter/ReportsFooter"
import SvgUtil from '../../Utils/SvgUtil';
import ReportsTabPanel from './ReportsTabPanel/ReportsTabPanel';
import ReportsContentHeader from './ReportsContentHeader/ReportsContentHeader';
import ReportStatus from './ReportStatus/ReportStatus';
import ReportsConstants from './ReportsConstants';
import ReportsServices from '../../../services/ReportsServices';
import ReportsUtils from './ReportsUtils';
import _ from 'lodash';

const {Text} = Typography;
const {Content} = Layout;

const NoData = () => {
  return (
      <Fragment>
        <Row justify="center" align="middle"  >
          <Col style={{ paddingTop: "80px" }}>{SvgUtil.getNoData()}</Col>
        </Row>
        <Row justify="center" align="middle" style={{paddingBottom: "110px"}}>
          <Col><Text>{"No Data"}</Text></Col>
        </Row>
      </Fragment>
  );
};


const Reports = (props) => {

  const [selectedTab, setSelectedTab] = useState("subDepartment");
  const [subDeptData,setSubDeptData] = useState([]);
  const [classData, setClassData] = useState([]);
  const [subClassData, setSubClassData] = useState([]);
  const [toggleClear, setToggleClear] = useState(false);
  const [reportLogData, setReportLogData] = useState([]);
  const [selectedKey, setSelectedKey] = useState({
    subDepartment:[],
    classes:[],
    subClass:[],
    vendors:[],
    skus:[],
    byos:[],
    markets:[],
    stores:[],
    skuType:[],
    skuStatus:[]
  });
  const [isGenerateReportOpen, setIsGenerateReportOpen] = useState(false);
  const [locationData, setLocationData] = useState({byoData:[],marketData:[],storeDataMap:new Map()});
  const [isDcChecked, setIsDcChecked] = useState(true);
  const [selectedDisaster, setSelectedDisaster] = useState("WITH_DISASTER");

  const generateReportRequest = async () => {
    props.setShowDimmer(true);

    let subDeptSplit = {};
    let distinctSubDept = selectedKey.subDepartment.map(k=> ReportsUtils.numberFormattedSubDepartment(k)) || [];
    let vendors = selectedKey.vendors.length > 0 ? selectedKey.vendors.map(k=> parseInt(k.split("-")[0].trim())):[];

    if(distinctSubDept.length === 1){
      subDeptSplit[distinctSubDept[0]]={skus:selectedKey.skus.map(k=> parseInt(k.sku)), vendors}
    }else {
      let dcSubDeptMap  = new Map();
      Object.keys(props.subDeptDataMap).forEach(k=> {
        props.subDeptDataMap[k].deptClassMap.forEach((classes,dept)=> {
          classes.forEach(t=> {
            dcSubDeptMap[dept + " | " + t]=k;
          })
        })
      });
      let subDeptVendorMap = {};
      if(vendors.length > 0){
        let response = await ReportsServices.getVendorDetails(vendors);
        subDeptVendorMap = (response && response.data) || {};
      }
      selectedKey.skus.forEach(k=> {
        let dcKey = k.departmentNumber + " | " + k.classNumber;
        let subDept = dcSubDeptMap[dcKey];
        subDeptSplit[subDept] = (subDeptSplit[subDept] || {});
        subDeptSplit[subDept]["skus"] = [...(subDeptSplit[subDept]["skus"] || []),k.sku];

      });

      Object.keys(subDeptVendorMap).forEach(subDept=> {
        subDeptSplit[subDept] = (subDeptSplit[subDept] || {});
        subDeptSplit[subDept]["vendors"] = subDeptVendorMap[subDept];
      })
    }

    let userId = props.userId;
    let classes = selectedKey.classes.map(k=> ReportsUtils.numberFormattedClass(k));
    let subclasses = selectedKey.subClass.map(k=> ReportsUtils.numberFormattedSubClass(k));
    let markets = selectedKey.markets.length > 0 ? selectedKey.markets.map(k=> parseInt(k.split("-")[0].trim())):[];
    let includeDC = isDcChecked;
    let skuTypes = selectedKey.skuType;
    let skuStatuses = selectedKey.skuStatus;
    let disaster = selectedDisaster;

    let runReportStatus = new Set();
    Promise.all(Object.keys(subDeptSplit).map(subDept => {
      return ReportsServices.runReportsRequest({
        userId, subDept,
        skus:subDeptSplit[subDept]["skus"], vendors:subDeptSplit[subDept]["vendors"],
        classes, subclasses,
        includeDC, markets,
        skuTypes, skuStatuses,disaster
      });
    })).then(k=>{
      let status = k.map(k=> k.status);
      runReportStatus = new Set(status)
    }).finally(()=>{
      setIsGenerateReportOpen(true);
      props.setShowDimmer(false);
      if(runReportStatus.has(200)){
        ReportsUtils.reportAlert("success",
          "Report Submitted",
          "Your report is being generated. This may take a few minutes. Please check back.")
      }else{
        ReportsUtils.reportAlert("error",
          "Report Failed",
          "Your report has not being generated. This may take a few minutes. Please check back.")
      }
    });
  }

  const callReportsLog = (skipTimeOut,refreshInterval=6000)=> {
    let responseData = [];
    setReportLogData(null)
    ReportsServices.getReportsLog(props.userId).then(response => {
      responseData = (response && response.data)|| [];
    }).catch(err => {
      console.log(err);
    }).finally(() => {
      let isAnyInProgressOrSubmitted = false;
      responseData.forEach(k=>{
        if(k.statCd === "IN-PROGRESS" || k.statCd === "SUBMITTED"){
          isAnyInProgressOrSubmitted = true;
        }
      });
      setReportLogData(responseData);
      if(!skipTimeOut && isAnyInProgressOrSubmitted && isGenerateReportOpen){
        setTimeout(() => {
          callReportsLog(null,20000);
        },refreshInterval);
      }

    });
  }

  useEffect(()=> {
    let responseData = [];
    ReportsServices.fetchLocationDetails().then(response => {
      responseData = (response && response.data)|| [];

    }).catch((err)=>{
      console.log(err);
    }).finally(()=>{
      let byoList = [];
      let marketList = [];
      let storeDataMap = new Map();
      responseData.forEach(byoData => {
        byoList.push({byo: byoData.byo, byoName: byoData.byoName});
        byoData.markets.forEach(marketData => {
          let marketObj = {market: marketData.market, marketName: marketData.marketName, byo: byoData.byo, byoTitle: (byoData.byo +" - "+byoData.byoName)}
          marketList.push(marketObj);
          marketData.stores.forEach(k => storeDataMap.set(k.store,{...k,...marketObj}));
        });
      })
      setLocationData({byoData: byoList, marketData: marketList, storeDataMap });
    })
  },[])


  useEffect(()=>{
    if(isGenerateReportOpen) {
      callReportsLog();
    }
  },[isGenerateReportOpen]);

  useEffect(() => {
    const subDept= _.map(props.subDeptDataMap, (val,key) => {return { ...val, subDeptNum: key };
    }).sort((a,b) => a.subDeptNum.toString().localeCompare(b.subDeptNum.toString(), 'en', { numeric: true }));
    setSubDeptData(subDept);
  },[props.subDeptDataMap])


  useEffect(() => {

    let deptClassNum = [];
    let getDeptKey = selectedKey.subDepartment[0] ? selectedKey.subDepartment[0].split("-")[0].padStart(4, "0") : [];
    if(Object.keys(props.subDeptDataMap).length > 0 && selectedKey.subDepartment[0]){
      props.subDeptDataMap[getDeptKey].deptClassMap.forEach(function(val, key) {
        deptClassNum.push({dept: key, class: val});
      })
    }

    let classArray = []
    deptClassNum.forEach(k=> {
      let classesData = props.dcsDataMap.get(k.dept).get("classes");
      k.class.map(eachClass => {
        let eachClassData = classesData.get(eachClass);
        if(eachClassData !== undefined) {
          classArray.push({
            deptNum: k.dept,
            classNum: eachClass,
            className: eachClassData.get("description"),
            classDes: eachClassData.get("name")
          });
        }
      });

    })
    let filteredClassData = classArray.sort((a,b)=> a.deptNum-b.deptNum || a.classNum - b.classNum)
    setClassData(filteredClassData);

  },[selectedKey.subDepartment])

    useEffect(() => {
    let subClassArray = []
      if(selectedKey.subDepartment.length>0 && selectedKey.classes.length>0) {
        let formattedClasses = selectedKey.classes;
        formattedClasses.forEach((k) => {
          props.dcsDataMap.get(k.deptNum).get("classes").get(k.classNum).get("subclasses").forEach(
              (val, key) => {
                subClassArray.push({
                  deptNum: k.deptNum,
                  classNum: k.classNum,
                  subClassNum: key,
                  subClassName: val.get("description"),
                  subClassDes: val.get("name")
                });
              });
        });
      }
    setSubClassData(subClassArray);
  },[selectedKey.classes]);

  useEffect(() => {
    let marketList = [];
    let marketByByo = [];
    if(selectedKey["markets"].length > 0){
      marketList = selectedKey["markets"].map(k => "m" + k.split('-')[0].trim());
    }
    let numberFormattedMarketList = marketList.map(k=> parseInt(k.slice(1)));
    locationData.marketData.filter((k) => {return numberFormattedMarketList.indexOf(k.market)!== -1}).map(k=> marketByByo.push(k.byoTitle));
    setSelectedKey(k => {
      return {
        ...k,
        "byos": [...new Set([...marketByByo])],
      };
    });
  }, [selectedKey.markets])

  const removeAllSelected = () =>{
    setToggleClear(!toggleClear);
    setSelectedKey(k => {
      return {
        ...k,
        "subDepartment":[],
        "classes":[],
        "subClass":[],
        "vendors":[],
        "skus":[],
        "byos":[],
        "markets":[],
        "stores":[],
        "skuType":[],
        "skuStatus":[]
      };
    });
  }

  return(
    <Layout id="reports-layout">
      <Content className="reports-layout-content">
        <Row className="reports-header-pad">
          <Col span={24}>
            <ReportsContentHeader
              setSelectedTab={setSelectedTab}
              removeAllSelected={removeAllSelected}
              isGenerateReportOpen={isGenerateReportOpen}
              setIsGenerateReportOpen={setIsGenerateReportOpen}
              callReportsLog={callReportsLog}/>
          </Col>
        </Row>
        <Row className="reports-sub-head-pad">

          <Col span={24} style={!isGenerateReportOpen ?{display:"none"}:{}}>
            <ReportStatus
              setShowDimmer = {props.setShowDimmer}
              noData={<NoData/>}
              reportLogData={reportLogData}
            />
          </Col>
          <Col span={24} style={isGenerateReportOpen ?{display:"none"}:{}}>
            <Row>
              <Col>
                <Text className="reports-sub-head-text">Please select at least one class, vendor, or SKU to generate a report.</Text>
              </Col>
            </Row>
            <Row className="reports-panel-pad">
              <Col>
                <Space direction="vertical" size={8}>
                  <Row>
                    <Col span={19}>
                      <Row justify="space-between" align="middle">
                        <Col >
                          <Text className="reports-selection-detail">{ReportsConstants.SELECTION_LABEL[selectedTab]}</Text>
                        </Col>
                        <Col style={{paddingRight:'24px'}}>
                          {selectedTab === "vendors" ? <Text>Limiting to 50 Vendors</Text> :
                              selectedTab === "skus" ? <Text>Limiting to 250 SKUs</Text> : ""}
                        </Col>
                      </Row>
                    </Col>
                    <Col span={5}></Col>
                  </Row>
                  <ReportsTabPanel
                    selectedTab={selectedTab}
                    setSelectedTab={setSelectedTab}
                    noData={<NoData/>}
                    subDeptData={subDeptData}
                    classData={classData}
                    subClassData={subClassData}
                    toggleClear={toggleClear}
                    selectedKey={selectedKey}
                    setSelectedKey={setSelectedKey}
                    locationData={locationData}
                    isDcChecked={isDcChecked}
                    setIsDcChecked={setIsDcChecked}
                    selectedDisaster={selectedDisaster}
                    setSelectedDisaster={setSelectedDisaster}
                  />
                </Space>
              </Col>
            </Row>
          </Col>
        </Row>
      </Content>
      {!isGenerateReportOpen &&
        <ReportsFooter
          selectedKey={selectedKey}
          generateReportRequest={generateReportRequest}
        />}
    </Layout>

  );
}
export default Reports;