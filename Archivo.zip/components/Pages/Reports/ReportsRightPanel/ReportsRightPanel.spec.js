import React from 'react'
import '@testing-library/jest-dom'
import {fireEvent, render, screen, waitFor} from '@testing-library/react';
import ReportsRightPanel from './ReportsRightPanel';

let selectedKey = {
    "subDepartment": ["21-LUMBER"],
    "classes": [
        {"deptNum": 21, "classNum": 2, "className": "SIDING", "classDes": "21 | 2-SIDING"},
        {"deptNum": 21, "classNum": 3, "className": "DIMENSION", "classDes": "21 | 3-DIMENSION"},
        {"deptNum": 21, "classNum": 4, "className": "COMPOSITON", "classDes": "21 | 4-COMPOSITON"}],
    "subClass": [
        {"deptNum": 21, "classNum": 2, "subClassNum": 5, "subClassName": "SOLID WOOD", "subClassDes": "21 | 2 | 5 - SOLID WOOD"},
        {"deptNum": 21, "classNum": 2, "subClassNum": 6, "subClassName": "FIBER CEMENT", "subClassDes": "21 | 2 | 6 - FIBER CEMENT"},
        {"deptNum": 21, "classNum": 2, "subClassNum": 60, "subClassName": "S/O SIDING", "subClassDes": "21 | 2 | 60 - S/O SIDING"},
        {"deptNum": 21, "classNum": 2, "subClassNum": 7, "subClassName": "SAMPLES", "subClassDes": "21 | 2 | 7 - SAMPLES"}],
    "vendors": [], "skus": [], "byos": [], "markets": [], "stores": [], "skuType": [], "skuStatus": []
    }

describe("validation User selection data in Right Panel",()=>{

    test('verify clear All button is not available if user made no selections in the tables.',()=>{
       render(<ReportsRightPanel selectedKey={{"subDepartment": [], "classes": [], "subClass": [],
            "vendors": [], "skus": [], "byos": [], "markets": [], "stores": [],
            "skuType": [], "skuStatus": []}} setSelectedKey={() => {}} /> )
        expect(screen.queryByText('Clear All')).toBeNull();
    })

    test('verify clear All button is available if user made selections in the tables.',()=>{
        render(<ReportsRightPanel selectedKey={selectedKey} setSelectedKey={() => {}} /> )
        expect(screen.getAllByText("Clear All").length).toBe(3);
    })

    test('validate Clear All button click',async () =>{
        render(<ReportsRightPanel selectedKey={{
            "subDepartment": ['21-LUMBER'], "classes": [], "subClass": [], "vendors": [],
            "skus": [], "byos": [], "markets": [], "stores": [], "skuType": [], "skuStatus": []
        }} setSelectedKey={() => {}} /> )
        expect(screen.getAllByText("Clear All").length).toBe(1);
        fireEvent.click(screen.getAllByText("Clear All")[0]);
        await waitFor(
            () => expect(screen.getAllByText("Clear All")).not.toBeFalsy(),
            3000
        );
    })

})