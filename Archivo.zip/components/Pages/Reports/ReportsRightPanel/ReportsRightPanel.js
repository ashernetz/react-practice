import React,{ useState } from 'react';
import { Row, Col, Typography, Space } from 'antd';
import "./ReportsRightPanel.scss"
import ReportsUtils from '../ReportsUtils';


const {Text} = Typography;


const dataDisplayCriteria = [
    {heading:"SUB DEPARTMENT", valueKey:"subDepartment"},
    {heading:"CLASS", valueKey:"classes",key:"classDes"},
    {heading:"SUBCLASS", valueKey:"subClass",key:"subClassDes"},
    {heading:"VENDOR", valueKey:"vendors"},
    {heading:"SKU", valueKey:"skus",key:"sku"},
    {heading:"SKU TYPE", valueKey:"skuType"},
    {heading:"SKU STATUS", valueKey:"skuStatus"},
    {heading:"BYO", valueKey:"byos"},
    {heading:"MARKET", valueKey:"markets"}
];
const ReportsRightPanel = (props) => {

    const [showMore, setShowMore] = useState(dataDisplayCriteria.reduce((total,current)=>{total[current.valueKey]=false; return total;},{}));

    const getSelectedKey = (selectedInput) => {
        if(selectedInput.key){
            return  props.selectedKey[selectedInput.valueKey].map(j=>j[selectedInput.key]);
        }else if(selectedInput.valueKey){
            return  props.selectedKey[selectedInput.valueKey];
        }
    };

    const clearActions = {
        subDepartment : ["subDepartment","classes","subClass"],
        classes :["classes","subClass"],
        byos:["byos","markets","stores"],
        markets:["byos","markets","stores"],
    };

    const clearSelection = (clearKey) => {

        const selectedKey = clearActions[clearKey];
        if(selectedKey){
                 props.setSelectedKey(k=>{
                        const newStateValue = {...k};
                        selectedKey.forEach(key => {
                            newStateValue[key] = [];
                        });
                        return newStateValue;
            })
        }else{
            props.setSelectedKey(k=> ({
                ...k,
                 [clearKey]:[]
            }))
        }
    }

    return(
        <Row id="reports-right-panel">
            <Col span={24} className="reports-right-panel-scroll" >
                <Space direction="vertical" size={16}>
                    {dataDisplayCriteria.map(k=>
                        (<Space direction="vertical" size={2}>
                            <Space direction="horizontal" size={10}>
                                <Text className="reports-right-panel-head">{k.heading}</Text>
                                {getSelectedKey(k)?.length>0 ? <a className='reports-right-panel-link'
                                                                                      onClick={() => {clearSelection(k.valueKey)}}>Clear All</a>:""}
                            </Space>
                            <Space direction="vertical" style={{paddingLeft:'15px'}}>
                                {ReportsUtils.CustomCollapseComponent(getSelectedKey(k),showMore[getSelectedKey(k)],(val)=>setShowMore(prev=>({...prev,[getSelectedKey(k)]:val})))}
                            </Space>
                        </Space>))}
                </Space>
            </Col>
        </Row>
    );
}

export default ReportsRightPanel;
