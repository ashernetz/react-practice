import React from 'react';
import { Row, Col, Typography, Space, Button } from 'antd';
import { FilterOutlined, LeftOutlined,ReloadOutlined } from '@ant-design/icons'
import "./ReportsContentHeader.scss";

const {Text} = Typography;

const ReportsContentHeader = (props) => {
  return (
      <Row justify="space-between" align="middle" id="reports-content-header">
        <Col>
          {props.isGenerateReportOpen ?
              <>
                  <LeftOutlined  style={{fontSize:'20px'}} onClick={()=> props.setIsGenerateReportOpen(false)}/>
                  <Text className="reports-header-text"> Report History</Text>
              </>
              : <Text className="reports-header-text">Generate a SKU Attributes Report</Text>
          }

        </Col>
        {props.isGenerateReportOpen ?
            <Col>
                  <Button 
                type="primary" 
                icon= {<ReloadOutlined />}
                style={{ marginLeft: 'auto' }} 
                onClick={()=> {props.callReportsLog(true);}}

              > Refresh
                  </Button>
            </Col>:
        <Col>
          {!props.isGenerateReportOpen &&
          <Space size={24}>
                  <Button onClick={()=> {window.open("https://myassortment-ui.apps.homedepot.com/status/multiSku")}} type="primary">
                      SKU-Store Report
                  </Button>
            <a className="reports-header-link" onClick={()=>{props.setIsGenerateReportOpen(true)}}>Report History</a>{/*eslint-disable-line*/}
            <Space >
              <FilterOutlined />
              <a className="reports-header-link" onClick={()=>{props.removeAllSelected();props.setSelectedTab('subDepartment')}}>Clear All Selections</a>{/*eslint-disable-line*/}
            </Space>
          </Space>}
        </Col>
}
      </Row>
  );
}

export default ReportsContentHeader;
