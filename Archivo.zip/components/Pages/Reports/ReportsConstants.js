export default class ReportsConstants {

  static SELECTION_LABEL = {
    subDepartment: "Select one Sub Department",
    class: "Classes has been filtered based on previous selection",
    subclass: "SubClasses has been filtered based on previous selection",
    vendors: "Enter Vendor numbers or Vendor Name below",
    skus:"Enter SKUs below: "
  }

  static STATUS_COLOR = {
    "SUBMITTED": "blue",
    "COMPLETED": "green",
    "IN-PROGRESS": "yellow",
    "FAILED-RETRYABLE": "orange",
    "FAILED": "red",
    "PARTIALLY COMPLETED": "lime"
  }
}
