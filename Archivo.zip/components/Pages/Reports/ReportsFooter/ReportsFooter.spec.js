import React from 'react';
import '@testing-library/jest-dom'
import {render, screen} from "@testing-library/react";
import ReportsFooter from './ReportsFooter';

jest.mock('axios');
jest.useFakeTimers();

let selectedKey = {classes: ['21 | 1-PLYWOOD'], subDepartment: ['21-LUMBER'], subClass: ['21 | 1 | 3 - OSB', '21 | 1 | 4 - SANDED'],vendors:[114995,18807],skus:[161640,159686]};
let noSelectedKey = {classes: [], subDepartment: [], subClass: [], vendors: [],skus:[]};


describe('ReportsFooter',()=> {

  it('should render a disabled button with the class of primary', () => {
    render(<ReportsFooter selectedKey={noSelectedKey}/>);
    const primaryButtonDisabled = screen.getByRole('button', {name: "Run Report"})
    expect(primaryButtonDisabled).toHaveClass('ant-btn-primary')
    expect(primaryButtonDisabled).toBeDisabled()
  });

  it('should render a button with the class of primary', () => {
    render(<ReportsFooter selectedKey={selectedKey}/>);
    const primaryButtonDisabled = screen.getByRole('button', {name: "Run Report"})
    expect(primaryButtonDisabled).toHaveClass('ant-btn-primary')
    expect(primaryButtonDisabled)
  })
});
