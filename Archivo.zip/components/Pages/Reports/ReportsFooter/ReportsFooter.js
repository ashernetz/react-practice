import React from 'react';
import {Row, Col, Button, Layout } from 'antd';
import "./ReportsFooter.scss";


const { Footer } = Layout;

const ReportsFooter = (props) => {
  return(
      <Footer id="reports-footer">
        <Row justify="end">
          <Col>
            <Button type="primary"
                    disabled={!((props.selectedKey.subDepartment.length > 0
                            && props.selectedKey.classes.length > 0)
                        || props.selectedKey.vendors.length > 0
                        || props.selectedKey.skus.length > 0)}
                    onClick={() => {props.generateReportRequest();}}
            >Run Report</Button>
          </Col>
        </Row>
      </Footer>
  );
}

export default ReportsFooter;
