import React from 'react';
import { Row, Col } from 'antd';
import "./ReportsTabPanel.scss";
import ReportsRightPanel from '../ReportsRightPanel/ReportsRightPanel';
import ReportsLeftPanel from '../ReportsLeftPanel/ReportsLeftPanel';

const ReportsTabPanel = (props) => {

  return(
      <>
        <Row>
          <Col xs={19} sm={19} md={19} lg={19} style={{paddingRight:'24px'}}>
            <Row>
              <Col>
                <ReportsLeftPanel
                    noData={props.noData}
                    selectedTab={props.selectedTab}
                    setSelectedTab={props.setSelectedTab}
                    subDeptData={props.subDeptData}
                    classData={props.classData}
                    subClassData={props.subClassData}
                    toggleClear={props.toggleClear}
                    selectedKey={props.selectedKey}
                    setSelectedKey={props.setSelectedKey}
                    locationData={props.locationData}
                    isDcChecked={props.isDcChecked}
                    setIsDcChecked={props.setIsDcChecked}
                    selectedDisaster={props.selectedDisaster}
                    setSelectedDisaster={props.setSelectedDisaster}
                />
              </Col>
            </Row>
          </Col>
          <Col xs={5} sm={5} md={5} lg={5} style={{backgroundColor:'#eceff1'}}>
            <Row style={{padding:'32px',paddingRight:'0px'}}>
              <Col>
                <ReportsRightPanel
                    selectedKey={props.selectedKey}
                    setSelectedKey = {props.setSelectedKey}
                />
              </Col>
            </Row>
          </Col>
        </Row>
      </>
  );
}

export default ReportsTabPanel;
