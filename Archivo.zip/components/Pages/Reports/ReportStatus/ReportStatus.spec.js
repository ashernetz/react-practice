import React from 'react'
import '@testing-library/jest-dom'
import {render, screen} from "@testing-library/react";
import ReportStatus from './ReportStatus';

jest.mock('axios');
jest.useFakeTimers();

let reportLogData = [{"id":266,"lastUpdTs":"2023-03-29T08:30:29.601+00:00","lastUpdId":"MC62YE","submSysusrId":"MC62YE","submTs":"2023-03-29T08:30:21.695+00:00","endTs":null,"statCd":"FAILED","link":null,"fileNm":null,"rptTyp":"531","rqstPayload":{"department":null,"classNumber":null,"subclasses":null,"userId":"MC62YE","includeDC":false},"recCnt":null,"failureReason":"{\"timestamp\":\"2023-03-29T12:30:29.281+00:00\",\"status\":400,\"error\":\"Bad Request\",\"path\":\"/v1/report/generate/266\"}"},{"id":281,"lastUpdTs":"2023-03-29T23:39:03.298+00:00","lastUpdId":"531_SYS_USR","submSysusrId":"MC62YE","submTs":"2023-03-29T23:39:00.395+00:00","endTs":"2023-03-29T23:39:03.297+00:00","statCd":"FAILED","link":null,"fileNm":null,"rptTyp":"531","rqstPayload":{"department":"21","classNumber":"021-001","subclasses":["021-001-002"],"userId":"MC62YE","includeDC":true},"recCnt":null,"failureReason":{"cause":null,"stackTrace":[{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"getDataConnectResponse","fileName":"DataConnectClient.java","lineNumber":82,"className":"com.homedepot.mm.pc.client.DataConnectClient","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"formDataConnectRequest","fileName":"DataConnectClient.java","lineNumber":59,"className":"com.homedepot.mm.pc.client.DataConnectClient","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"generateReport","fileName":"ReportService.java","lineNumber":59,"className":"com.homedepot.mm.pc.service.ReportService","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"invoke","fileName":"<generated>","lineNumber":-1,"className":"com.homedepot.mm.pc.service.ReportService$$FastClassBySpringCGLIB$$ef1d69b5","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"invoke","fileName":"MethodProxy.java","lineNumber":218,"className":"org.springframework.cglib.proxy.MethodProxy","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"invokeJoinpoint","fileName":"CglibAopProxy.java","lineNumber":793,"className":"org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"proceed","fileName":"ReflectiveMethodInvocation.java","lineNumber":163,"className":"org.springframework.aop.framework.ReflectiveMethodInvocation","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"proceed","fileName":"CglibAopProxy.java","lineNumber":763,"className":"org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation","nativeMethod":false},{"classLoaderName":"app","moduleName":null,"moduleVersion":null,"methodName":"lambda$invoke$0","fileName":"AsyncExecutionInterceptor.java","lineNumber":115,"className":"org.springframework.aop.interceptor.AsyncExecutionInterceptor","nativeMethod":false},{"classLoaderName":null,"moduleName":"java.base","moduleVersion":"11.0.18","methodName":"run","fileName":"FutureTask.java","lineNumber":264,"className":"java.util.concurrent.FutureTask","nativeMethod":false},{"classLoaderName":null,"moduleName":"java.base","moduleVersion":"11.0.18","methodName":"runWorker","fileName":"ThreadPoolExecutor.java","lineNumber":1128,"className":"java.util.concurrent.ThreadPoolExecutor","nativeMethod":false},{"classLoaderName":null,"moduleName":"java.base","moduleVersion":"11.0.18","methodName":"run","fileName":"ThreadPoolExecutor.java","lineNumber":628,"className":"java.util.concurrent.ThreadPoolExecutor$Worker","nativeMethod":false},{"classLoaderName":null,"moduleName":"java.base","moduleVersion":"11.0.18","methodName":"run","fileName":"Thread.java","lineNumber":829,"className":"java.lang.Thread","nativeMethod":false}],"message":"Error occurred while calling the data connect APIcom.fasterxml.jackson.core.JsonParseException: Unrecognized token '$': was expecting (JSON String, Number, Array, Object or token 'null', 'true' or 'false')\n at [Source: (String)\"{\"uid\":\"MC62YE\",\"limit\":${LIMIT},\"engine_key\":\"Internal_VendorDrill\",\"filters\":{\"filterValues\":[{\"Values\":[\"021-001\"],\"QueryName\":\"Class_Nbr\"}]},\"metrics\":[{\"FriendlyName\":\"COUNT STRS AVAIL\",\"QueryName\":\"m_store_count_avail\"},{\"FriendlyName\":\"CURR COST\",\"QueryName\":\"m_current_cost_amount\"},{\"FriendlyName\":\"CURR COST EFF DT\",\"QueryName\":\"m_cur_cost_begin_dt\"},{\"FriendlyName\":\"BLENDED MARKET COST\",\"QueryName\":\"m_blended_cost_amount\"},{\"FriendlyName\":\"BLENDED MARKET COST EFF DT\",\"QueryName\":\"m_blen\"[truncated 1585 chars]; line: 1, column: 26]","suppressed":[],"localizedMessage":"Error occurred while calling the data connect APIcom.fasterxml.jackson.core.JsonParseException: Unrecognized token '$': was expecting (JSON String, Number, Array, Object or token 'null', 'true' or 'false')\n at [Source: (String)\"{\"uid\":\"MC62YE\",\"limit\":${LIMIT},\"engine_key\":\"Internal_VendorDrill\",\"filters\":{\"filterValues\":[{\"Values\":[\"021-001\"],\"QueryName\":\"Class_Nbr\"}]},\"metrics\":[{\"FriendlyName\":\"COUNT STRS AVAIL\",\"QueryName\":\"m_store_count_avail\"},{\"FriendlyName\":\"CURR COST\",\"QueryName\":\"m_current_cost_amount\"},{\"FriendlyName\":\"CURR COST EFF DT\",\"QueryName\":\"m_cur_cost_begin_dt\"},{\"FriendlyName\":\"BLENDED MARKET COST\",\"QueryName\":\"m_blended_cost_amount\"},{\"FriendlyName\":\"BLENDED MARKET COST EFF DT\",\"QueryName\":\"m_blen\"[truncated 1585 chars]; line: 1, column: 26]"}}];
let reportLogDataWithNoDataConnectData = [{"id": 852,"lastUpdTs": "2023-07-05T01:40:47.923+00:00","lastUpdId": "SXM87V2","submSysusrId": "SXM87V2","submTs": "2023-07-05T01:30:44.762+00:00","endTs": "2023-07-05T01:40:47.920+00:00","statCd": "COMPLETED","link": "","fileNm": "","rptTyp": "531","rqstPayload": {"department": null,"classNumber": "059-013","subclasses": ["059-013-012"],"skus": [],"vendors": [],"markets": [],"userId": "MC62YE","includeDC": true,"distinctSubDepts": ["059S"]},"recCnt": null,"failureReason": "No Data"}];
let reportLogDataWithSuccessfulReportGeneration = [{"id": 1252,"lastUpdTs": "2023-07-20 12:18:59.321000","lastUpdId": "531_SYS_USR","submSysusrId": "MC62YE","submTs": "2023-07-20 12:18:30.260000","endTs": "2023-07-20 12:18:59.320000","statCd": "COMPLETED","link": "http://dummy-report-link.com","fileNm": "SKU_ATTRIBUTES_ALL_Report_025H_SubDept_SKUFiltered_2023-07-20_12-18-57.xlsx","rptTyp": "531","rqstPayload": {"department":null,"classNumber":"025-010","subclasses":[],"skus":[1002708057],"vendors":[],"markets":[],"userId":"MC62YE","includeDC":true,"distinctSubDepts":null,"subDept":"025H","skuStatuses":["100-ACTIVE"],"skuTypes":["NORMAL"]},"recCnt": 80,"failureReason": null}];

beforeEach(async () => {
  // render(<ReportStatus reportLogData={reportLogData}/>);
})

describe("Basic Component Rendering", () => {
  it("Should not render data without props ", () => {
    render(<ReportStatus columns={()=>{ }} dataSource={()=>{}} tableClassName="reports-table-pagination" locale={()=>{}}/>)
    expect(screen.queryAllByTestId("AdvancedTable"))
        .toHaveLength(0)
  })
});

describe('ReportStatus with data ',()=> {

  test('status id', async () => {
    render(<ReportStatus reportLogData={reportLogData}/>);
    expect(screen.getAllByText(266)[0]).toBeInTheDocument();
  });

  test('report type', async () => {
    render(<ReportStatus reportLogData={reportLogData}/>);
    expect(screen.getAllByText("SKU Attributes")[0]).toBeInTheDocument();
  });

  test('status', async () => {
    render(<ReportStatus reportLogData={reportLogData}/>);
    expect(screen.getAllByText('FAILED')[0]).toBeInTheDocument();
  });

  test('Should Show Not Applicable when report fails ', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText('NA')[0]).toBeInTheDocument();
  });


});

describe('ReportStatus with No excel data ',()=> {


  test('status id', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText(852)[0]).toBeInTheDocument();
  });

  test('should show report type', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText('SKU Attributes')[0]).toBeInTheDocument();
  });

  test('Should show status', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText('COMPLETED')[0]).toBeInTheDocument();
  });
  test('Should Show No Data in the UI ', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText('NO DATA')[0]).toBeInTheDocument();
  });

  test('Should Show Not Applicable when report fails ', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithNoDataConnectData}/>);
    expect(screen.getAllByText('NA')[0]).toBeInTheDocument();
  });
});


describe('ReportStatus with valid excel excel generation scenario ',()=> {

  test('should show number of rendered cells', async () => {
    const { container } =render(<ReportStatus reportLogData={reportLogDataWithSuccessfulReportGeneration}/>);
    expect(container.getElementsByClassName('ant-table-cell').length).toBe(12);
  });

  /**
   * When valid data is present 6 cells are present for heading and 6 cells for actual data
   */

  test('status id', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithSuccessfulReportGeneration}/>);
    expect(screen.getAllByText(1252)[0]).toBeInTheDocument();
  });

  test('should show report type', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithSuccessfulReportGeneration}/>);
    expect(screen.getAllByText('SKU Attributes')[0]).toBeInTheDocument();
  });


  test('Should show status', async () => {
    render(<ReportStatus reportLogData={reportLogDataWithSuccessfulReportGeneration}/>);
    expect(screen.getAllByText('COMPLETED')[0]).toBeInTheDocument();
  });


});
