import React from 'react';
import { Row, Col, Typography, Space, Tag } from 'antd';
import "./ReportStatus.scss"
import UXSmallPulse from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse';
import AdvancedTable from '../../../GlobalComponents/AdvancedTable/AdvancedTable';
import ReportsUtils from '../ReportsUtils';
import ReportsServices from '../../../../services/ReportsServices';
import {excelDownload} from "../../../Utils/ExcelUtil";
import ReportsConstants from "../ReportsConstants";

const {Text} = Typography;
const reportStatusColumns = (setShowDimmer) =>  ([
  {
    title: <Text strong>Job ID</Text>,
    dataIndex:'id',
    width: 100,
    defaultSortOrder: 'descend',
    isCustomFilter: true,
    sorter: (a,b) =>  a.id - b.id,
    render: (id) => <Text>{id?id:"NA"}</Text>
  },
  {
    title: <Text strong>Report Name</Text>,
    dataIndex:'rptName',
    width: 325,
    render: (fileNm,row) => <Text>{row.fileNm?row.fileNm:"NA"}</Text>
  },
  {
    title: <Text strong>Date</Text>,
    dataIndex:'submTs',
    width: 175,
    render: (submTs) => <Text>{submTs?formSeperatedDateTime(submTs):"NA"}</Text>

  },
  {
    title: <Text strong>Report Type</Text>,
    dataIndex:'rptTyp',
    width: 150,
    render: (rptTyp) => <Text>{rptTyp === "531" ? "SKU Attributes" :"NA"}</Text>

  },
  {
    title: <Text strong>Status</Text>,
    dataIndex:'statCd',
    width: 150,
    render: (statCd) => <Text>{statCd?<Tag color={ReportsConstants.STATUS_COLOR[statCd]}>
      {statCd}
    </Tag>:"NA"}</Text>

  },
  {
    title: <Text strong>Link to Download</Text>,
    dataIndex:'fileNm',
    width: 100,
    render: (fileNm,row) => {
      if(row.link==="" && row.failureReason==="No Data"){
        return(
            <Text>NO DATA</Text>
        );
      }else if((row.statCd === "COMPLETED" || row.statCd ==="PARTIALLY COMPLETED")  && fileNm){
        return(<>
              <a onClick={()=> downloadExcelReport(fileNm,setShowDimmer)}>Download</a> {/*eslint-disable-line*/}
            </>
        );
      }else{
        return "NA";
      }
    }
  }
]);



const formSeperatedDateTime = (inputDate) => {
  return(
      <Space size={4}>
        <Text>{ReportsUtils.formattedDateYYYYMMDD(inputDate)}</Text>
        <Text>{"|"}</Text>
        <Text>{ReportsUtils.formattedTime(inputDate)}</Text>
      </Space>
  )
}

const downloadExcelReport = (fileName,setShowDimmer) => {
  setShowDimmer(true);
  ReportsServices.downloadReport(fileName).then(response => {
    if(response && response.data){
      excelDownload(fileName,response.data);
      setShowDimmer(false);

    }
  })
}
const ReportStatus = (props) => {

  return(
      <Row id="reports-status">
        <Col span={24}>
          {/*feature components*/}
          {/*<Row justify="space-between" style={{paddingBottom:'12px'}}>*/}
          {/*  <Col>*/}
          {/*    <Space size={8}>*/}
          {/*      <Text className="reports-from-text">Show Reports From: </Text>*/}
          {/*      <Dropdown menu={menuProps}>*/}
          {/*        <Button>*/}
          {/*          <Space>*/}
          {/*            This Month*/}
          {/*            <DownOutlined />*/}
          {/*          </Space>*/}
          {/*        </Button>*/}
          {/*      </Dropdown>*/}
          {/*    </Space>*/}
          {/*  </Col>*/}
          {/*  /!*<Col>*!/*/}
          {/*  /!*  <Text>Generate a Report</Text>*!/*/}
          {/*  /!*</Col>*!/*/}
          {/*</Row>*/}
          <Row style={{"padding-bottom":'20px'}}>
            <Col>
              <Tag color="lime" >PARTIALLY COMPLETED</Tag>
              <Text>- Report will only include first 300K rows of market data and first 300K rows of DC data. All other data will be excluded from the report.</Text>
            </Col>
          </Row>
          <Row>
            <Col>
              <AdvancedTable
                  tableClassName="reports-table-pagination"
                  columns={reportStatusColumns(props.setShowDimmer)}
                  locale={{ emptyText: props.noData }}
                  dataSource={props.reportLogData}
                  extraTableProps={{
                    scroll: { y: 430 },
                    loading :{spinning:!props.reportLogData, indicator:<UXSmallPulse/>},
                  }}
              />
            </Col>
          </Row>
        </Col>
      </Row>
  );
}

export default ReportStatus;
