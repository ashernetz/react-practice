import '@testing-library/jest-dom'
import {fireEvent, render, screen} from '@testing-library/react';
import ReportsLeftPanel from "./ReportsLeftPanel";
import Reports from "../Reports";

jest.mock('axios');
jest.useFakeTimers();


let subDeptData = [{subDeptNum: '0021', subDeptName: 'LUMBER', subDeptDes: '21-LUMBER'},
    {subDeptNum: '0022', subDeptName: 'BLDG MAT', subDeptDes: '22-BLDG MAT'}]

let classData = [{deptNum: 21, classNum: 1, className: 'PLYWOOD', classDes: '21 | 1-PLYWOOD'},
    {deptNum: 21, classNum: 2, className: 'SIDING', classDes: '21 | 2-SIDING'},
    {deptNum: 21, classNum: 3, className: 'DIMENSION', classDes: '21 | 3-DIMENSION'}];

let subClassData = [
    {deptNum: 21, classNum: 1, subClassNum: 2, subClassName: 'SHEATHING', subClassDes: '21 | 1 | 2 - SHEATHING'},
    {deptNum: 21, classNum: 1, subClassNum: 3, subClassName: 'OSB', subClassDes: '21 | 1 | 3 - OSB'},
    {deptNum: 21, classNum: 1, subClassNum: 4, subClassName: 'SANDED', subClassDes: '21 | 1 | 4 - SANDED'},
    {deptNum: 21, classNum: 1, subClassNum: 5, subClassName: 'HARDWOOD', subClassDes: '21 | 1 | 5 - HARDWOOD'}]

let RenderLeftPanel = <ReportsLeftPanel
    noData={() => {}}
    selectedTab={() => {}}
    setSelectedTab={() => {}}
    subDeptData={subDeptData}
    classData={classData}
    subClassData={subClassData}
    toggleClear={false}
    selectedKey={{
        "classes": ['21 | 1-PLYWOOD'], "subDepartment": ['21-LUMBER'],
        "subClass": ['21 | 1 | 3 - OSB', '21 | 1 | 4 - SANDED'],
        "vendors": [],
        "skus": [],
        "byos": [],
        "markets": [],
        "stores": [],
        "skuType": [],
        "skuStatus": []
    }}
    setSelectedKey={() => {}}
    isDcChecked={() => {}}
    setIsDcChecked={() => {}}
    selectedDisaster={'WITH_DISASTER'}
    setSelectedDisaster={() => {}}
/>

describe('Test Left Panel CheckBox',()=> {

    test('check dc checked',() => {
        render(RenderLeftPanel);
        expect(screen.getByTestId('dc-checked').checked).toBe(true);
    });

    test('first checkbox checked',() => {
        render(RenderLeftPanel);
        expect(screen.getByTestId('WITH_DISASTER').checked).toBe(true);
        expect(screen.getByTestId('WITHOUT_DISASTER').checked).toBe(false);
        expect(screen.getByTestId('ONLY_DISASTER').checked).toBe(false);
        });

    test('test onClick by with disaster',()=>{
        const  {getByText} = render(RenderLeftPanel);
        let checkBoxGetByText = getByText('With Disaster');
        const onClickCheckBox = fireEvent.click(checkBoxGetByText);
        expect(onClickCheckBox).toBe(true);
    });

    test('test onClick by without disaster',()=>{
        const  {getByText} = render(RenderLeftPanel);
        let checkBoxGetByText = getByText('Without Disaster');
        const onClickCheckBox = fireEvent.click(checkBoxGetByText);
        expect(onClickCheckBox).toBe(true);
    });

    test('test onClick by only disaster',()=>{
        const  {getByText} = render(RenderLeftPanel);
        let checkBoxGetByText = getByText('Only Disaster');
        const onClickCheckBox = fireEvent.click(checkBoxGetByText);
        expect(onClickCheckBox).toBe(true);
    });

})