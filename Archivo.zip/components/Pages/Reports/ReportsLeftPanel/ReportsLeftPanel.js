import React,{useState} from "react";
import { Row, Col, Typography, Tabs, Checkbox, Divider, Space } from "antd";
import "./ReportsLeftPanel.scss";
import SubDepartmentTable from "./ReportsDcsTable/SubDepartmentTable"
import ClassTable from "./ReportsDcsTable/ClassTable"
import SubClassTable from "./ReportsDcsTable/SubClassTable"
import VendorsTable from "./VendorsTable/VendorsTable"
import SkuTable from './SkuTable/SkuTable';
import StoreTable from "./StoreTable/StoreTable";
import ByoMarket from './ByoMarket/ByoMarket';


const { Text } = Typography;

const IncludeDistribution=(props) =>{
  return (
      <Row test-dataid="check-box">
        <Col span={24}>
          <Checkbox checked={props.isDcChecked}
                    data-testid={"dc-checked"}
                    onChange={(e)=>{
              props.setIsDcChecked(e.target.checked);
            }}>
            <Row>
              <Col>
                <Row>
                  <Col><Text>Include Distribution</Text></Col>
                </Row>
                <Row>
                  <Col><Text>Centers</Text></Col>
                </Row>
              </Col>
            </Row>
          </Checkbox>
        </Col>
      </Row>

  );
}
const ReportsLeftPanel = (props) => {

  const checkBoxList = [
    {label: 'With Disaster', value: 'WITH_DISASTER'},
    {label: 'Without Disaster', value: 'WITHOUT_DISASTER'},
    {label: 'Only Disaster', value: 'ONLY_DISASTER'}
  ];

  const onChangeDisaster = (e) => {
    if (e.target.checked) {
      props.setSelectedDisaster(e.target.value);
    }
  };


  const items = [
    {
      label: <Text className="reports-tab-heading">SUB DEPARTMENT</Text>,
      key: 'subDepartment',
      children: <Row>
        <Col span={24}>
          <SubDepartmentTable
              noData={props.noData}
              subDeptData={props.subDeptData}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">VENDOR</Text>,
      key: 'vendors',
      children: <Row>
        <Col span={24}>
          <VendorsTable
              noData={props.noData}
              toggleClear={props.toggleClear}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
              classData={props.classData}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">CLASS</Text>,
      key: 'class',
      disabled: props.selectedKey.subDepartment.length > 0 ? false:true,
      children: <Row>
        <Col span={24}>
          <ClassTable
              noData={props.noData}
              classData={props.classData}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">SUBCLASS</Text>,
      key: 'subclass',
      disabled: props.selectedKey.classes.length > 0 ? false:true,
      children: <Row>
        <Col span={24}>
          <SubClassTable
              noData={props.noData}
              subClassData={props.subClassData}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">SKU</Text>,
      key: 'skus',
      children: <Row>
        <Col span={24}>
          <SkuTable
              noData={props.noData}
              toggleClear={props.toggleClear}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
              classData = {props.classData}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">BYO/MARKET</Text>,
      key: 'byo',
      children: <Row>
        <Col span={24}>
          <ByoMarket
              noData={props.noData}
              locationData ={props.locationData}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
              toggleClear={props.toggleClear}
              selectedTab={props.selectedTab}
          />
        </Col>
      </Row>
    },
    {
      label: <Text className="reports-tab-heading">STORES</Text>,
      key: 'stores',
      children: <Row>
        <Col span={24}>
          <StoreTable
              noData={props.noData}
              selectedKey={props.selectedKey}
              setSelectedKey={props.setSelectedKey}
              locationData ={props.locationData}
              selectedTab = {props.selectedTab}
          />
        </Col>
      </Row>
    },
    {
      label: <>
        <Divider className="reports-tab-divider-Gap"/>
        <Space direction="vertical" align="start">
          <IncludeDistribution
              isDcChecked={props.isDcChecked}
              setIsDcChecked={props.setIsDcChecked}/>
          <Space direction="vertical" align="start">
            <Text className="reports-tab-disaster-market-title">Disaster Markets</Text>
            {
              checkBoxList.map((item) => (
                  <Checkbox
                      checked={props.selectedDisaster === item.value}
                      value={item.value}
                      data-testid={item.value}
                      onChange={onChangeDisaster}
                  >
                    {item.label}
                  </Checkbox>))
            }
          </Space>
        </Space></>,
      key: 'dc'
    }
  ];


  return(
      <Row id="reports-left-panel">
        <Col span={24}>
          <Tabs
              tabPosition="left"
              tabBarStyle={{width:'195px'}}
              activeKey={props.selectedTab}
              onTabClick={e => {
                if (e !== 'dc') {
                  props.setSelectedTab(e);
                }
              }}
              items={items}
               />
        </Col>
      </Row>
  );
}

export default ReportsLeftPanel;
