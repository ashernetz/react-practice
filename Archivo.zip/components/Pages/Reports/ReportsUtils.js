import React from "react";
import {Typography, Space, notification} from 'antd';
import "./Reports.scss";

const {Text} = Typography;

export default class ReportsUtils {

  static numberFormattedSubDepartment = (inputString) => {
    let formattedSubDepartment = "";
    if(inputString){
      formattedSubDepartment = inputString.split("-")[0].trim().padStart(4,0);
    }
    return formattedSubDepartment;
  }

  static numberFormattedClass = (inputString) => {
    let formattedClass = "";
    if(inputString){
      let deptNum = inputString.deptNum.toString().padStart(3, '0');
      let classNum = inputString.classNum.toString().padStart(3, '0');
      formattedClass = deptNum+"-"+classNum;
    }
    return formattedClass;
  }

  static numberFormattedSubClass = (inputString) => {
    let formattedSubClass = "";
    if(inputString){
      let deptNum = inputString.deptNum.toString().padStart(3, '0');
      let classNum = inputString.classNum.toString().padStart(3, '0');
      let subClassNum = inputString.subClassNum.toString().padStart(3, '0');
      formattedSubClass = deptNum+"-"+classNum+"-"+subClassNum;
    }
    return formattedSubClass;
  }

  static formattedDateYYYYMMDD = (inputDate) => {
    let formattedDate = "";
    if(inputDate){
      formattedDate = inputDate.split('T')[0];
    }
    return formattedDate;
  }

  static formattedTime = (inputDate) => {
    let formattedTime = "";
    if(inputDate){
      let newDate = new Date(inputDate);
      formattedTime = newDate.toLocaleString('en-US', { timeZone: 'UTC',hour: 'numeric', minute: 'numeric', hour12: true })
    }
    return formattedTime;
  }

  static CustomCollapseComponent = (data,showMore,setShowMore) => {
    return (
        <>
          <Space size={0} direction="vertical">
            {data.length> 0 ?
                data.filter((k,index) => showMore || index < 3)
                    .map(k=><Space  direction="vertical"><Text>{k}</Text></Space>)
                :<Text>-</Text>}
            {data.length > 3 ?
                <a style={{fontSize:'14px'}} onClick={() => setShowMore(!showMore)}>{showMore ? "Show less" : ("+ "+(data.length-3)+" more...")}</a>:""} {/*eslint-disable-line*/}
          </Space>
        </>
    );

  };

  static reportAlert = (type,message,description) => {
    notification[type]({
      message: message,
      description:description,
    });
  };

  static reportTableStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
  };

  static capitalizeFirstLetter = (string) => {
    return string[0].toUpperCase() + string.slice(1);
  };
}
