function formatFiscalWeek(value) {
    return value ? parseInt(value.replace("FW", "")) : null;
}

function getHierarchy (selectedDCS, subDeptDataMap, dcsDataMap){

    try {
        let subDepartment = "";
        let subDepartmentName = "";
        let departmentNumber = 0;
        let departmentName = "";
        let classNumber = 0;
        let className = "";
        let subClassNumber = 0;
        let subClassName = "";

        if (subDeptDataMap && dcsDataMap && selectedDCS && selectedDCS.split("-")[0] !== 0) {
            let dcs = selectedDCS.split("-");
            departmentNumber = Number.parseInt(dcs[0]);
            classNumber = Number.parseInt(dcs[1]);
            subClassNumber = Number.parseInt(dcs[2]);
            subDepartment = Object.keys(subDeptDataMap).find(k => {
                let deptClassMap = subDeptDataMap[k].deptClassMap;
                return deptClassMap.has(departmentNumber) && deptClassMap.get(
                    departmentNumber).includes(classNumber);
            });
            subDepartmentName = subDeptDataMap.hasOwnProperty(subDepartment)
                ? subDeptDataMap[subDepartment].longDescription : "";

            let deptMap = dcsDataMap.get(departmentNumber);
            let classMap = dcsDataMap.get(departmentNumber).get("classes").get(classNumber);

            departmentName = deptMap.get("longDescription");
            className = classMap.get("longDescription");

            if (subClassNumber) {
                subClassName = classMap.get("subclasses").get(subClassNumber).get(
                    "longDescription");
            }

        }
        return {
            subDepartment,
            subDepartmentName,
            departmentNumber,
            departmentName,
            classNumber,
            className,
            subClassNumber,
            subClassName
        }
    } catch (e) {
        //console.log("Wrong DCS key : " + dcsKey);
        return {};
    }


}


export {
    formatFiscalWeek,getHierarchy
}