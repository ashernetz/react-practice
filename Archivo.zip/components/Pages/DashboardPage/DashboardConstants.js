const widgets = {
    PROD_OVW: "Product Overview",
    OFFSIDES: "Offside Products",
    ZONE_OVW: "Zone Overview",
    HEALTH: "Health",
    PERFORMANCE: "Performance",
    PRC_CHG: "Price Change Requests"
};

const DEFAULT_ORDER = [
    widgets.PROD_OVW, 
    widgets.OFFSIDES, 
    widgets.ZONE_OVW, 
    widgets.HEALTH, 
    widgets.PERFORMANCE, 
    widgets.PRC_CHG
];

const DashboardConstants = {
    widgets,
    DEFAULT_ORDER,
    DEFAULT_DASH_CONFIG: {
        widgetOrder: DEFAULT_ORDER,
        widgetEnablement: {},
        competitorDataEnablement: {}
    }
};

export default DashboardConstants