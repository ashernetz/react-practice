import React, {Fragment, useContext, useState} from 'react';
import {Badge, Tooltip} from 'antd';
import DCSOverviewModal
  from "../../DashboardDrawer/DCSOverviewModal/DCSOverviewModal";
import SkuContext from "../../../context/SkuContext";
import PriceDataServices from "../../../services/PriceDataServices";
import AlertUtil from "../../Utils/AlertUtil";
import DCSUtil from "../../Utils/DCSUtil";
import {UXSpin} from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import {trackEvent} from '../../Utils/mixpanel';
import "./DashboardPage.scss";

const DashboardHierarchySelect = () => {
  const skuContext = useContext(SkuContext);
  const [isDCSModalOpen, setIsDCSModalOpen] = useState(false);

  const updateUserProfile = (title,dcs,userProfile)=> {
    skuContext.updateShowDimmer(true);
    PriceDataServices.updateUserProfileData(title,dcs,userProfile).then( response => {
      if(response.status === 200){
        let dcsKey = response.data.departmentNumber + '-' + response.data.classNumber + '-' +response.data.subClassNumber;
        skuContext.updateProfileData({
          ...response.data,
          subClassDetails: dcsKey
        });
        skuContext.updateStateFields({selectedDCS:dcsKey})}

    }).catch(k => {
      AlertUtil.showAlert("error", "Error",AlertUtil.getErrorMessage("updating user profile"));
    }).finally(()=>skuContext.updateShowDimmer(false));
  };

  const getDropDownValue = () => {
     return DCSUtil.getHierarchyName(
          skuContext.dcsDataMap,
          skuContext.selectedDCS,
          "Choose Class/Sub Class"
      );

  };

  function handleClickingDCS() {
    setIsDCSModalOpen(true);
    trackEvent("CLICKED_DASHBOARD_HEADER_DCS");
  }

  const getToolTipData = () => {
    let tooltipData = "";
    if(skuContext.selectedDCS) {
      let dcsKey = skuContext.selectedDCS.split("-");
      let subClassNumber = Number.parseInt(dcsKey[2]);
      let deptNumber = Number.parseInt(dcsKey[0]);
      let classNumber = Number.parseInt(dcsKey[1]);
      let hierarchyName = DCSUtil.getHierarchyName(
          skuContext.dcsDataMap,
          skuContext.selectedDCS,
          ""
      );

      tooltipData = hierarchyName + " belongs to D" + deptNumber;

      if (classNumber !== 0) {
        tooltipData = tooltipData + " C" + classNumber;
      }
      if (subClassNumber !== 0) {
        tooltipData = tooltipData + " S" + subClassNumber;
      }
    }
    return tooltipData;
  };


  return (<Fragment>
    {skuContext.dcsDataMap.size > 0 ?
        <Fragment>
          <a id="dashboard-page-header-dcs" onClick={handleClickingDCS}>{getDropDownValue()}</a>  {/*eslint-disable-line*/}
          <Badge
              offset={[0,-5]}
            count={
              <div>
                <Tooltip title={getToolTipData()} placement="bottom">
                  <i className="material-icons-outlined dashboard-dcs-info">
                    info
                  </i>
                </Tooltip>
              </div>
            }
        /></Fragment>:<UXSpin/>}
    {isDCSModalOpen && <DCSOverviewModal
        selectedDCS={skuContext.selectedDCS}
        isOpen={true}
        onClose={() => setIsDCSModalOpen(false)}
        dcsDataMap={skuContext.dcsDataMap}
        onDCSChange={(dcsKey) => skuContext.updateStateFields({selectedDCS:dcsKey})}
        profileData={skuContext.profileData}
        updateUserProfile={updateUserProfile}
    />}</Fragment>);
};

export default DashboardHierarchySelect;