import React, {Fragment} from 'react';
import { Typography, Row, Col } from 'antd';
import "./DataConnectionIssue.scss";
import SvgUtil from "../../../Utils/SvgUtil";

const { Text } = Typography;

const DataConnectionIssue = (props) => {
    

    return (
        <Fragment>
            <Row justify="center" align="middle">
                <Col className="data-connection-image">
                    {SvgUtil.getDataConnectionIssueSvg()}
                </Col>
            </Row>
            <Row justify="center" align="middle" gutter={[0,8]} style={{ paddingTop: "10px" }}>
                <Col>
                    <Text className="data-connection-bold">
                        Data Connection Issues
                </Text>
                </Col>
            </Row>
            <Row justify="center" align="middle" gutter={[0,8]}>
                <Col >
                  <Text className="data-connection">Looks like we are having some issues retrieving data</Text>
                </Col>
            </Row>
          <Row justify="center" align="middle"gutter={[0,8]}>
            <Col>
              <Text className="data-connection">
                We're working on this issue.
              </Text>
            </Col>
          </Row>
            {/* <Row justify="center" align="middle" gutter={[0,24]}>
                <Col>
                    <Text className="data-connection-sos">
                       SOS Request Sent
                </Text>
                </Col>
            </Row> */}
        </Fragment>
    );

};

export default DataConnectionIssue;
