import React from 'react';
import {Row, Col, Typography, PageHeader } from 'antd';
import "./DashboardPage.scss";
import DashboardHierarchySelect from "./DashboardHierarchySelect";
import TimeTransformSelect
  from "../../GlobalComponents/HeaderCrumbs/TimeTransformSelect/TimeTransformSelect";

const {Text} = Typography;
//const { Option } = Select;

const DashboardPageHeader = () => {

    return (
        <PageHeader ghost={false}
            id="dashboard-page-header" className="dashboard-page-header"  style={{marginBottom: "27px", paddingTop:"0px"}}>

            {/* Want to use antd grid's Space comp here, but Space module won't import. Will remove display: flex since it has been declared evil */}
            {/* <Space> */}
                {/* <Row align={"middle"}>
                    <Col span={12}> */}
          {/* </Col>
                    <Col span={12}> */}
            <Row align="middle" justify='start' gutter={[16,0]}>
              <Col>
                <Text className="dashboard-page-header-home">Home</Text>
              </Col>
              <Col><Text className="dashboard-page-header-delimiter">|</Text></Col>
              <Col>
                <DashboardHierarchySelect/>
              </Col>
              <Col><Text className="dashboard-page-header-delimiter">|</Text></Col>
              <Col style={{padding: 0}}>
                <TimeTransformSelect/>
              </Col>
              {/*<Col>*/}
              {/*  <Dropdown*/}
              {/*      overlay={dropdownOverlay}*/}
              {/*      trigger={["click"]}*/}
              {/*      onVisibleChange={(visible) => {toggleDropdownVisible(visible)}}*/}
              {/*  >*/}
              {/*      <Row id="dashboard-page-header-fiscal-week" align="middle" justify="space-between">*/}
              {/*          <Col span={22}>*/}
              {/*              <Text type="secondary">| Fiscal Week {props.fiscalWeek}</Text>*/}
              {/*          </Col>*/}
              {/*          <Col span={2}>*/}
              {/*              <DownOutlined*/}
              {/*                  id="dashboard-page-header-arrow"*/}
              {/*                  className={dropdownVisible ? "arrow-up" : "arrow-down"}*/}
              {/*                  style={{color: "#767676"}}*/}
              {/*              />*/}
              {/*          </Col>*/}
              {/*      </Row>*/}
              {/*  </Dropdown>*/}
              {/*</Col>*/}
            </Row>
                    {/* </Col>
                </Row> */}
            {/* </Space> */}
        </PageHeader>
    );
};

export default DashboardPageHeader;
