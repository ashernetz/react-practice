import React, { useContext, useState, useEffect } from 'react';
import { Row, Col, Layout } from 'antd';
import SkuContext from '../../../context/SkuContext';
import PriceDataServices from '../../../services/PriceDataServices';
import DCSUtil from '../../Utils/DCSUtil';
import "./DashboardPage.scss";
import DashboardPageHeader from './DashboardPageHeader';
// import ProductOverviewWidget from '../../Widgets/ProductOverviewWidget/ProductOverviewWidget';
import ZoneOverviewWidget from '../../Widgets/ZoneOverviewWidget/ZoneOverviewWidget';
import HealthWidget from '../../Widgets/HealthWidget/HealthWidget';
import { getHierarchy } from './DashboardPageUtil';
import PerformanceWidget from "../../Widgets/PerformanceWidget/PerformanceWidget";
import DashboardServices from "../../../services/DashboardServices";
import PriceChangeWidget from "../../Widgets/PriceChangeWidget/PriceChangeWidget";
import SkuGroupsWidget from "../../Widgets/SkuGroupsWidget/SkuGroupsWidget";
import CPIWidget from "../../Widgets/CPIWidget/CPIWidget";
import { isErroredResponse } from '../../Utils/CommonUtil';
import ProductOverviewAndPerformanceWidgets from '../../Widgets/ProductOverviewAndPerformanceWidgets/ProductOverviewAndPerformanceWidgets';

const { Content } = Layout;

const DashboardPageObsolete = (props) => {
    const context = useContext(SkuContext);
    const [widgets, setWidgets] = useState([]);
    const [performersData, setPerformersData] = useState({ data: {}, is5xx: false });
    const [zoneOverviewData, setZoneOverviewData] = useState({ data: "", is5xx: false });
    const [hierarchyDetails, setHierarchyDetails] = useState({});
    const [healthOverviewData, setHealthOverviewData] = useState({ data: "", is5xx: false });
    const [performanceData, setPerformanceData] = useState({ data: "", is5xx: false });

    useEffect(() => {
        if (Object.keys(hierarchyDetails).length > 0) {
            setHealthOverviewData({ is5xx: false, data: "" });
            DashboardServices.getHealthOverviewDetails(hierarchyDetails, props.user.userId).then(response => {
                setHealthOverviewData({ is5xx: false, data: response.data });
            }).catch(error => {
                setHealthOverviewData({ data: {}, is5xx: isErroredResponse(error) });
                console.log(error);
            });

            setPerformanceData({ is5xx: false, data: "" });
            DashboardServices.getFinancialPerformanceDetails(hierarchyDetails, props.user.userId).then(response => {
                setPerformanceData({ is5xx: false, data: response.data });

            }).catch(error => {
                setPerformanceData({ data: [], is5xx: isErroredResponse(error) });
                console.log(error);
            })
        }
    }, [hierarchyDetails,context.timeTransformType.split("|")[0]]);

    useEffect(() => {
        if (Object.keys(hierarchyDetails).length > 0) {
            setZoneOverviewData({ is5xx: false, data: "" });
            DashboardServices.getZoneOverviewDetails(hierarchyDetails, props.user.userId).then(response => {
                setZoneOverviewData({ is5xx: false, data: response.data });
            }).catch(err => {
                setZoneOverviewData({ data: {}, is5xx: isErroredResponse(err) });
                console.log(err)
            }).finally(() => {
                // if performersData context.updateShowDimmer(false);
            })
        }
        // Maybe use axios.all() with .spread()
    }, [hierarchyDetails, context.timeTransformType]);

    useEffect(() => {
        let enabledWidgets = ["ProductOverview", "OffsideProducts", "Health", "GroupsOverview", "Performance", "ZoneOverview", "PriceChangeRequests"]; // return value of API call or whatever to decide what widgets to show for the user
        setWidgets(enabledWidgets);
    }, []);

    useEffect(() => {
        if (context.selectedDCS) {
            setHierarchyDetails(getHierarchy(context.selectedDCS, context.subDeptDataMap, context.dcsDataMap));
        }
    }, [context.selectedDCS]);

    useEffect(() => {
        if (Object.keys(hierarchyDetails).length > 0) {
            let dcsKey = context.selectedDCS.split("-");
            let subClassList = DCSUtil.getSubclassesList(context.dcsDataMap, context.selectedDCS);
            setPerformersData({ is5xx: false, data: {} });
            PriceDataServices.readPerformersDCSDetails(dcsKey[0], dcsKey[1], dcsKey[2], subClassList, props.user.userId).then(response => {
                setPerformersData({ is5xx: false, data: response.data });

                // setFiscalWeek(response.data.fiscalWeek.replace("FW", ""));
            }).catch(err => {
                setPerformersData({ data: { "topPerformersSalesMap": {}, "bottomPerformersSalesMap": {}, "topPerformersUnitsMap": {}, "bottomPerformersUnitsMap": {}, "disasterStoreMap": {} }, is5xx: isErroredResponse });
                console.log(err)
                // setPerformersData({});
            }).finally(() => {
                /**Will enable when needed globally**/
            });
            let favSkuMap = { ...context.favSkuMap };
            if (favSkuMap && Object.keys(favSkuMap).length > 0) {
                let skuNumbers = Object.keys(favSkuMap);
                PriceDataServices.fetchPerformanceDataForSkus(Object.keys(favSkuMap),
                    props.user.userId).then(response => {
                        if (response.status === 200) {
                            let skuCompMap = response.data;
                            if (skuNumbers.length > 0) {
                                skuNumbers.forEach(sku => {
                                    let isPresent = skuCompMap.hasOwnProperty(sku)
                                    favSkuMap[sku].netUnitsComp = isPresent ? skuCompMap[sku].netUnitsComp : 0;
                                    favSkuMap[sku].netSalesComp = isPresent ? skuCompMap[sku].netSalesComp : 0;
                                    favSkuMap[sku].rawSales = isPresent ? skuCompMap[sku].rawSales : 0;
                                    favSkuMap[sku].rawUnits = isPresent ? skuCompMap[sku].rawUnits : 0;
                                });
                            }
                            context.updateStateFields({ favSkuMap, skuCompMap });
                        }
                    }).catch(resp => {
                        console.log(resp);
                    });
            }
        }
    }, [hierarchyDetails, context.timeTransformType]);

    const spanAppender = (i, j, k, l, m, n) => { return { xs: i, sm: j, md: k, lg: l, xl: m, xxl: n } };

    const getAllSkusforView = (metric) => {
        let dcsKey = context.selectedDCS.split("-");
        let selectedOption = metric;
        if (metric === 'Favorites') {
            selectedOption = "FAV";
        }
        let data = {
            classNumber: dcsKey[1],
            department: dcsKey[0],
            searchType: selectedOption,
            subClassNumber: dcsKey[2],
            userId: props.user.userId,

        };

        props.diverseMultiSearch(data, 'ENTERED_MULTIPLE_ITEM_IN_' + selectedOption, context.updateShowDimmer);

    };

    function setupWidgetGrid() {
        let grid = [];
        
        // Keeping this for being able to revert back to how this widget was before stacking it with MyPerformance
        //
        // if (widgets.includes("ProductOverview")) {
        //     grid.push({
        //         span: 7, xs: { span: 24, order: 1 }, sm: { span: 24, order: 1 }, md: { span: 24, order: 1 }, lg: { span: 12, order: 1 }, xl: { span: 8, order: 1 }, xxl: { span: 8, order: 1 }, component:
        //             <ProductOverviewWidget skuSearch={props.skuSearch} performersData={performersData.data} is5xx={performersData.is5xx} onClickLink={getAllSkusforView} />
        //     })
        // }
        // 

        if (widgets.includes("ProductOverview")) {
            grid.push({
                span: 7, xs: { span: 24, order: 1 }, sm: { span: 24, order: 1 }, md: { span: 24, order: 1 }, lg: { span: 12, order: 1 }, xl: { span: 8, order: 1 }, xxl: { span: 8, order: 1 }, component:
                    <ProductOverviewAndPerformanceWidgets skuSearch={props.skuSearch} performersData={performersData.data} is5xx={performersData.is5xx} onClickLink={getAllSkusforView} config={props.config} />
            })
        }
        if (widgets.includes("OffsideProducts")) {
            grid.push({
                span: 17, xs: { span: 24, order: 2 }, sm: { span: 24, order: 2 }, md: { span: 24, order: 2 }, lg: { span: 12, order: 2 }, xl: { span: 9, order: 2 }, xxl: { span: 9, order: 2 }, component:
                    <CPIWidget
                        skuSearch={props.skuSearch}
                        userId={props.user.userId}
                        hierarchyDetails={hierarchyDetails}
                        favouriteSku={context.profileData.favouriteSku}
                        favSkuMap={context.favSkuMap}
                        competitorDataUrl={props.config.competitorDataUrl}
                        selectedDCS={context.selectedDCS}
                        diverseMultiSearch = {(data)=>props.diverseMultiSearch(data, "DCS_SEARCH_FROM_CPI_WIDGET", context.updateShowDimmer)}
                    />
            })
        }
        if (widgets.includes("Health")) {
            grid.push({
                span: 9, xs: { span: 24, order: 3 }, sm: { span: 24, order: 3 }, md: { span: 24, order: 3 }, lg: { span: 12, order: 3 }, xl: { span: 7, order: 3 }, xxl: { span: 7, order: 3 }, component:
                    <HealthWidget
                        fiscalWeek={context.lastFiscalWeek ? "FW" + context.lastFiscalWeek : "FW"}
                        hierarchyDetails={hierarchyDetails}
                        is5xx={healthOverviewData.is5xx}
                        healthOverviewData={healthOverviewData.data} />
            })
        }
        if (widgets.includes("GroupsOverview")) {
            grid.push({
                span: 15, xs: { span: 24, order: 4 }, sm: { span: 24, order: 4 }, md: { span: 24, order: 4 }, lg: { span: 12, order: 4 }, xl: { span: 12, order: 4 }, xxl: { span: 12, order: 4 }, component:

                    <SkuGroupsWidget userId={props.user.userId} multiItemInquiry={props.multiItemInquiry} selectedDCS={context.selectedDCS} newGroupButtonEnabled={props.config.newGroupButtonEnabled} timeTransformType ={context.timeTransformType} />

            })
        }
        if (widgets.includes("Performance")) {
            grid.push({
                span: 15, xs: { span: 24, order: 5 }, sm: { span: 24, order: 5 }, md: { span: 24, order: 5 }, lg: { span: 12, order: 5 }, xl: { span: 12, order: 5 }, xxl: { span: 12, order: 5 }, component:
                    <PerformanceWidget performanceData={performanceData.data} is5xx={performanceData.is5xx} hierarchyDetails={hierarchyDetails} />
            })
        }
        if (widgets.includes("ZoneOverview")) {
            grid.push({
                span: 15, xs: { span: 24, order: 6 }, sm: { span: 24, order: 6 }, md: { span: 24, order: 6 }, lg: { span: 12, order: 6 }, xl: { span: 12, order: 6 }, xxl: { span: 12, order: 6 }, component:
                    <ZoneOverviewWidget
                        apiKey={props.config.apiKey}
                        zoneOverviewData={zoneOverviewData.data}
                        is5xx={zoneOverviewData.is5xx}
                        hierarchyDetails={hierarchyDetails}
                        healthOverviewData={healthOverviewData.data}
                        userRestrictionStatus={"allowed"}
                        selectedDCS={context.selectedDCS}
                        fiscalWeek={context.lastFiscalWeek ? "FW" + context.lastFiscalWeek : "FW"}

                    />
            })
        }
        if (widgets.includes("PriceChangeRequests")) {
            grid.push({
                span: 15, xs: { span: 24, order: 7 }, sm: { span: 24, order: 7 }, md: { span: 24, order: 7 }, lg: { span: 12, order: 7 }, xl: { span: 12, order: 7 }, xxl: { span: 12, order: 7 }, component:
                    <PriceChangeWidget
                        hierarchyDetails={hierarchyDetails}
                        stockProductUrl={props.config.stockProductUrl}
                        selectedDCS={context.selectedDCS}
                    />
            })
        }
        // if (widgets.includes("CPI")) {
        //     grid.push({
        //         span: 15, xs: { span: 24, order: 3 }, sm: { span: 24, order: 3 }, md: { span: 24, order: 3 }, lg: { span: 12, order: 3 }, xl: { span: 12, order: 3 }, xxl: { span: 12, order: 3 }, component:
        //             <CPIWidget
        //                 skuSearch={props.skuSearch}
        //                 userId={props.user.userId}
        //                 hierarchyDetails={hierarchyDetails}
        //                 favouriteSku={context.profileData.favouriteSku}
        //                 favSkuMap={context.favSkuMap}
        //                 competitorDataUrl={props.config.competitorDataUrl}
        //                 selectedDCS={context.selectedDCS}
        //                 cpiData={cpiData}
        //             />
        //     })
        // }


        // If we want dynamic Zone Overview width (for when Product Overview is not available)
        // span: enabledWidgets["ProductOverview"] ? 18 : 24

        // Add later
        // Class Performance, Class Health
        // Match Coverage, CPI Health
        // grid.push({span: 17, component: <Card bodyStyle={{padding: 0}}><WidgetHeader title="Performance" label={selectedZone} /></Card>})
        // grid.push({span: 7, component: <Card bodyStyle={{padding: 0}}><WidgetHeader title="Class Health" /></Card>})
        // grid.push({span: 8, component: <Card bodyStyle={{padding: 0}}><WidgetHeader title="Match Coverage" /></Card>})
        // grid.push({span: 10, component: <Card bodyStyle={{padding: 0}}><WidgetHeader title="CPI Health" /></Card>})

        return grid;
    }

    return (
        <Layout id="dashboard-page">
            <DashboardPageHeader />
            <Content id="dashboard-page-content">
                <Row className="dashFlex" gutter={[24, 24]}>
                    {
                        setupWidgetGrid().map((widget, index) => {
                            return <Col key={index} {...spanAppender(widget.xs, widget.sm, widget.md, widget.lg, widget.xl, widget.xxl)} >{widget.component}</Col>
                        })
                    }
                </Row>
            </Content>
        </Layout>
    );
};

export default DashboardPageObsolete;
