import React, { useContext, useState, useEffect } from 'react';
import { Row, Col, Layout } from 'antd';
import SkuContext from '../../../context/SkuContext';
import PriceDataServices from '../../../services/PriceDataServices';
import DCSUtil from '../../Utils/DCSUtil';
import "./DashboardPage.scss";
import DashboardPageHeader from './DashboardPageHeader';
import ProductOverviewWidget from '../../Widgets/ProductOverviewWidget/ProductOverviewWidget';
import { getHierarchy } from './DashboardPageUtil';
import PriceChangeWidget from "../../Widgets/PriceChangeWidget/PriceChangeWidget";
import SkuGroupsWidget from "../../Widgets/SkuGroupsWidget/SkuGroupsWidget";
import CPIWidget from "../../Widgets/CPIWidget/CPIWidget";
import { isErroredResponse } from '../../Utils/CommonUtil';
import SkuGroupService from "../../../services/SkuGroupService";
import NewSuperWidget from "../../Widgets/SuperWidget/NewSuperWidget";
import DiscountsWidget from "../../Widgets/DiscountsWidget/DiscountsWidget";

const { Content } = Layout;

const DashboardPage = (props) => {
    const context = useContext(SkuContext);
    const [widgets, setWidgets] = useState([]);
    const [performersData, setPerformersData] = useState({ data: {}, is5xx: false });
    const [hierarchyDetails, setHierarchyDetails] = useState({});
    const [skuGroupsData, setSkuGroupsData] = useState({});
    const [loadingSkuGroupData, toggleLoadingSkuGroupData] = useState(true);
    const [skuGroupAnchors, setSkuGroupAnchors] = useState();

    useEffect(() => {
        let enabledWidgets = ["ProductOverview", "OffsideProducts", "Health", "Performance", "ZoneOverview", "PriceChangeRequests", "Super","Discounts"]; // return value of API call or whatever to decide what widgets to show for the user
        setWidgets(enabledWidgets);
    }, []);

    useEffect(() => {
        if (context.selectedDCS) {
            setHierarchyDetails(getHierarchy(context.selectedDCS, context.subDeptDataMap, context.dcsDataMap));
        }
    }, [context.selectedDCS]);

    useEffect(() => {
        if (Object.keys(hierarchyDetails).length > 0) {
            let dcsKey = context.selectedDCS.split("-");
            let subClassList = DCSUtil.getSubclassesList(context.dcsDataMap, context.selectedDCS);
            setPerformersData({ is5xx: false, data: {} });
            PriceDataServices.readPerformersDCSDetails(dcsKey[0], dcsKey[1], dcsKey[2], subClassList, props.user.userId).then(response => {
                setPerformersData({ is5xx: false, data: response.data });
            }).catch(err => {
                setPerformersData({ data: { "topPerformersSalesMap": {}, "bottomPerformersSalesMap": {}, "topPerformersUnitsMap": {}, "bottomPerformersUnitsMap": {}, "disasterStoreMap": {} }, is5xx: isErroredResponse });
                console.log(err)
            }).finally(() => {
                /**Will enable when needed globally**/
            });
            let favSkuMap = { ...context.favSkuMap };
            if (favSkuMap && Object.keys(favSkuMap).length > 0) {
                let skuNumbers = Object.keys(favSkuMap);
                PriceDataServices.fetchPerformanceDataForSkus(Object.keys(favSkuMap),
                    props.user.userId).then(response => {
                        if (response.status === 200) {
                            let skuCompMap = response.data;
                            if (skuNumbers.length > 0) {
                                skuNumbers.forEach(sku => {
                                    let isPresent = skuCompMap.hasOwnProperty(sku)
                                    favSkuMap[sku].netUnitsComp = isPresent ? skuCompMap[sku].netUnitsComp : 0;
                                    favSkuMap[sku].netSalesComp = isPresent ? skuCompMap[sku].netSalesComp : 0;
                                    favSkuMap[sku].rawSales = isPresent ? skuCompMap[sku].rawSales : 0;
                                    favSkuMap[sku].rawUnits = isPresent ? skuCompMap[sku].rawUnits : 0;
                                });
                            }
                            context.updateStateFields({ favSkuMap, skuCompMap });
                        }
                    }).catch(resp => {
                        console.log(resp);
                    });
            }
        }
    }, [hierarchyDetails, context.timeTransformType]);

    useEffect(() => {
        if(context.selectedDCS){
            toggleLoadingSkuGroupData(true);
            setSkuGroupsData({})
            SkuGroupService.getSkuGroups(undefined, context.selectedDCS)
                .then((response) => {
                    if (response && response.data) {
                        let skuGroups = {};
                        let skuGroupNumbers ={};
                        response.data.forEach(k => {
                            k.title = k.skuGroupName;
                            k.name = k.skuGroupName;
                            k.key = k.skuGroupId;
                            skuGroups[k.skuGroupId] = k;
                            skuGroupNumbers[k.skuGroupId] = k.skuNumbers;
                        });
                        setSkuGroupsData(skuGroups);
                        getSkuGroupAur(skuGroupNumbers);
                        getAnchorSkusForGroups(skuGroups, skuGroupNumbers);
                    }
                }).catch((e) => {
                console.log("Error with SkuGroupService.getSkuGroups:", e)
            }).finally(() => {
                toggleLoadingSkuGroupData(false);
            })
        }
    }, [context.selectedDCS]);

    useEffect(()=>{
        if(!loadingSkuGroupData && Object.keys(skuGroupsData).length>0){
            getSkuGroupsPerformanceData(Object.values(skuGroupsData).reduce((total,current)=>{total[current.skuGroupId] = current.skuNumbers;return total},{}));
        }
    },[context.timeTransformType,loadingSkuGroupData]);



    const getAnchorSkusForGroups = (skuGroups, skuGroupNumbers) => {
        SkuGroupService.getAnchorSkusForGroups(skuGroupNumbers).then(response => {
            if (response && response.data) {
                let anchors = new Map();
                Object.keys(response.data).forEach(index => {
                    let skuGroupId = skuGroups[index].key
                    let anchorSku = getAnchorFromBestLineStructure(response.data[index])
                    anchors.set(skuGroupId, anchorSku)
                })
                setSkuGroupAnchors(anchors)
            }
        }).catch(e => {
            console.log("Error with SkuGroupService.getAnchorSkusForGroups", e)
        })
    }

    function getAnchorFromBestLineStructure(lineStructures) {
        let recommendedLineStructure = {}
        if (lineStructures && lineStructures.length) {
            recommendedLineStructure = lineStructures.reduce((prev, current) => (
                (((current.anchorSku) && (prev.skuCount && current.skuCount)) && (prev.skuCount > current.skuCount)) 
            ) ? prev : current)
        }
        return recommendedLineStructure["anchorSku"]
    }

    const getSkuGroupsPerformanceData = (skuGroupNumbers)=> {
        SkuGroupService.getSkuGroupPerformanceData(skuGroupNumbers, props.user.userId, false).then(response => {
            if(response && response.data){
                setSkuGroupsData(k=> {
                    let finalSkuGroupObject = {};
                    Object.keys(k).forEach((skuGroupId) => {
                        let {totalCompPercentage,totalUnitsPercentage,totalThisYearSales,totalThisYearUnits} = response.data[skuGroupId]||{};
                        finalSkuGroupObject[skuGroupId]={...k[skuGroupId],totalCompPercentage,totalUnitsPercentage,totalThisYearSales,totalThisYearUnits};
                    });
                    return finalSkuGroupObject;
                });
            }
        }).catch((e) => {
            console.log("Error with SkuGroupService.getSkuGroupPerformanceData", e)
        })
    }

    const updateSkuGroupAurResponse = (val) => {
        let input = {...(val||{})};
        input["aur_PERCENT_FW"] = input["aur_FW_percentage"]; delete input["aur_FW_percentage"];
        input["aur_PERCENT_R3"] = input["aur_R3_percentage"]; delete input["aur_R3_percentage"];
        input["aur_PERCENT_R4"] = input["aur_R4_percentage"]; delete input["aur_R4_percentage"];
        input["aur_PERCENT_QTD"] = input["aur_QTD_percentage"]; delete input["aur_QTD_percentage"];
        input["aur_PERCENT_YTD"] = input["aur_YTD_percentage"]; delete input["aur_YTD_percentage"];
        input["aur_PERCENT_R12"] = input["aur_R12_percentage"]; delete input["aur_R12_percentage"];
        return input;
    }
    const getSkuGroupAur = (skuGroupDataMap) => {
        SkuGroupService.getAurBySkuGroupIdsAndSkus(skuGroupDataMap, props.userId, false).then((aurResponse) => {
            if(aurResponse && aurResponse.data){
                setSkuGroupsData(k => {
                    let finalSkuGroupObject = {};
                    Object.keys(k).forEach((skuGroupId) => {
                        finalSkuGroupObject[skuGroupId] = {...(updateSkuGroupAurResponse(aurResponse.data[skuGroupId]||{})), ...k[skuGroupId]};
                    });
                    return finalSkuGroupObject;
                });
            }
        }).catch(e => {
            console.log("Error with SkuGroupService.getAurBySkuGroupIdsAndSkus", e)
        })
    }

    const spanAppender = (i, j, k, l, m, n) => { return { xs: i, sm: j, md: k, lg: l, xl: m, xxl: n } };

    const getAllSkusforView = (metric) => {
        let dcsKey = context.selectedDCS.split("-");
        let selectedOption = metric;
        if (metric === 'Favorites') {
            selectedOption = "FAV";
        }
        let data = {
            classNumber: dcsKey[1],
            department: dcsKey[0],
            searchType: selectedOption,
            subClassNumber: dcsKey[2],
            userId: props.user.userId,

        };

        props.diverseMultiSearch(data, 'ENTERED_MULTIPLE_ITEM_IN_' + selectedOption, context.updateShowDimmer);

    };

    function setupWidgetGrid() {
        let grid = [];
        
        
        if (widgets.includes("Super")) {
            grid.push({
                span: 24, xs: { span: 24, order: 1 }, sm: { span: 24, order: 1 }, md: { span: 24, order: 1 }, lg: { span: 24, order: 1 }, xl: { span: 24, order: 1 }, xxl: { span: 24, order: 1 }, component:
                    <NewSuperWidget
                        userId={props.user.userId}
                        dcsData={context.dcsDataMap}
                        selectedDCS={context.selectedDCS}
                        hierarchyDetails={hierarchyDetails}
                        multiItemInquiry={props.multiItemInquiry}
                        diverseMultiSearch = {(data)=>props.diverseMultiSearch(data, "DCS_SEARCH_FROM_CPI_WIDGET", context.updateShowDimmer)}
                        skuGroupsData = {skuGroupsData}
                        loadingSkuGroupData ={loadingSkuGroupData}
                        skuGroupAnchors={skuGroupAnchors}
                    />
            })
        }

        if (widgets.includes("Discounts")) {
            grid.push({
                span: 24, xs: { span: 24, order: 1 }, sm: { span: 24, order: 1 }, md: { span: 24, order: 1 }, lg: { span: 24, order: 1 }, xl: { span: 24, order: 1 }, xxl: { span: 24, order: 1 }, component:
                    <DiscountsWidget
                        hierarchyDetails={hierarchyDetails}
                        discountPromoEnable = {props.config.discountPromoEnable}
                    />
            })
        }

        if (widgets.includes("ProductOverview")) {
            grid.push({
                span: 7, xs: { span: 24, order: 1 }, sm: { span: 24, order: 1 }, md: { span: 24, order: 1 }, lg: { span: 8, order: 1 }, xl: { span: 8, order: 1 }, xxl: { span: 8, order: 1 }, component:
                    <ProductOverviewWidget skuSearch={props.skuSearch} performersData={performersData.data} is5xx={performersData.is5xx} onClickLink={getAllSkusforView} />            })
        }

        if (widgets.includes("OffsideProducts")) {
            grid.push({
                span: 16, xs: { span: 24, order: 2 }, sm: { span: 24, order: 2 }, md: { span: 24, order: 2 }, lg: { span: 16, order: 2 }, xl: { span: 16, order: 2 }, xxl: { span: 16, order: 2 }, component:
                    <CPIWidget
                        skuSearch={props.skuSearch}
                        userId={props.user.userId}
                        hierarchyDetails={hierarchyDetails}
                        favouriteSku={context.profileData.favouriteSku}
                        favSkuMap={context.favSkuMap}
                        competitorDataUrl={props.config.competitorDataUrl}
                        selectedDCS={context.selectedDCS}
                        diverseMultiSearch = {(data)=>props.diverseMultiSearch(data, "DCS_SEARCH_FROM_CPI_WIDGET", context.updateShowDimmer)}
                    />
            })
        }

   
        if (widgets.includes("GroupsOverview")) {
            grid.push({
                span: 15, xs: { span: 24, order: 4 }, sm: { span: 24, order: 4 }, md: { span: 24, order: 4 }, lg: { span: 12, order: 4 }, xl: { span: 12, order: 4 }, xxl: { span: 12, order: 4 }, component:

                    <SkuGroupsWidget userId={props.user.userId} multiItemInquiry={props.multiItemInquiry} selectedDCS={context.selectedDCS} newGroupButtonEnabled={props.config.newGroupButtonEnabled} timeTransformType ={context.timeTransformType}
                                     skuGroupsData = {skuGroupsData}
                                     loadingSkuGroupData ={loadingSkuGroupData}
                    />

            })
        }
        if (widgets.includes("PriceChangeRequests")) {
            grid.push({
                span: 15, xs: { span: 24, order: 7 }, sm: { span: 24, order: 7 }, md: { span: 24, order: 7 }, lg: { span: 12, order: 7 }, xl: { span: 12, order: 7 }, xxl: { span: 12, order: 7 }, component:
                    <PriceChangeWidget
                        hierarchyDetails={hierarchyDetails}
                        stockProductUrl={props.config.stockProductUrl}
                        selectedDCS={context.selectedDCS}
                    />
            })
        }

   
        return grid;
    }

    return (
        <Layout id="dashboard-page">
            <DashboardPageHeader />
            <Content id="dashboard-page-content">
                <Row className="dashFlex" gutter={[24, 24]}>
                    {
                        setupWidgetGrid().map((widget, index) => {
                            return <Col key={index} {...spanAppender(widget.xs, widget.sm, widget.md, widget.lg, widget.xl, widget.xxl)} >{widget.component}</Col>
                        })
                    }
                </Row>
            </Content>
        </Layout>
    );
};

export default DashboardPage;
