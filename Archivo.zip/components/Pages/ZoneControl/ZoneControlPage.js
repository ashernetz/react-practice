import React, {Component} from 'react';
import {Col, Layout, Row} from 'antd';
import './ZoneControlPage.scss';
import ZoneBarLayout
  from "../../ZoneControlComponents/ZoneBarLayout/ZoneBarLayout";
import CurrentZonesDrawer
  from "../../ZoneControlComponents/CurrentZonesDrawer/CurrentZonesDrawer";
import ZoneContext from "../../../context/ZoneContext";
import ZoneMapViewWrapper
  from "../../ZoneControlComponents/ZoneMapView/ZoneMapViewWrapper";

const {Content} = Layout;

export default class ZoneControlPage extends Component {

  static contextType = ZoneContext;

  state = {hoveredTraitId: 0};

  componentDidMount() {
    this.context.resetZoneState();
  }

  updateHoveredTrait=(hoveredTraitId) =>{
    this.setState({hoveredTraitId});
  };
  render() {

    return (
        <Content className="zone-page-content">
          <ZoneBarLayout/>
          <Row>
            <Col>
                <CurrentZonesDrawer updateHoveredTrait={this.updateHoveredTrait}/>
            </Col>
            <Col 
                 style={{width: 'calc(100vw - 560px)', marginLeft: '560px'}}>
              <ZoneMapViewWrapper hoveredTraitId = {this.state.hoveredTraitId} apiKey={this.props.config.apiKey}/>
            </Col>
          </Row>
        </Content>);

  }
}

