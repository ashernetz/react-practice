import React from 'react';
import { Row, Col, Typography, Modal } from 'antd';
import { RightOutlined } from '@ant-design/icons';
import "./MultipleVendorDetectedModal.scss";
import multiSkuBoxes from "../../../../images/MultiSKUBoxes.svg";
//import {trackEvent} from '../../../Utils/mixpanel';

const { Text } = Typography;

const VendorCard = (props) => {
  return(
      <Row  align="middle" className="vendor-card-size">
        <Col span={6}>
          <img
              className="vendor-card-sku-img"
              src={multiSkuBoxes}
              alt="MultiSKUBoxes"
          />
        </Col>
        <Col span={16}>
          <Row gutter={[8, 0]}>
            <Col><Text type="secondary" className="multiple-vendor">{props.vendorType}</Text></Col>
            <Col><Text type="secondary" className="mvendor-sku-number">{props.vendorNumber}</Text></Col>
          </Row>
          <Row>
            <Col span={24}>
              <Text className="mvendor-name">{props.vendorName}</Text>
            </Col>
          </Row>
        </Col>
        <Col span={2}>
          <Row justify="space-bewtween" align="middle"><Col> <RightOutlined className="mvendor-right-arrow" /></Col></Row>
        </Col>
      </Row>
  );
}

const MultipleVendorDetectedModal = (props) => {


  return(
      <Modal
          title="Multiple Vendor Detected"
          centered
          open={props.isOpen}
          onCancel={props.onClose}
          destroyOnClose={true}
          className="omsid-detected-modal"
          onOk={props.onClose}
          okText="Cancel"
          okButtonProps={{ size: 'large' }}
          cancelButtonProps={{ style: { display: 'none' } }}
      >
        <Row className="vendor-modal-content" gutter={[0, 16]}>
          <Row justify="start">
            <Col span={24}>
              <Text>Please select the vendor you would like to view from the options below:</Text>
            </Col>
          </Row>
          {props.multiVendorList.map((data,key)=>
              (<Row key={key} style={{cursor:"pointer"}} justify="center"
                    onClick = {()=>{
                      props.onVendorCardClick(data.vendorNumber,data.vendorName);
                      props.onClose()}}>
            <Col span={24}>
              <VendorCard
                  {...data}
              />
            </Col>
          </Row>))}
        </Row>
      </Modal>
  );
}
export default MultipleVendorDetectedModal;
