import React from 'react';
import {Row, Col, Typography} from 'antd';
import OnlineMultiSkuTable from "../../../ProductSearchComponents/OnlineMultiSkuTable";
import "./MultiSkuPage.scss"

//const { TabPane } = Tabs;
const {Text} = Typography;
const MultiSkuOnlineTabs = (props) => {
    return (
        <>
            <Row style={{marginBottom:"16px"}}> <Col> <Text className="multi-sku-header-label">Overview of Online SKUs</Text></Col></Row>
            <Row style={{marginBottom:"50px"}}>
                <Col span={24}>
                    {/*<Tabs*/}
                    {/*    className="multi-sku-tabs"*/}
                    {/*    size="large"*/}
                    {/*    defaultActiveKey="1"*/}
                    {/*    tabBarGutter={[32, 8]}>*/}
                    {/*    <TabPane tab="Online SKUs" key="1">*/}
                                <OnlineMultiSkuTable
                                    key={props.key}
                                    onlineMultiSkuData={props.onlineMultiSkuData}
                                    compsAndUnitsFormatter={props.compsAndUnitsFormatter}
                                    getOnlineRetailTimelineData={props.getOnlineRetailTimelineData}
                                    skuTimelineMap={props.skuTimelineMap}
                                    lastKey = {props.lastKey}
                                    getAllSkusforDCSView = {props.getAllSkusforDCSView}
                                    onNewPageRender = {props.onNewPageRender}
                                />
                    {/*    </TabPane>*/}
                    {/*</Tabs>*/}
                </Col>
            </Row>
        </>
    );
};

export  default MultiSkuOnlineTabs;