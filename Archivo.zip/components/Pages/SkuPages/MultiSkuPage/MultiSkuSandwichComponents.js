import React, {Fragment} from 'react';
import {Col, Row} from "antd";
import MultiSkuDetailHeader from "./MultiSkuDetailHeader";
import MultiSkuCards from "../MultiSkuCards/MultiSkuCards";
import "./MultiSkuPage.scss"
import MultiSkuPageFooter from "./MultiSkuPageFooter";


const MultiSkuSandwichComponents = (props) => {

    return (
        <Fragment>
            <Row id="multi-sku-page-header" align="middle" justify="space-between" >
                <MultiSkuDetailHeader data={props}/>
            </Row>
            <Row gutter={[0, 56]} className="multi-sku-card-x-scroll">
                <Col span={24} className="sandwich-row-content">
                    <MultiSkuCards data={props}/>
                </Col>
            </Row>
            {props.children}
            <MultiSkuPageFooter data={props}/>
        </Fragment>
    );
};

export default MultiSkuSandwichComponents;
