import React  from 'react';
import {Row, Col,Typography} from 'antd';
import "./MultiSkuPage.scss"
import InStoreMultiSkuTable from "../../../ProductSearchComponents/InStoreMultiSkuTable";

// const { TabPane } = Tabs;
const {Text} = Typography;

const MultiSkuInstoreTabs = (props) => {
    return (
        <>
        <Row style={{marginBottom:"16px"}}> <Col> <Text className="multi-sku-header-label">Overview of Store SKUs</Text></Col></Row>
        <Row style={{marginBottom:"50px"}}>
            <Col span={24}>
                {/*<Tabs*/}
                {/*    className="multi-sku-tabs"*/}
                {/*    size="large"*/}
                {/*    defaultActiveKey="1"*/}
                {/*    tabBarGutter={[32, 8]}>*/}
                {/*    <TabPane tab="Overview of Store SKUs" key="1">*/}
                        <InStoreMultiSkuTable
                            compsAndUnitsFormatter = {props.compsAndUnitsFormatter}
                            inStoreSkuRowData = {props.inStoreSkuRowData}
                            messageType = {props.messageType}
                            key = {props.key}
                            lastKey = {props.lastKey}
                            onNewPageRender = {props.onNewPageRender}
                            getAllSkusforDCSView = {props.getAllSkusforDCSView}
                            />
                {/*    </TabPane>*/}
                {/*</Tabs>*/}
            </Col>
        </Row>
        </>
    );
};


export  default MultiSkuInstoreTabs;