import React, {useState} from 'react';
import {Button, Col, Layout, Row} from "antd";
import "./MultiSkuPage.scss";
import {trackEvent} from "../../../Utils/mixpanel";
import {Link} from "react-router-dom";
import EditSkuGroupModal from "../SkuGroup/EditSkuGroupModal";

const {Footer} = Layout;

const SKUGroupEdit = ({groupName, skuGroupData, userId, onSkuGroupUpdate, onSkuGroupDelete}) =>{
    const [modalOpen,setModalOpen] = useState(false);
    return(<>
        <Button block type="primary" ghost='true' size='large' onClick={()=>{setModalOpen(true);trackEvent("CLICKED_EDIT_GROP_IN_MULTI_SKU_PAGE",{groupName})}}  >Edit Group </Button>
        {modalOpen && <EditSkuGroupModal
          skuGroupData={skuGroupData}
          userId={userId}
          onClose={() => setModalOpen(false)}
          onSkuGroupUpdate={onSkuGroupUpdate}
          onSkuGroupDelete={onSkuGroupDelete}
        />}

    </>);
};

const MultiSkuPageFooter = (props) => {

    return (<><Footer id="multi-sku-page-footer">
        <Row gutter={[16,0]} justify="end">
            {(!props.data.showOnline && props.data.skuGroupData) &&
              <Col><SKUGroupEdit groupName={props.data.skuGroupData.groupName}
                                 skuGroupData={props.data.skuGroupData}
                                 onSkuGroupUpdate={props.data.onSkuGroupUpdate}
                                 onSkuGroupDelete={props.data.onSkuGroupDelete}
                                 userId = {props.data.userId}/></Col>}
            <Col>
                <Link to={{
                    pathname: "/EditPrices",
                    state: {
                        skus: props.data.inStoreMultiSkuData && props.data.inStoreMultiSkuData.skuRetailList && props.data.inStoreMultiSkuData.skuRetailList.map(obj => obj.skuNumber),
                        zoneMultiplierGroupId: props.data.skuGroupData && props.data.skuGroupData.zoneGroupMultiplierId,
                        skuGroupName: props.data.skuGroupData && props.data.skuGroupData.groupName,
                        skuGroupId: props.data.skuGroupData && props.data.skuGroupData.skuGroupId,
                    }
                }}>
                    <Button block disabled={!props.data.userAccessEditPrices} type="primary" ghost='true' size='large'>
                        Edit Prices
                    </Button>
                </Link>
            </Col>
        </Row>
    </Footer></>)
}

export default MultiSkuPageFooter;