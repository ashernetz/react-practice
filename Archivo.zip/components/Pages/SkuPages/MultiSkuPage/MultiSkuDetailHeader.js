import React from 'react';
import {Button, Row, Col, Radio, Typography, Space, Image} from 'antd';
import { FilterOutlined } from '@ant-design/icons';
import "./MultiSkuPage.scss";
import {UXSpin} from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import {trackEvent} from '../../../Utils/mixpanel';
import MultiSkuFilterHelper from "../MultiSkuFilter/MultiSkuFilterHelper";

const { Text } = Typography;

const MultiSkuDetailHeader =(props) => {
    let onlineSkuCount = props.data.onlineSkuCount ? props.data.onlineSkuCount.length : 0;
    let inStoreSkuCount = props.data.inStoreSkuCount ? props.data.inStoreSkuCount.length : 0;
    let headerData = props.data.headerData;

    return(
        <>
            <Row gutter={[16,0]}>
                <Col>
                   <Image src={headerData.icon} alt="Image" height="80px" width="80px"/>
                </Col>
                <Col>
                    <Space size={0} direction="vertical">
                        <Space size={10}>
                            <Text className="multi-sku-header-description">{headerData.headerDescription}</Text>
                            {headerData.headerDescription.includes('Vendor') ? "" :
                               <>| <Text className="multi-sku-header-vendor">{props.data.vendorList}</Text></> }
                        </Space>
                        <Text className="multi-sku-header-store-count">
                            {props.data.dataIndex === 'inStore'?
                                props.data.inStoreMultiSkuData.isLoaded !== ""?inStoreSkuCount+" Store SKUs": <UXSpin fontSize={14}/>:
                                props.data.onlineMultiSkuData.isLoaded !== ""?onlineSkuCount+" Online SKUs":<UXSpin fontSize={14}/>}
                        </Text>
                    </Space>
                </Col>
            </Row>
            <Row gutter={[16,0]} justify="end" style={{paddingRight:"20px"}}>
                <Col>
                    <Radio.Group onChange={(e)=>{props.data.setShowOnline(!props.data.showOnline);trackEvent("CLICKED_MULTI_SKU_PAGE_TOGGLE_BUTTON",{"value":e.target.value})}}
                                 value={props.data.dataIndex}>
                        <Radio.Button disabled = {inStoreSkuCount === 0} value="inStore">In-Store {props.data.inStoreMultiSkuData.isLoaded !== ""?`(${inStoreSkuCount})`: <UXSpin fontSize={14}/>}</Radio.Button>
                        <Radio.Button disabled = {onlineSkuCount === 0} value="online">Online {props.data.onlineMultiSkuData.isLoaded !== ""?`(${onlineSkuCount})`:<UXSpin fontSize={14}/>}</Radio.Button>
                    </Radio.Group>
                </Col>
                <Col>
                    <Button type="primary"
                            ghost='true'
                            icon={<FilterOutlined />}
                            onClick={()=> {
                                MultiSkuFilterHelper.frameDCSInput(new Set([...props.data.onlineMultiSkuData.distinctDCSSet,...props.data.inStoreMultiSkuData.distinctDCSSet]));
                                props.data.setMultiSkuFilterOpen(true);
                            }}>Filter SKUs</Button>
                </Col>
            </Row>
        </>
    );
};

export default MultiSkuDetailHeader;
