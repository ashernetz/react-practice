import React, { useContext, useEffect, useState} from 'react';
import {Alert, Col, Layout, Row, Typography} from 'antd';
import "./MultiSkuPage.scss";
import OnlineSkuDetailsPageHeader from '../../../ProductSearchComponents/OnlinePageHeader';
import SingleAndMultiSkuServices from '../../../../services/SingleAndMultiSkuServices';
import SkuContext from "../../../../context/SkuContext";
import CompUtil from "../../../Utils/CompUtil";
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import {inStoreMultiSKUExcelDataMapper, onlineMultiSKUExcelDataMapper} from "../../../Helper/ExcelHelper";
import MultiSkuApiHelper from "../../../Helper/MultiSkuApiHelper";
import AlertUtil from "../../../Utils/AlertUtil";
import {trackEvent} from "../../../Utils/mixpanel";
import HeaderServices from '../../../../services/HeaderServices';
import VendorDisplayText from './../VendorDisplayText';
import ProductDownload from '../../../ProductSearchComponents/ProductDownload/ProductDownload';
import {
    getSubClassDescription,
} from '../../../Utils/CommonUtil';
import MultiSkuFilter from './../MultiSkuFilter/MultiSkuFilter';
import MultiSkuFilterContext from "../../../../context/MultiSkuFilterContext";
import MultiSkuFilterHelper from "./../MultiSkuFilter/MultiSkuFilterHelper";
import MultiSkuOnlineTabs from "./MultiSkuOnlineTabs";
import MultiSkuInstoreTabs from "./MultiSkuInstoreTabs";
import MultiSkuSandwichComponents from "./MultiSkuSandwichComponents";
import searchResultIcon from '../../../../images/search_results_icon.svg';
import skuGroupIcon from '../../../../images/sku_group_icon.svg';


const { Text } = Typography;
const { Content } = Layout;

const headerData = ()=>JSON.parse(JSON.stringify({
    dcsTitle: "",
    omsIdTitle: "",
    skuTitle:"",
    minMaxRetail: {minRetail:"",maxRetail:"",minMaxRetail:""},
    onHandQuantity: "",
    productCount: "",
    totalThisYearSales: "",
    totalCompPercentage: "",
    totalThisYearUnits: "",
    totalUnitsPercentage: "",
    fiscalWeek:"",
    multiVendorList :"-",
    aggregatedCPI:{},
    filterHeaderData:{
        minMaxRetail:{minRetail:"",maxRetail:"",minMaxRetail:""},
        aggregatedCPI:{},
        totalThisYearSales: "",
        totalCompPercentage: "",
        totalThisYearUnits: "",
        totalUnitsPercentage: "",
    },
}));
const initialState = {
    onlineMultiSkuData: {onlineSkuDetailList: [],isLoaded:"",distinctDCSSet : new Set()},
    inStoreMultiSkuData: {skuRetailList: [],isLoaded:"",distinctDCSSet : new Set()},
    multiSkuFilterOpen: false,
    exceedSkuThresholdAlert: ""
};

const SKU_LIST_UPDATE = "Sku List Update";
const APPLY_FILTER = "Apply Filter";

const compsAndUnitsFormatter = (input, rowJustify = "start") => {
    let compOrUnitValue = CompUtil.findPercentageUpOrDown(input);
    return (!input && input !== "-" ? <UXSpin /> : <Row justify={rowJustify} gutter={[4, 0]} >
        <Col><Text className={compOrUnitValue && "comp-units-" + compOrUnitValue}> {isNaN(input)?"N/A":CompUtil.formatPrice(CompUtil.formatCompData(input))}</Text></Col>
        <Col>{CompUtil.getArrowUpDownComponent(compOrUnitValue)}</Col>
    </Row>)
};

const dcsVendorAlertTypeCheck = (dcsSet,vendorList,isVendorSearch,isPacManUser) => {

    let messageType = "";
    if(isVendorSearch === false || isPacManUser === false){
        messageType = null;
    } else if(dcsSet.size === 0 ){
        messageType = "-";
    } else if(isVendorSearch && (dcsSet.size > 4 || (Array.isArray(vendorList) && vendorList.length > 4))){
        messageType = dcsSet.size > 4 ? "dcs" : "vendor"
    }
    return messageType;
};

const MultiSkuPage = (props) => {
    const context = useContext(SkuContext);
    const filterContext = useContext(MultiSkuFilterContext);
    const [showOnline, setShowOnline] = useState(false);
    const [onlineMultiSkuData, setOnlineMultiSkuData] = useState({...initialState.onlineMultiSkuData});
    const [multiSkuHeaderData,setMultiSkuHeaderData] = useState({"online":{...headerData()},"inStore":{...headerData()}});
    const [inStoreMultiSkuData,setInStoreMultiSkuData] = useState({...initialState.inStoreMultiSkuData});
    const [skuTimelineMap, setSkuTimelineMap] = useState({});
    const [searchValues,setSearchValues] = useState({omsIdList:[],skuList:[],multiSearchData:{},existingData:{}});
    const [refreshKey,setRefreshKey] = useState(1);
    const [extraValues,setExtraValues] = useState({inStoreDcsVendorAlertType:""});
    const [multiSkuFilterOpen, setMultiSkuFilterOpen] = useState(initialState.multiSkuFilterOpen);
    const [exceedSkuThresholdAlert,setExceedSkuThresholdAlert] = useState(initialState.exceedSkuThresholdAlert);

    let isDiverseSearch = props.searchValues.multiSearchData && Object.keys(props.searchValues.multiSearchData).length > 0;
    let isVendorSearch = isDiverseSearch && props.searchValues.multiSearchData.input.searchType === "VNDR";
    let isOnlineVendorSearch = isVendorSearch && props.searchValues.multiSearchData.input.isOnlineVendor === true;
    let isInStoreVendorSearch= isVendorSearch && props.searchValues.multiSearchData.input.isOnlineVendor === false;
    let searchedVendorNumber = isVendorSearch ? props.searchValues.multiSearchData.input.vendorNumber:null;
    let isPacManUser = props.userAccess ? props.userAccess.isSubmitEnabled ?  props.userAccess.isSubmitEnabled :false : false;
    let skuGroupData = (props.searchValues.skuGroupData && Object.keys(props.searchValues.skuGroupData).length>0) ? props.searchValues.skuGroupData:null;
    MultiSkuFilterHelper.updateFilterContext(filterContext);

    //filterData
    let isFilterApplied = filterContext.selectedFilters.isFilterApplied;
    let filteredInStoreData = isFilterApplied?inStoreMultiSkuData.skuRetailList.filter(k=> MultiSkuFilterHelper.filterData(k)):inStoreMultiSkuData.skuRetailList;
    let filteredOnlineData = isFilterApplied?onlineMultiSkuData.onlineSkuDetailList.filter(k=> MultiSkuFilterHelper.filterData(k)):onlineMultiSkuData.onlineSkuDetailList;

    // Edit Prices
    // need to update ldap list
    //const areAllAnchorSkus = filteredInStoreData.every(sku => sku.isAnchorSku === true);
    const isPLS = skuGroupData && skuGroupData.isPLS && skuGroupData.zoneGroupMultiplierId;
    let userAccessEditPrices = !!(isPLS && !showOnline && filteredInStoreData.length > 0);


    const headerHeadingDetails = () =>{
        let inputMultiSearchData =  isDiverseSearch ? props.searchValues.multiSearchData.input : null;
        let searchType = inputMultiSearchData?props.searchValues.multiSearchData.input.searchType:null;
        let heading = {icon:searchResultIcon, headerDescription: "Search Results"};
        let subClassDescription = (inputMultiSearchData && searchType === 'DCS') ? getSubClassDescription(
            context.dcsDataMap,inputMultiSearchData.department,inputMultiSearchData.classNumber,inputMultiSearchData.subClassNumber): null;

        switch(searchType){
            case "VNDR":
                heading ={
                    icon:searchResultIcon,
                    headerDescription:`Vendor: ${ inputMultiSearchData.vendorNumber} - ${inputMultiSearchData.vendorName}`};
                break;
            case "DCS":
                heading ={
                    icon:searchResultIcon,
                    headerDescription:`SubClass: ${inputMultiSearchData.department} | ${inputMultiSearchData.classNumber} | ${inputMultiSearchData.subClassNumber} - ${subClassDescription}`};
                break;
            case "KVI":
                heading ={
                    icon:searchResultIcon,
                    headerDescription:"KVI SKUs"};
                break;
            case "FAV":
                heading ={
                    icon:searchResultIcon,
                    headerDescription:"Favourite SKUs"};
                break;
            default:
                if(skuGroupData){
                    heading ={
                        icon:skuGroupIcon,
                        headerDescription:`SKU Group: ${ skuGroupData.groupName}`};
                }
        }
        heading['mainHeading'] = "Multiple SKUs";
        return heading;
    }

    const resetState = () => {
        setShowOnline(false);
        setMultiSkuHeaderData({"online":{...headerData()},"inStore":{...headerData()}});
        setOnlineMultiSkuData({...initialState.onlineMultiSkuData});
        setInStoreMultiSkuData({...initialState.inStoreMultiSkuData});
        setSkuTimelineMap({});
        setRefreshKey(k=>k+1);
        setExtraValues({inStoreDcsVendorAlertType:""});
        setExceedSkuThresholdAlert(initialState.exceedSkuThresholdAlert);
        filterContext.clearFilterSelection();
    };

    const onlineMultiSkuApiTriggers = (skuList)=>{
        MultiSkuApiHelper.fetchOnlineOhQuantity(skuList, setMultiSkuHeaderData);
        MultiSkuApiHelper.fetchMultiSkuPerformance(skuList,props.userId,true,setMultiSkuHeaderData,setOnlineMultiSkuData,isDiverseSearch,searchedVendorNumber);
        MultiSkuApiHelper.fetchOnlineSkuRank(skuList, setOnlineMultiSkuData);
    };

    const fetchFilterAggregates = (isTimeTransform) => {
        if (isFilterApplied) {
            let inStoreSkuList = filteredInStoreData.map(k => Number.parseInt(k.skuNumber));
            let onlineSkuList = filteredOnlineData.map(k => Number.parseInt(k.skuNumber));
            if (!isTimeTransform) {
                setVendorAlertType(true);
                MultiSkuApiHelper.filterAggregateCPI(inStoreSkuList, props.userId, setMultiSkuHeaderData);
                MultiSkuApiHelper.filteredMinMaxRetailOnline(filteredOnlineData,setMultiSkuHeaderData);
                MultiSkuApiHelper.calculateInStoreMinMaxRetail(filteredInStoreData,setMultiSkuHeaderData,true);
            }
            MultiSkuApiHelper.filterAggregatePerformance(onlineSkuList, props.userId, true, setMultiSkuHeaderData);
            MultiSkuApiHelper.filterAggregatePerformance(inStoreSkuList, props.userId, false, setMultiSkuHeaderData);
        }else {
            setVendorAlertType(false);
        }
    }

    const setVendorAlertType = (isClear) =>{
        let messageType = isClear? "" : dcsVendorAlertTypeCheck(inStoreMultiSkuData.distinctDCSSet,multiSkuHeaderData.inStore.multiVendorList,isVendorSearch,isPacManUser);
        setExtraValues(k=>({...k,inStoreDcsVendorAlertType:messageType}));
    }

    const inStoreMultiSkuApiTriggers = (skuList)=>{
        MultiSkuApiHelper.fetchMultiSkuPerformance(skuList,props.userId,false,setMultiSkuHeaderData,setInStoreMultiSkuData,isDiverseSearch,searchedVendorNumber);
        MultiSkuApiHelper.fetchInStoreCPIDetails(skuList,props.userId,setInStoreMultiSkuData);
        MultiSkuApiHelper.fetchInstoreAggregatedCPI(props.searchValues.multiSearchData,skuList,props.userId,setMultiSkuHeaderData,context.dcsDataMap);
        MultiSkuApiHelper.fetchInStoreAverageUnitRetail(skuList,props.userId,setInStoreMultiSkuData);
        // MultiSkuApiHelper.fetchInStoreMaxCost(skuList,props.userId,setInStoreMultiSkuData);
        // MultiSkuApiHelper.fetchInStoreMinCost(skuList,props.userId,setInStoreMultiSkuData);
        // MultiSkuApiHelper.fetchInStoreModeCost(skuList,props.userId,false,setInStoreMultiSkuData);
        MultiSkuApiHelper.fetchVendorsBySkus(skuList,false,setInStoreMultiSkuData);
        MultiSkuApiHelper.fetchCurrentCostBySku(skuList,setInStoreMultiSkuData);
        MultiSkuApiHelper.fetchInStoreSkuRank(skuList,setInStoreMultiSkuData);
    };


    useEffect(()=>{
        if (props.searchValues.omsIdList.length > 0 || props.searchValues.skuList.length > 0) {
            context.updateShowDimmer(true);
            resetState();
            setSearchValues(props.searchValues);
            checkSkuThresholdExceeded(SKU_LIST_UPDATE);
            if(isDiverseSearch){
                MultiSkuApiHelper.fetchMultiSearchPerformanceData(props.searchValues.multiSearchData,props.userId,true,setMultiSkuHeaderData,context.dcsDataMap);
                MultiSkuApiHelper.fetchMultiSearchPerformanceData(props.searchValues.multiSearchData,props.userId,false,setMultiSkuHeaderData,context.dcsDataMap);
                MultiSkuApiHelper.fetchMinMaxRetailRange(props.searchValues.multiSearchData,true,setMultiSkuHeaderData);
                //MultiSkuApiHelper.fetchMinMaxRetailRange(props.searchValues.multiSearchData,false,setMultiSkuHeaderData);
                MultiSkuApiHelper.fetchMultiVendorData(props.searchValues.multiSearchData,true,setMultiSkuHeaderData,"");
                MultiSkuApiHelper.fetchMultiVendorData(props.searchValues.multiSearchData,false,setMultiSkuHeaderData,"");
            }
        }else {
            context.updateShowDimmer(false);
            AlertUtil.showAlert("error", "Error", <div>No valid SKU's or OMSId's present</div>);
            props.updateShowNewDashboardView(true);
            context.updateShowDimmer(false);

        }

    },[props.searchValues.omsIdList,props.searchValues.skuList]);


    useEffect(()=>{
        if(onlineMultiSkuData.isLoaded === true && onlineMultiSkuData.onlineSkuDetailList){
            let skuList = onlineMultiSkuData.onlineSkuDetailList.map(k => Number.parseInt(k.skuNumber));
            setMultiSkuHeaderData(k => ({
                ...k, "online": {
                    ...k.online, totalThisYearSales: "",
                    totalCompPercentage: "",
                    totalThisYearUnits: "",
                    totalUnitsPercentage: ""
                }
            }));
            setOnlineMultiSkuData(k=>({...k,onlineSkuDetailList:[...k.onlineSkuDetailList.map(k=>{let temp = {...k};temp.compPercentage="";temp.unitsPercentage=""; temp.rawSales = ""; temp.rawUnits = "";return temp;})]}));
            MultiSkuApiHelper.fetchMultiSkuPerformance(skuList,props.userId,true,setMultiSkuHeaderData,setOnlineMultiSkuData,isDiverseSearch,searchedVendorNumber);
            if(isDiverseSearch){
                MultiSkuApiHelper.fetchMultiSearchPerformanceData(searchValues.multiSearchData,props.userId,true,setMultiSkuHeaderData,context.dcsDataMap);

            }
        }

        if(inStoreMultiSkuData.isLoaded === true && inStoreMultiSkuData.skuRetailList ){
            let skuList = inStoreMultiSkuData.skuRetailList.map(k => Number.parseInt(k.skuNumber));
            setMultiSkuHeaderData(k => ({
                ...k, "inStore": {
                    ...k.inStore, totalThisYearSales: "",
                    totalCompPercentage: "",
                    totalThisYearUnits: "",
                    totalUnitsPercentage: ""
                    //aggregatedCPI: {}
                }
            }));
            setInStoreMultiSkuData(k=>({...k,skuRetailList:[...k.skuRetailList.map(k=>{let temp = {...k};temp.compPercentage="";temp.unitsPercentage="";temp.rawSales = ""; temp.rawUnits = "";return temp;})]}));
            MultiSkuApiHelper.fetchMultiSkuPerformance(skuList,props.userId,false,setMultiSkuHeaderData,setInStoreMultiSkuData,isDiverseSearch,searchedVendorNumber);
            //MultiSkuApiHelper.fetchInStoreCPIDetails(skuList,props.userId,setInStoreMultiSkuData);
            //MultiSkuApiHelper.fetchInstoreAggregatedCPI(props.searchValues.multiSearchData,skuList,props.userId,setMultiSkuHeaderData,context.dcsDataMap);
            MultiSkuApiHelper.fetchInStoreAverageUnitRetail(skuList,props.userId,setInStoreMultiSkuData);
            // MultiSkuApiHelper.fetchInStoreMaxCost(skuList,props.userId,setInStoreMultiSkuData);
            // MultiSkuApiHelper.fetchInStoreMinCost(skuList,props.userId,setInStoreMultiSkuData);
            // MultiSkuApiHelper.fetchInStoreModeCost(skuList,props.userId,false,setInStoreMultiSkuData);
            // MultiSkuApiHelper.fetchVendorsBySkus(skuList,false,setInStoreMultiSkuData);
            if(isDiverseSearch){
                MultiSkuApiHelper.fetchMultiSearchPerformanceData(searchValues.multiSearchData,props.userId,false,setMultiSkuHeaderData,context.dcsDataMap);

            }
        }

        fetchFilterAggregates(true)


    },[context.timeTransformType]);

    useEffect(()=>{
        if(!multiSkuFilterOpen){
            fetchFilterAggregates(false);
        }
    },[isFilterApplied,multiSkuFilterOpen])

    useEffect(()=>{
        if(inStoreMultiSkuData.isLoaded === false){
            setShowOnline(true);
        }
        if(onlineMultiSkuData.isLoaded !== "" && inStoreMultiSkuData.isLoaded !== ""){
            context.updateShowDimmer(false);
        }
        if(onlineMultiSkuData.isLoaded === false && inStoreMultiSkuData.isLoaded === false){
            context.updateShowDimmer(true);
            AlertUtil.showAlert("error", "Error",<div>No valid SKU or OMSId present</div>);
            props.updateShowNewDashboardView(true);
            context.updateShowDimmer(false);

        }
    },[onlineMultiSkuData.isLoaded,inStoreMultiSkuData.isLoaded]);


    useEffect(() => {
        if (searchValues.omsIdList.length > 0 || searchValues.skuList.length > 0) {
            setOnlineMultiSkuData(k=>({...k,isLoaded:""}));
            setInStoreMultiSkuData(k=>({...k,isLoaded:""}));
            let alertMessage = "";
            SingleAndMultiSkuServices.determineSellingChannel(searchValues.skuList,searchValues.omsIdList).then(response=>{

                if(response.data && response.data.onlineSkus && response.data.coreSkus){
                    if(Object.keys(response.data.onlineSkus).length === 0 && Object.keys(response.data.coreSkus).length === 0){
                        alertMessage = <div>No valid SKUs or OMSIds present</div>;
                    }else {
                        if(Object.keys(response.data.coreSkus).length>0){
                            MultiSkuApiHelper.fetchInStoreDetails(props.userId,response.data,setInStoreMultiSkuData,inStoreMultiSkuApiTriggers,setMultiSkuHeaderData,isDiverseSearch);
                            if(!isDiverseSearch || isOnlineVendorSearch ){
                                MultiSkuApiHelper.fetchMultiVendorData("",false,setMultiSkuHeaderData,Object.keys(response.data.coreSkus));
                            }
                        }else {
                            //setInStoreMultiSkuData({...initialState.inStoreMultiSkuData,isLoaded:false});
                            setInStoreMultiSkuData(k=>({...k,isLoaded:false}));

                        }
                        if(Object.keys(response.data.onlineSkus).length>0){
                            MultiSkuApiHelper.fetchMultiSkuOnlineData(initialState, response.data,setOnlineMultiSkuData,context,onlineMultiSkuApiTriggers,setMultiSkuHeaderData,isDiverseSearch,searchedVendorNumber);
                            if(!isDiverseSearch || isInStoreVendorSearch ){
                                MultiSkuApiHelper.fetchMultiVendorData("",true,setMultiSkuHeaderData,Object.keys(response.data.onlineSkus));
                            }

                        }else {
                            //setOnlineMultiSkuData({...initialState.onlineMultiSkuData,isLoaded:false});
                            setOnlineMultiSkuData(k=>({...k,isLoaded:false}));

                        }

                    }
                }
            }).catch(err => {
                console.log("Error occurred while calling SellingChannelAPI " + err);
                alertMessage = AlertUtil.getErrorMessage("calling selling channel API");
            }).finally(()=>{
                if(alertMessage){
                    context.updateShowDimmer(false);
                    AlertUtil.showAlert("error", "Error", alertMessage);
                    props.updateShowNewDashboardView(true);
                }
            });
        }
    }, [searchValues.omsIdList, searchValues.skuList]);


    useEffect(()=>{
        setVendorAlertType(false);
    },[multiSkuHeaderData.inStore.multiVendorList,inStoreMultiSkuData.distinctDCSSet]);


    const getVendorName = (multiSearchData,headerData) => {

        if(multiSearchData.input && multiSearchData.input.searchType === "VNDR" &&
            (showOnline === multiSearchData.input.isOnlineVendor || multiSearchData.input.isOnlineVendor === undefined)){
            return multiSearchData.input.vendorName.toUpperCase();
        }else {
            return <VendorDisplayText
                multiVendorList={headerData.multiVendorList}
                getAllSkusforDCSView = {getAllSkusforDCSView}
                dcsTitle={headerData.formattedDCS}
                selectedType={showOnline?"ONLINE" : "INSTORE"}
                trackEventTitle={(showOnline?"ONLINE" : "INSTORE") +"_MULTI_SKU_PAGE"}
            />
        }
    };

    const ExceedSkuThresholdAlert = ({exceedSkuThresholdAlert, setExceedSkuThresholdAlert}) => {
        let message = (exceedSkuThresholdAlert === APPLY_FILTER) ?
            "The total number of SKUs exceeds what is displayed. Filters are only applied to the SKUs currently shown."
            : "The total number of SKUs exceeds what can be displayed. The SKU list shown in the table below has been truncated.";

        return (<Alert className="multi-sku-filter-alert"
                       message={message}
                       type="warning"
                       closable
                       afterClose={()=>setExceedSkuThresholdAlert("")}/>);
    }

    const checkSkuThresholdExceeded = (alertTrigger) => {
        let lastKey = props.searchValues.multiSearchData.lastKey;
        if (lastKey && lastKey > 0) {
            trackEvent("EXCEED_TOTAL_SKU_THRESHOLD", {
                'Alert Trigger': alertTrigger,
                'Search Input' : {...props.searchValues.multiSearchData.input}
            });
            setExceedSkuThresholdAlert(alertTrigger);
        }
    }

    const onNewPageRender = (updateTablePage,pageNumber) => {
        let page = pageNumber;
        let input = {...searchValues.multiSearchData.input,lastKey:searchValues.multiSearchData.lastKey};
        context.updateShowDimmer(true);
        HeaderServices.postMultiSKuSearch(input).then(response => {
            setSearchValues(k=>({...k,skuList:response.data.skuList,omsIdList:[],multiSearchData:{...k.multiSearchData,lastKey:response.data.lastKey}}));
        }).catch(err => {
            page = page-1;
            context.updateShowDimmer(false);
            console.log(err);
        }).finally(()=> {updateTablePage(page)});
    }

    const getAllSkusforDCSView = (formattedDCS,vendorNumber,vendorName) => {
        let data = {};
        if(vendorNumber){
            data = {
                searchType: "VNDR",
                vendorNumber: vendorNumber?vendorNumber:0,
                vendorName:vendorName?vendorName:"",
                isOnlineVendor:showOnline};
        }else {
            let dcsKey= formattedDCS.split(" ");

            data = {
                classNumber: Number.parseInt(dcsKey[1].replace(/\D/g,'')),
                department: Number.parseInt(dcsKey[0].replace(/\D/g,'')),
                searchType: "DCS",
                subClassNumber: Number.parseInt(dcsKey[2].replace(/\D/g,''))
            }
        }
        props.diverseMultiSearch(data,vendorNumber?"VENDOR_MULTI_SKU_SEARCH_"+vendorNumber+"_"+formattedDCS:"ENTERED_MULTIPLE_ITEM_IN_DCS_"+formattedDCS,context.updateShowDimmer);
    };

    let pageHeaderData = headerHeadingDetails();

    let dataIndex= showOnline?"online":"inStore";
    return (<>
                <Layout id="multi-sku-page-layout">
                    <OnlineSkuDetailsPageHeader
                        backArrowClick={(k) => props.updateShowNewDashboardView(true)}
                        headerData={pageHeaderData}
                        downloadOption={showOnline ?
                            <ProductDownload
                                multiSearchData = {searchValues.multiSearchData}
                                isOnline = {true}
                                disabled ={onlineMultiSkuData.onlineSkuDetailList.length === 0}
                                isFilterApplied = {isFilterApplied}
                                excelData = {()=>onlineMultiSKUExcelDataMapper(filteredOnlineData, multiSkuHeaderData.online,isFilterApplied)}/>:
                            <ProductDownload
                                key={refreshKey+"-download"}
                                verifyAccessToken={props.verifyAccessToken}
                                multiVendorList= {multiSkuHeaderData.inStore.multiVendorList}
                                distinctDCSSet = {inStoreMultiSkuData.distinctDCSSet}
                                skuObjectList = {filteredInStoreData}
                                multiSearchData = {searchValues.multiSearchData}
                                inStoreDcsVendorAlertType = {extraValues.inStoreDcsVendorAlertType}
                                isOnline = {false}
                                disabled ={inStoreMultiSkuData.skuRetailList.length === 0}
                                isPacManUser ={isPacManUser}
                                userId = {props.userId}
                                config = {props.config}
                                isFilterApplied = {isFilterApplied}
                                excelData = {()=>inStoreMultiSKUExcelDataMapper(filteredInStoreData, multiSkuHeaderData.inStore,isFilterApplied)}/>
                        }
                    />

                    <Content id="multi-sku-page-content">
                        {exceedSkuThresholdAlert && <ExceedSkuThresholdAlert exceedSkuThresholdAlert={exceedSkuThresholdAlert} setExceedSkuThresholdAlert={setExceedSkuThresholdAlert}/>}
                        <MultiSkuSandwichComponents
                            config={props.config}
                            onlineMultiSkuData={onlineMultiSkuData}
                            inStoreMultiSkuData={inStoreMultiSkuData}
                            onlineSkuCount={filteredOnlineData}
                            inStoreSkuCount={filteredInStoreData}
                            showOnline={showOnline}
                            isVendorSearch = {isVendorSearch}
                            setShowOnline={setShowOnline}
                            vendorList={getVendorName(searchValues.multiSearchData,multiSkuHeaderData[dataIndex])}
                            userAccessEditPrices = {userAccessEditPrices}
                            setMultiSkuFilterOpen = {setMultiSkuFilterOpen}
                            skuGroupData={skuGroupData}
                            headerData={pageHeaderData}
                            isFilterApplied={isFilterApplied}
                            multiSkuHeaderData={multiSkuHeaderData}
                            dataIndex={dataIndex}
                            userId = {props.userId}
                            onSkuGroupUpdate={(data) => props.multiItemInquiry(data.skuNumbers, [], null, null, {...skuGroupData,
                                groupName:data.groupName,
                                groupDescription:data.groupDescription,
                                skuNumbers:data.skuNumbers
                              })
                            }
                            onSkuGroupDelete={() => props.updateShowNewDashboardView(true)}
                        >

                        <Row gutter={[0, 56]}>
                            <Col span={24} className="sandwich-row-content">
                                {showOnline ?
                                    <MultiSkuOnlineTabs
                                        key={refreshKey+"-online"}
                                        onlineMultiSkuData={filteredOnlineData}
                                        compsAndUnitsFormatter={compsAndUnitsFormatter}
                                        getOnlineRetailTimelineData={(skuNumber,omsIdVendorData) => {
                                            if (!skuTimelineMap.hasOwnProperty(skuNumber)) {
                                                MultiSkuApiHelper.getOnlineRetailTimelineData(skuNumber, omsIdVendorData,setSkuTimelineMap);
                                            }
                                        }}
                                        skuTimelineMap={skuTimelineMap}
                                        lastKey = {searchValues.multiSearchData.lastKey}
                                        getAllSkusforDCSView = {getAllSkusforDCSView}
                                        onNewPageRender = {onNewPageRender}
                                    />
                                    : <MultiSkuInstoreTabs
                                        compsAndUnitsFormatter = {compsAndUnitsFormatter}
                                        inStoreSkuRowData = {filteredInStoreData}
                                        messageType = {extraValues.inStoreDcsVendorAlertType}
                                        key = {refreshKey+"-instore"}
                                        lastKey = {searchValues.multiSearchData.lastKey}
                                        onNewPageRender = {onNewPageRender}
                                        getAllSkusforDCSView = {getAllSkusforDCSView}
                                    />
                                }
                            </Col>
                        </Row>
                        </MultiSkuSandwichComponents>

                        {multiSkuFilterOpen && <MultiSkuFilter
                            isOnline = {showOnline}
                            searchType = {isDiverseSearch?props.searchValues.multiSearchData.input.searchType:""}
                            onClose={ () => {
                                setMultiSkuFilterOpen(false);
                                checkSkuThresholdExceeded(APPLY_FILTER);
                            }}/>}

                    </Content>
                </Layout>
        </>
    );

};

export default MultiSkuPage;