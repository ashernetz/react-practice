import React from 'react';
import { Row, Divider } from 'antd';

import { Card } from '../../../GlobalComponents/Card/Card';
import { CardRowItem } from './CardItems';
import { OmniAssortmentReportLink } from './OmniAssortmentReportLink';
import {
  useDCAssortment,
  useLoading,
} from '../../../DCAssortment/DCAssortmentProvider';

export function DCAssortmentCard({
  myAssortmentBaseUrl,
  skus,
  showMetrics = true,
  maxSkusLimit,
}) {
  const dcAssortment = useDCAssortment();
  const { isDCSLoading } = useLoading();

  const totalDCsValue = isDCSLoading ? 'spin' : dcAssortment.length;

  return (
    <Card title="DC ASSORTMENT">
      {showMetrics && (
        <>
          <Row>
            <CardRowItem
              type="NB"
              name="Regional Asst. DCs"
              value={totalDCsValue}
            />
          </Row>
          <Divider />
        </>
      )}
      <OmniAssortmentReportLink
        myAssortmentBaseUrl={myAssortmentBaseUrl}
        maxSkusLimit={maxSkusLimit}
        skus={skus}
      />
    </Card>
  );
}
