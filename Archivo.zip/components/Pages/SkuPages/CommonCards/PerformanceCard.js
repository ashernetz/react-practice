import React from 'react';
import './CommonCards.scss';
import { Row, Col, Typography, Space } from 'antd';
import { CardRowItem } from './CardItems';
import {formatNumberToCompact} from '../../../Utils/CommonUtil';
import { Card } from '../../../GlobalComponents/Card/Card'

const { Text } = Typography;

const PerformanceCard = (props) => {
    let performanceData = props.performanceData;

const salesAndUnitsRowData =(currentYearValue, percentage, prefix) => {
  return(
      <Space direction="vertical" size={0}>
        {currentYearValue && !isNaN(currentYearValue) &&
        <Text className="col-item-value">{prefix}{formatNumberToCompact(currentYearValue)}</Text>}
        <Text className="col-item-second-value">{props.compsAndUnitsFormatterWithoutArrow(percentage)}</Text>
      </Space>
  );
};

  return(
    <Card title="PERFORMANCE">
      <Row gutter={[8, 8]}>
        <CardRowItem
          name="Sales"
          value={salesAndUnitsRowData(performanceData.totalThisYearSales, performanceData.totalCompPercentage, "$")}
        />
        <CardRowItem
          name="Units"
          value={salesAndUnitsRowData(performanceData.totalThisYearUnits, performanceData.totalUnitsPercentage, "")}
        />
      </Row>
    </Card>
  );
};
export default PerformanceCard;
