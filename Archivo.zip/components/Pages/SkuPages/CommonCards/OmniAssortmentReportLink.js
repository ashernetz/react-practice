import React from 'react';
import { isEdge, isIE } from 'react-device-detect';
import { Typography } from 'antd';

const BrowserLimits = {
  EDGE: 2083,
};

function getUrl(url, searchParams) {
  const size = [...searchParams.keys()].length;

  return size ? `${url}?${searchParams.toString()}` : url;
}

function getOmniAssortmentReportRoute(baseUrl, skus) {
  const searchParams = new URLSearchParams();

  if (skus?.length) {
    searchParams.set('skus', skus.join(','));
  }

  const url = getUrl(`${baseUrl}/reports/oar`, searchParams);

  return isUrlLengthSupported(url) ? url : null;
}

function isUrlLengthSupported(url) {
  let limit = null;

  if (isIE || isEdge) {
    limit = BrowserLimits.EDGE;
  }

  return limit ? url.length <= limit : true;
}

export function OmniAssortmentReportLink({
  myAssortmentBaseUrl,
  skus,
  maxSkusLimit = 150,
}) {
  if (skus.length > maxSkusLimit) {
    return null;
  }

  const omniAssortmentReportUrl = getOmniAssortmentReportRoute(
    myAssortmentBaseUrl,
    skus
  );

  if (!omniAssortmentReportUrl) {
    return null;
  }

  return (
    <Typography.Link href={omniAssortmentReportUrl} target="_blank">
      Omni Assortment Report
    </Typography.Link>
  );
}
