import React from 'react';
import './CommonCards.scss';
import { Row, Col, Typography, Space } from 'antd';
import { CardRowItem } from './CardItems';
import CompUtil from "../../../Utils/CompUtil";
import CPIUtil from "../../../Utils/CPIUtil";
import {StarFilled} from "@ant-design/icons";
import { Card } from '../../../GlobalComponents/Card/Card'

const { Text } = Typography;

const CompetitiveCard = (props) => {
    let cpiData = props.cpiData ? props.cpiData : [];
    const cpiValueColorFormat = (value) =>{
        return value ?(value < 1 ? "competitive-cpi-color-green" : "competitive-cpi-color-red"):"";
    };

    const cpiRowData =(competitorId) => {
        return(
            <Space direction="vertical" size={0}>
                {cpiData[competitorId].cpiDaily &&
                    <>
                        <Text className={cpiValueColorFormat(cpiData[competitorId].cpiDaily)}>
                            {CPIUtil.formatCPI(cpiData[competitorId].cpiDaily)}
                        </Text>
                        <Space size={4}>
                            <Text className="cpi-sales-coverage">
                                {(cpiData[competitorId].cpiSalesCovDlyPercentage)?CompUtil.formatPrice(cpiData[competitorId].cpiSalesCovDlyPercentage)+'%':"NA"}
                            </Text>
                            <Text className="cpi-sales-coverage-value">{"|"}</Text>
                            <Text className="cpi-sales-coverage-value">
                                {(cpiData[competitorId].cpiSalesCovDollarDlyDenom) ?
                                    CompUtil.formatMuMdPrice(cpiData[competitorId].cpiSalesCovDollarDlyDenom,true):"NA"}
                            </Text>
                        </Space>
                    </>
                    }
                </Space>
            );
        };
    const ShowCompetitor = (props) => {
        return(
                <Row>
                    <Col>
                        {props.primaryCompetitor === "Y" ? <StarFilled style={{ color: '#f96302',fontSize:'12px',paddingBottom:'2px', paddingRight:'5px' }} /> :""}
                    </Col>
                    <Col>
                        {CPIUtil.competitorCPIName[props.competitorId]}
                    </Col>
                </Row>
        );
    };
    const CompetitorCardRowData =(props) =>{
        return(
            <CardRowItem
                name={<ShowCompetitor
                    primaryCompetitor={cpiData[props.competitorId] ? cpiData[props.competitorId].primaryCompetitor : ""}
                    competitorId={props.competitorId}
                />}
                type="NB"
                value={cpiData[props.competitorId] ? cpiData[props.competitorId] === "-" ? cpiData[props.competitorId] : cpiRowData(props.competitorId) : "spin"}
            />
        );
    }

    return(
      <Card title="COMPETITIVE">
        <Row gutter={[8, 8]} className="competitor-card">
          {CPIUtil.displayCPIOrder.map((competitorId)=> {
            return <CompetitorCardRowData competitorId={competitorId} />;
          })}
        </Row>
      </Card>
    );
};
export default CompetitiveCard;
