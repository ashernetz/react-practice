import React from 'react';
import './CommonCards.scss';
import {Row, Col, Typography} from 'antd';
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";

const { Text } = Typography;

const CardRowItem = (props) => {
  return(
      <Col span={props.span||12}>
        <Row>
          <Col span={24}>
              <Text className="col-item-title">{props.name}</Text>
          </Col>
          </Row>
        <Row>
          <Col span={24}>
            {props.type ? <ValueText inputValue={props.value} type={props.type}/>:props.value}
          </Col>
        </Row>
      </Col>
  );
};

const ValueText = ({inputValue,type="NB"}) =>{

        if(inputValue==="spin"){
            return <UXSpin/>;
        }else{
            let value = inputValue === "-" ? "N/A" : inputValue;
            switch (type){
                case "NB": return <NormalBold value={value}/>;
                default : return <Text>{value}</Text>
            }
        }


}
const NormalBold = ({value}) => {
     return <Text className="col-item-value">{value}</Text>
}





export { CardRowItem, NormalBold };
