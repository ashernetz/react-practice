import { CardRowItem } from '../CommonCards/CardItems';
import React from 'react';
import '../CommonCards/CommonCards.scss';
import { Row } from 'antd';
import { Card } from '../../../GlobalComponents/Card/Card'

const MultiSkuFinancialCard = (props) => {

    const retailRange = (props.multiSkuHeaderData.minMaxRetail.minMaxRetail === "" ? "spin" :
                (!props.multiSkuHeaderData.minMaxRetail.minMaxRetail ? "-" :
                    props.multiSkuHeaderData.minMaxRetail.minMaxRetail));

    return(
      <Card title="FINANCIAL">
        <Row gutter={[0, 8]}>
          <CardRowItem
            name="Retail Range"
            type="NB"
            value={retailRange}
          />
        </Row>
      </Card>
    );
};

export default MultiSkuFinancialCard;