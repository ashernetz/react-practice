import React from 'react';
import {Space, Typography} from "antd";
import MultiSkuFinancialCard from "./MultiSkuFinancialCard";
import CompUtil from "../../../Utils/CompUtil";
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import PerformanceCard from "../CommonCards/PerformanceCard";
import CompetitiveCard from "../CommonCards/CompetitiveCard";
import { DCAssortmentCard } from '../CommonCards/DCAssortmentCard'

const {Text} = Typography;

const MultiSkuCards = (props) => {

    const compsAndUnitsFormatterWithoutArrow = (input) => {
        let compOrUnitValue = CompUtil.findPercentageUpOrDown(input);
        return (!input && input !== "-" ? <UXSpin/> :
            <Text strong className={compOrUnitValue && "comp-units-" + compOrUnitValue}>
                {compOrUnitValue === "arrow-up" ? ("+"+CompUtil.formatPrice(CompUtil.formatCompData(input))):CompUtil.formatPrice(CompUtil.formatCompData(input))}
            </Text>)
    };

    const headerData = props.data.isFilterApplied ?
        props.data.multiSkuHeaderData[props.data.dataIndex].filterHeaderData :
        props.data.multiSkuHeaderData[props.data.dataIndex];

    const skus = props.data.showOnline
      ? props.data.onlineSkuCount
      : props.data.inStoreSkuCount;
    const skuIds = skus.map(({ skuNumber }) => skuNumber);

    return(
        <Space direction="horizontal" size="large" id="aggregated-card-size" >
            <PerformanceCard
                performanceData={headerData}
                compsAndUnitsFormatterWithoutArrow={compsAndUnitsFormatterWithoutArrow}
                isSingleSkuPage={false}
            />
            {(!props.data.isVendorSearch ||  props.data.isFilterApplied) && !props.data.showOnline && <CompetitiveCard cpiData = {headerData.aggregatedCPI}/>}
            <MultiSkuFinancialCard
                multiSkuHeaderData={headerData}/>
          <DCAssortmentCard
            showMetrics={false}
            myAssortmentBaseUrl={props.data.config.myAssortmentBaseUrl}
            maxSkusLimit={props.data.config.OARSkuLimit}
            skus={skuIds}
          />
        </Space>
    );
};

export default MultiSkuCards;
