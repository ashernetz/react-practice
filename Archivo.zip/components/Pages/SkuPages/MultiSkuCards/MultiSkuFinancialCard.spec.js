import React from 'react'
import MultiSkuFinancialCard from "./MultiSkuFinancialCard";
import {shallow} from "enzyme";
import '@testing-library/jest-dom'
import {render, screen} from "@testing-library/react";

const headerData ={minMaxRetail:{minMaxRetail:"$12.00-$30.35"}};
const emptyHeaderData ={minMaxRetail:{minMaxRetail:""}};
const testHeaderData ={minMaxRetail:{minMaxRetail:"-"}};

beforeEach(async () => {
    render(<MultiSkuFinancialCard multiSkuHeaderData={headerData}/>);
})

describe('MultiSkuFinancialCard', () => {

    it('show the header', () =>{
        let financialCardHeader = screen.getByText("FINANCIAL").closest("span")
        expect(financialCardHeader).toBeInTheDocument();
        expect(financialCardHeader).toBeVisible();
    })

    it('show retail range label', () =>{
        let retailLabel = screen.getByText("Retail Range").closest("span")
        expect(retailLabel).toBeInTheDocument();
        expect(retailLabel).toBeVisible();
    })

    it('show retail range value', () =>{
        let retailRangeValue = screen.getByText(headerData.minMaxRetail.minMaxRetail);
        expect(retailRangeValue).toBeInTheDocument();
        expect(retailRangeValue).toBeVisible();
    })

    it('check retail range spin', () =>{
        render(<MultiSkuFinancialCard multiSkuHeaderData={emptyHeaderData}/>);
        let retailRangeValue = screen.getByRole("img").closest('span');
        expect(retailRangeValue).toBeInTheDocument();
        expect(retailRangeValue).toBeVisible();
    })

    it('check retail range NA', () =>{
        render(<MultiSkuFinancialCard multiSkuHeaderData={testHeaderData}/>);
        let retailRangeValue = screen.getByText("N/A").closest('span');
        expect(retailRangeValue).toBeInTheDocument();
        expect(retailRangeValue).toBeVisible();
    })
})