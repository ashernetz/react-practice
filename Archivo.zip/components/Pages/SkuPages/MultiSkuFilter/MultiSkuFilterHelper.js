export default class MultiSkuFilterHelper {


    static SELECTED_FILTERS_INITIAL_VALUES = {
        dcs: '',
        specialDesignation: [],
        isFilterApplied: false,
        retailMode: {minVal:'',maxVal:''},
        // priceRange: {minVal:'',maxVal:''},
        // aur: {minVal:'',maxVal:''},
        salesPerformance: "0",
        unitPerformance: "0"
    }
    static filterContext = null;

    static updateFilterContext(context) {
        this.filterContext = context;
    }

    static frameDCSInput = (dcsSet) => {
        this.filterContext.updateFilterInputs({dcs: [...dcsSet].map(k=>({name:k,value:k}))});
    }

    static frameZoneInput = (zone) => {
        this.filterContext.updateFilterInputs({zone: [...zone]});
    }

    static filterDCS=(rowData,dcs)=>{
        return dcs?rowData.hyphenatedDcs === dcs:true;
    }

    static filterZone=(rowData,zone)=>{
        return zone?rowData === zone:true;
    }

    static filterVendor=(rowData,vendor)=>{
        return vendor?rowData.hyphenatedDcs === vendor:true;
    }

    static filterAnchorSku = (rowData, specialDesignation) => {
        return specialDesignation ? (specialDesignation.includes("Anchor SKU") ? rowData.isAnchorSku : true) : true;
    }
    static isAnchorFilterApplied = (selectedFilters) => {
        return selectedFilters.isFilterApplied && selectedFilters.specialDesignation &&  selectedFilters.specialDesignation.includes("Anchor SKU");
    }
  
    static filterRetailMode =(rowData,retailMode)=> {

        let allowMin = true;
        let allowMax = true;
        if (retailMode.minVal) {
            allowMin = rowData.mostCommonRetail >= retailMode.minVal;
        }
        if (retailMode.maxVal) {
            allowMax = rowData.mostCommonRetail <= retailMode.maxVal;
        }
        return allowMin && allowMax;
    }
    // static filterPriceRange =(rowData,priceRange)=>{
    //
    //     let allowMin = true;
    //     let allowMax = true;
    //     if(priceRange.minVal){
    //         allowMin = rowData.minRetail >= priceRange.minVal;
    //     }
    //     if(priceRange.maxVal){
    //         allowMax = rowData.maxRetail <= priceRange.maxVal;
    //     }
    //     return allowMin && allowMax;
    // }
    
    //   static filterAur =(rowData,aurVal)=>{
    //
    //     let allowMin = true;
    //     let allowMax = true;
    //     if(aurVal.minVal){
    //         allowMin = rowData.aur >= aurVal.minVal;
    //     }
    //     if(aurVal.maxVal){
    //         allowMax = rowData.aur <= aurVal.maxVal;
    //        }
    //     return allowMin && allowMax;
    // }


    static filterSalesPerformance=(rowData,salesPerformance)=>{
        if (salesPerformance > 0)
            return rowData.compPercentage > 0;
        else if (salesPerformance < 0)
            return rowData.compPercentage < 0;
        else
            return true;
    }

    static filterUnitPerformance=(rowData,unitPerformance)=>{
        if (unitPerformance > 0)
            return rowData.unitsPercentage > 0;
        else if (unitPerformance < 0)
            return rowData.unitsPercentage < 0;
        else
            return true;
    }

    static filterData=(rowData)=>{
        return this.filterDCS(rowData,this.filterContext.selectedFilters.dcs) &&
            this.filterAnchorSku(rowData, this.filterContext.selectedFilters.specialDesignation) &&
            this.filterSalesPerformance(rowData,this.filterContext.selectedFilters.salesPerformance) &&
            this.filterUnitPerformance(rowData,this.filterContext.selectedFilters.unitPerformance)&&
        //this.filterZone(rowData,this.filterContext.selectedFilters.zone) &&
        // this.filterVendor(rowData,this.filterContext.selectedFilters.vendor) &&
        this.filterRetailMode(rowData,this.filterContext.selectedFilters.retailMode)
        // this.filterPriceRange(rowData,this.filterContext.selectedFilters.priceRange)&&
        // this.filterAur(rowData,this.filterContext.selectedFilters.aur)
    }

    static checkIfFilterIsApplied = (defaultFilterValue,currentFilterValue,excludeList) => {
        let isFilterApplied = false;
        excludeList = [...excludeList,...["isFilterApplied"]];
        if(currentFilterValue){
            Object.keys(currentFilterValue).some(eachFilter => {
                if(!excludeList.includes(eachFilter)){
                    let currentValue = currentFilterValue[eachFilter];
                    let defaultValue = defaultFilterValue[eachFilter];

                    if(defaultValue instanceof Array){
                        if( defaultValue.length !== currentValue.length || !defaultValue.every(v => currentValue.includes(v)) ) {
                            isFilterApplied = true;
                        }
                    }else if(defaultValue !== currentValue){
                        isFilterApplied = true;
                    }
                }
                return isFilterApplied;

            });
        }

        return isFilterApplied;

    };

}
