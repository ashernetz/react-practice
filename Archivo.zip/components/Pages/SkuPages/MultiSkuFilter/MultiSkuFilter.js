import React, {useContext, useEffect, useState} from 'react';
import {Button, Checkbox, Col, Divider, Drawer, Form, Input, Layout, Row, Select, Space, Typography} from 'antd';
import "./MultiSkuFilter.scss";
import {isMobile} from 'react-device-detect';
import Radio from 'antd/lib/radio';
import MultiSkuFilterContext from "../../../../context/MultiSkuFilterContext";
import MultiSkuFilterHelper from "./MultiSkuFilterHelper";

const {Text}=Typography;
const {Content} = Layout;
const {Option} = Select;

let FILTER_TYPES = {
  "DCS":{isAllow:(searchType,isOnline)=>searchType !== "DCS","fields":[{"name":"dcs","span":24,"type":"select"}]},
  // "Zone":{isAllow:(searchType,isOnline)=>searchType === "DCS" && !isOnline,"fields":[{"name":"zone","span":24,"type":"select"}],"visible":false},
  //"Vendor":{isAllow:(searchType,isOnline)=>searchType === "VNDR","fields":[{"name":"vendor","span":24,"type":"select"}]},
  "Dollar Sales Performance":{"fields":[{"name":"salesPerformance","span":24,"type":"radio"}]},
  "Unit Sales Performance":{"fields":[{"name":"unitPerformance","span":24,"type":"radio"}]},
  //"CPI":{"fields":[{"name":"cpi","span":24,"type":"select"},{"name":"cpiRange","span":12,"type":"range"}]},

  "Retail":{"fields":[
     // {"name":"priceRange","span":12,"type":"range",title:"Price Range"},
     // {"name":"aur","span":12,"type":"range",title:"AUR"},
     {"name":"retailMode","span":12,"type":"range",title:"Retail Mode"}]},

  // "Cost (Invoice)":{"fields":[
  //     {"name":"costRange","span":12,"type":"range",title:"Cost Range"},
  //     {"name":"costMean","span":12,"type":"range",title:"Cost Mean"},
  //     {"name":"costMode","span":12,"type":"range",title:"Cost Mode"}]},
  //
  // "IMU":{"fields":[{"name":"imu","span":24,"type":"range"}]},
  // "Gross Margin":{"fields":[{"name":"grossMargin","span":24,"type":"range"}]},
  "Special Designation":{"fields":[{"name":"specialDesignation","span":24,"type":"checkbox"}]},
}

const checkboxOnChange = (checkedValues) => {
  console.log('checked = ', checkedValues);
}

const specialDesignationOptions = [
 // { label: 'KVI', value: 'KVI' },
  { label: 'Anchor SKU', value: 'Anchor SKU' },
//  { label: 'Favorite', value: 'Favorite' },
];

const DropDownSelect = ({field={}},props) => {
  return(<Form.Item name={field.name}>
      <Select
          style={{ width: 332 }}
          size="large"
          placeholder=""
          optionFilterProp="children"
      >
          {(field.input?field.input:[]).map(k=> <Option key={k.value} value={k.value}>{k.name}</Option>)}
      </Select>
      </Form.Item>
  );
}

const MinAndMaxRange = ({field={}},props) => {
  return(
      <Space size={8}>
        <Form.Item name ={[field.name,'minVal']} >
          <Input type="number" placeholder="$Min" size="large" style={{width:'84px'}} />
        </Form.Item>
        <Form.Item>
         <Text >to</Text>
        </Form.Item>
        <Form.Item name ={[field.name,'maxVal']} >
          <Input type="number" placeholder="$Max" size="large" style={{width:'84px'}}/>
        </Form.Item>
      </Space>

  );
}

const RadioComponent = ({field={}},props) => {
  return(
      <Form.Item name={field.name}>
          <Radio.Group>
            <Radio.Button value="1">Positive</Radio.Button>
            <Radio.Button value="-1">Negative</Radio.Button>
            <Radio.Button value="0">Both</Radio.Button>
          </Radio.Group>
      </Form.Item>
  );
}

const CheckboxComponent = ({field={}},props) => {
  return(
      <Space align="start" direction="vertical" size="small">
        <Form.Item name={field.name}>
          <Checkbox.Group options={specialDesignationOptions} defaultValue={[]} onChange={checkboxOnChange} />
        </Form.Item>
      </Space>
  );
}

const BottomComponent = (props) => {
  return(
      <Row align="middle" className='multi-sku-bottom-component'>
        <Col style={{paddingRight:'73px'}}>
          <Button disabled={props.clearAllDisable} onClick={()=>props.clearFilter()}>Clear All</Button>
        </Col>
        <Col>
          <Row align="middle">
            <Col><Button onClick={()=> props.filterCancel()}>Cancel</Button></Col>
            <Col style={{paddingLeft:'20px'}}><Button htmlType="submit" disabled={props.disable} form="filter-form-id" >Apply</Button> </Col>
          </Row>
        </Col>
      </Row>
  );
}

const getFormItem = (field) => {
  let component = null;
  let type = field.type;
  switch(type) {
    case "select":
      component= <DropDownSelect field={field}/>;break;
    case "radio":
      component= <RadioComponent field={field}/>;break;
    case "range":
      component= <MinAndMaxRange field={field}/>;break;
    case "checkbox":
      component= <CheckboxComponent field={field}/>;break;
    default:
      component= "";
  }
  return component;
}

const MultiSkuFilter = (props) => {

    const filterContext = useContext(MultiSkuFilterContext);
    const [form] = Form.useForm();
    const [isFilterApplied,setIsFilterApplied] = useState(false);


    useEffect(()=>{
        if(filterContext.selectedFilters.isFilterApplied){
            setIsFilterApplied(true);
            form.setFieldsValue({...filterContext.selectedFilters});

        }
    },[filterContext.selectedFilters])

  return (
      <Drawer
          placement='right'
          closable={false}
          onClose={props.onClose}
          open={true}
          mask={true}
          width={isMobile ? 280 : 380}
          footer = {<BottomComponent clearAllDisable = {!(filterContext.selectedFilters.isFilterApplied || isFilterApplied)} disable = {!isFilterApplied} clearFilter={ ()=>{form.resetFields(); props.onClose(); filterContext.clearFilterSelection()}} filterCancel={()=>  props.onClose()}/>}

      >
        <Row className='multi-sku-filter-heading'  align="middle">
          <Col><Text id="multi-sku-filter-title" strong>Filters</Text></Col>
        </Row>
        <Divider className="multi-sku-dividerNoGap" />
        <Form
            id="filter-form-id"
            form={form}
            initialValues={MultiSkuFilterHelper.SELECTED_FILTERS_INITIAL_VALUES}
            onValuesChange = {(changedVales,allValues)=>{setIsFilterApplied(MultiSkuFilterHelper.checkIfFilterIsApplied(MultiSkuFilterHelper.SELECTED_FILTERS_INITIAL_VALUES,allValues,[]))}}
            onFinish={(values)=>{
              filterContext.updateFilterSelection({...values,isFilterApplied:true});
              props.onClose();
            }}>
        <Content style={{paddingLeft:'24px',paddingRight:'24px',paddingTop:'10px'}}>
          <Space align="start" direction="vertical" size="small">
              {Object.keys(FILTER_TYPES).filter(k=>FILTER_TYPES[k].isAllow? FILTER_TYPES[k].isAllow(props.searchType,props.isOnline):true).map(mainLabel=>{
                return(  <>
                <Space align="start" direction="vertical" size="small">
                  <Text className="multi-sku-label">{mainLabel}</Text>
                  <Row>
                    {FILTER_TYPES[mainLabel].fields.map(field=>
                        <Col span={field.span}>
                          {field.title && <Row gutter={[0,8]}><Col>{field.title}</Col></Row>}
                          <Row><Col>{getFormItem({...field,
                            input: filterContext.filterInputs[field.name]
                           //  input:(filterContext.filterInputs[field.name] == "zone" ? filterContext.filterInputs[field.name].map(k => k.zoneName) : filterContext.filterInputs[field.name])
                          })}</Col></Row>
                        </Col>
                    )}
                      {mainLabel !== "Special Designation" && <Divider type="horizontal" className="multi-sku-dividerNoGap"/>}
                  </Row>
                  {/*<Row><Col span={24}><Divider type="horizontal" className="multi-sku-dividerNoGap"/></Col></Row>*/}
                </Space>
              </>)
            })
            }
          </Space>
        </Content>
        </Form>

      </Drawer>
  );
};

export default MultiSkuFilter;
