import SingleAndMultiSkuServices from "../../../../services/SingleAndMultiSkuServices";

export default class SingleSkuCardApiHelper {
    static fetchInStoreCostData (sku,availableStores,setCardData){
        let maxCost=0,minCost=0,modeCost=0,modeCount=0,priceMap;
        SingleAndMultiSkuServices.getInvoiceCostForSkuStoreList(availableStores.map((store)=>({sku,store})))
            .then(resp=>{
            if(resp.status === 200 ) {
                let res = resp.data;
                if(res.length){
                 priceMap = res.reduce( (total, current) => {
                       if(current.cost) {
                           total.set(current.cost, (total.get(current.cost) || 0) + 1)
                       };
                        return total;
                    }, new Map());
                    priceMap.forEach((value,key)=>{
                                maxCost = (maxCost === 0 || key > maxCost) ? key : maxCost;
                                minCost = (minCost === 0 || key < minCost) ? key : minCost;
                        if (value >= modeCount) {
                                if (value !== modeCount || (value === modeCount && key < modeCost)) {
                                    modeCount = value;
                                    modeCost = key;
                                }
                            }

                    });
                }
            }
        }).catch(err=>
            console.log(err)
        ).finally(k=> {
            setCardData(prev => ({...prev,inStore:{...prev.inStore,costData:{maxCost,minCost,modeCost,costPoints:priceMap && priceMap.size}}}))
        });

    }


    static fetchRegionalAssortmentData = (sku,setCardData) => {
        let assortmentData = {regionallyAssorted:"-"};
        SingleAndMultiSkuServices.fetchRegionallyAssortedSkuData(sku)
            .then(k=>{
                assortmentData.regionallyAssorted=k.data.regionallyAssorted ? 'Yes' : 'No'})
            .catch(err=>console.log(err))
            .finally(k=>{
                setCardData(prev => ({...prev,online:{...prev.online,assortmentData}}));
            });
    }

}
