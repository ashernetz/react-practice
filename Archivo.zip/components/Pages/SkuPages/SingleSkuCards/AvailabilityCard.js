import React, {useState} from 'react';
import '../CommonCards/CommonCards.scss';
import { Row, Col, Space } from 'antd';
import {CardRowItem, CardTitle, NormalBold} from '../CommonCards/CardItems';
import CompUtil from '../../../Utils/CompUtil';
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import MultipleVendorDetectedModal from "../MultipleVendorDetectedModal/MultipleVendorDetectedModal";
import { Card } from '../../../GlobalComponents/Card/Card'

const VendorItem = ({multiVendorList,getAllSkusforDCSView}) => {

    const [showMultipleVendor, setShowMultipleVendor] = useState(false);

    let vendorList = multiVendorList;
    let vendorText = <UXSpin/>;

    if(multiVendorList !== "-"){

        if(vendorList.length === 0){
            vendorText = <NormalBold value="N/A"/>
        }else if(vendorList.length === 1){
            let vendorNumber = vendorList[0].vendorNumber;
            let vendorName = vendorList[0].vendorName;
            vendorText = <Space direction="vertical" size={0} onClick={()=>getAllSkusforDCSView("",vendorNumber,vendorName)}>
                <a className="col-vendor-name">{vendorName}</a> {/*eslint-disable-line*/}
                <a className="col-vendor-number">{"#"+vendorNumber}</a> {/*eslint-disable-line*/}
            </Space>
        }else {
            vendorText = <a className="col-vendor-name" onClick={()=>{ setShowMultipleVendor(true); }}>MULTIPLE VENDORS</a>}{/*eslint-disable-line*/}
    }
    return <>{vendorText}
        {showMultipleVendor &&
            <MultipleVendorDetectedModal
                isOpen={showMultipleVendor}
                onClose={() => setShowMultipleVendor(false)}
                onVendorCardClick = {(vendorNumber,vendorName)=>{getAllSkusforDCSView("",vendorNumber,vendorName);

                }}
                multiVendorList={multiVendorList}
            />}</>;
};

const AvailabilityCard = (props) => {

  let {cardData} = props;
  return(
    <Card title="AVAILABILITY">
      {props.selectedType === "inStore" && <Row gutter={[8, 8]}>
        <CardRowItem
          name="Store Assorted"
          value={cardData.assortedStores?cardData.assortedStores:"spin"}
          type="NB"
        />
        <CardRowItem
          name="Daily ISS%"
          value={cardData.dailyISS ?(cardData.dailyISS !=="-"?`${CompUtil.formatPrice(cardData.dailyISS)}%`:cardData.dailyISS):"spin"}
          type="NB"
        />
      </Row>}
      <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
        {props.selectedType === "inStore" &&
          <CardRowItem
            name="Active Stores"
            value={cardData.activeStores?cardData.activeStores:"spin"}
            type="NB"
          />
        }
        <CardRowItem
          name="Active Vendor"
          span={24}
          value={<VendorItem multiVendorList={cardData.multiVendorList}
            getAllSkusforDCSView={props.getAllSkusforDCSView}
          />}
        />
      </Row>
    </Card>
  );
};
export default AvailabilityCard;
