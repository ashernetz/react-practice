import React, { useState} from 'react';
import '../CommonCards/CommonCards.scss';
import { Row, Col, Typography, Modal, Divider, Button } from 'antd';
import { CardRowItem } from '../CommonCards/CardItems';
import { Card } from '../../../GlobalComponents/Card/Card'

const { Text } = Typography;

const SellabilityModal = ({onClose}) => {
  return(
      <Modal
          title={<Text className="sellability-modal-title">2 Sellability Issue</Text>}
          className="sellability-modal"
          open={true}
          onCancel={onClose}
          footer={null}>

        <Row  gutter={[0,16]} style={{marginBottom: "16px"}}>
          <Col>
            <Row gutter={[0,4]} style={{marginBottom: "4px"}}><Col><Text className="sellability-content-head-text">Pending S-Type Conversion</Text></Col></Row>
            <Row gutter={[0,4]} style={{marginBottom: "4px"}}><Col><Text className="sellability-content-text">The Atlanta FDC does not support S-Type SKU’s.</Text></Col></Row>
          </Col>
        </Row>
        <Row  gutter={[0,16]} style={{marginBottom: "16px"}}>
          <Col span={24}>
            <Divider/>
          </Col>
        </Row>
        <Row  gutter={[0,16]} style={{marginBottom: "16px"}} justify="space-between">
          <Col span={18}>
            <Row><Col><Text className="sellability-content-head-text">SKU Store in DC Area has 0.00 Retail</Text></Col></Row>
            <Row><Col><Text className="sellability-content-text">Retail must be set up for this SKU to be sellable.</Text></Col></Row>
          </Col>
          <Col span={6}><Button>Resolve in Pacman</Button></Col>
        </Row>
      </Modal>
  );
};

const AssortmentCard = (props) => {

    const [sellabilityModalOpen, setSellabilityModalOpen] = useState(false);

    return(
        props.selectedType === "online" && <><Card title="ASSORTMENT">
          <Row gutter={[8, 8]}>
            <CardRowItem name="Regionally Assorted" type="NB" value={props.assortmentData.regionallyAssorted}/>
          </Row>
        </Card>
            {sellabilityModalOpen && <SellabilityModal onClose={()=>setSellabilityModalOpen(false)}/>}
        </>
    );
};
export default AssortmentCard;
