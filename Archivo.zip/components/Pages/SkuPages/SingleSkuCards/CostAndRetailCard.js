import React, {useContext} from 'react';
import '../CommonCards/CommonCards.scss';
import { Row, Col, Divider, Typography } from 'antd';
import {CardRowItem, CardTitle} from '../CommonCards/CardItems';
import CompUtil from "../../../Utils/CompUtil";
import { minMaxRetailFormatter} from "../../../Utils/CommonUtil";
import SkuContext from "../../../../context/SkuContext";
import { Card } from '../../../GlobalComponents/Card/Card'

const { Text } = Typography;

const CostAndRetailCard = (props) => {
  const context = useContext(SkuContext);

  const minMaxRetail = context.skuData.minMaxPriceRange ? minMaxRetailFormatter(
          context.skuData.minMaxPriceRange[0],
          context.skuData.minMaxPriceRange[1]) : "";

  const totalPricePointCount = context.skuData.pricePointRelevantCount ? context.skuData.pricePointRelevantCount : " ";

  const mostCommonRetail= context.skuData.mostCommonRetails
      ? context.skuData.mostCommonRetails[0] ? "$"
          + CompUtil.formatPrice(Number.parseFloat(context.skuData.mostCommonRetails[0])) : "-" : "";
  let retail = props.singleSkuHeaderData.effectiveRetail;
  let cost = props.singleSkuHeaderData.effectiveCost === undefined ? "-" : props.singleSkuHeaderData.effectiveCost;

  let promoPriceDiff = props.singleSkuHeaderData.permRetail- props.singleSkuHeaderData.effectiveRetail;

  let calPromoPercentage = ((promoPriceDiff/props.singleSkuHeaderData.permRetail)*100).toFixed(2);

  let promotionType =  props.singleSkuHeaderData.retailType;

  let permRetail = props.singleSkuHeaderData.permRetail;

  let modeInvoiceCost = props.costData ? (props.costData.modeCost?'$'+CompUtil.formatPrice(props.costData.modeCost/100):"-"): "spin";
  let minMaxCost = props.costData ? ((props.costData.minCost && props.costData.maxCost) ? minMaxRetailFormatter(
      props.costData.minCost/100,
      props.costData.maxCost/100):"-") : "spin";


    const StrikeThroughPricing = () => {
    return(
        <>
          <Row gutter={[8,0]} >
            <Col>
              <Text className="col-item-value">{retail?`$${CompUtil.formatPrice(retail)}`:""}</Text>
            </Col>
            <Col>
              <Text delete className="col-item-title">{permRetail?`$${CompUtil.formatPrice(permRetail)}`:""}</Text>
            </Col>
          </Row>
          <Row>
            <Col span={24}>
              <Divider className="strike-through-divider"/>
            </Col>
          </Row>
          <Row gutter={[8,0]}>
            <Col>
              <Text className="col-item-title">{promoPriceDiff?`-$${CompUtil.formatPrice(promoPriceDiff)}`:""}</Text>
            </Col>
            <Col>
              <Text className="col-item-title">{'(-'+calPromoPercentage+'%)'}</Text>
            </Col>
          </Row>
        </>
    );
  };

  return(
    <Card title="COST & RETAIL">
      {props.selectedType === 'online' ?
        <Row gutter={[8, 8]}>
          {promotionType === "PROMOTION" ?
          <CardRowItem
            name="Online Retail"
            value={<StrikeThroughPricing/>}
          />:
          <CardRowItem
            name="Online Retail"
            type="NB"
            value={retail?(retail !== "-"?`$${CompUtil.formatPrice(retail)}`:retail):"spin"}
          />}
          <CardRowItem
            name="Online Cost"
            type="NB"
            value={cost?(cost !== "-"?`$${CompUtil.formatPrice(cost)}`:cost):"spin"}
          />
        </Row>
      :
        <Row gutter={[0, 8]}>
          <CardRowItem
            name="Mode Retail"
            type="NB"
            value={mostCommonRetail||"spin"}
          />
          <CardRowItem
            name={totalPricePointCount+" Price Points"}
            type="NB"
            value={minMaxRetail||"spin"}
          />
         <CardRowItem
           name={"Mode Invoice Cost"}
           type="NB"
           value={modeInvoiceCost}
         />
         <CardRowItem
           name={(props.costData ? (props.costData.costPoints || ""): "") +" Invoice Costs"}
           type="NB"
           value={minMaxCost}
         />
        </Row>
      }
    </Card>
  );
};
export default CostAndRetailCard;
