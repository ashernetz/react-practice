import React from 'react';
import {Space} from "antd";
import CostAndRetailCard from "./CostAndRetailCard";
import AvailabilityCard from "./AvailabilityCard";
import PerformanceCard from "../CommonCards/PerformanceCard";
import CompetitiveCard from "../CommonCards/CompetitiveCard";
import AssortmentCard from "./AssortmentCard";
import { DCAssortmentCard } from '../CommonCards/DCAssortmentCard'

const SingleSkuCards = (props) => {

    let {requiredCardData,selectedType,compsAndUnitsFormatterWithoutArrow,getAllSkusforDCSView} = props;
    return(
        <Space direction="horizontal" size="large" id="aggregated-card-size" >
          <PerformanceCard
              performanceData = {requiredCardData}
              compsAndUnitsFormatterWithoutArrow ={compsAndUnitsFormatterWithoutArrow}
              isSingleSkuPage={true}
          />
          {selectedType === 'inStore' &&
          <CompetitiveCard
              cpiData = {requiredCardData.cpiData}
          />
          }
          <CostAndRetailCard
              singleSkuHeaderData = {requiredCardData}
              selectedType = {selectedType}
              costData = {props.cardData[selectedType].costData}
          />
          <AvailabilityCard
              cardData = {requiredCardData}
              selectedType = {selectedType}
              getAllSkusforDCSView={getAllSkusforDCSView}
          />
          <AssortmentCard
              loadedSku = {props.loadedSku}
              assortmentData={props.cardData.online.assortmentData || "spin"}
              selectedType = {selectedType}/>
          <DCAssortmentCard
            myAssortmentBaseUrl={props.config.myAssortmentBaseUrl}
            maxSkusLimit={props.config.OARSkuLimit}
            skus={[props.loadedSku]}
          />
        </Space>

    );
}

export default SingleSkuCards;
