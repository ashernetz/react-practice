import React, {useContext} from 'react';
import {Button, Col, Layout, Row} from "antd";
import {trackEvent} from "../../../Utils/mixpanel";
import SkuContext from "../../../../context/SkuContext";
import "./SingleSkuPage.scss";

const {Footer} = Layout;

const SingleSkuPageFooter = (props) => {
    const context = useContext(SkuContext);

    let {selectedType,userAccess,verifyAccessToken,setShowOnlineEditPrice,setShowEditPrice}=props;

    return (<><Footer id="single-sku-page-footer">
        <Row justify="end">
            {selectedType === "online" && userAccess.isOnlineEditEnabled?
                <Col><Button
                    onClick={()=>{
                        verifyAccessToken();
                        setShowOnlineEditPrice(flag=>!flag);
                        trackEvent("CLICKED_ONLINE_EDIT_PRICE_FROM_ONLINE_SINGLE_SKU_PAGE");
                    }}
                    key="submit"
                    type="primary"
                    ghost='true'
                    block>
                    Change Price </Button></Col>: ""}
            {selectedType === "inStore" && context.skuData.allowExecution && context.skuData.allowZonePriceChange ?
                <Col><Button
                    onClick={()=>{
                        verifyAccessToken();
                        setShowEditPrice(flag=>!flag);
                        trackEvent("CLICKED_EDIT_PRICE_FROM_IN_STORE_SINGLE_SKU_PAGE");
                    }}
                    key="submit"
                    type="primary"
                    ghost='true'
                    block>
                    Change Price </Button></Col> : ""}
        </Row>
    </Footer></>)
}

export default SingleSkuPageFooter;
