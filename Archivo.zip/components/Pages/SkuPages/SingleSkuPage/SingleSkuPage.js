import React, {Fragment, useContext, useEffect, useState,useRef} from 'react';
import { Col, Layout, Row, Typography} from 'antd';
import { useHistory, useLocation } from 'react-router-dom';

import "./SingleSkuPage.scss";
import OnlineSkuDetailsPageHeader from '../../../ProductSearchComponents/OnlinePageHeader';
import OnlineSingleSkuTabs from '../../../ProductSearchComponents/OnlineSingleSkuTabs/OnlineSingleSkuTabs';
import InStoreSingleSkuTabs from '../../../ProductSearchComponents/InStoreSingleSkuTabs/InStoreSingleSkuTabs';
import SkuContext from "../../../../context/SkuContext";
import CompUtil from "../../../Utils/CompUtil";
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import AlertUtil from "../../../Utils/AlertUtil";
import SingleSkuApiHelper from "../../../Helper/SingleSkuApiHelper";
import SkuInfoPage from "../../LandingPage/SkuInfoPage";
// import NoSkuImage from "../../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
// import UXImage    from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import {convertSearchTextToItemList} from "../../../Utils/CommonUtil";
// import SvgUtil from "../../../Utils/SvgUtil";
import SingleAndMultiSkuServices from "../../../../services/SingleAndMultiSkuServices";
// import {trackEvent} from "../../../Utils/mixpanel";
import MultipleOmsidsDetectedModal
    from "./../MultipleOmsidsDetectedModal/MultipleOmsidsDetectedModal";
import SandwichComponents from "./SandwichComponents";
import CardDataApiHelper from "../SingleSkuCards/SingleSkuCardApiHelper";
import SingleSkuCardApiHelper from "../SingleSkuCards/SingleSkuCardApiHelper";
import { DCAssortmentProvider } from '../../../DCAssortment/DCAssortmentProvider'

const {Text} = Typography;
const {Content} = Layout;
const onlineHeaderData = {
    dcsTitle: "",
    omsIdTitle: "",
    omsIdList: "",
    skuTitle: "",
    minMaxRetail: "",
    onHandQuantity: "",
    totalThisYearSales: "",
    totalCompPercentage: "",
    totalThisYearUnits: "",
    totalUnitsPercentage: "",
    fiscalWeek: "",
    vendorName: "",
    vendorNumber:"",
    effectiveRetail: "",
    effectiveCost: "",
    skuDescription: "",
    skuImageUrl:"",
    multiVendorList:"-",
};

const inStoreHeaderData = {totalThisYearSales: "", totalCompPercentage: "", totalThisYearUnits: "", totalUnitsPercentage: "",dailyISS: "",  multiVendorList:"-",cpiData:null};

const initialState = {
    inStoreMultiSkuData: {skuRetailList: []},
    singleSkuHeaderData: {"online": {...onlineHeaderData}, "inStore": {...inStoreHeaderData}},
    singleSkuLoadInfo: {
        onlineSku: 0,
        inStoreSku: 0,
        selectedType: "online",
        isOnlineLoaded: "",
        isInStoreLoaded: "",
        isMixed: false,
        onlineSkuImageUrl:"-",
        inStoreSkuImageUrl:"-"

    }
};


const compsAndUnitsFormatter = (input, rowJustify = "start") => {
    let compOrUnitValue = CompUtil.findPercentageUpOrDown(input);
    return (!input && input !== "-" ? <UXSpin/> :
        <Row justify={rowJustify} gutter={[4, 0]}>
        <Col>
          <Text className={compOrUnitValue && "comp-units-" + compOrUnitValue}>
            {CompUtil.formatPrice(CompUtil.formatCompData(input))}
          </Text>
        </Col>
        <Col>{CompUtil.getArrowUpDownComponent(compOrUnitValue)}</Col>
    </Row>)
};

const isMapView = (location) => {
  return location.pathname.toLowerCase().includes('map')
}

const SingleSkuPage = (props) => {
    const context = useContext(SkuContext);
    const [skuRank, setSkuRank] = useState([]);
    const [singleSkuLoadInfo,setSingleSkuLoadInfo] = useState({...initialState.singleSkuLoadInfo});
    const [selectedType, setSelectedType] = useState("inStore");
    const [onlineMultiOMSIdData,setOnlineMultiOMSIdData] = useState({data:{},isOnlineLoaded:"",isInStoreLoaded:"",isModalOpen:false});
    const [singleSkuHeaderData, setSingleSkuHeaderData] = useState({"online": {...onlineHeaderData}, "inStore": {...inStoreHeaderData}});
    const [skuTimelineMap, setSkuTimelineMap] = useState({});
    const location = useLocation()
    const [isShowMap, setIsShowMap] = useState(isMapView(location));
    const [skuZonePerformanceData, setSkuZonePerformanceData] = useState({data:"",is5xx:false});
    const [onlineSalesPerformanceData, setOnlineSalesPerformanceData] = useState({data:"",is5xx:false});
    const [inStoreSalesPerformanceData, setInStoreSalesPerformanceData] = useState({data:"",is5xx:false});
    const timeTransformInitialRender = useRef(true);
    const [storeList, setStoreList] = useState(null);
    const [regionalAssortment,setRegionalAssortment] = useState({regionallyAssorted:"spin"});
    const [cardData,setCardData] = useState({online:{assortmentData:null},inStore:{costData:null}});
    const history = useHistory();

    useEffect(() => {
        context.updateDailyISS(singleSkuHeaderData.inStore.dailyISS);
    }, [singleSkuHeaderData.inStore.dailyISS])

    useEffect(()=>{
        if(singleSkuLoadInfo.isInStoreLoaded === false){
            setSelectedType("online");
        }
        if(singleSkuLoadInfo.isOnlineLoaded !== "" && singleSkuLoadInfo.isInStoreLoaded !== ""){
            context.updateShowDimmer(false);
        }
        if(singleSkuLoadInfo.isOnlineLoaded === false && singleSkuLoadInfo.isInStoreLoaded === false){
            AlertUtil.showAlert("error", "Error",<div>No valid SKU or OMSId present</div>);
            props.updateShowNewDashboardView(true);
        }
    },[singleSkuLoadInfo.isOnlineLoaded,singleSkuLoadInfo.isInStoreLoaded]);

    useEffect(()=>{
        history.replace(isShowMap ? `/s/${props.skuOrOmsId}/map` : `/s/${props.skuOrOmsId}`);
    }, [isShowMap])

  useEffect(() => {
    if (timeTransformInitialRender.current) {
      timeTransformInitialRender.current = false;
    } else {
      if (context.skuNumber) {
        let skuNumber = Number.parseInt(context.skuNumber);
        setSkuZonePerformanceData({data: "", is5xx: false});
        SingleSkuApiHelper.getZonePerformanceData(skuNumber,props.user.userId,setSkuZonePerformanceData);
        setSingleSkuHeaderData(k => ({
          ...k, "inStore": {
            ...k.inStore, totalThisYearSales: "",
            totalCompPercentage: "",
            totalThisYearUnits: "",
            totalUnitsPercentage: "",
            // cpiData:null
          }
        }));
        SingleSkuApiHelper.fetchSingleSkuPerformance([skuNumber], props.user.userId, false,setSingleSkuHeaderData,context.updateInStoreSkuPerformance);
        // SingleSkuApiHelper.getInStoreCPIDataForSKU(skuNumber,props.user.userId,setSingleSkuHeaderData);
      }

      if (singleSkuHeaderData.online.skuTitle) {
        let skuNumber = Number.parseInt(singleSkuHeaderData.online.skuTitle);

        setSingleSkuHeaderData(k => ({
          ...k, "online": {
            ...k.online, totalThisYearSales: "",
            totalCompPercentage: "",
            totalThisYearUnits: "",
            totalUnitsPercentage: ""
          }
        }));
        SingleSkuApiHelper.fetchSingleSkuPerformance([skuNumber], props.user.userId, true, setSingleSkuHeaderData);

      }    }

  }, [context.timeTransformType]);


    useEffect(() => {
        let {skuNumberList,omsIdList} = convertSearchTextToItemList(props.skuOrOmsId);
        if (skuNumberList.length > 0 || omsIdList.length>0) {
            context.updateShowDimmer(true);
            resetState();
            let selectedType = "inStore";
            let alertMessage = "";
            SingleAndMultiSkuServices.determineSellingChannel(skuNumberList,omsIdList)
                .then(({data:responseData=null}) => {
                    if (responseData && responseData.onlineSkus && responseData.coreSkus) {
                    if (Object.keys(responseData.onlineSkus).length === 0 && Object.keys(responseData.coreSkus).length === 0) {
                        alertMessage = <div>No valid SKU or OMSId present</div>;

                    } else {

                        if (Object.keys(responseData.coreSkus).length > 0) {
                            inStoreSingleSkuMainApiTrigger(responseData);
                        } else {
                            setSingleSkuLoadInfo(info=>  ({...info,isInStoreLoaded:false}));
                            setIsShowMap(false);
                        }
                        if (Object.keys(responseData.onlineSkus).length > 0) {
                          onlineSingleSkuMainApiTrigger(responseData);
                        } else {
                          SingleSkuApiHelper.checkForMultipleOMSScenario(responseData,setOnlineMultiOMSIdData,setSingleSkuLoadInfo,onMultiOMSIdSkuClick,"online");
                          selectedType = "inStore";
                          // setSingleSkuLoadInfo(info=>  ({...info,isOnlineLoaded:false}));

                        }

                    }
                }
                    else
                    {
                        alertMessage = <div>No valid SKU or OMSId present</div>;
                    }

                    setSelectedType(selectedType);
            }).catch(err => {
                console.log("Error occurred while calling SellingChannelAPI " + err);
                alertMessage = AlertUtil.getErrorMessage(
                    "calling selling channel API");


            }).finally(()=>{
                if(alertMessage){
                    context.updateShowDimmer(false);
                    AlertUtil.showAlert("error", "Error", alertMessage);
                    props.updateShowNewDashboardView(true);
                }
            });

        }else {
            if(props.skuOrOmsId){
                AlertUtil.showAlert("error", "Error", <div>No valid SKU or OMSId present</div>);
                props.updateShowNewDashboardView(true);
            }
        }
    }, [props.skuOrOmsId]);

    useEffect(()=>{
        setIsShowMap(isMapView(location));
    }, [location.pathname])

     function onlineSingleSkuMainApiTrigger(responseData){
        let skuObject = Object.values(responseData.onlineSkus)[0];
        let imageUrl = skuObject.imgSourcePath?skuObject.imgSourcePath.replace("_145.","_400."):"";
        setSingleSkuHeaderData(data =>({...data,"online": {...onlineHeaderData}}));
        setSingleSkuLoadInfo(info=>  ({...info,onlineSku:skuObject.skuNumber,onlineSkuImageUrl:imageUrl,skuRatingCount:0,skuRatingValue:0}));
        SingleSkuApiHelper.fillSkuRatingData(skuObject,setSingleSkuLoadInfo);
        SingleSkuApiHelper.fetchSingleSkuOnlineData(responseData,onlineSingleSkuAdditionalApiTriggers, setSingleSkuHeaderData,setSingleSkuLoadInfo);
        SingleSkuApiHelper.fetchMultipleVendor(skuObject.skuNumber,true,setSingleSkuHeaderData);
        SingleAndMultiSkuServices.fetchSkuRank([skuObject.skuNumber]).then(rank => {setSkuRank(rank.data);
        });
    }
    
    function onlineSingleSkuAdditionalApiTriggers(skuList,omsIdVendorObject) {
        //SingleSkuApiHelper.fetchOnlineOhQuantity(skuList, setSingleSkuHeaderData);
        SingleSkuApiHelper.getOnlineRetailTimelineData(skuList,omsIdVendorObject,setSkuTimelineMap);
        SingleSkuApiHelper.fetchSingleSkuPerformance(skuList, props.user.userId, true, setSingleSkuHeaderData);
        SingleSkuApiHelper.fetchSalesPerformanceData(skuList[0],props.user.userId,true,setOnlineSalesPerformanceData);
        SingleSkuCardApiHelper.fetchRegionalAssortmentData(skuList[0],setCardData);
        localizedRetailStoreAPITrigger(skuList[0]);
    }

    function localizedRetailStoreAPITrigger(skuNumber){
        setStoreList(null);
        SingleSkuApiHelper.fetchLocalizedRetailStores(skuNumber,setStoreList);
    }

     function inStoreSingleSkuMainApiTrigger(responseData){
        let skuObject = Object.values(responseData.coreSkus)[0];
        let imageUrl = skuObject.imgSourcePath?skuObject.imgSourcePath.replace("_145.","_400."):"";
        setSingleSkuLoadInfo(info=>  ({...info,inStoreSku:skuObject.skuNumber,inStoreSkuImageUrl:imageUrl}));
        SingleSkuApiHelper.getZonePerformanceData(skuObject.skuNumber,props.user.userId,setSkuZonePerformanceData);
        SingleSkuApiHelper.fetchSingleSkuPerformance([skuObject.skuNumber], props.user.userId, false, setSingleSkuHeaderData,context.updateInStoreSkuPerformance);
        SingleSkuApiHelper.fetchDailyInStockSalesData(skuObject.skuNumber,setSingleSkuHeaderData);
        SingleSkuApiHelper.fetchSalesPerformanceData(skuObject.skuNumber,props.user.userId,false,setInStoreSalesPerformanceData);
        SingleSkuApiHelper.fetchMultipleVendor(skuObject.skuNumber,false,setSingleSkuHeaderData);
        SingleSkuApiHelper.getInStoreCPIDataForSKU(skuObject.skuNumber,props.user.userId,setSingleSkuHeaderData);
        SingleAndMultiSkuServices.fetchSkuRank([skuObject.skuNumber]).then(rank => {setSkuRank(rank.data);
        });
    }

    const resetState = () => {
      setSingleSkuLoadInfo({...initialState.singleSkuLoadInfo});
      setSelectedType("inStore");
      setOnlineMultiOMSIdData({data:{},isOnlineLoaded:"",isInStoreLoaded:"",isModalOpen:false});
      setSingleSkuHeaderData({"online": {...onlineHeaderData}, "inStore": {...inStoreHeaderData}});
      setSkuTimelineMap({});
      setIsShowMap(isMapView(location));
      setSkuZonePerformanceData({data:"",is5xx:false});
      setOnlineSalesPerformanceData({data:"",is5xx:false});
      setInStoreSalesPerformanceData({data:"",is5xx:false});
      setCardData({online:{assortmentData:null},inStore:{costData:null}});
    };

    function onMultiOMSIdSkuClick (sku,sellingChannelData,selectedType,isDirect) {
        let fetchKeysOrder=selectedType === "online" ? ["onlineSkus","coreSkus"]:["coreSks","onlineSks"];
        let isOnlineOrInStoreLoad = selectedType === "online"? "isOnlineLoaded": "isInStoreLoaded";
        context.updateShowDimmer(true);
        setOnlineMultiOMSIdData(k=>({...k,isModalOpen: false,[isOnlineOrInStoreLoad]: isDirect?false:true}));
        setSingleSkuLoadInfo(k=>({...k,[isOnlineOrInStoreLoad]:""}));
        if(!isDirect){setSelectedType(selectedType);}
        let responseData = {...sellingChannelData};
        responseData[fetchKeysOrder[0]] = Object.keys(responseData[fetchKeysOrder[0]])
            .filter(k=>k===sku.toString())
            .reduce((acc,item)=>{acc[item]=responseData[fetchKeysOrder[0]][item]; return acc;},{});

        if(selectedType === "online"){
            onlineSingleSkuMainApiTrigger(responseData);
        }
    }
    const onSellingChannelChange=(value)=>{
        if (value === "online" && onlineMultiOMSIdData.isOnlineLoaded === true) {
            setOnlineMultiOMSIdData(k => ({...k, isModalOpen: true}));
        } else {
            if(selectedType!==value){setSelectedType(value)}
        }

    };

  const getAllSkusforDCSView = (formattedDCS,vendorNumber,vendorName) => {


    let data = {};
    if(vendorNumber){
      data = {
        searchType: "VNDR",
        vendorNumber: vendorNumber?vendorNumber:0,
        vendorName:vendorName?vendorName:"",
        isOnlineVendor:selectedType === "online"};
    }else {
      let dcsKey= formattedDCS.split(" ");

      data = {
        classNumber: Number.parseInt(dcsKey[1].replace(/\D/g,'')),
        department: Number.parseInt(dcsKey[0].replace(/\D/g,'')),
        searchType: "DCS",
        subClassNumber: Number.parseInt(dcsKey[2].replace(/\D/g,''))
      }
    }
    props.diverseMultiSearch(data,vendorNumber?"VENDOR_VIEW_FROM_SKU_DETAILS_"+vendorNumber+"_"+formattedDCS:"DCS_VIEW_FROM_SKU_DETAILS_"+formattedDCS,context.updateShowDimmer);
};

    return (
        <Fragment>
            {singleSkuLoadInfo.inStoreSku ? <SkuInfoPage user={props.user}
                                      config={props.config}
                                      style={{padding: 0}}
                                      searchSku={singleSkuLoadInfo.inStoreSku} isShowMap={isShowMap}
                                      backToSkuDetails={() => setIsShowMap(false)}
                                      backToHome={()=>props.updateShowNewDashboardView(true)}
                                      verifyAccessToken = {props.verifyAccessToken}
                                      updateShowNewDashboardView={() => {}}
                                      setSingleSkuLoadInfo={setSingleSkuLoadInfo}
                                      getAllSkusforDCSView={getAllSkusforDCSView}
                                      multiVendorList={singleSkuHeaderData.inStore.multiVendorList}
                                      headerData = {{mainHeading:"SKU Map"}}
                                      setCardData = {setCardData}
                                        />: null}
            {onlineMultiOMSIdData.isModalOpen &&

            <MultipleOmsidsDetectedModal
                onlineMultiSkuData = {onlineMultiOMSIdData.data?onlineMultiOMSIdData.data.onlineSkus:[]}
                onClose={()=>(setOnlineMultiOMSIdData(k=>({...k,isModalOpen: false})))}
                onSkuClick={(sku)=>{
                    onMultiOMSIdSkuClick(sku,onlineMultiOMSIdData.data,"online",false)}}/>}
            {!isShowMap &&
            <Layout id="single-sku-page-layout">


                <OnlineSkuDetailsPageHeader
                    headerData = {{mainHeading:"SKU Details"}}
                    backArrowClick={(k) => props.updateShowNewDashboardView(true)}/>

                <Content id="single-sku-page-content">
                  <DCAssortmentProvider skuId={singleSkuLoadInfo.inStoreSku}>
                    <SandwichComponents
                        singleSkuHeaderData = {singleSkuHeaderData[selectedType]}
                        skuRank = {skuRank}
                        selectedType = {selectedType}
                        compsAndUnitsFormatter ={compsAndUnitsFormatter}
                        singleSkuLoadInfo={singleSkuLoadInfo}
                        userAccess = {props.user.accesses}
                        userId = {props.user.userId}
                        config = {props.config}
                        verifyAccessToken = {props.verifyAccessToken}
                        getAllSkusforDCSView = {getAllSkusforDCSView}
                        onPriceMapButtonClick = {()=>setIsShowMap(true)}
                        onSellingChannelChange = {onSellingChannelChange}
                        onlineMultiOMSIdData={onlineMultiOMSIdData}
                        cardData = {cardData}>

                        {/*<Row justify="space-between" style={{height:'115px'}}>*/}
                            {/*<SingleSkuDetailHeader*/}
                            {/*                    singleSkuHeaderData = {singleSkuHeaderData[selectedType]}*/}
                            {/*                    selectedType = {selectedType}*/}
                            {/*                    singleSkuLoadInfo={singleSkuLoadInfo}*/}
                            {/*                    skuRating = {{count:singleSkuLoadInfo.skuRatingCount,value:singleSkuLoadInfo.skuRatingValue}}*/}
                            {/*                   getAllSkusforDCSView = {getAllSkusforDCSView}*/}
                            {/*                    onPriceMapButtonClick = {onPriceMapButtonClick}*/}
                            {/*                    onSellingChannelChange = {onSellingChannelChange}*/}
                            {/*    />*/}
                            {/*</div>*/}
                            {/*<Col sm={24} xxl={10}>*/}
                            {/*    <Row gutter={[32, 16]}>*/}
                            {/*        <Col className="SSproductImageCol" xl={6} xxl={10} style={{textAlign: "center", padding: "8px 24px 8px 24px"}}>*/}
                            {/*           */}
                            {/*            {singleSkuLoadInfo[selectedType+"SkuImageUrl"] !== "-" ?*/}
                            {/*                <div>{selectedType==="inStore" && <FavoriteButton isInStoreFav={true}/>}*/}
                            {/*                <UXImage*/}
                            {/*                    classNames = "sku-image-large"*/}
                            {/*                    imageUrl={singleSkuLoadInfo[selectedType+"SkuImageUrl"] ? singleSkuLoadInfo[selectedType+"SkuImageUrl"]:NoSkuImage}/></div>*/}
                            {/*                : <div className="sku-image-large"><UXSpin/></div>}*/}
                            {/*        </Col>*/}
                            {/*        <Col xl={16} xxl={14}>*/}
                            {/*            <Row gutter={[56, 8]} align="middle">*/}
                            {/*                <Col>*/}
                            {/*                    <Radio.Group*/}
                            {/*                         onChange={(e) => {onSellingChannelChange(e.target.value);trackEvent("CLICKED_SINGLE_SKU_PAGE_TOGGLE_BUTTON",{"value":e.target.value})}}*/}
                            {/*                         value={selectedType}>*/}
                            {/*                      <Radio.Button*/}
                            {/*                          onClick = {(e)=>{onSellingChannelClick(e.target.value)}}*/}
                            {/*                          disabled={!onlineMultiOMSIdData.isOnlineLoaded && !singleSkuLoadInfo.isOnlineLoaded} value="online">*/}
                            {/*                        Online {singleSkuLoadInfo.isOnlineLoaded=== ""?<UXSpin fontSize={14}/>:""}*/}
                            {/*                      </Radio.Button>*/}
                            {/*                      <Radio.Button*/}
                            {/*                          disabled={!singleSkuLoadInfo.isInStoreLoaded} value="inStore">*/}
                            {/*                        In Store {singleSkuLoadInfo.isInStoreLoaded=== ""?<UXSpin fontSize={14}/>:""}*/}
                            {/*                      </Radio.Button>*/}
                            {/*                    </Radio.Group>*/}
                            {/*                </Col>*/}
                            {/*                {selectedType === "inStore" &&*/}
                            {/*                <Col>*/}
                            {/*                  <Button*/}
                            {/*                      id="single-sku-show-map"*/}
                            {/*                      type="default"*/}
                            {/*                      onClick={() => {setIsShowMap(true);trackEvent("CLICKED_SHOW_MAP_BUTTON_FROM_SINGLE_SKU_PAGE")}}*/}
                            {/*                      icon={SvgUtil.getMapShowIcon({svgStyle:{verticalAlign:'-4px',marginRight:'5px',fill:'#767676'}})}>*/}
                            {/*                    Show Map</Button>*/}
                            {/*                </Col>*/}
                            {/*                }*/}

                            {/*            </Row>*/}
                            {/*            <SingleSkuInfoCard*/}
                            {/*                singleSkuHeaderData = {singleSkuHeaderData[selectedType]}*/}
                            {/*                selectedType = {selectedType}*/}
                            {/*                skuRating = {{count:singleSkuLoadInfo.skuRatingCount,value:singleSkuLoadInfo.skuRatingValue}}*/}
                            {/*                compsAndUnitsFormatter ={compsAndUnitsFormatter}*/}
                            {/*                editPriceSkuImg={singleSkuLoadInfo}*/}
                            {/*                userAccess = {props.user.accesses}*/}
                            {/*                userId = {props.user.userId}*/}
                            {/*                config = {props.config}*/}
                            {/*                verifyAccessToken = {props.verifyAccessToken}*/}
                            {/*                getAllSkusforDCSView = {getAllSkusforDCSView}*/}
                            {/*          />*/}
                            {/*        </Col>*/}
                            {/*    </Row>*/}
                            {/*</Col>*/}
                        {/*</Row>*/}

                        <Row gutter={[0, 56]}>
                            <Col span={24} className="sandwich-row-content">
                                {selectedType === "online" ?
                                    <OnlineSingleSkuTabs
                                        singleSkuHeaderData = {singleSkuHeaderData[selectedType]}
                                        skuTimelineMap={skuTimelineMap}
                                        skuNumber={singleSkuLoadInfo.onlineSku}
                                        userId={props.user.userId}
                                        storeList={storeList}
                                        salesPerformanceData={onlineSalesPerformanceData}
                                        onLocalizedTabClick={(skuNumber) => localizedRetailStoreAPITrigger(skuNumber)}
                                        onVendorClick = {(vendorNumber,vendorName)=>getAllSkusforDCSView(singleSkuHeaderData[selectedType].dcsTitle,vendorNumber,vendorName)}
                                    /> :
                                    <InStoreSingleSkuTabs
                                        skuNumber={singleSkuLoadInfo.inStoreSku}
                                        userId={props.user.userId}
                                        salesMetricsData={context.salesMetricsMap["salesMetricBoxPlotList"]}
                                        zoneRowsPerformanceData = {skuZonePerformanceData}
                                        compsAndUnitsFormatter={compsAndUnitsFormatter}
                                        salesPerformanceData={inStoreSalesPerformanceData}
                                        singleSkuCPIData={singleSkuHeaderData.inStore.cpiData}/>}

                            </Col>
                        </Row>
                    </SandwichComponents>
                  </DCAssortmentProvider>

                </Content>
                {/*<SingleSkuPageFooter*/}
                {/*    headerData = {singleSkuHeaderData[selectedType]}*/}
                {/*    selectedType = {selectedType}*/}
                {/*    compsAndUnitsFormatter ={compsAndUnitsFormatter}*/}
                {/*    editPriceSkuImg={singleSkuLoadInfo}*/}
                {/*    userAccess = {props.user.accesses}*/}
                {/*    userId = {props.user.userId}*/}
                {/*    config = {props.config}*/}
                {/*    verifyAccessToken = {props.verifyAccessToken}*/}
                {/*    />*/}
                {/*<Footer id="single-sku-page-footer">*/}
                {/*    <Row justify="end"><Col><Button>Edit Price</Button></Col></Row>*/}
                {/*</Footer>*/}
            </Layout>}</Fragment>

    );
};

export default SingleSkuPage;
