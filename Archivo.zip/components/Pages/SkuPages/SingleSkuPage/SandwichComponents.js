import React, {Fragment, useContext, useState} from 'react';
import {Col, Row, Typography} from "antd";
import {dcsFormatter, minMaxRetailFormatter} from '../../../Utils/CommonUtil';
import CompUtil from "../../../Utils/CompUtil";
import ModifyPriceModal from "../../../ModifyPriceModal/ModifyPriceModal";
import OnlineEditPriceModal from "../../../ProductSearchComponents/OnlineEditPriceModal/OnlineEditPriceModal"
import SingleSkuDetailHeader from "./SingleSkuDetailHeader";
import SkuContext from "../../../../context/SkuContext";
import SingleSkuPageFooter from "./SingleSkuPageFooter";
import SingleSkuCards from "../SingleSkuCards/SingleSkuCards";
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";

const {Text} = Typography;


const compsAndUnitsFormatterWithoutArrow = (input) => {
    let compOrUnitValue = CompUtil.findPercentageUpOrDown(input);
    return (!input && input !== "-" ? <UXSpin/> :
                <Text strong className={compOrUnitValue && "comp-units-" + compOrUnitValue}>
                   {compOrUnitValue === "arrow-up" ? ("+"+CompUtil.formatPrice(CompUtil.formatCompData(input))):CompUtil.formatPrice(CompUtil.formatCompData(input))}
                </Text>)
};
const SandwichComponents = (props) => {

    const context = useContext(SkuContext);
    const [showEditPrice,setShowEditPrice] =  useState(false);
    const [showOnlineEditPrice,setShowOnlineEditPrice] =  useState(false);
    let  {singleSkuHeaderData, skuRank, selectedType,compsAndUnitsFormatter,singleSkuLoadInfo,userAccess,config,userId,verifyAccessToken ,getAllSkusforDCSView,onPriceMapButtonClick,onSellingChannelChange, onlineMultiOMSIdData } = props;

    const getInStoreHeaderData = () => {
        return {
            dcsTitle: dcsFormatter(context.skuData.departmentNumber,context.skuData.classNumber, context.skuData.subClassNumber),
            skuTitle: context.skuNumber,
            skuDescription: context.skuDescription,
            minMaxRetail: context.skuData.minMaxPriceRange ? minMaxRetailFormatter(
                context.skuData.minMaxPriceRange[0],
                context.skuData.minMaxPriceRange[1]) : "",
            totalPricePointCount: context.skuData.pricePointRelevantCount,
            mostCommonRetail: context.skuData.mostCommonRetails
                ? context.skuData.mostCommonRetails[0] ? "$"
                    + CompUtil.formatPrice(Number.parseFloat(context.skuData.mostCommonRetails[0])) : "-" : "-",
            vendorName: context.skuVendors?context.skuVendors:(context.skuVendors===""?"NO ACTIVE VENDORS":"-"),
            assortedStores : singleSkuLoadInfo.isInStoreLoaded ? context.skuData.totalStoreCount?
                (context.skuData.availableStores.length + "/" + context.skuData.totalStoreCount):"-":"",
            activeStores : singleSkuLoadInfo.isInStoreLoaded ? context.skuData.assortedActiveStoreCount ?
                (context.skuData.assortedActiveStoreCount + "/" + context.skuData.totalStoreCount):"-":""
        }
    };

    let headerData = singleSkuHeaderData;

    if (selectedType === "inStore") {
        headerData = {...singleSkuHeaderData,...getInStoreHeaderData()};
    }

    return (
        <Fragment>
                <Row id="single-sku-page-header" align="middle" justify="space-between" >
                    <SingleSkuDetailHeader headerData={headerData}
                                           skuRank={skuRank}
                                           selectedType={selectedType}
                                           singleSkuLoadInfo={singleSkuLoadInfo}
                                           getAllSkusforDCSView={getAllSkusforDCSView}
                                           onPriceMapButtonClick={onPriceMapButtonClick}
                                           onSellingChannelChange={onSellingChannelChange}
                                           onlineMultiOMSIdData = {onlineMultiOMSIdData}
                    />
                </Row>
            <Row gutter={[0, 56]} className="single-sku-card-x-scroll">
                <Col span={24} className="sandwich-row-content">
                    <SingleSkuCards
                        config={config}
                        loadedSku = {singleSkuLoadInfo.onlineSku||singleSkuLoadInfo.inStoreSku}
                        requiredCardData={headerData}
                        selectedType={selectedType}
                        getAllSkusforDCSView={getAllSkusforDCSView}
                        compsAndUnitsFormatterWithoutArrow={compsAndUnitsFormatterWithoutArrow}
                        cardData = {props.cardData}
                    />
                </Col>
            </Row>
            {props.children}
            <SingleSkuPageFooter
                selectedType={selectedType}
                userAccess={userAccess}
                verifyAccessToken={verifyAccessToken}
                setShowOnlineEditPrice={setShowOnlineEditPrice}
                setShowEditPrice={setShowEditPrice}/>
            {/*<Row>*/}
            {/*            /!*Commenting  out condition && headerData.vendorNumber !==0 to disable Edit price button if there is no active vendor*!/*/}
            {/*            {selectedType === "online" && userAccess.isOnlineEditEnabled?*/}
            {/*                <Col><Button*/}
            {/*                    onClick={()=>{*/}
            {/*                        verifyAccessToken();*/}
            {/*                        setShowOnlineEditPrice(flag=>!flag);*/}
            {/*                        trackEvent("CLICKED_ONLINE_EDIT_PRICE_FROM_ONLINE_SINGLE_SKU_PAGE");*/}
            {/*                    }}*/}
            {/*                    key="submit"*/}
            {/*                    size="large"*/}
            {/*                    type="primary"*/}
            {/*                    ghost='true'*/}
            {/*                    block*/}
            {/*                    className="edit-price-button">*/}
            {/*                    Edit Price </Button></Col>: ""}*/}
            {/*            {selectedType === "inStore" && context.skuData.allowExecution && context.skuData.allowZonePriceChange ?*/}
            {/*                <Col><Button*/}
            {/*                    onClick={()=>{*/}
            {/*                        verifyAccessToken();*/}
            {/*                        setShowEditPrice(flag=>!flag);*/}
            {/*                        trackEvent("CLICKED_EDIT_PRICE_FROM_IN_STORE_SINGLE_SKU_PAGE");*/}
            {/*                    }}*/}
            {/*                    key="submit"*/}
            {/*                    size="large"*/}
            {/*                    type="primary"*/}
            {/*                    ghost='true'*/}
            {/*                    block*/}
            {/*                    className="edit-price-button">*/}
            {/*                    Edit Price </Button></Col> : ""}*/}
            {/*        </Row>*/}
                    {/*<Row>*/}
                    {/*    <Col span={24}>*/}
                    {/*        <OnlineItemProperties*/}
                    {/*            totalThisYearSales={headerData.totalThisYearSales}*/}
                    {/*            totalCompPercentage={headerData.totalCompPercentage}*/}
                    {/*            totalThisYearUnits={headerData.totalThisYearUnits}*/}
                    {/*            totalUnitsPercentage={headerData.totalUnitsPercentage}*/}
                    {/*            isOnline={selectedType==="online"}*/}
                    {/*            isSingleSku={true}*/}
                    {/*            assortedStores = {headerData.assortedStores}*/}
                    {/*            compsAndUnitsFormatter={compsAndUnitsFormatter}*/}
                    {/*            onHandQuantity={headerData.onHandQuantity}*/}
                    {/*            dailyISSData={headerData.dailyISS}*/}
                    {/*            activeStores ={headerData.activeStores}/>*/}
                    {/*    </Col>*/}
                    {/*</Row>*/}
            {showEditPrice && <ModifyPriceModal
                isAddNew
                isOpen={showEditPrice}
                onClose={()=> setShowEditPrice(false)} /> }
            {showOnlineEditPrice &&
                <OnlineEditPriceModal
                    isAddNew
                    isOpen={showOnlineEditPrice}
                    onClose={() => setShowOnlineEditPrice(false)}
                    compsAndUnitsFormatter={compsAndUnitsFormatter}
                    headerData={headerData}
                    isOnline={selectedType==="online"}
                    isSingleSku={true}
                    config =  {config}
                    userId = {userId}
                    editPriceSkuImg={singleSkuLoadInfo[selectedType+"SkuImageUrl"]}/>}
        </Fragment>);
};

export default SandwichComponents;
