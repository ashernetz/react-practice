import React from 'react';
import {Button, Col, Typography, Radio, Space, Image, Tooltip} from "antd";
import {trackEvent} from "../../../Utils/mixpanel";
import SkuRating from "../../../ProductSearchComponents/SkuRating/SkuRating";
import NoSkuImage from "../../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import {UXSpin} from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";


const {Text} = Typography;

const SingleSkuDetailHeader =(props) =>{

    let {headerData,skuRank,selectedType,singleSkuLoadInfo,getAllSkusforDCSView, onPriceMapButtonClick,onSellingChannelChange, onlineMultiOMSIdData} = props;

    const TopSKUTooltip = () =>{
        return (
            <Tooltip arrowPointAtCenter title = {info} placement ='right' color="#ffffff"
                     overlayClassName="cpi-tooltip-arrow"
                     overlayInnerStyle={{
                         padding: '20px',
                         width: '250px',
                         height: '240px',
                         marginLeft: '0px',
                     }}
            >
                <div className="top-skus">
                    <span class="trophy-icon" > 
                        { skuRank[0].rank <= 20000 ? 
                         <img
                            className="top20K-trophy"
                            src={require("../../../../images/top20KTrophyIcon.svg").default}
                        />
                        :
                        <img
                            className="top100K-trophy"
                            src={require("../../../../images/top100KTrophyIcon.svg").default}
                        />
                        }
                    </span>
                </div>
            </Tooltip>
        )
    };

    const info = () => {
        return (
            <>
                <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>{skuRank[0].rank <= 20000 ? "Top 20K SKU" : "Top 100K SKU"}</p>
                <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>Rank: { skuRank[0].rank}</p>
                <p style={{color: 'black', marginTop: '-5px'}}>Based on annual R12 enterprise (online and in-store) sales dollars, this SKU is within the top {skuRank[0].rank <= 20000 ? "20,000" : "100,000"} across The Home Depot USA. Top SKUs are updated quarterly.</p>
             </>
        )
    }



    return (
        <>
            <Col>
                <Space size="small" >
                    <div>
                        {singleSkuLoadInfo[selectedType+"SkuImageUrl"] !== "-" ?
                        <Image src={singleSkuLoadInfo[selectedType+"SkuImageUrl"] ? singleSkuLoadInfo[selectedType+"SkuImageUrl"]:NoSkuImage}
                               alt="Image" height="100px" width="100px"/>
                        :<UXSpin/>}
                    </div>
                    <div>
                        <Space direction="vertical"
                               size="small"
                        >
                            <Space size="middle" align="center" className="sku-detail-row">
                                <Text className="sku-detail-text">SKU# {headerData.skuTitle}</Text>
                                {selectedType === 'online'?
                                    <>
                                        <Text className="sku-detail-text">|</Text>
                                        <Text className="sku-detail-text">{headerData.omsIdTitle}</Text>
                                    </>
                                    :null}
                                <a type="link" className="dcs-text" onClick={()=> {trackEvent("CLICKED_DCS_FROM_"+(selectedType === "online"?"ONLINE" : "INSTORE") +"_SINGLE_SKU_PAGE",{"dcs":headerData.dcsTitle});getAllSkusforDCSView(headerData.dcsTitle)}}>{headerData.dcsTitle?headerData.dcsTitle.replaceAll("-","").replaceAll(" "," | "):""}</a> {/*eslint-disable-line*/}
                                <SkuRating count={singleSkuLoadInfo.skuRatingCount} value={singleSkuLoadInfo.skuRatingValue}/>
                                <a className="website-link-text" target="_blank" href={"https://www.homedepot.com/s/"+ headerData.skuTitle} onClick={()=>trackEvent("CLICKED_VIEW_WEBSITE_FROM_SINGLE_SKU_PAGE")}>View on website</a>{/*eslint-disable-line*/}
                                {skuRank.length != 0 ? <div class="top-skus"> <TopSKUTooltip/> </div> : null}
                            </Space>
                            <Space size="large">
                                <Text className="sku-description">{headerData.skuDescription}</Text>
                                <Radio.Group
                                    size="middle"
                                    onChange={(e) => {onSellingChannelChange(e.target.value);trackEvent("CLICKED_SINGLE_SKU_PAGE_TOGGLE_BUTTON",{"value":e.target.value})}}
                                    value={selectedType}>
                                    <Radio.Button
                                        disabled={!onlineMultiOMSIdData.isOnlineLoaded && !singleSkuLoadInfo.isOnlineLoaded}
                                        value="online">
                                        Online {singleSkuLoadInfo.isOnlineLoaded=== ""?<UXSpin fontSize={14}/>:""}
                                    </Radio.Button>
                                    <Radio.Button
                                        disabled={!singleSkuLoadInfo.isInStoreLoaded}
                                        value="inStore">
                                        In Store {singleSkuLoadInfo.isInStoreLoaded=== ""?<UXSpin fontSize={14}/>:""}
                                    </Radio.Button>
                                </Radio.Group>
                            </Space>
                        </Space>
                    </div>
                </Space>
            </Col>
            {selectedType === "inStore" &&
                <Col className="price-map-button-col">
                        <Button
                            onClick={() => {
                                onPriceMapButtonClick();
                                trackEvent("CLICKED_SHOW_MAP_BUTTON_FROM_SINGLE_SKU_PAGE")
                            }}
                            type="primary"
                            ghost='true'
                            size="middle"
                            block>
                            View Price Map </Button>
                </Col>
            }
        </>


    )
};
export default SingleSkuDetailHeader;
