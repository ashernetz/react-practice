import React from 'react'
import '@testing-library/jest-dom'
import { Modal, message } from 'antd'
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import noop from 'lodash/noop'

import EditSkuGroupModal from "./EditSkuGroupModal";
import SkuGroupService from "../../../../services/SkuGroupService";

jest.mock('../../../../services/SkuGroupService', () => ({
  __esModule: true,
  default: {
    updateSkuGroup: jest.fn().mockResolvedValue({
      status: 200,
      data: 'Sku Group Updated Successfully',
    }),
    deleteSkuGroups: jest.fn().mockResolvedValue({
      status: 200,
      data: 'Sku Group Deleted Successfully',
    })
  },
}));

const skuGroupData ={
  isPLS: false,
  groupName: 'jxb2169',
  groupDescription: 'rick',
  skuNumbers: [521351, 239296],
  zoneGroupMultiplierId: null,
  skuGroupId: '515461d7-52c8-45f6-8654-4b21c747b3a1',
}

const getProps = (props = {}) => ({
  userId: 'mc62ye',
  skuGroupData,
  onClose: jest.fn(),
  onSkuGroupUpdate: jest.fn(),
  onSkuGroupDelete: jest.fn(),
  ...props,
})

describe('EditSkuGroupModal', () => {
  afterEach(Modal.destroyAll)

  it('renders default state', () => {
    render(<EditSkuGroupModal {...getProps({ skuGroupData: {} })} />);

    expect(screen.getByText("Group Name")).toBeInTheDocument();
    expect(screen.getByText("Group Description")).toBeInTheDocument();
    expect(screen.getByText("SKUs")).toBeInTheDocument();
    expect(screen.getByText('Delete Group')).toBeInTheDocument();
    expect(screen.getByText('Cancel')).toBeInTheDocument();
    expect(screen.getByText('Save')).toBeInTheDocument();
    expect(screen.getByText('Save').closest('button')).toBeDisabled();
  })

  it('render modal with sku group data', () => {
    render(<EditSkuGroupModal {...getProps()} />);

    expect(screen.queryByDisplayValue('jxb2169')).toBeInTheDocument();
    expect(screen.queryByDisplayValue('rick')).toBeInTheDocument();
  })

  it('enable save button on sku group name change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupName), {
      target: {value: 'test'},
    });
    expect(screen.getByText('Save').closest('button')).toBeEnabled();
  })

  it('disable save button on sku group name change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupName), {
      target: {value: 'test$%^'},
    });
    expect(screen.getByText('Save').closest('button')).toBeDisabled();
  })

  it('enable save button on sku group description change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupDescription), {
      target: {value: 'test'},
    });
    expect(screen.getByText('Save').closest('button')).toBeEnabled();
  })

  it('disable save button on sku group description change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupDescription), {
      target: {value: 'test@#$'},
    });
    expect(screen.getByText('Save').closest('button')).toBeDisabled();
  })

  it('enable save button on sku number change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.skuNumbers), {
      target: {value: '123456,786523'},
    });
    expect(screen.getByText('Save').closest('button')).toBeEnabled();
  })

  it('disable save button on sku number change', () => {
    render(<EditSkuGroupModal {...getProps()} />);
    fireEvent.change(screen.getByDisplayValue(skuGroupData.skuNumbers), {
      target: {value: '1234abc'},
    });
    expect(screen.getByText('Save').closest('button')).toBeDisabled();
  })

  it.each([
    ['group name', 'jxb2169'],
    ['group description', 'rick'],
    ['sku list', '521351,239296'],
  ])('does nothing if %s is empty', async (name, displayValue) => {
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    fireEvent.change(screen.getByDisplayValue(displayValue), {
      target: { value: '' },
    });

    await waitFor(noop)

    expect(props.onClose).not.toHaveBeenCalled()
    expect(SkuGroupService.updateSkuGroup).not.toHaveBeenCalled()
    expect(SkuGroupService.deleteSkuGroups).not.toHaveBeenCalled()
  });

  it('handle cancel or modal close function', () => {
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    expect(screen.getByText('Cancel')).toBeInTheDocument()
    fireEvent.click(screen.getByText(/Cancel/i))
    expect(props.onClose).toHaveBeenCalled();
  })

  it('render delete sku group modal', async () => {
    render(<EditSkuGroupModal {...getProps()} />);

    expect(screen.getByText('Delete Group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Delete Group'))

    await waitFor(() => {
      expect(screen.queryByText("Delete SKU Group?")).toBeInTheDocument();
    })

    expect(screen.getByText("Permanently deleting this SKU group will redirect you to the dashboard.")).toBeInTheDocument();
    expect(screen.getAllByText('Cancel').length).toEqual(2);
    expect(screen.getByText('OK')).toBeInTheDocument();
  })

  it('handle delete group popup OK button', async () => {
    const messageSuccessSpy = jest.spyOn(message, 'success')
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    fireEvent.click(screen.getByText('Delete Group'))

    await waitFor(() => {
      expect(screen.queryByText("Delete SKU Group?")).toBeInTheDocument();
      expect(screen.queryByText('OK')).toBeInTheDocument()
    })

    fireEvent.click(screen.getByText('OK'))

    await waitFor(() => {
      expect(SkuGroupService.deleteSkuGroups).toHaveBeenCalledWith([skuGroupData.skuGroupId]);
    })

    expect(props.onClose).toHaveBeenCalled()
    expect(props.onSkuGroupDelete).toHaveBeenCalled()
    expect(messageSuccessSpy).toHaveBeenCalledWith(expect.objectContaining({
      content: 'Successfully Deleted SKU Group',
    }))
  })

  it('shows error message if delete sku group is failed ', async () => {
    SkuGroupService.deleteSkuGroups.mockRejectedValueOnce(
      new Error('Something went wrong')
    )
    const messageErrorSpy = jest.spyOn(message, 'error')
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    fireEvent.click(screen.getByText('Delete Group'))

    await waitFor(() => {
      expect(screen.queryByText("Delete SKU Group?")).toBeInTheDocument();
      expect(screen.queryByText('OK')).toBeInTheDocument()
    })

    fireEvent.click(screen.getByText('OK'))

    await waitFor(() => {
      expect(SkuGroupService.deleteSkuGroups).toHaveBeenCalledWith([skuGroupData.skuGroupId]);
    })

    expect(props.onSkuGroupDelete).not.toHaveBeenCalled()
    expect(props.onClose).toHaveBeenCalled()
    expect(messageErrorSpy).toHaveBeenCalledWith(expect.objectContaining({
      content: 'Unable to Delete SKU Group',
    }))
  });

  it('handle delete group popup Cancel button', async () => {
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    expect(screen.getByText('Delete Group')).toBeInTheDocument()
    fireEvent.click(screen.getByText('Delete Group'))

    await waitFor(() => {
      expect(screen.queryByText("Delete SKU Group?")).toBeInTheDocument();
      expect(screen.queryAllByText('Cancel').length).toEqual(2)
    })

    fireEvent.click(screen.getAllByText('Cancel')[1]);

    expect(props.onClose).toHaveBeenCalled();
  })

  it('handle edit group popup Save button', async () => {
    const messageSuccessSpy = jest.spyOn(message, 'success')
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupName), {
      target: {value: 'test'},
    });
    fireEvent.click(screen.getByText('Save'));
    const updatedSkuGroupPartial = {
      groupName: 'test',
      lastUpdatedUser: 'mc62ye',
    };

    await waitFor(() => {
      expect(SkuGroupService.updateSkuGroup).toHaveBeenCalledWith(
        expect.objectContaining(updatedSkuGroupPartial)
      );
    })

    expect(props.onClose).toHaveBeenCalled()
    expect(props.onSkuGroupUpdate).toHaveBeenCalledWith(
      expect.objectContaining(updatedSkuGroupPartial)
    )
    expect(messageSuccessSpy).toHaveBeenCalledWith(expect.objectContaining({
      content: 'Successfully Edited SKU Group',
    }))
  })

  it('shows error message if update group is failed', async () => {
    SkuGroupService.updateSkuGroup.mockRejectedValueOnce(
      new Error('Something went wrong')
    )
    const messageErrorSpy = jest.spyOn(message, 'error')
    const props = getProps()
    render(<EditSkuGroupModal {...props} />);

    fireEvent.change(screen.getByDisplayValue(skuGroupData.groupName), {
      target: { value: 'test' },
    });
    fireEvent.click(screen.getByText('Save'));

    await waitFor(() => {
      expect(SkuGroupService.updateSkuGroup).toHaveBeenCalledWith(
        expect.objectContaining({ groupName: 'test' })
      );
    })

    expect(props.onSkuGroupUpdate).not.toHaveBeenCalled()
    expect(props.onClose).not.toHaveBeenCalled()
    expect(messageErrorSpy).toHaveBeenCalledWith(expect.objectContaining({
      content: 'Unable to Edit SKU Group',
    }))
  });
})
