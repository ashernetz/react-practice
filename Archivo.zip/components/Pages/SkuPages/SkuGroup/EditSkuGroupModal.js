import React, { useState } from "react";
import {
  Row,
  Col,
  Modal,
  Input,
  Typography,
  Space,
  Button,
  message

} from "antd";
import "./EditSkuGroupModal.scss";
import {ExclamationCircleOutlined} from "@ant-design/icons";
import SkuGroupService from "../../../../services/SkuGroupService";
import {isGroupNameValid} from "../../../Utils/SkuGroupUtil";

const {Text} = Typography;
const {TextArea} = Input;

const EditSkuGroupModal = (props) => {


  const [skuGroup, setSkuGroup] = useState({
    skuGroupId: props.skuGroupData.skuGroupId,
    groupName: props.skuGroupData.groupName,
    groupDescription: props.skuGroupData.groupDescription,
    skuNumbers: props.skuGroupData.skuNumbers,
    lastUpdatedUser: props.userId
  });

  const [isSaveButtonDisabled, setSaveButtonDisabled] = useState(true);

  const handleSkuInput = (value) => {
    if (!value) {
      setSkuGroup({...skuGroup, skuNumbers: []})
      return
    }
    const numberCheck = /^[0-9,\n]*$/;
    if (numberCheck.test(value)) {
      const skuNumbers = value.split(/[ ,\n]+/).map(k => k.trim());
      setSkuGroup({ ...skuGroup, skuNumbers });
      setSaveButtonDisabled(false);
    }
  }

  const handleGroupName = (value,key) => {
    if (!value) {
      setSkuGroup({...skuGroup, [key]: ''})
      return
    }
    if (!isGroupNameValid(value)) {
      setSkuGroup({ ...skuGroup, [key]: value });
      setSaveButtonDisabled(false);
    }
  };

  const filterSkuNumbers = () =>{
    setSkuGroup(prev => ({...prev, skuNumbers: prev.skuNumbers.filter(sku => sku)}));
  }


  const saveSkuGroup = async () => {
    setSaveButtonDisabled(true);
    try {
      await SkuGroupService.updateSkuGroup(skuGroup);
      props.onClose();
      props.onSkuGroupUpdate(skuGroup);
      message.success({
        content: 'Successfully Edited SKU Group',
        className: "edit-group-success-message",
        duration: 2,
      });
    } catch(error) {
      const errorMsg = (error.response && error.response.status === 400) ? error.response.data : 'Unable to Edit SKU Group';
      message.error({
        content: errorMsg,
        className: "edit-group-error-message",
        duration: 2,
      });
    }
  }

  const deleteGroup = () =>{
    props.onClose();
    Modal.confirm({
      title: "Delete SKU Group?",
      icon: <ExclamationCircleOutlined />,
      className:"delete-sku-group-modal",
      onOk() {
        deleteSkuGroup(skuGroup.skuGroupId);
      },
      content: (
        <Text>
          Permanently deleting this SKU group will redirect you to the dashboard.
        </Text>
      ),
    });
  };

  const deleteSkuGroup = async (skuGroupId) => {
    try {
      await SkuGroupService.deleteSkuGroups([skuGroupId]);
      props.onClose();
      props.onSkuGroupDelete();
      message.success({
        content: 'Successfully Deleted SKU Group',
        className: "edit-group-success-message",
        duration: 2,
      });
    } catch {
      message.error({
        content: 'Unable to Delete SKU Group',
        className: "edit-group-error-message",
        duration: 2,
      });
    }
  }


  const footerButtons = [
    <Row key={0}>
      <Col span={24}>
        <Button
          key="override"
          type="primary"
          size="large"
          style={{float: "left"}}
          danger
          onClick={deleteGroup}
        >
          Delete Group
        </Button>
        <Button
          key="back"
          type="default"
          size="large"
          onClick={props.onClose}
        >
          Cancel
        </Button>
        <Button
          key="submit"
          type="primary"
          size="large"
          disabled={isSaveButtonDisabled}
          onClick={saveSkuGroup}
        >
          Save
        </Button>
      </Col>
    </Row>
  ];

  return (
    <Modal
      open={true}
      className="sku-group-modal"
      title="Edit Group"
      footer={footerButtons}
      onCancel={props.onClose}
      destroyOnClose={true}
    >
      <Row gutter={[0, 8]} className="input-label">
        <Col span={24}>
          <Space direction="horizontal" size={2}>
            <Text className="mandatory-input-icon">*</Text>
            <Text strong>Group Name</Text>
          </Space>
        </Col>
      </Row>
      <Row gutter={[0, 16]} className="input-field">
        <Col span={24}>
          <Input size="large" style={{fontSize: '14px'}}
                 value={skuGroup.groupName}
                 onChange={(e) => handleGroupName(e.target.value, 'groupName')}
          />
        </Col>
      </Row>
      <Row gutter={[0, 8]} className="input-label">
        <Col span={24}>
          <Space direction="horizontal" size={2}>
            <Text className="mandatory-input-icon">*</Text>
            <Text strong>Group Description</Text>
          </Space>
        </Col>
      </Row>
      <Row gutter={[0, 16]} className="input-field">
        <Col span={24}>
          <TextArea style={{height: '60px', resize: "none"}}
                    value={skuGroup.groupDescription}
                    onChange={(e) => handleGroupName(e.target.value, 'groupDescription')}
          />
        </Col>
      </Row>
      <Row gutter={[0, 8]} className="input-label">
        <Col span={24}>
          <Space direction="horizontal" size={2}>
            <Text className="mandatory-input-icon">*</Text>
            <Text strong>SKUs</Text>
          </Space>
        </Col>
      </Row>
      <Row className="input-field">
        <Col span={24}>
          <TextArea className="skus-input-textarea"
                    style={{resize: "none"}}
                    value={skuGroup.skuNumbers}
                    onChange={(e) => handleSkuInput(e.target.value)}
                    onBlur={filterSkuNumbers}
          />
        </Col>
      </Row>
    </Modal>
  );

}

export default EditSkuGroupModal;
