import React , {useState,Fragment} from 'react';
import {Col, Row, Tooltip,Typography} from 'antd';
import {UXSpin} from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import {trackEvent} from '../../Utils/mixpanel';
import MultipleVendorDetectedModal
  from './MultipleVendorDetectedModal/MultipleVendorDetectedModal';
import "./OnlineSkuPage.scss";

const {Text} = Typography;
const VendorNumberTooltip = (vendorNumber,vendorName) => {
  return (
      <Fragment>
        <Row>
          <Col type="flex" span={24}>
            <Text className="vendor-tooltip-text"> {vendorName ? vendorName.toUpperCase() : ""}</Text>
            <Text className="vendor-tooltip-text"> #{vendorNumber ? vendorNumber : ""}</Text>
          </Col>
        </Row>
      </Fragment>
  );
};

const VendorDisplayText = ({multiVendorList,getAllSkusforDCSView,dcsTitle,selectedType,isSmall,trackEventTitle=""}) => {

  const [showMultipleVendor, setShowMultipleVendor] = useState(false);

  let vendorList = multiVendorList;
  let vendorText = <UXSpin/>;

  let vendorClassName = "vendor-name" + (isSmall?" vendor-small" :"");
  if(multiVendorList !== "-"){

    if(vendorList.length === 0){
      vendorText = <Text className={vendorClassName}> NO ACTIVE VENDORS</Text>
    }else if(vendorList.length === 1){
      vendorText = <><Text
          className={vendorClassName + " vendor-link"}
          onClick={()=>{trackEvent("CLICKED_VENDOR_FROM_"+trackEventTitle,{"vendor":vendorList[0].vendorName.toUpperCase()}); getAllSkusforDCSView(dcsTitle,vendorList[0].vendorNumber,vendorList[0].vendorName)}}>
        <a type="link">{vendorList[0].vendorName.toUpperCase()} </a>{/*eslint-disable-line*/}
      </Text>
        <Tooltip title={VendorNumberTooltip(vendorList[0].vendorNumber,vendorList[0].vendorName)} placement="top">
          <i className="material-icons-outlined vendor-tooltip-info">
            info
          </i>
        </Tooltip></>
    }else {
      vendorText = <Text
          className={vendorClassName + " vendor-link"}
          onClick={()=>{
            trackEvent("CLICKED_MULTI_VENDOR_MODAL_FROM_"+trackEventTitle,{"vendor":vendorList[0].vendorName.toUpperCase()});
            setShowMultipleVendor(true);
          }}
      ><a type="link">MULTIPLE VENDORS</a>{/*eslint-disable-line*/}</Text>
    }
  }
  return <>{vendorText}
    {showMultipleVendor &&
    <MultipleVendorDetectedModal
        isOpen={showMultipleVendor}
        onClose={() => setShowMultipleVendor(false)}
        onVendorCardClick = {(vendorNumber,vendorName)=>{getAllSkusforDCSView(dcsTitle,vendorNumber,vendorName);
          trackEvent("CLICKED_VENDOR_FROM_"+trackEventTitle+"(MODAL)",{"vendor":vendorNumber});

        }}
        multiVendorList={multiVendorList}
    />}</>;
};

export default VendorDisplayText
