import React , {useContext,useState,Fragment} from 'react';
import {Button, Col, Row, Typography } from "antd";
import SkuRating from "../../ProductSearchComponents/SkuRating/SkuRating";
import OnlineItemProperties from "../../ProductSearchComponents/OnlineItemProperties";
import {
  dcsFormatter,
  minMaxRetailFormatter,
} from '../../Utils/CommonUtil';
import CompUtil from "../../Utils/CompUtil";
import SkuContext from "../../../context/SkuContext";
import ModifyPriceModal from "../../ModifyPriceModal/ModifyPriceModal";
import OnlineEditPriceModal from "../../ProductSearchComponents/OnlineEditPriceModal/OnlineEditPriceModal"
import {trackEvent} from "../../Utils/mixpanel";
import VendorDisplayText from './VendorDisplayText';

const {Text} = Typography;

const SingleSkuInfoCard = ({singleSkuHeaderData,selectedType,compsAndUnitsFormatter,skuRating,editPriceSkuImg,userAccess,config,userId,verifyAccessToken ,getAllSkusforDCSView }) => {

  const context = useContext(SkuContext);
  const [showEditPrice,setShowEditPrice] =  useState(false);
  const [showOnlineEditPrice,setShowOnlineEditPrice] =  useState(false);


  const getInStoreHeaderData = () => {
    return {
      dcsTitle: dcsFormatter(context.skuData.departmentNumber,context.skuData.classNumber, context.skuData.subClassNumber),
      skuTitle: context.skuNumber,
      skuDescription: context.skuDescription,
      minMaxRetail: context.skuData.minMaxPriceRange ? minMaxRetailFormatter(
          context.skuData.minMaxPriceRange[0],
          context.skuData.minMaxPriceRange[1]) : "",
      totalPricePointCount: context.skuData.pricePointRelevantCount,
      mostCommonRetail: context.skuData.mostCommonRetails
          ? context.skuData.mostCommonRetails[0] ? "$"
              + CompUtil.formatPrice(Number.parseFloat(context.skuData.mostCommonRetails[0])) : "-" : "-",
      vendorName: context.skuVendors?context.skuVendors:(context.skuVendors===""?"NO ACTIVE VENDORS":"-"),
      assortedStores : context.skuData.totalStoreCount?context.skuData.availableStores.length + "/" + context.skuData.totalStoreCount:"",
      activeStores : context.skuData.assortedActiveStoreCount ? context.skuData.assortedActiveStoreCount + "/" + context.skuData.totalStoreCount:""
    }
  };

  let headerData = singleSkuHeaderData;

  if (selectedType === "inStore") {
    headerData = {...singleSkuHeaderData,...getInStoreHeaderData()};
  }
  let promoPriceDiff = headerData.permRetail- headerData.effectiveRetail;

  let calPromoPercentage = ((promoPriceDiff/headerData.permRetail)*100).toFixed(2);

  return (
      <Fragment>

        <Row gutter={[8, 8]} align="middle" justify="start">
          <Col>
            <a type="link" style={{color:"#286fad"}} onClick={()=> {trackEvent("CLICKED_DCS_FROM_"+(selectedType === "online"?"ONLINE" : "INSTORE") +"_SINGLE_SKU_PAGE",{"dcs":headerData.dcsTitle});getAllSkusforDCSView(headerData.dcsTitle)}}>{headerData.dcsTitle}</a> {/*eslint-disable-line*/}
          </Col>
          {selectedType === "online" ?
              <Col><Text type="secondary" className="sku-details">{headerData.omsIdTitle}</Text></Col>
              : ""}
          <Col><Text type="secondary" className="sku-details">SKU {headerData.skuTitle}</Text></Col>
        </Row>
        <Row gutter={[0, 8]} align="middle">

          <Col>
            <VendorDisplayText
                multiVendorList={headerData.multiVendorList}
                getAllSkusforDCSView = {getAllSkusforDCSView}
                dcsTitle={headerData.dcsTitle}
                selectedType={selectedType}
                trackEventTitle={(selectedType === "online"?"ONLINE" : "INSTORE") +"_SINGLE_SKU_PAGE"}
            />
          </Col>
        </Row>
        <Row gutter={[0, 8]} align="middle">
          <Col><Text className="sku-description">{headerData.skuDescription}</Text></Col>
        </Row>
        <Row gutter={[0,16]}>
        <Col>
          <SkuRating {...skuRating}/>
        </Col>
      </Row>

        {selectedType === "online" ?
          <Fragment>
            <Row gutter={[16,24]} align="bottom">
              <Col className="retail-amount-col-spacing">
                <Text className="dollar-amount">${CompUtil.formatPrice(
                    headerData.effectiveRetail)}</Text>
              </Col>
              {headerData.retailType === "PROMOTION" ?
              <Col className="retail-amount-col-spacing">
                  <Text delete className="promo-text promo-text-position">${CompUtil.formatPrice(headerData.permRetail)}</Text>
                  <Text className="promo-text promo-text-off-color">${CompUtil.formatPrice(promoPriceDiff)} OFF {'('+calPromoPercentage+'%)'}</Text>
              </Col>:""}
            </Row>
            <Row gutter={[0,24]}>
              <Col span={24}>
                <Text>Active Cost : <Text className="online-active-cost">{headerData.effectiveCost ? "$"+CompUtil.formatPrice(headerData.effectiveCost) : "NA"}</Text></Text>
              </Col>
            </Row>
          </Fragment>
          :
          <Row align="middle">
            <Col span={24}><Text className="dollar-amount">{headerData.minMaxRetail}</Text></Col>
          </Row>}


      {selectedType === "inStore" ?
          <Row gutter={[8, 16]} align="middle">
            <Col><Text className="most-common-text">{headerData.totalPricePointCount} Price Points</Text></Col>
            <Col><Text>|</Text></Col>
            <Col><Text className="most-common-text">{headerData.mostCommonRetail}</Text></Col>
            <Col><Text className="most-common-text">Most Common</Text></Col>
          </Row> : ""}
        <Row>
          <Col>
            <Row gutter={[16, 24]} align="middle">
              <Col>
                <Button
                    onClick={()=>trackEvent("CLICKED_VIEW_WEBSITE_FROM_SINGLE_SKU_PAGE")}
                    href={"https://www.homedepot.com/s/"+ headerData.skuTitle}
                    size="large"
                    target="_blank"
                    type="primary"
                    ghost='true'
                    block
                    className="view-website-button">
                  View Website </Button>
              </Col>
                {/*Commenting  out condition && headerData.vendorNumber !==0 to disable Edit price button if there is no active vendor*/}
              {selectedType === "online" && userAccess.isOnlineEditEnabled?
              <Col><Button
                      onClick={()=>{
                        verifyAccessToken();
                        setShowOnlineEditPrice(flag=>!flag);
                        trackEvent("CLICKED_ONLINE_EDIT_PRICE_FROM_ONLINE_SINGLE_SKU_PAGE");
                      }}
                      key="submit"
                      size="large"
                      type="primary"
                      ghost='true'
                      block
                      className="edit-price-button">
                  Edit Price </Button></Col>: ""}
              {selectedType === "inStore" && context.skuData.allowExecution && context.skuData.allowZonePriceChange ?
                  <Col><Button
                      onClick={()=>{
                        verifyAccessToken();
                        setShowEditPrice(flag=>!flag);
                        trackEvent("CLICKED_EDIT_PRICE_FROM_IN_STORE_SINGLE_SKU_PAGE");
                      }}
                      key="submit"
                      size="large"
                      type="primary"
                      ghost='true'
                      block
                      className="edit-price-button">
                    Edit Price </Button></Col> : ""}
            </Row>
            <Row>
              <Col span={24}>
                <OnlineItemProperties
                    totalThisYearSales={headerData.totalThisYearSales}
                    totalCompPercentage={headerData.totalCompPercentage}
                    totalThisYearUnits={headerData.totalThisYearUnits}
                    totalUnitsPercentage={headerData.totalUnitsPercentage}
                    isOnline={selectedType==="online"}
                    isSingleSku={true}
                    assortedStores = {headerData.assortedStores}
                    compsAndUnitsFormatter={compsAndUnitsFormatter}
                    onHandQuantity={headerData.onHandQuantity}
                    dailyISSData={headerData.dailyISS}
                    activeStores ={headerData.activeStores}/>
              </Col>
            </Row>
          </Col>
        </Row>
        {showEditPrice && <ModifyPriceModal
            isAddNew
            isOpen={showEditPrice}
            onClose={()=> setShowEditPrice(false)} /> }
        {showOnlineEditPrice &&
          <OnlineEditPriceModal
            isAddNew
            isOpen={showOnlineEditPrice}
            onClose={() => setShowOnlineEditPrice(false)}
            compsAndUnitsFormatter={compsAndUnitsFormatter}
            headerData={headerData}
            isOnline={selectedType==="online"}
            isSingleSku={true}
            config =  {config}
            userId = {userId}
            editPriceSkuImg={editPriceSkuImg[selectedType+"SkuImageUrl"]}/>}
      </Fragment>);
};

export default SingleSkuInfoCard;
