import React, { Fragment,useEffect } from 'react';
import { Row, Col, Typography, Modal } from 'antd';
import { RightOutlined } from '@ant-design/icons';
import "./MultipleOmsidsDetectedModal.scss";
import NoSkuImage from "../../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import UXImage from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import {trackEvent} from "../../../Utils/mixpanel";

const { Text } = Typography;

const OmsidCard = (props) => {
    return (
        <Fragment>
            <Row align="middle" className="omsid-card-size ">

                <Col span={6}><UXImage imageUrl={props.imgSourcePath?props.imgSourcePath:NoSkuImage} classNames="omsid-card-sku-img" /></Col>
                <Col span={16}>
                    <Row gutter={[24, 0]}>
                        <Col sm={12}><Text type="secondary" className="online-omsid-number">OMSID {props.omsId}</Text></Col>
                        <Col sm={12}><Text type="secondary" className="online-sku-number">SKU {props.skuNumber}</Text></Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <Text className="online-vendor-name">{props.vendorName?props.vendorName.toUpperCase():"-"}</Text>
                        </Col>
                    </Row>
                    <Row>
                        <Col className="online-text-shortener">
                            <Text className="online-sku-description">{props.skuDescription}</Text>
                        </Col>
                    </Row>
                </Col>
                <Col span={2}>
                    <Row justify="space-bewtween" align="middle"><Col> <RightOutlined className="right-arrow" /></Col></Row>
                </Col>
            </Row>
        </Fragment>
    );
};

const MultipleOmsidsDetectedModal = (props) => {

    useEffect(()=>{
        trackEvent("OPEN_MULTI_OMS_DETECT_MODAL",{"skuList": props.onlineMultiSkuData? Object.values(props.onlineMultiSkuData):[]});
    },[]);


    return (
        <Modal
            title="Multiple OMSIDs Detected"
            centered
            open={true}
            onCancel={props.onClose}
            destroyOnClose={true}
            className="omsid-detected-modal"
            onOk={props.onClose}
            okText="Close"
            okButtonProps={{ size: 'large' }}
            cancelButtonProps={{ style: { display: 'none' } }}
        >
            <div className="omsid-modal-content">
                <Row justify="start" gutter={[0, 16]} >
                    <Col span={24}>
                        <Text>Please select the related product you would like to view from the options below:</Text>
                    </Col>
                </Row>
                {props.onlineMultiSkuData? Object.values(props.onlineMultiSkuData).map((data,key)=>
                    <Row key={key} justify="center" gutter={[0, 16]}
                         onClick={() => {
                             trackEvent("SKU_CLICK_MULTI_OMS_DETECT_MODAL",{"sku": data.skuNumber});
                             props.onSkuClick(data.skuNumber)
                         }}>
                        <Col span={24}>
                            <OmsidCard {...data}/>
                        </Col>
                    </Row>
                ): null}

            </div>


        </Modal>

    );
}
export default MultipleOmsidsDetectedModal;