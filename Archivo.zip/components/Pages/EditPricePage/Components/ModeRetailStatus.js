import CompUtil from '../../../Utils/CompUtil';
import { UXSpin } from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import { Col, Divider, Popover, Row, Typography } from 'antd';
import React from 'react';
import PropTypes from 'prop-types';

const { Text } = Typography;

class ModeRetailStatus extends React.PureComponent {
  getModeRetailStatus(modeRetailStatuses) {
    return (
      <div className={'mode-retail-info-content'}>
        {modeRetailStatuses &&
          modeRetailStatuses.map(
            ({ retail, occurrences, statusCode, completeStatus }) => (
              <Row key={statusCode} gutter={[8, 8]} span={24}>
                <Col span={10}>{`${
                  Number(retail)
                    ? `$${Number((retail / 100).toFixed(2))}`
                    : retail
                } (${occurrences})`}</Col>
                <Col span={2}>
                  <Divider
                    style={{ height: '25px', borderLeft: '1px solid #CACACA' }}
                    type="vertical"
                  />
                </Col>
                <Col span={12}>{`${completeStatus}`}</Col>
              </Row>
            )
          )}
      </div>
    );
  }

  render() {
    let { modeRetailStatuses, loading } = this.props;
    let lowestStatus = modeRetailStatuses && modeRetailStatuses[0];
    if (loading) {
      return <UXSpin />;
    }
    if (!lowestStatus) {
      return <Text>{'--'}</Text>;
    }
    return (
      <Popover
        content={this.getModeRetailStatus(modeRetailStatuses)}
        trigger="hover"
        placement="top"
      >
        <Text data-testid={`mode-retail-${lowestStatus.sku}`}>
          {'$' + CompUtil.formatPrice(lowestStatus.retail / 100)}
          <Text>{` (${lowestStatus.occurrences})`}</Text>
        </Text>
      </Popover>
    );
  }
}

ModeRetailStatus.propTypes = {
  modeRetailStatuses: PropTypes.array,
  loading: PropTypes.bool.isRequired,
};

export default ModeRetailStatus;
