import { Col, Image, Modal, Row, Space, Typography } from 'antd';
import AnchorSku from '../../../../images/AnchorSku.svg';
import React from 'react';

const { Text } = Typography;

const ZoneMultiplierGroupModal = ({
  zoneMultiplierGroupData,
  zoneMlpModalClose,
}) => {
  const anchorZone = zoneMultiplierGroupData.anchorGroupId;
  const zoneGroup = zoneMultiplierGroupData.zoneGroups.sort((a) =>
    a.id === anchorZone ? -1 : 1
  );

  return (
    <Modal
      className="zone-mlp-modal"
      title={
        <Text className="zone-mlp-modal-title">Zone Multiplier Groups</Text>
      }
      open={true}
      onCancel={() => zoneMlpModalClose()}
      footer={null}
    >
      <div className="zone-mlp-modal-content">
        {!zoneGroup
          ? null
          : zoneGroup.map((zone) => (
              <>
                <Row style={{ padding: '10px' }} gutter={[8, 0]}>
                  {zone.id === anchorZone ? (
                    <Col>
                      <Space>
                        <Image
                          src={AnchorSku}
                          alt="Anchor"
                          height="22px"
                          width="21px"
                        />
                        <Text strong className="zone-group-text">
                          {zone.name}
                        </Text>
                      </Space>
                    </Col>
                  ) : (
                    <Col>
                      <Text strong className="zone-group-text">
                        {zone.name}
                      </Text>
                    </Col>
                  )}
                </Row>
                <Row style={{ padding: '10px' }} gutter={[0, 8]}>
                  {zone.zones.map((k) => (
                    <Col key={'zone-name-' + k.zoneName} span={8}>
                      <Row gutter={[16, 0]}>
                        <Col span={4}>
                          <Row justify="end" align="middle">
                            <Col>
                              <Text>{k.zoneId ? k.zoneId : '-'}</Text>
                            </Col>
                          </Row>
                        </Col>
                        <Col span={20}>
                          <Row justify="start" align="middle">
                            <Col>
                              <Text>{k.zoneName ? k.zoneName : '-'}</Text>
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                  ))}
                </Row>
              </>
            ))}
      </div>
    </Modal>
  );
};

export { ZoneMultiplierGroupModal };
