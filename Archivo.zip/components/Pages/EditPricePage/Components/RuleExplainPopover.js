import AnchorSku from '../../../../images/AnchorSku.svg';
import React from 'react';
import { Typography } from 'antd';

const { Text } = Typography;

const RuleExplainPopover = ({ anchorSku, retail, recRules }) => {
  let recommendedPrice =
    recRules &&
    recRules.recommendation &&
    (recRules.recommendation.recommendedPrice / 100).toFixed(2);
  return (
    <div className="popover-window-content">
      {retail && recommendedPrice === retail ? (
        [
          <p key={'skuToSku'} className="popover-rules">
            <p>SKU to SKU:</p> {getSkuToSkuRule(recRules, anchorSku)}
          </p>,
          <p key={'zoneMultiplier'} className="popover-rules">
            <p>Zone Multiplier: </p>
            {getZoneMultiplierRule(recRules)}
          </p>,
          <p key={'Target'} className="popover-rules">
            {getTargetRule(recRules, 'Target:')}
          </p>,
          getPriceEndingRule(
            recRules,
            'CustomPriceEnding',
            'Custom Price Ending:'
          ),
          getPriceEndingRule(
            recRules,
            'EnterprisePriceEnding',
            'THD Price Ending:'
          ),
        ]
      ) : retail && recommendedPrice !== retail ? (
        <p className="popover-rules">
          Price manually set.
          <br /> no applied rules.
        </p>
      ) : null}
    </div>
  );
};

const renderAnchorIcon = () => (
  <>
    <img src={AnchorSku} alt="Anchor" style={{ height: 15, width: 15 }} />{' '}
  </>
);

const renderSku = (sku, anchorSku) => {
  return (
    <>
      {' '}
      {sku === anchorSku && renderAnchorIcon()} {sku}{' '}
    </>
  );
};
const getSkuToSkuEquation = (
  anchorSku,
  sourceSku,
  targetSku,
  minDelta,
  maxDelta,
  relationType
) => {
  const source = renderSku(sourceSku, anchorSku);
  const target = renderSku(targetSku, anchorSku);
  const multiplier = getMultiplier(relationType, minDelta, maxDelta);
  const relation = relationType === 'MULTIPLICATIVE' ? 'x' : '+';
  return (
    <Text>
      {' '}
      {target} = {source} {relation} {multiplier}{' '}
    </Text>
  );
};

const getMultiplier = (relationType, minDelta, maxDelta) => {
  if (minDelta !== maxDelta) {
    return 'Range Rule';
  }
  if (relationType === 'MULTIPLICATIVE') {
    return minDelta.toFixed(3);
  } else if (relationType === 'ADDITIVE') {
    return (minDelta / 100).toFixed(2);
  } else {
    return 'Unknown Relation';
  }
};

const getSkuToSkuRule = (recRules, anchorSku) => {
  if (recRules) {
    //go through different types of rules and find only sku to sku rules [{}]
    const skuToSku = recRules.recommendation.recommendationList.find(
      (rec) => rec.recommendationType === 'SkuToSku'
    );
    if (skuToSku && skuToSku.recommendationPath) {
      //select last item in the array, .slice(-1) returns new array holding last index
      const lastRecPath = skuToSku.recommendationPath.slice(-1)[0];
      //use index 0 to access fields
      return getSkuToSkuEquation(
        anchorSku,
        lastRecPath.sourceSku,
        lastRecPath.targetSku,
        lastRecPath.minDelta,
        lastRecPath.maxDelta,
        lastRecPath.relationType
      );
    } else return 'NA';
  } else {
    return 'NA';
  }
};

const getZoneMultiplierRule = (recRules) => {
  let output = 'NA';
  if (recRules) {
    const zoneMultiplierRule = recRules.recommendation.recommendationList.find(
      (rec) => rec.recommendationType === 'ZoneMultiplier'
    );
    if (zoneMultiplierRule) {
      output = <Text>{zoneMultiplierRule.effectiveWeight.toFixed(3)}</Text>;
    }
  }
  return output;
};

const getTargetRule = (recRules, title) => {
  if (recRules) {
    const targetRule = recRules.recommendation.recommendationList.find(
      (rec) => rec.recommendationType === 'Target'
    );
    if (targetRule) {
      const ruletype = targetRule.reason.split(title);
      return (
        <div className="popover-rules">
          <p>{title}</p>
          <p>
            <Text>{ruletype}</Text>
          </p>
        </div>
      );
    }
  }
  return '';
};

function toTitleCase(str) {
  return str.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}

function isNullOrWhitespace(input) {
  return !input || !input.trim();
}

const getPriceEndingRule = (recRules, recType, title) => {
  let explainText = '';
  if (recRules) {
    let zoneMultiplierRule = recRules.recommendation.recommendationList.find(
      (rec) => rec.recommendationType === recType
    );
    if (zoneMultiplierRule) {
      if (recType === 'CustomPriceEnding') {
        const ending = zoneMultiplierRule.ending || '';
        explainText = `${toTitleCase(
          zoneMultiplierRule.ruleType.replace('_', ' ')
        )} ${ending}`;
      } else if (recType === 'EnterprisePriceEnding') {
        explainText = !isNullOrWhitespace(zoneMultiplierRule.reason)
          ? zoneMultiplierRule.reason
          : 'No Rule Applied';
      }
      return (
        <div key={recType} className="popover-rules">
          <p>{title}</p>
          <p>
            <Text>{explainText}</Text>
          </p>
        </div>
      );
    }
  }
};

export { RuleExplainPopover };
