import React from 'react';
import { render, screen } from '@testing-library/react';
import { RuleExplainPopover } from './RuleExplainPopover';
import { additiveSkuToSkuRec } from './__fixtures__/additiveSkuToSkuRec';
import { multiplicativeSkuToSkuRec } from './__fixtures__/multiplicativeSkuToSkuRec';

describe('RuleExplainPopover', () => {
  test('render rule popover with sku to sku adder', () => {
    render(
      <RuleExplainPopover
        anchorSku={301329}
        retail={'87.00'}
        recRules={additiveSkuToSkuRec}
      />
    );

    expect(screen.getByText(/24.00/)).toBeInTheDocument(); //sku to sku adder amount
    expect(screen.getByText(/0.901/)).toBeInTheDocument(); //zone multiplier
    expect(screen.getAllByText(/301329/)[0]).toBeInTheDocument(); //anchor sku
  });

  test('render rule popover with sku to sku multiplier', () => {
    render(
      <RuleExplainPopover
        anchorSku={301329}
        retail={'156.90'}
        recRules={multiplicativeSkuToSkuRec}
      />
    );

    expect(screen.getByText(/2.400/)).toBeInTheDocument(); //sku to sku multiplier amount
    expect(screen.getByText(/0.901/)).toBeInTheDocument(); //zone multiplier
    expect(screen.getAllByText(/301329/)[0]).toBeInTheDocument(); //anchor sku
  });

  test('render rule popover with Target Rules', () => {
    render(
      <RuleExplainPopover
        anchorSku={301329}
        retail={'156.90'}
        recRules={multiplicativeSkuToSkuRec}
      />
    );

    expect(screen.getAllByText(/Target/)[0]).toBeInTheDocument();
    expect(screen.getByText('Target:')).toBeInTheDocument();
    expect(screen.getByText('IMU 55.0%')).toBeInTheDocument();
  });

  test('render rule popover with Custom Price Ending Rules', () => {
    render(
      <RuleExplainPopover
        anchorSku={301329}
        retail={'156.90'}
        recRules={multiplicativeSkuToSkuRec}
      />
    );
    expect(screen.getByText(/Custom Price Ending/)).toBeInTheDocument();
    expect(screen.getByText('Round Up .30')).toBeInTheDocument();
  });
});
