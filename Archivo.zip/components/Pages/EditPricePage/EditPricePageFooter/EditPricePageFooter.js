import React from 'react';
import { Button, Col, Layout, Row } from 'antd';
import './EditPricePageFooter.scss';
// import {InfoCircleOutlined} from '@ant-design/icons';
//const {Text} = Typography;
const { Footer } = Layout;

const EditPricePageFooter = ({
  updateMetrics,
  setRecommendPriceModal,
  generateRCW,
  enableUpdateMetricsButton,
  enableRecButton,
  enableRCWButton,
}) => {
  return (
    <Footer id="edit-price-footer">
      <Row align="middle" justify="end" gutter={[16, 0]}>
        {/*<Col>*/}
        {/*    <Input*/}
        {/*        placeholder="Enter Email Id"*/}
        {/*        suffix={*/}
        {/*            <Tooltip title="For Testing purpose">*/}
        {/*                <InfoCircleOutlined style={{ color: 'rgba(0,0,0,.45)' }} />*/}
        {/*            </Tooltip>*/}
        {/*        }*/}
        {/*        onChange={(e) => {*/}
        {/*                let inputValue = e.target.value;*/}
        {/*                setUserEmail (inputValue)*/}

        {/*    }}/>*/}
        {/*</Col>*/}
        <Col>
          <Button
            disabled={!enableUpdateMetricsButton}
            type={'primary'}
            data-testid="update_metrics"
            onClick={() => {
              updateMetrics();
            }}
            ghost
          >
            Update Metrics
          </Button>
        </Col>
        <Col>
          <Button
            disabled={!enableRecButton}
            type={'primary'}
            data-testid="recommend_prices"
            onClick={() => {
              setRecommendPriceModal(true);
            }}
            ghost
          >
            Recommend Prices
          </Button>
        </Col>
        <Col>
          <Button
            disabled={!enableRCWButton}
            type={'primary'}
            onClick={() => {
              generateRCW();
            }}
          >
            Generate RCW
          </Button>
        </Col>
      </Row>
    </Footer>
  );
};

export default EditPricePageFooter;
