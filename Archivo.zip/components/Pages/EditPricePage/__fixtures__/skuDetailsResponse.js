export const skuDetailsResponse = {
  data: [
    { sku: 301329, description: '3/4"X10\' GAL PIPE', dcs: '001-001-001' },
    { sku: 332259, description: 'test description', dcs: '001-001-001' },
    { sku: 191396, description: 'test description', dcs: '001-001-001' },
    { sku: 652490, description: 'test description', dcs: '001-001-001' },
    { sku: 652512, description: 'test description', dcs: '001-001-001' },
    { sku: 652520, description: 'test description', dcs: '001-001-001' },
    { sku: 652539, description: 'test description', dcs: '001-001-001' },
    { sku: 652547, description: 'test description', dcs: '001-001-001' },
    { sku: 652563, description: 'test description', dcs: '001-001-001' },
    { sku: 652695, description: 'test description', dcs: '001-001-001' },
    { sku: 689930, description: 'test description', dcs: '001-001-001' },
  ],
};
