export const skuData = [
  { sku: 12345, description: 'Desc One', dcs: '001-001-001' },
  { sku: 23456, description: 'Desc Two', dcs: '001-001-001' },
  { sku: 34567, description: 'Desc Three', dcs: '001-001-001' },
];

export const currentRetails = {
  data: [
    { sku: 12345, retail: 1000, occurrences: 100, strategy: 'ACTIVE' },
    { sku: 12345, retail: 1000, occurrences: 50, strategy: 'OUT_SEASON' },
    { sku: 23456, retail: 2000, occurrences: 150, strategy: 'IN_SEASON' },
    { sku: 23456, retail: 1, occurrences: 15, strategy: 'CLEARANCE' },
  ],
};

export const currentZoneGroupRetails = {
  data: [
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 1000,
      occurrences: 100,
      strategy: 'ACTIVE',
    },
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 1500,
      occurrences: 33,
      strategy: 'INACTIVE',
    },
    {
      sku: 12345,
      zoneGroupId: '98798798-5717-4562-b3fc-2c963f66afa6',
      retail: 1000,
      occurrences: 50,
      strategy: 'INACTIVE',
    },
    {
      sku: 23456,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 2000,
      occurrences: 150,
      strategy: 'IN_SEASON',
    },
    {
      sku: 23456,
      zoneGroupId: '98798798-5717-4562-b3fc-2c963f66afa6',
      retail: 1,
      occurrences: 15,
      strategy: 'CLEARANCE',
    },
  ],
};

export const currentZoneGroupCPI = {
  data: [
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 3141,
      cpi: 0.9,
    },
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 527,
      cpi: 1.1,
    },
    {
      sku: 23456,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 3141,
      cpi: 0.8,
    },
    {
      sku: 23456,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 527,
      cpi: 1.2,
    },
    {
      sku: 34567,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 3141,
      cpi: 0.8,
    },
    {
      sku: 34567,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      competitorId: 527,
      cpi: 1.2,
    },
  ],
};

export const zoneGroups = {
  data: {
    id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    name: 'myMultiplierGroup',
    description: 'This is a group of zones with multipliers.',
    anchorGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
    zoneGroups: [
      {
        id: '12312312-5717-4562-b3fc-2c963f66afa6',
        name: 'Core',
        weight: 1,
        zones: [
          {
            traitId: 101,
            userDefZoneId: '57',
            zoneName: 'Zone One',
            stores: [1, 2, 3],
          },
        ],
      },
      {
        id: '98798798-5717-4562-b3fc-2c963f66afa6',
        name: 'Menards',
        weight: 0.8,
        zones: [
          {
            traitId: 202,
            userDefZoneId: '57',
            zoneName: 'Zone Two',
            stores: [4, 5, 6],
          },
        ],
      },
    ],
  },
};
