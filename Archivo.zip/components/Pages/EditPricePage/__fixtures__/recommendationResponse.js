export const recommendationResponse = {
  data: [
    {
      sku: 854892,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      recommendation: {
        recommendationType: 'Layered',
        currentPrice: 1057,
        recommendedPrice: 1472,
        recommendationList: [
          {
            recommendationType: 'SkuToSku',
            currentPrice: 1057,
            recommendedPrice: 1047,
            recommendationPath: [
              {
                sourceSku: 301329,
                targetSku: 652539,
                minDelta: 0.3087,
                maxDelta: 0.3087,
                relationType: 'ADDITIVE',
              },
            ],
            added: true,
          },
          {
            recommendationType: 'ZoneMultiplier',
            currentPrice: 1047,
            recommendedPrice: 1472,
            anchorGroup: '4f205b79-45fa-4b36-ab2a-d7c4509afb6c',
            targetGroup: '10b724c2-661b-4a50-846d-cd58d01c8a45',
            effectiveWeight: 1.40625,
          },
        ],
      },
    },
    {
      sku: 301329,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      recommendation: {
        recommendationType: 'Layered',
        currentPrice: 1057,
        recommendedPrice: 1472,
        recommendationList: [
          {
            recommendationType: 'SkuToSku',
            currentPrice: 1057,
            recommendedPrice: 1047,
            recommendationPath: [
              {
                sourceSku: 301329,
                targetSku: 652539,
                minDelta: 0.3087,
                maxDelta: 0.3087,
                relationType: 'ADDITIVE',
              },
            ],
            added: true,
          },
          {
            recommendationType: 'ZoneMultiplier',
            currentPrice: 1047,
            recommendedPrice: 1472,
            anchorGroup: '4f205b79-45fa-4b36-ab2a-d7c4509afb6c',
            targetGroup: '10b724c2-661b-4a50-846d-cd58d01c8a45',
            effectiveWeight: 1.40625,
          },
        ],
      },
    },
    {
      sku: 301329,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      recommendation: {
        recommendationType: 'Layered',
        currentPrice: 1057,
        recommendedPrice: 1472,
        recommendationList: [
          {
            recommendationType: 'SkuToSku',
            currentPrice: 1057,
            recommendedPrice: 1047,
            recommendationPath: [
              {
                sourceSku: 301329,
                targetSku: 652539,
                minDelta: 0.3087,
                maxDelta: 0.3087,
                relationType: 'ADDITIVE',
              },
            ],
            added: true,
          },
          {
            recommendationType: 'ZoneMultiplier',
            currentPrice: 1047,
            recommendedPrice: 1472,
            anchorGroup: '4f205b79-45fa-4b36-ab2a-d7c4509afb6c',
            targetGroup: '10b724c2-661b-4a50-846d-cd58d01c8a45',
            effectiveWeight: 1.40625,
          },
        ],
      },
    },
  ],
};
