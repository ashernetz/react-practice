export const zoneMultiplierGroupResponse = {
  data: {
    id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    name: 'myMultiplierGroup',
    description: 'This is a group of zones with multipliers.',
    anchorGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
    zoneGroups: [
      {
        id: '12312312-5717-4562-b3fc-2c963f66afa6',
        name: 'Core',
        weight: 1.768,
        zones: [
          {
            traitId: 28283,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
      {
        id: '98798798-5717-4562-b3fc-2c963f66afa6',
        name: 'Menards',
        weight: 2.234,
        zones: [
          {
            traitId: 28267,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
      {
        id: '768795-5717-4562-b3fc-2c963f66afa6',
        name: 'Lowes',
        weight: 9.86,
        zones: [
          {
            traitId: 28400,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
    ],
  },
};
