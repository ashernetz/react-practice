export const shareCodeResponse = {
  skuGroupName: '',
  skus: [301329, 191396],
  zoneGroupMultiplierId: '7c0b7834-03c8-4783-b557-f4ed987ff7d5',
  costs: { 191396: '2.00', 301329: '1.00' },
  retails: {
    191396: {
      'ecb1516f-a6e9-4630-819e-232f30810e7b': {
        retail: '0.49',
        isManualEdit: false,
      },
      '4f1db72f-8231-4d5f-adbe-5acfaf19535e': {
        retail: '0.47',
        isManualEdit: false,
      },
      '11f9009c-1a96-4718-8b69-4378881bd599': {
        retail: '0.34',
        isManualEdit: false,
      },
      '0c28fd74-6214-4dd6-b0ea-1318a16789f7': {
        retail: '0.43',
        isManualEdit: false,
      },
    },
    301329: {
      '0c28fd74-6214-4dd6-b0ea-1318a16789f7': {
        retail: '1.00',
        isManualEdit: false,
      },
      'ecb1516f-a6e9-4630-819e-232f30810e7b': {
        retail: '1.15',
        isManualEdit: false,
      },
      '4f1db72f-8231-4d5f-adbe-5acfaf19535e': {
        retail: '1.10',
        isManualEdit: false,
      },
      '11f9009c-1a96-4718-8b69-4378881bd599': {
        retail: '0.80',
        isManualEdit: false,
      },
    },
  },
};
