export const currentZoneGroupRetails = {
  data: [
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 1000,
      occurrences: 100,
      strategy: 'ACTIVE',
    },
    {
      sku: 12345,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 1500,
      occurrences: 33,
      strategy: 'INACTIVE',
    },
    {
      sku: 12345,
      zoneGroupId: '98798798-5717-4562-b3fc-2c963f66afa6',
      retail: 1000,
      occurrences: 50,
      strategy: 'INACTIVE',
    },
    {
      sku: 23456,
      zoneGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
      retail: 2000,
      occurrences: 150,
      strategy: 'IN_SEASON',
    },
    {
      sku: 23456,
      zoneGroupId: '98798798-5717-4562-b3fc-2c963f66afa6',
      retail: 1,
      occurrences: 15,
      strategy: 'CLEARANCE',
    },
  ],
};
