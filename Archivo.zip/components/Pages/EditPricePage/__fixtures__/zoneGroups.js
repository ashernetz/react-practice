export const zoneGroups = {
  data: {
    id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
    name: 'myMultiplierGroup',
    description: 'This is a group of zones with multipliers.',
    anchorGroupId: '12312312-5717-4562-b3fc-2c963f66afa6',
    zoneGroups: [
      {
        id: '12312312-5717-4562-b3fc-2c963f66afa6',
        name: 'Core',
        weight: 1,
        zones: [
          {
            traitId: 101,
            userDefZoneId: '57',
            zoneName: 'Zone One',
            stores: [1, 2, 3],
          },
        ],
      },
      {
        id: '98798798-5717-4562-b3fc-2c963f66afa6',
        name: 'Menards',
        weight: 0.8,
        zones: [
          {
            traitId: 202,
            userDefZoneId: '57',
            zoneName: 'Zone Two',
            stores: [4, 5, 6],
          },
        ],
      },
    ],
  },
};
