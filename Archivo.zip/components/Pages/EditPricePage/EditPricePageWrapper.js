import { SkuDescriptionProvider } from './Context/SkuDescriptionProvider';
import React from 'react';
import { TargetRulesProvider } from './Context/TargetRulesProvider';
import { VendorProvider } from './Context/VendorContext';

const EditPricePageWrapper =
  (Component) =>
  ({ ...props }) =>
    (
      <VendorProvider>
        <TargetRulesProvider>
          <SkuDescriptionProvider>
            <Component {...props} />
          </SkuDescriptionProvider>
        </TargetRulesProvider>
      </VendorProvider>
    );

export default EditPricePageWrapper;
