import React, { createContext, useCallback, useContext, useState } from 'react';
import noop from 'lodash/noop';
import PropTypes from 'prop-types';

export const SCOPE = {
  WHOLE_SKU_GROUP: 'WHOLE_SKU_GROUP',
  ZONE_GROUP: 'BY_ZONE_GROUP',
  EACH_SKU: 'EACH_SKU',
};

export const STRATEGY = {
  BY_PERCENT: 'PROPORTIONALLY_BY_PERCENT',
  BY_PENNY: 'EQUALLY_BY_PENNY',
};

export const TARGET = {
  IMU: 'IMU',
  MARKUP: 'MARKUP',
  MARKDOWN: 'MARKDOWN',
};

const TargetRulesContext = createContext({
  targetRules: {},
  updateTargetRules: noop,
});

export function useTargetRules() {
  return useContext(TargetRulesContext);
}

export function TargetRulesProvider({ children }) {
  const [targetRules, setTargetRules] = useState({
    scope: SCOPE.WHOLE_SKU_GROUP,
    strategy: STRATEGY.BY_PERCENT,
    targets: [],
  });

  const updateTargetRules = useCallback((scope, strategy, newTargets) => {
    setTargetRules((prevState) => {
      return {
        ...prevState,
        scope,
        strategy,
        targets: newTargets,
      };
    });
  }, []);

  const value = {
    targetRules,
    updateTargetRules,
  };

  return (
    <TargetRulesContext.Provider value={value}>
      {children}
    </TargetRulesContext.Provider>
  );
}

TargetRulesProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
