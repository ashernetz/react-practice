import React, { createContext, useContext, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import noop from 'lodash/noop';

export const VendorContext = createContext({
  vendorData: {
    selectedVendor: '',
    vendors: [],
    vendorGroupData: {},
    costs: {},
    markets: {},
  },
  updateVendorData: noop,
});

export function useVendorData() {
  const { vendorData, updateVendorData } = useContext(VendorContext);
  return { vendorData, updateVendorData };
}

export function VendorProvider({ children }) {
  const [vendorData, setVendorData] = useState({
    selectedVendor: '',
    vendors: [],
    vendorGroupData: {},
    costs: {},
    markets: {},
  });

  const updateVendorData = useCallback((vendorType, vendorValue) => {
    setVendorData((prevState) => ({ ...prevState, [vendorType]: vendorValue }));
  }, []);

  return (
    <VendorContext.Provider value={{ vendorData, updateVendorData }}>
      {children}
    </VendorContext.Provider>
  );
}

VendorProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
