import React, { createContext, useContext, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import noop from 'lodash/noop';

const SkuDescriptionContext = createContext({
  skuDescriptions: {},
  updateSkuDescriptions: noop,
});

export function useSkuDescriptions() {
  return useContext(SkuDescriptionContext);
}

export function SkuDescriptionProvider({ children }) {
  const [skuDescriptions, setSkuDescriptions] = useState({
    data: {},
    isLoading: false,
  });

  const updateSkuDescriptions = useCallback((skuDescription) => {
    setSkuDescriptions(skuDescription);
  }, []);

  const value = {
    skuDescriptions,
    updateSkuDescriptions,
  };

  return (
    <SkuDescriptionContext.Provider value={value}>
      {children}
    </SkuDescriptionContext.Provider>
  );
}

SkuDescriptionProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
