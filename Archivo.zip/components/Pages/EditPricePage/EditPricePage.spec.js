import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { SKULEVEL_CONTENT } from '../../../constants/ToolTip';
import EditPricePage from './EditPricePage';
import SkuContext from '../../../context/SkuContext';
import { act } from 'react-dom/test-utils';
import axios from 'axios';
import { when } from 'jest-when';
import { zoneMultiplierGroupResponse } from './__fixtures__/zoneMultiplierGroupResponse';
import { currentRetailResponse } from './__fixtures__/currentRetailResponse';
import { recommendationResponse } from './__fixtures__/recommendationResponse';
import { skuDetailsResponse } from './__fixtures__/skuDetailsResponse';
import { vendorDataResponse } from './__fixtures__/vendorDataResponse';
import { costsDataResponse } from './__fixtures__/costsDataResponse';
import CompUtil from '../../Utils/CompUtil';

jest.mock('axios');
jest.useFakeTimers();

const departmentClassMap = new Map();
departmentClassMap.set('86', [45]);

const anchorResponse = { data: [854892] };

beforeEach(async () => {
  when(axios.get)
    .calledWith(
      `/api/multi-sku/zoneMultiplierGroups?zoneMultiplierGroupId=${zoneMultiplierGroupResponse.data.id}`
    )
    .mockResolvedValue(zoneMultiplierGroupResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/modeRetailStatus`, expect.anything())
    .mockResolvedValue(currentRetailResponse);
  when(axios.post)
    .calledWith(
      `/api/recommendation/zone-group-recommendations`,
      expect.anything()
    )
    .mockResolvedValue(recommendationResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/sku/dcs-description`, expect.anything())
    .mockResolvedValue(skuDetailsResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/sku/anchors`, expect.anything())
    .mockResolvedValue(anchorResponse);
  when(axios.post)
    .calledWith('/api/dataConnect/vendor/vendorData', expect.anything())
    .mockResolvedValue(vendorDataResponse);
  when(axios.post)
    .calledWith('/api/dataConnect/cost/first/blended', expect.anything())
    .mockResolvedValue({ data: costsDataResponse });

  await act(async () => {
    const { container } = render(
      <SkuContext.Provider
        value={{
          subDeptDataMap: {
            '0013': {
              name: '13-123',
              deptClassMap: departmentClassMap,
              description: '123',
              longDescription: 'TEST',
            },
          },
          updateShowDimmer: () => {},
        }}
      >
        <EditPricePage
          userId={'MC62YE'}
          userEmail={'Michelle_Cox_Bradford@homedepot.com'}
          backArrowClick={() => {}}
          zoneMultiplierGroupId={zoneMultiplierGroupResponse.data.id}
          skuGroupName={'Galvanized Pipe'}
          skuGroupId={'42823a09-790c-4a97-a681-61d65183a762'}
          skuList={[
            301329, 332259, 191396, 652490, 652512, 652520, 652539, 652547,
            652563, 652695, 689930,
          ]}
        />
      </SkuContext.Provider>
    );
  });
}, 30000);

describe('EditPricePage', () => {
  test('SKULEVEL_CONTENT', async () => {
    expect(screen.getAllByText('New Retail')[0]).toBeInTheDocument();
    await act(async () => {
      fireEvent.click(screen.getAllByTestId('new-retail-info')[0]);
    });
    expect(
      screen.getByText(
        'Hover over new retail price to view applied rules and understand how the system' +
          ' generated your new recommended price.'
      )
    ).toBeInTheDocument();
  });

  test('render Retail Table', async () => {
    await act(async () => {
      fireEvent.click(screen.getByText('Retail'));
    });
    expect(screen.getByText('Line Structure Metrics')).toBeInTheDocument();
  });

  test('render Edit New Retail Input popover', async () => {
    jest.setTimeout(30000);
    expect(screen.getByTestId('recommend_prices')).not.toBeDisabled();
    await act(async () => {
      fireEvent.click(screen.getByTestId('recommend_prices'));
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('recommend'));
      jest.runAllTimers();
    });
    await act(async () => {
      fireEvent.mouseOver(screen.getAllByTestId('new-retail-input-14.72')[0]);
      jest.runAllTimers();
    });

    expect(screen.getByText('Applied Rules')).toBeInTheDocument();
    expect(screen.getByText(/SKU to SKU:/)).toBeInTheDocument();
    expect(screen.getByText(/Zone Multiplier:/)).toBeInTheDocument();
    expect(screen.getByText(/1.406/)).toBeInTheDocument();
    await act(async () => {
      fireEvent.mouseLeave(screen.getAllByTestId(/new-retail-input-14.72/)[0]);
    });

    expect(screen.getByText('Applied Rules')).not.toBeVisible();
    expect(screen.getByText(/SKU to SKU/)).not.toBeVisible();
    expect(screen.getByText(/Zone Multiplier:/)).not.toBeVisible();
    expect(screen.getByText(/1.406/)).not.toBeVisible();
  });

  test('render Edit New Retail Input popover with manual update', async () => {
    await act(async () => {
      fireEvent.click(screen.getByTestId('recommend_prices'));
    });
    await act(async () => {
      fireEvent.click(screen.getByTestId('recommend'));
      jest.runAllTimers();
    });
    await act(async () => {
      fireEvent.change(screen.getAllByTestId('new-retail-input-14.72')[0], {
        target: { value: '23' },
      });
    });
    await act(async () => {
      fireEvent.mouseOver(screen.getAllByTestId(/new-retail-input-23/)[0]);
      jest.runAllTimers();
    });

    expect(screen.getByText('Applied Rules')).toBeInTheDocument();
    expect(screen.getByText(/Price manually set/));
    await act(async () => {
      fireEvent.mouseLeave(screen.getAllByTestId(/new-retail-input-23/)[0]);
    });
    expect(screen.getByText(/Price manually set/)).not.toBeVisible();
  });

  test('mode retail status', async () => {
    expect(screen.getAllByText('100 - Active')[0]).toBeInTheDocument();
  });

  test('mode retail popover', async () => {
    await act(async () => {
      fireEvent.mouseOver(screen.getByTestId(/mode-retail-301329/));
    });

    await waitFor(
      () => {
        expect(screen.getByText('400 - Inactive')).toBeInTheDocument();
      },
      { timeout: 2000 }
    );

    await act(async () => {
      fireEvent.mouseLeave(screen.getByTestId(/mode-retail-301329/));
    });

    await waitFor(
      () => {
        expect(screen.getByText('400 - Inactive')).not.toBeVisible();
      },
      { timeout: 500 }
    );
  });

  test('Description popover', async () => {
    await act(async () => {
      fireEvent.mouseOver(screen.getByTestId(/description-301329/));
      jest.runAllTimers();
    });
    expect(screen.getByText('3/4"X10\' GAL PIPE')).toBeInTheDocument();
  });

  test('render Edit New Retail Input ', async () => {
    await act(async () => {
      fireEvent.change(screen.getAllByTestId(/new-retail-input/)[0], {
        target: { value: '14.72' },
      });
      fireEvent.change(screen.getAllByTestId(/new-retail-input/)[1], {
        target: { value: '24.72' },
      });
      fireEvent.change(screen.getAllByTestId(/new-retail-input/)[2], {
        target: { value: '34.72' },
      });
      fireEvent.click(screen.getByTestId('update_metrics'));
    });
    expect(screen.queryByDisplayValue('243.74')).not.toBeInTheDocument();
    expect(screen.queryByDisplayValue('14.72')).toBeInTheDocument();
    expect(screen.queryByDisplayValue('24.72')).toBeInTheDocument();
    expect(screen.queryByDisplayValue('34.72')).toBeInTheDocument();
    await act(async () => {
      fireEvent.change(screen.getAllByTestId('new-retail-input-14.72')[0], {
        target: { value: '' },
      });
    });
    expect(screen.getAllByText('--')[0]).toBeInTheDocument();
  });

  test('render Edit Price Page when there is no anchor SKU ', async () => {
    const { container } = render(
      <SkuContext.Provider
        value={{
          updateShowDimmer: () => {},
        }}
      >
        <EditPricePage
          userId={'MC62YE'}
          userEmail={'Michelle_Cox_Bradford@homedepot.com'}
          backArrowClick={() => {}}
          zoneMultiplierGroupId={'3bf84d52-d3ee-4875-8a1b-c69d695dd7df'}
          skuGroupName={'Galvanized Pipe'}
          skuList={[
            332259, 191396, 652490, 652512, 652520, 652539, 652547, 652563,
            652695, 689930,
          ]}
          prevColumnTemplates={[]}
          prevCustomColumns={{}}
          skuGroupId={'42823a09-790c-4a97-a681-61d65183a762'}
        />
      </SkuContext.Provider>
    );
    expect(
      screen.getAllByText('Recommend Prices')[1].closest('button')
    ).toBeDisabled();
  });

  test('open Disaster Dropdown', async () => {
    await act(async () => {
      fireEvent.click(screen.getByTestId('update_metrics'));
    });
    expect(screen.queryByText('Total After Disaster')).toBeInTheDocument();
  });

  test('create custom column and paste single column values with no headers', async () => {
    //click settings
    await act(async () => {
      fireEvent.click(screen.getByTestId('edit-price-page-settings'));
    });
    expect(screen.queryByText('Column Settings')).toBeInTheDocument();

    //click column settings
    await act(async () => {
      fireEvent.click(screen.getByTestId('column-settings-drawer'));
    });

    //click add new column
    await act(async () => {
      fireEvent.click(screen.getByTestId('add-new-skuMuMd'));
    });

    //click apply button
    await act(async () => {
      fireEvent.click(screen.getByTestId('column-settings-apply-button'));
    });

    //create paste event
    const clipboardEvent = new Event('paste', {
      bubbles: true,
      cancelable: true,
      composed: true,
    });

    // set `clipboardData` and `getData` properties. Set your mocked properties here
    clipboardEvent['clipboardData'] = {
      getData: () => '301329\tabc\n' + '    332259\t123\n' + '    191396\t456',
    };

    //click into custom column
    await act(async () => {
      fireEvent.click(screen.getByTestId('custom-column-input-301329'));
    });

    //fire paste event into targeted custom column
    await act(async () => {
      fireEvent(
        screen.queryByTestId('custom-column-input-301329'),
        clipboardEvent
      );
    });

    //then assert that the values are present on DOM
    expect(screen.queryByTestId('custom-column-input-301329').value).toBe(
      'abc'
    );
    expect(screen.queryByTestId('custom-column-input-332259').value).toBe(
      '123'
    );
    expect(screen.queryByTestId('custom-column-input-191396').value).toBe(
      '456'
    );
  });

  test('create custom column and paste multiple columns with headers', async () => {
    //click settings
    await act(async () => {
      fireEvent.click(screen.getByTestId('edit-price-page-settings'));
    });
    expect(screen.queryByText('Column Settings')).toBeInTheDocument();

    //click column settings
    await act(async () => {
      fireEvent.click(screen.getByTestId('column-settings-drawer'));
    });

    //click add new column
    await act(async () => {
      fireEvent.click(screen.getByTestId('add-new-skuMuMd'));
    });

    await act(async () => {
      fireEvent.click(screen.getByTestId('add-new-skuMuMd'));
    });

    //click apply button
    await act(async () => {
      fireEvent.click(screen.getByTestId('column-settings-apply-button'));
    });

    //create paste event
    const clipboardEvent = new Event('paste', {
      bubbles: true,
      cancelable: true,
      composed: true,
    });

    // set `clipboardData` and `getData` properties. Set your mocked properties here
    clipboardEvent['clipboardData'] = {
      getData: () =>
        'sku\tNew Column 1\tnew column 2\tcore\r\n' +
        '    301329\tshiny\t1inch\t12\r\n' +
        '    332259\tmatte\t2inch\t15.1\r\n' +
        '    191396\tgloss\t3inch\t9.01\r',
    };

    //click into custom column
    await act(async () => {
      fireEvent.click(screen.getAllByTestId('custom-column-input-301329')[0]);
    });
    //fire paste event into targeted custom column
    await act(async () => {
      fireEvent(
        screen.queryAllByTestId('custom-column-input-301329')[0],
        clipboardEvent
      );
    });

    //then assert that the values are present on DOM
    expect(screen.queryAllByTestId('custom-column-input-301329')[1].value).toBe(
      'shiny'
    );
    expect(screen.queryAllByTestId('custom-column-input-332259')[1].value).toBe(
      'matte'
    );
    expect(screen.queryAllByTestId('custom-column-input-191396')[1].value).toBe(
      'gloss'
    );

    expect(screen.queryAllByTestId('custom-column-input-301329')[0].value).toBe(
      '1inch'
    );
    expect(screen.queryAllByTestId('custom-column-input-332259')[0].value).toBe(
      '2inch'
    );
    expect(screen.queryAllByTestId('custom-column-input-191396')[0].value).toBe(
      '3inch'
    );

    // New Retail Pastes
    expect(screen.queryByDisplayValue('12.00')).toBeInTheDocument();
    expect(screen.queryByDisplayValue('15.10')).toBeInTheDocument();
    expect(screen.queryByDisplayValue('9.01')).toBeInTheDocument();
  });
  test('recommend modal opening', async () => {
    when(axios.post)
      .calledWith(
        `/api/recommendation/zone-group-recommendations`,
        expect.anything()
      )
      .mockResolvedValue(recommendationResponse);
    await act(async () => {
      fireEvent.click(screen.getByText('Recommend Prices'));
    });
    await act(async () => {
      fireEvent.click(
        screen.getByText(/Recommend prices with Mode Retail where /)
      );
    });
    await act(async () => {
      fireEvent.click(screen.getAllByText('Recommend Prices')[1]);
    });
    expect(screen.queryByDisplayValue('14.72')).toBeInTheDocument();
  });

  describe('Cost Table', () => {
    beforeEach(async () => {
      await act(async () => {
        fireEvent.click(screen.getByText('Cost'));
      });
    });

    test('render Cost Table static columns', async () => {
      expect(screen.queryAllByText('SKU Information')[0]).toBeInTheDocument();
      expect(screen.queryAllByText('Galvanized Pipe')[0]).toBeInTheDocument();
      expect(screen.getAllByText('301329')[0]).toBeInTheDocument();
      expect(screen.getAllByText('652512')[0]).toBeInTheDocument();
      expect(screen.getAllByText('3/4"X10\' GAL PIPE')[0]).toBeInTheDocument();
      expect(screen.queryAllByText('Vendor/Cost')[0]).toBeInTheDocument();
    });

    describe('Vendor Selection', () => {
      beforeEach(async () => {
        await act(async () => {
          fireEvent.click(
            screen.getAllByTestId('column-search-filter-dropdown')[0]
          );
        });
      });

      test('search vendors in selection dropdown', async () => {
        const inputElement = await screen.findByPlaceholderText(
          'Search vendors in this table'
        );
        expect(inputElement).toBeInTheDocument();
        expect(screen.getByText('CHARLOTTE PIPE (#26492)')).toBeInTheDocument();
        expect(
          screen.getByText('INTERLINE BRANDS (#60005081)')
        ).toBeInTheDocument();
        // Search by number
        await act(async () => {
          fireEvent.input(inputElement, { target: { value: '60005081' } });
        });
        expect(screen.queryByText('CHARLOTTE PIPE (#26492)')).toBeNull();
        expect(
          screen.getByText('INTERLINE BRANDS (#60005081)')
        ).toBeInTheDocument();
        // Clear search
        await act(async () => {
          fireEvent.input(inputElement, { target: { value: '' } });
        });
        expect(screen.getByText('CHARLOTTE PIPE (#26492)')).toBeInTheDocument();
        expect(
          screen.getByText('INTERLINE BRANDS (#60005081)')
        ).toBeInTheDocument();
        // Search by name
        await act(async () => {
          fireEvent.input(inputElement, {
            target: { value: 'CHARLOTTE PIPE' },
          });
        });
        expect(screen.getByText('CHARLOTTE PIPE (#26492)')).toBeInTheDocument();
        expect(screen.queryByText('INTERLINE BRANDS (#60005081)')).toBeNull();
      });

      test('selecting vendor from vendor dropdown displays selected icon', async () => {
        const selectedIcon = screen.getByTestId('selected-option-icon');
        const parentOfSelected = selectedIcon.parentElement;
        expect(parentOfSelected).toContainElement(
          screen.getByText('CHARLOTTE PIPE (#26492)')
        );
        await act(async () => {
          fireEvent.click(screen.getByText('INTERLINE BRANDS (#60005081)'));
        });
        const newSelectedIcon = screen.getByTestId('selected-option-icon');
        const parentOfNewlySelected = newSelectedIcon.parentElement;
        expect(parentOfNewlySelected).toContainElement(
          screen.getByText('INTERLINE BRANDS (#60005081)')
        );
      });

      test('selecting vendor displays markets for vendor', async () => {
        await act(async () => {
          fireEvent.click(screen.getByText('INTERLINE BRANDS (#60005081)'));
        });
        expect(screen.queryAllByText('OUTER ISLANDS')[0]).toBeInTheDocument();
        expect(screen.queryAllByText('314')[0]).toBeInTheDocument();
        await act(async () => {
          fireEvent.click(
            screen.getAllByTestId('column-search-filter-dropdown')[0]
          );
        });
        await act(async () => {
          fireEvent.click(
            screen.getByText('CHARLOTTE PIPE & FOUNDRY (#80332)')
          );
        });
        expect(screen.queryAllByText('OUTER ISLANDS')[0]).toBeUndefined();
        expect(screen.queryAllByText('314')[0]).toBeUndefined();
        expect(
          screen.queryAllByText('JACKSONVILLE, IL')[0]
        ).toBeInTheDocument();
        expect(screen.queryAllByText('586')[0]).toBeInTheDocument();
        expect(screen.queryAllByText('ST. LOUIS')[0]).toBeInTheDocument();
        expect(screen.queryAllByText('109')[0]).toBeInTheDocument();
      });
    });

    test('render market column headers', async () => {
      expect(screen.queryAllByText('Mkt/DC')[0]).toBeInTheDocument();
      expect(screen.queryAllByText('Mkt/DC Name')[0]).toBeInTheDocument();
    });

    describe('current/blended cost columns', () => {
      test('render current/blended cost columns headers', async () => {
        expect(screen.getByText('Current Blended Cost')).toBeInTheDocument();
        expect(screen.getByText('Current Cost')).toBeInTheDocument();
      });

      test('render the current/blended cost data based on the selected vendor', async () => {
        await act(async () => {
          fireEvent.click(
            screen.getAllByTestId('column-search-filter-dropdown')[0]
          );
        });
        await act(async () => {
          fireEvent.click(
            screen.getByText('VALENCIA PIPE COMPANY (D (#18608)')
          );
        });

        const costsForSelectedVendor = costsDataResponse.filter(
          (cost) => cost.vendor === 18608
        );

        for (let cost of costsForSelectedVendor) {
          const formattedBlendedCost =
            '$' + CompUtil.formatPrice(cost.blendedCost, true);
          const formattedCurrentCost =
            '$' + CompUtil.formatPrice(cost.firstCost, true);
          const blendedCostElement = await screen.findByText(
            formattedBlendedCost
          );
          const currentCostElement = await screen.findByText(
            formattedCurrentCost
          );
          expect(blendedCostElement).toBeInTheDocument();
          expect(currentCostElement).toBeInTheDocument();
        }
      });

      test('render -- if there is no cost/blended cost for the selected vendor', async () => {
        await act(async () => {
          fireEvent.click(
            screen.getAllByTestId('column-search-filter-dropdown')[0]
          );
        });
        await act(async () => {
          fireEvent.click(
            screen.getByText('CHARLOTTE PIPE & FOUNDRY (#80332)')
          );
        });

        const costsForSelectedVendor = costsDataResponse.filter(
          (cost) => cost.vendor === 80332
        );

        for (let cost of costsForSelectedVendor) {
          if (!cost.firstCost || !cost.blendedCost) {
            const noCostElement = await screen.findByText('--');
            expect(noCostElement).toBeInTheDocument();
          }
        }
      });
    });
  });
});

afterAll(() => {
  jest.resetAllMocks();
});
