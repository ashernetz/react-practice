import SingleAndMultiSkuServices from '../../../../services/SingleAndMultiSkuServices';

export default class DataBarUtil {
  static buildSkuZoneRequest = (
    skuList,
    zoneMultiplierGroupData,
    newRetails = {},
    newCosts = {}
  ) => {
    let request = [];

    skuList.forEach((sku) => {
      zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
        const newRetail =
          newRetails[sku] &&
          newRetails[sku][zoneGroup.id] &&
          newRetails[sku][zoneGroup.id].retail;
        const newCost = newCosts[sku];

        zoneGroup.zones.forEach((zone) => {
          let requestObj = {
            sku: parseInt(sku),
            traitId: zone.traitId,
          };

          if (newRetail) {
            requestObj.price = Math.round(parseFloat(newRetail) * 100);
          }
          if (newCost) {
            requestObj.costOverride = Math.round(parseFloat(newCost) * 100);
          }

          request.push(requestObj);
        });
      });
    });
    return request;
  };

  static getCurrentImuLineStructure = (
    skuList,
    zoneMultiplierGroupData,
    setCurrentImuLineStructureValue,
    setLoadingImuLineStructureCurrent
  ) => {
    let request = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData
    );
    let imuResponse = [];
    SingleAndMultiSkuServices.fetchCurrentLineStructureIMU(request)
      .then((response) => {
        imuResponse = response.data;
        setCurrentImuLineStructureValue(parseFloat(imuResponse.imu));
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setLoadingImuLineStructureCurrent(false);
      });
  };

  static getProjectedImuLineStructure = (
    skuList,
    zoneMultiplierGroupData,
    newRetails,
    newCosts,
    setProjectedImuLineStructureValue,
    setLoadingImuLineStructureProjected,
    setDisasterProjectedImuLineStructureValue,
    setLoadingDisasterImuLineStructureProjected,
    isDisaster,
    retries = 3
  ) => {
    let request = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts
    );
    let imuResponse = [];
    SingleAndMultiSkuServices.fetchProjectedLineStructureIMU(
      request,
      isDisaster
    )
      .then((response) => {
        imuResponse = response.data;
        if (isDisaster) {
          setDisasterProjectedImuLineStructureValue(
            parseFloat(imuResponse.imu)
          );
        } else {
          setProjectedImuLineStructureValue(parseFloat(imuResponse.imu));
        }
      })
      .catch((err) => {
        if (retries > 0) {
          const retriesRemaining = retries - 1;
          return DataBarUtil.getProjectedImuLineStructure(
            skuList,
            zoneMultiplierGroupData,
            newRetails,
            newCosts,
            setProjectedImuLineStructureValue,
            setLoadingImuLineStructureProjected,
            setDisasterProjectedImuLineStructureValue,
            setLoadingDisasterImuLineStructureProjected,
            isDisaster,
            retriesRemaining
          );
        }
        console.log(err);
      })
      .finally(() => {
        if (isDisaster) {
          setLoadingDisasterImuLineStructureProjected(false);
        } else {
          setLoadingImuLineStructureProjected(false);
        }
      });
  };
}
