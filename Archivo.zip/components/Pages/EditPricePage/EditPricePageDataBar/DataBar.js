import React from 'react';
import { Button, Col, Divider, Popover, Row, Typography } from 'antd';
import './DataBar.scss';
import { SkuGroupData } from './DataBarComponents/SkuGroupDataComponent';
import { IMUData } from './DataBarComponents/IMUComponent';
import { MarkUpMarkDownData } from './DataBarComponents/MarkupMarkDownComponent';
import { CompetitorCpiData } from './DataBarComponents/CompetitorCPIComponent';
import EditPriceUtil from '../Util/EditPriceUtil';
import { CaretRightOutlined, InfoCircleOutlined } from '@ant-design/icons';

const { Text } = Typography;

const DataBar = (props) => {
  // TODO use DisasterData
  const {
    cpiData: { cpiList = [], isLoading },
    disasterData: {
      disasterCpiData: { projectedCpi = [], isProjectedLoading },
      disasterMarkUpTotal,
      disasterMarkDownTotal,
      loadingDisasterMuMd,
      disasterProjectedImuLineStructureValue,
      loadingDisasterImuLineStructureProjected,
      setIsDisasterBarOpen,
      isDisasterBarOpen,
    },
    selectedTableTab,
  } = props;

  const filterProjectedCpiData = (
    competitorId,
    dataConnectCpiValues,
    myPriceCpiValues,
    projCpiValues
  ) => {
    let dcCpi =
      dataConnectCpiValues &&
      dataConnectCpiValues.find((item) => item.competitorId === competitorId);
    let mpCpi =
      myPriceCpiValues &&
      myPriceCpiValues.find((item) => item.competitorId === competitorId);
    let projCpi = projCpiValues[competitorId];
    if (dcCpi && mpCpi && projCpi) {
      return EditPriceUtil.projectedCpiThreshold(
        dcCpi['cpi'],
        mpCpi['cpi'],
        projCpi
      );
    }
  };

  const toggleDisasterBar = () => {
    setIsDisasterBarOpen(!isDisasterBarOpen);
  };

  const createCpiList = (
    cpiList,
    isLoading,
    myPriceCpiData,
    projectedCpiData,
    projectedCpiDisasterData,
    isDisasterImpact = false
  ) => {
    return cpiList.map((item) => (
      <Col key={item.competitorId} flex="0 0 100px" className="cpi-data-bar">
        <CompetitorCpiData
          isDisasterImpact={isDisasterImpact}
          competitorName={!isDisasterImpact && item.competitorName}
          currentCpi={item.cpi}
          currentCpiIsLoading={isLoading}
          isWithinThreshold={filterProjectedCpiData(
            item.competitorId,
            cpiList,
            myPriceCpiData.cpiList,
            projectedCpiData.projectedCpi
          )}
          projectedCpi={projectedCpiData.projectedCpi[item.competitorId]}
          projectedCpiDisaster={projectedCpi[item.competitorId]}
          projectedCpiIsLoading={projectedCpiData.isProjectedLoading}
          projectedCpiDisasterIsLoading={isProjectedLoading}
          isDisasterBarOpen={isDisasterBarOpen}
        />
      </Col>
    ));
  };

  const renderCpiList = createCpiList(
    cpiList,
    isLoading,
    props.myPriceCpiData,
    props.projectedCpiData,
    props.projectedCpiDisasterData
  );

  const disasterImpactInfoContent = (
    <div
      className="disaster-impact-info-content"
      data-testid="disaster-impact-tooltip"
    >
      <p>
        <strong>Disaster Impact</strong> shows what will be subtracted due to
        disaster markets.
      </p>
      <p>
        <strong>Total After Disaster</strong> shows the new total with disaster
        impact subtracted.
      </p>
    </div>
  );
  return (
    <Row className="data-bar-container">
      <Col flex="auto">
        <Row gutter={[16, 0]} className="data-bar-box-wrapper">
          <Col flex="0 0 25px">
            <Row>
              <Col>
                <Text className="data-bar-title">Metrics</Text>
              </Col>
            </Row>
            <Row className="disaster-impact-row">
              <Col flex="0 0 25px">
                <Button
                  className="disaster-impact-button"
                  type="link"
                  size={'small'}
                  onClick={() => toggleDisasterBar()}
                >
                  <CaretRightOutlined
                    className={`data-bar-caret-icon ${
                      isDisasterBarOpen ? 'is-bar-open' : ''
                    }`}
                  />
                  <Text className="data-bar-title disaster-impact">
                    Disaster Impact
                  </Text>
                </Button>
                <Popover
                  content={disasterImpactInfoContent}
                  trigger="hover"
                  placement="top"
                >
                  <Button
                    type="link"
                    size={'small'}
                    icon={<InfoCircleOutlined className="data-bar-info-icon" />}
                    data-testid="disaster-impact-info-icon"
                  />
                </Popover>
              </Col>
            </Row>
            {isDisasterBarOpen && (
              <Row>
                <Col>
                  <Text className="data-bar-title disaster-impact disaster-impact--total">
                    Total After Disaster
                  </Text>
                </Col>
              </Row>
            )}
          </Col>
          {selectedTableTab !== 'Cost' && renderCpiList}
          {selectedTableTab !== 'Cost' && (
            <>
              <Col flex="0 0 50px">
                <Divider
                  type="vertical"
                  style={{
                    height: isDisasterBarOpen ? '92px' : '46px',
                    borderLeft: '1px solid #CACACA',
                    paddingRight: '52px',
                  }}
                />
              </Col>
              <Col flex="0 0 75px">
                <MarkUpMarkDownData
                  title={'MU'}
                  value={props.markUpTotal}
                  isMuMdLoading={props.loadingMuMd}
                  isDisasterBarOpen={isDisasterBarOpen}
                  disasterValue={disasterMarkUpTotal}
                  isDisasterLoading={loadingDisasterMuMd}
                />
              </Col>
              <Col flex="0 0 75px">
                <MarkUpMarkDownData
                  title={'MD'}
                  value={props.markDownTotal}
                  isMuMdLoading={props.loadingMuMd}
                  isDisasterBarOpen={isDisasterBarOpen}
                  disasterValue={disasterMarkDownTotal}
                  isDisasterLoading={loadingDisasterMuMd}
                />
              </Col>
              <Col flex="0 0 75px">
                <MarkUpMarkDownData
                  title={'MU-MD'}
                  value={props.markUpTotal + props.markDownTotal}
                  isMuMdLoading={props.loadingMuMd}
                  isDisasterBarOpen={isDisasterBarOpen}
                  disasterValue={disasterMarkUpTotal + disasterMarkDownTotal}
                  isDisasterLoading={loadingDisasterMuMd}
                />
              </Col>
              <Col flex="0 0 50px">
                <Divider
                  type="vertical"
                  style={{
                    height: isDisasterBarOpen ? '92px' : '46px',
                    borderLeft: '1px solid #CACACA',
                    marginLeft: '52px',
                    paddingRight: '52px',
                    marginRight: '0px',
                  }}
                />
              </Col>
            </>
          )}
          {selectedTableTab !== 'Cost' && (
            <Col flex="0 0 150px">
              <IMUData
                title={'IMU'}
                currentImu={props.currentImuLineStructure}
                projectedIMU={props.projectedImuLineStructureValue}
                currentImuIsLoading={props.loadingImuLineStructureCurrent}
                projectedImuIsLoading={props.loadingImuLineStructureProjected}
                disasterProjectedIMU={disasterProjectedImuLineStructureValue}
                disasterProjectedImuIsLoading={
                  loadingDisasterImuLineStructureProjected
                }
                isDisasterBarOpen={isDisasterBarOpen}
              />
            </Col>
          )}
        </Row>
      </Col>
    </Row>
  );
};
export default DataBar;
