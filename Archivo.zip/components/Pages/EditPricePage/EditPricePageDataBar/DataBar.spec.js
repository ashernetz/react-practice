import React from 'react';
import '@testing-library/jest-dom';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import DataBar from './DataBar';
import { act } from 'react-dom/test-utils';

const getProps = (props = {}) => ({
  cpiData: {
    cpiList: [],
    isLoading: false,
  },
  disasterData: {
    disasterCpiData: {
      disasterCpiList: [],
    },
    setIsDisasterBarOpen: jest.fn(),
    isDisasterBarOpen: false,
  },
  skus: [],
  ...props,
});
jest.useFakeTimers();

describe('Disaster Impact Header', () => {
  test('renders Disaster Impact title', () => {
    render(<DataBar {...getProps()} />);
    expect(screen.getByText('Disaster Impact')).toBeInTheDocument();
  });

  test('opens Disaster dropdown when Disaster Impact is clicked', () => {
    const props = getProps({
      disasterData: { ...getProps().disasterData, isDisasterBarOpen: true },
    });
    render(<DataBar {...props} />);
    fireEvent.click(screen.getByText('Disaster Impact'));
    expect(props.disasterData.setIsDisasterBarOpen).toHaveBeenCalledWith(
      !props.disasterData.isDisasterBarOpen
    );
    expect(screen.getByText('Total After Disaster')).toBeInTheDocument();
  });

  test('opens Disaster tooltip on hover info icon', async () => {
    render(<DataBar {...getProps()} />);

    const infoIcon = screen.getByTestId('disaster-impact-info-icon');
    const tooltipText = /shows what will be subtracted due to disaster markets/;

    await act(async () => {
      fireEvent.mouseOver(infoIcon);
    });

    await waitFor(
      () => {
        expect(screen.getByText(tooltipText)).toBeInTheDocument();
      },
      { timeout: 2000 }
    );

    await act(async () => {
      fireEvent.mouseLeave(infoIcon);
    });

    await waitFor(
      () => {
        expect(screen.getByText(tooltipText)).not.toBeVisible();
      },
      { timeout: 500 }
    );
  });
});
