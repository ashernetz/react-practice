import SingleAndMultiSkuServices from '../../../../services/SingleAndMultiSkuServices';
import HeaderServices from '../../../../services/HeaderServices';
import DCSUtil from '../../../Utils/DCSUtil';
import DataBarUtil from '../EditPricePageDataBar/DataBarUtil';
import { CompetitorNameAndIdList } from '../../../../constants/typecode';
import {
  MODE_RETAIL_POPOVER,
  MODE_RETAIL_STATUS,
} from '../../../../constants/ToolTip';
import _ from 'lodash';

export default class EditPriceUtil {
  static fetchAnchorSkus(skuList, setAnchorSkus) {
    setAnchorSkus({ data: new Set(), isLoading: true });

    SingleAndMultiSkuServices.fetchAnchorSkus(skuList)
      .then((response) => {
        let anchorSkus = new Set(response.data || []);
        setAnchorSkus({ data: anchorSkus, isLoading: false });
      })
      .catch(() => {
        setAnchorSkus({ data: new Set(), isLoading: false });
      });
  }

  static fetchSkuDescriptionAndDCS(skuList, setSkuDescriptions, setSkuDCS) {
    setSkuDCS({ data: {}, isLoading: true });
    setSkuDescriptions({ data: {}, isLoading: true });

    SingleAndMultiSkuServices.fetchSkusDcsAndDescriptions(skuList)
      .then((response) => {
        let results = response.data;
        let skuDescriptions = {};
        let skuDCS = {};
        results.forEach((skuData) => {
          skuDescriptions[skuData.sku] = skuData.description || '';
          skuDCS[skuData.sku] = skuData.dcs || '';
        });
        setSkuDescriptions({ data: skuDescriptions, isLoading: false });
        setSkuDCS({ data: skuDCS, isLoading: false });
      })
      .catch(() => {
        setSkuDCS({ data: {}, isLoading: false });
        setSkuDescriptions({ data: {}, isLoading: false });
      });
  }

  static fetchCurrentCostBySkus(skuList, setCosts) {
    setCosts({ data: {}, isLoading: true });
    SingleAndMultiSkuServices.currentCostBySku(skuList)
      .then((response) => {
        let currentCost = response.data;
        let costsBySku = {};
        currentCost.forEach((skuData) => {
          costsBySku[skuData.sku] = skuData.cost / 100;
        });
        setCosts({ data: costsBySku, isLoading: false });
      })
      .catch(() => {
        setCosts({ data: {}, isLoading: false });
      });
  }

  static fetchZoneMultiplierGroups(
    zoneMultiplierGroupId,
    setZoneMultiplierGroupData
  ) {
    SingleAndMultiSkuServices.fetchZoneMultiplierGroups(zoneMultiplierGroupId)
      .then((response) => {
        let zoneMultiplierData = response.data;
        zoneMultiplierData.zoneGroups.forEach((zoneGroup) => {
          zoneGroup.isAnchor =
            zoneGroup.id === zoneMultiplierData.anchorGroupId;
        });
        setZoneMultiplierGroupData(zoneMultiplierData);
      })
      .catch((err) => {
        console.log(err);
        setZoneMultiplierGroupData({});
      });
  }

  static fetchMarkUpMarkDownBySku(
    skuList,
    zoneMultiplierGroupData,
    newRetails,
    setSkuZoneMuMd,
    setNetSkuZoneMuMd,
    setMarkUpTotal,
    setMarkDownTotal,
    setLoadingMuMd,
    isDisaster,
    setDisasterMarkUpTotal,
    setDisasterMarkDownTotal,
    setLoadingDisasterMuMd
  ) {
    let skuZonePriceList = this.buildSkuZonePriceRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails
    );
    if (skuZonePriceList.length < 1) {
      setLoadingMuMd(false);
      setLoadingDisasterMuMd(false);
      return;
    }

    let skuZoneMuMdMap = {};
    let traitIdZoneIdMap = this.buildTraitIdZoneIdMap(zoneMultiplierGroupData);
    let netSkuMuMd = {};
    SingleAndMultiSkuServices.fetchMarkUpMarkDown(skuZonePriceList, isDisaster)
      .then((response) => {
        let markUpTotal = 0;
        let markDownTotal = 0;
        response.data.forEach((skuzonemarkup) => {
          let skuNumber = skuzonemarkup.sku;
          let markUpMarkDown = skuzonemarkup.markup / 100;
          let traitId = skuzonemarkup.traitId;
          let zoneGroupId = traitIdZoneIdMap.get(traitId);

          if (zoneGroupId) {
            skuZoneMuMdMap[skuNumber] = skuZoneMuMdMap[skuNumber] || {};
            skuZoneMuMdMap[skuNumber][zoneGroupId] =
              skuZoneMuMdMap[skuNumber][zoneGroupId] || 0;

            skuZoneMuMdMap[skuNumber][zoneGroupId] += markUpMarkDown;

            if (markUpMarkDown > 0) {
              markUpTotal += markUpMarkDown;
            } else {
              markDownTotal += markUpMarkDown;
            }
          }
        });
        skuList.forEach((sku) => {
          if (skuZoneMuMdMap[sku]) {
            netSkuMuMd[sku] = Object.values(skuZoneMuMdMap[sku]).reduce(
              (a, b) => a + b
            );
          }
        });

        setSkuZoneMuMd(skuZoneMuMdMap);
        setNetSkuZoneMuMd(netSkuMuMd);

        if (isDisaster) {
          setDisasterMarkUpTotal(markUpTotal);
          setDisasterMarkDownTotal(markDownTotal);
        } else {
          setMarkUpTotal(markUpTotal);
          setMarkDownTotal(markDownTotal);
        }
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        if (isDisaster) {
          setLoadingDisasterMuMd(false);
        } else {
          setLoadingMuMd(false);
        }
      });
  }

  static buildSkuZonePriceRequest = (
    skuList,
    zoneMultiplierGroupData,
    newRetails
  ) => {
    let skuZonePriceRequest = [];
    skuList.forEach((sku) => {
      zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
        let newRetail =
          newRetails[sku] &&
          newRetails[sku][zoneGroup.id] &&
          newRetails[sku][zoneGroup.id].retail;
        if (newRetail) {
          zoneGroup.zones.forEach((zone) => {
            skuZonePriceRequest.push({
              sku: parseInt(sku),
              traitId: zone.traitId,
              price: Math.round(parseFloat(newRetail) * 100),
            });
          });
        }
      });
    });
    return skuZonePriceRequest;
  };

  static buildTraitIdZoneIdMap = (zoneMultiplierGroupData) => {
    let traitIdZoneIdMap = new Map();

    zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
      zoneGroup.zones.forEach((zone) => {
        traitIdZoneIdMap.set(zone.traitId, zoneGroup.id);
      });
    });

    return traitIdZoneIdMap;
  };

  static generateRCW(userId, payload, callback = () => {}, updateShowDimmer) {
    updateShowDimmer(true);
    SingleAndMultiSkuServices.generateRcw(userId, payload)
      .then((response) => {
        if (response.data === 'no recommendations generated') {
          callback(false);
        } else {
          callback(true);
        }
        console.log(response);
      })
      .catch((err) => {
        callback(false);
        console.log(err);
      })
      .finally(() => {
        updateShowDimmer(false);
      });
  }

  /**
   * Calculates the proportion/weighting between "retail : anchorRetail", and returns that proportion if it differs
   * from the input weight.
   * @param anchorRetail retail of the anchor sku
   * @param retail retail of a corresponding non-anchor sku
   * @param weight default weight of the non-anchor sku's retail compared to the anchor sku's retail.
   * @returns {string|null} the new weight between anchor and non-anchor, or null if the new weight is equal to
   * the default weight or any input is null.
   */
  static calculateOverrideWeight = (anchorRetail, retail, weight) => {
    if (retail && anchorRetail && weight) {
      anchorRetail = parseFloat(anchorRetail);

      let overrideWeight = retail / anchorRetail;
      overrideWeight = overrideWeight.toFixed(10);

      let isOverride =
        Math.abs(weight * parseFloat(anchorRetail) - parseFloat(retail)) >=
        0.006;
      return isOverride ? overrideWeight : null;
    }
    return null;
  };

  static projectedCpiThreshold = (dcCpi, mpCpi, projectedCpi) => {
    if (dcCpi && mpCpi) {
      let percentDifference = Math.abs(1 - mpCpi / dcCpi) * 100;
      return projectedCpi && percentDifference <= 0.5;
    }

    return false;
  };

  static buildRecommendationRequest = (
    zoneMultiplierGroupId,
    newRetails,
    rules,
    targetRules
  ) => {
    const prices = [];
    for (let sku in newRetails) {
      const retail = newRetails[sku];
      for (let zoneGroupId in retail) {
        if (retail[zoneGroupId] && retail[zoneGroupId].retail) {
          const data = {
            sku: sku,
            zoneGroupId: zoneGroupId,
            price: Math.round(retail[zoneGroupId].retail * 100),
          };
          prices.push(data);
        }
      }
    }
    return {
      zoneMultiplierGroupId: zoneMultiplierGroupId,
      prices: prices,
      recommendationLayers: rules,
      targetRules: this.buildTargetRules(targetRules),
    };
  };

  static buildTargetRules = (targetRules) => {
    let targetRulesObj = {};
    targetRulesObj['scope'] = targetRules.scope;
    targetRulesObj['strategy'] = targetRules.strategy;
    let targetsArray = [];
    let targetsObj = {};
    targetRules.targets.forEach((obj) => {
      targetsObj['targets'] = {};
      if (obj.target === 'IMU') {
        targetsObj['targets']['target'] = 'IMU';
        targetsObj['targets']['value'] = obj.value;
      }
      if (obj.target === 'MARKUP') {
        targetsObj['targets']['target'] = 'MUMD';
        targetsObj['targets']['value'] = obj.value * 100;
      }
      if (obj.target === 'MARKDOWN') {
        targetsObj['targets']['target'] = 'MUMD';
        targetsObj['targets']['value'] = '-' + obj.value * 100;
      }
      if (obj.zoneGroupId) {
        targetsObj['targets']['zoneGroupId'] = obj.zoneGroupId;
      }
      targetsArray.push(targetsObj['targets']);
    });

    targetRulesObj['targets'] = targetsArray;
    return targetRulesObj;
  };

  /**
   * Gets recommended retails from PLS based on line-structure rules, puts the recommendations in the state, and
   * sets all retails to the recommended prices.
   * @param skuList array of skus on the edit price page.
   * @param anchorSku Anchor sku to generate recommendations using.
   * @param zoneMultiplierGroupData zone multiplier group response from zone-group-management api.
   * @param zoneGroupCurrentRetailData object that contains the sku-zoneGroup current retail level data
   * @param newRetails newRetails for each sku-zoneGroup.
   * @param setNewRetails setState function to set new retails
   * @param removeMuMdSkus function to remove mu/md
   * @param setRecommendations setState function for recommendations.
   * @param updateShowDimmer function to show loading symbol while waiting on response.
   * @param setRecommendations setState Function to get recommendation rules
   * @param rules
   * @param override
   * @param targetRules
   * @param isCurrentRetailUsed boolean value that is used to determine if the old retail should be used when no new retail is provided
   */
  static getRecRetails = (
    skuList,
    anchorSku,
    zoneMultiplierGroupData,
    newRetails,
    setNewRetails,
    removeMuMdSkus,
    updateShowDimmer,
    setRecommendations,
    rules,
    override,
    targetRules
  ) => {
    let recommendationRequest = this.buildRecommendationRequest(
      zoneMultiplierGroupData.id,
      newRetails,
      rules,
      targetRules
    );
    //fetch recommendations from endpoint
    updateShowDimmer(true);

    SingleAndMultiSkuServices.getZoneGroupRecommendation(recommendationRequest)
      .then((response) => {
        let recommendations = response.data;

        // Format recs into an index-able object.
        let skuZoneGroupRecs = {};
        recommendations.forEach((rec) => {
          let zoneGroupId = rec.zoneGroupId;
          if (rec.recommendation && rec.recommendation.recommendationList) {
            skuZoneGroupRecs[rec.sku] = skuZoneGroupRecs[rec.sku] || {};
            skuZoneGroupRecs[rec.sku][zoneGroupId] = rec;
          }
        });
        setRecommendations(skuZoneGroupRecs);
        this.setSkuZoneGroupRecommendations(
          skuList,
          zoneMultiplierGroupData,
          skuZoneGroupRecs,
          newRetails,
          setNewRetails,
          removeMuMdSkus,
          override
        );
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        updateShowDimmer(false);
      });
  };

  /**
   * Iterates through the sku-zoneGroup pairs, and sets each sku-zoneGroup retail to its recommended price.
   * @param skuList list of skus to get recommendations for.
   * @param zoneMultiplierGroupData zoneMultiplierGroup data to get recommendations for.
   * @param skuZoneGroupRecs line structure recommendations with format: object[sku_number][zoneGroupId] = pls_recommendation_object.
   */
  static setSkuZoneGroupRecommendations(
    skuList,
    zoneMultiplierGroupData,
    skuZoneGroupRecs,
    newRetails,
    setNewRetails,
    removeMuMdSkus,
    override
  ) {
    let newSkuZoneRetails = { ...newRetails };

    skuList.forEach((sku) => {
      let newZoneRetails = newSkuZoneRetails[sku] || {};
      zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
        let retail = this.findZoneGroupRetail(sku, zoneGroup, skuZoneGroupRecs);
        if (retail) {
          if (
            !override &&
            newRetails[sku] &&
            newRetails[sku][zoneGroup.id] &&
            newRetails[sku][zoneGroup.id].isManualEdit
          ) {
            return; // If we should not override manual edits AND this is a manually input retail, continue.
          }
          const roundedRetail = (Math.round(retail * 100) / 100).toFixed(2);
          newZoneRetails[zoneGroup.id] = {
            retail: roundedRetail,
            isManualEdit: false,
          };
        }
      });
      newSkuZoneRetails[sku] = newZoneRetails;
    });
    setNewRetails(newSkuZoneRetails);
    removeMuMdSkus(skuList);
  }

  /**
   * to find a retail for any zoneGroupId in the input zoneGroup object.
   * @param sku sku to pull recommendation for.
   * @param zoneGroup zoneGroup to pull recommendation for.
   * @param skuZoneGroupRecs line structure recommendations with format: object[sku_number][zoneGroupId] = pls_recommendation_object.
   * @returns {string} retail in dollars
   */
  static findZoneGroupRetail(sku, zoneGroup, skuZoneGroupRecs) {
    let skuRecs = skuZoneGroupRecs[sku];
    if (skuRecs) {
      let rec = skuZoneGroupRecs[sku][zoneGroup.id];
      if (rec) {
        return (
          parseFloat(rec['recommendation']['recommendedPrice']) / 100
        ).toString();
      }
    }
    return undefined;
  }

  static splitDcs = (hypenatedDcs) => {
    let dcs = hypenatedDcs.split('-');
    let subDepartment = dcs[0];
    let classNumber = parseInt(dcs[1]);
    let subClassNumber = parseInt(dcs[2]);
    return { subDepartment, classNumber, subClassNumber };
  };
  static extractHierarchy = (hyphenatedDcs, subDeptDataMap) => {
    let dcs = hyphenatedDcs.split('-');
    let department = parseInt(dcs[0]);
    let classNumber = parseInt(dcs[1]);
    let subClassNumber = parseInt(dcs[2]);
    let subDepartment = DCSUtil.getSubDept(
      subDeptDataMap,
      department,
      classNumber
    );
    return { department, subDepartment, classNumber, subClassNumber };
  };

  static fetchZoneByDCS = (hierarchy, setZoneByDcsList) => {
    let zoneDcs = {};
    HeaderServices.fetchZoneByDCS(
      hierarchy.subDepartment,
      hierarchy.classNumber,
      hierarchy.subClassNumber
    )
      .then((response) => {
        let zoneList = response.data;
        zoneDcs = zoneList.zones.reduce(
          (total, current) => ({
            ...total,
            [current.zoneId]: current.zoneName,
          }),
          {}
        );
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setZoneByDcsList(zoneDcs);
      });
  };

  static fetchPermRetailBySku = (skuList, setPermRetailOccurrence) => {
    SingleAndMultiSkuServices.permRetailBySku(skuList)
      .then((response) => {
        let responseData = response.data;
        let permRetailStoreOccurrences = {};
        responseData.forEach((object) => {
          permRetailStoreOccurrences[object.sku] = {
            permRetail: object.retail / 100,
            occurrences: object.occurrences,
          };
        });
        setPermRetailOccurrence(permRetailStoreOccurrences);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  static fetchSkuLevelImu = (
    skuList,
    setNetSkuLevelImu,
    zoneMultiplierGroupData
  ) => {
    let request = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData
    );
    setNetSkuLevelImu((prevState) => ({ ...prevState, isLoading: true }));
    let skuLevelImu = {};
    SingleAndMultiSkuServices.fetchSkuLevelImu(request)
      .then((response) => {
        let responseData = response.data;
        responseData.forEach((item) => {
          skuLevelImu[item.sku] = { ...item };
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setNetSkuLevelImu((prevState) => ({
          ...prevState,
          data: skuLevelImu,
          isLoading: false,
        }));
      });
  };

  static fetchProjectedSkuLevelImu = (
    skuList,
    setProjectedNetSkuLevelImu,
    zoneMultiplierGroupData,
    newRetails,
    newCosts
  ) => {
    let request = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts
    );
    setProjectedNetSkuLevelImu((prevState) => ({
      ...prevState,
      isLoading: true,
    }));
    let projectedSkuLevelImu = {};
    SingleAndMultiSkuServices.fetchProjectedSkuLevelImu(request)
      .then((response) => {
        let responseData = response.data;
        responseData.forEach((item) => {
          projectedSkuLevelImu[item.sku] = { ...item };
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setProjectedNetSkuLevelImu((prevState) => ({
          ...prevState,
          data: projectedSkuLevelImu,
          isLoading: false,
        }));
      });
  };

  static fetchPermRetailBySkuZoneGroup = (
    skuList,
    zoneMultiplierGroupData,
    setPermRetailBySkuZoneGroup,
    setLoadingZoneModeRetail
  ) => {
    setLoadingZoneModeRetail(true);

    let permRetailBySkuZoneGroup = {};
    let request = {
      skus: skuList,
      zoneMultiplierGroupId: zoneMultiplierGroupData.id,
    };

    SingleAndMultiSkuServices.permRetailBySkuZoneGroup(request)
      .then((response) => {
        response.data.forEach((item) => {
          permRetailBySkuZoneGroup[item.sku] =
            permRetailBySkuZoneGroup[item.sku] || {};
          permRetailBySkuZoneGroup[item.sku][item.zoneGroupId] = {
            permRetail: item.retail / 100,
            occurrences: item.occurrences,
          };
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setPermRetailBySkuZoneGroup(permRetailBySkuZoneGroup);
        setLoadingZoneModeRetail(false);
      });
  };

  static fetchProjectedZoneGroupImu = (
    skuList,
    zoneMultiplierGroupData,
    newRetails,
    newCosts,
    setProjectedZoneGroupImu
  ) => {
    let zoneMultiplierGroupId = zoneMultiplierGroupData.id;
    let skuTraitIdPrice = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts
    );
    let request = {
      zoneMultiplierGroupId: zoneMultiplierGroupId,
      skuZonePriceCostList: skuTraitIdPrice,
    };
    setProjectedZoneGroupImu((prevState) => ({
      ...prevState,
      isLoading: true,
    }));

    let projectedZoneGroupIMU = {};
    SingleAndMultiSkuServices.fetchProjectedZoneGroupIMU(request)
      .then((response) => {
        response.data.forEach((imuSkuZoneGroup) => {
          let sku = imuSkuZoneGroup.sku;
          let zoneGroupId = imuSkuZoneGroup.zoneGroupId;
          let imu = imuSkuZoneGroup.imu;
          projectedZoneGroupIMU[sku] = projectedZoneGroupIMU[sku] || {};
          projectedZoneGroupIMU[sku][zoneGroupId] = imu;
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setProjectedZoneGroupImu({
          data: projectedZoneGroupIMU,
          isLoading: false,
        });
      });
  };

  static fetchZoneGroupImu = (
    skuList,
    zoneMultiplierGroupData,
    setZoneGroupImu
  ) => {
    let skuZoneData = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData
    );
    let request = {
      zoneMultiplierGroupId: zoneMultiplierGroupData.id,
      skuZones: skuZoneData,
    };
    setZoneGroupImu((prevState) => ({ ...prevState, isLoading: true }));
    let zoneGroupIMU = {};
    SingleAndMultiSkuServices.fetchZoneGroupIMU(request)
      .then((response) => {
        response.data.forEach((imuSkuZoneGroup) => {
          let sku = imuSkuZoneGroup.sku;
          let zoneGroupId = imuSkuZoneGroup.zoneGroupId;
          let imu = imuSkuZoneGroup.imu;
          zoneGroupIMU[sku] = zoneGroupIMU[sku] || {};
          zoneGroupIMU[sku][zoneGroupId] = imu;
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setZoneGroupImu({ data: zoneGroupIMU, isLoading: false });
      });
  };
  static fetchCurrentDataConnectCPI = (
    skuList,
    zoneMultiplierGroupData,
    setLineStructureCpiData
  ) => {
    setLineStructureCpiData({
      cpiList: CompetitorNameAndIdList,
      isLoading: true,
    });
    let skuZoneData = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData
    );
    SingleAndMultiSkuServices.fetchCurrentCpi(skuZoneData)
      .then((response) => {
        let responseData = response.data;
        if (responseData.length) {
          let result = CompetitorNameAndIdList.map((item) => {
            let findItem = responseData.find(
              (dataItem) => dataItem.competitorId === item.competitorId
            );
            if (findItem) {
              return { ...item, cpi: findItem.cpi };
            } else {
              return item;
            }
          });
          setLineStructureCpiData({ cpiList: result, isLoading: false });
        } else {
          setLineStructureCpiData({
            cpiList: CompetitorNameAndIdList,
            isLoading: false,
          });
        }
      })
      .catch((err) => {
        console.log(err);
        setLineStructureCpiData({
          cpiList: CompetitorNameAndIdList,
          isLoading: false,
        });
      });
  };

  static fetchCurrentMyPriceCpi = (
    skuList,
    zoneMultiplierGroupData,
    setMyPriceCpi
  ) => {
    setMyPriceCpi({ cpiList: [] });
    let skuZoneData = DataBarUtil.buildSkuZoneRequest(
      skuList,
      zoneMultiplierGroupData
    );
    SingleAndMultiSkuServices.fetchCurrentMyPriceCPI(skuZoneData)
      .then((response) => {
        let responseData = response.data;
        setMyPriceCpi({ cpiList: responseData });
      })
      .catch((err) => {
        console.log(err);
        setMyPriceCpi({ cpiList: [] });
      });
  };

  static buildProjectedCpiRequest = (
    skuList,
    zoneMultiplierGroupData,
    newRetails
  ) => {
    let request = [];
    skuList.forEach((sku) => {
      zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
        let newRetail =
          newRetails[sku] &&
          newRetails[sku][zoneGroup.id] &&
          newRetails[sku][zoneGroup.id].retail;
        zoneGroup.zones.forEach((zone) => {
          let requestObj = {
            sku: parseInt(sku),
            traitId: zone.traitId,
          };
          if (newRetail) {
            requestObj.price = Math.round(parseFloat(newRetail) * 100);
          }
          request.push(requestObj);
        });
      });
    });
    return request;
  };

  static fetchProjectedCpi = (
    skuList,
    zoneMultiplierGroupData,
    updateLineStructureProjectedCpiData,
    newRetails,
    isDisaster
  ) => {
    let request = this.buildProjectedCpiRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails
    );
    updateLineStructureProjectedCpiData({
      projectedCpi: {},
      isProjectedLoading: true,
    });
    SingleAndMultiSkuServices.fetchProjectedCpi(request, isDisaster)
      .then((response) => {
        let responseData = response.data;
        let cpiPerCompetitor = {};
        responseData.forEach((obj) => {
          cpiPerCompetitor[obj.competitorId] = obj.cpi;
        });
        updateLineStructureProjectedCpiData({
          projectedCpi: cpiPerCompetitor,
          isProjectedLoading: false,
        });
      })
      .catch((err) => {
        console.log(err);
        updateLineStructureProjectedCpiData({
          projectedCpi: {},
          isProjectedLoading: false,
        });
      });
  };

  static fetchZoneGroupCompetitorPrice = (
    skuList,
    zoneMultiplierGroupData,
    setZoneGroupCompetitorCPI
  ) => {
    let request = {
      zoneMultiplierGroupId: zoneMultiplierGroupData.id,
      skus: skuList,
    };
    setZoneGroupCompetitorCPI((prevState) => ({
      ...prevState,
      isLoading: true,
    }));
    let zoneGroupCompetitorPrice = {};
    SingleAndMultiSkuServices.fetchCompetitorPriceCPI(request)
      .then((response) => {
        response.data.forEach((competitorPriceSkuZoneGroup) => {
          let sku = competitorPriceSkuZoneGroup.sku;
          let zoneGroupId = competitorPriceSkuZoneGroup.zoneGroupId;
          let competitorPrice = competitorPriceSkuZoneGroup.scaledPricePennies;
          let competitorId = competitorPriceSkuZoneGroup.competitorId;
          zoneGroupCompetitorPrice[sku] = zoneGroupCompetitorPrice[sku] || {};
          zoneGroupCompetitorPrice[sku][zoneGroupId] =
            zoneGroupCompetitorPrice[sku][zoneGroupId] || {};
          zoneGroupCompetitorPrice[sku][zoneGroupId][competitorId] =
            competitorPrice;
        });
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setZoneGroupCompetitorCPI({
          data: zoneGroupCompetitorPrice,
          isLoading: false,
        });
      });
  };

  static fetchCurrentZoneGroupCpi = (
    skuList,
    zoneMultiplierGroupData,
    setZoneGroupCurrentCpi
  ) => {
    setZoneGroupCurrentCpi({ data: {}, isLoading: true });
    let request = {
      skus: skuList,
      zoneMultiplierGroupId: zoneMultiplierGroupData.id,
    };

    let currentCpiByZoneGroup = {};
    SingleAndMultiSkuServices.fetchCurrentZoneGroupCpi(request)
      .then((response) => {
        let responseData = response.data;
        responseData.forEach((item) => {
          currentCpiByZoneGroup[item.sku] =
            currentCpiByZoneGroup[item.sku] || {};
          currentCpiByZoneGroup[item.sku][item.zoneGroupId] =
            currentCpiByZoneGroup[item.sku][item.zoneGroupId] || {};
          currentCpiByZoneGroup[item.sku][item.zoneGroupId][item.competitorId] =
            item.cpi;
        });
        setZoneGroupCurrentCpi({
          data: currentCpiByZoneGroup,
          isLoading: false,
        });
      })
      .catch((err) => {
        setZoneGroupCurrentCpi({ data: {}, isLoading: false });
        console.log(err);
      });
  };

  static fetchModeRetailStatus = (skuList, setModeRetailStatus) => {
    setModeRetailStatus({ data: {}, isLoading: true });
    SingleAndMultiSkuServices.fetchModeRetailStatus(skuList)
      .then((response) => {
        let responseData = response.data;
        responseData = responseData.map((skuModeRetail) => {
          return {
            ...skuModeRetail,
            statusCode: `${+MODE_RETAIL_STATUS[skuModeRetail.strategy]}`,
            completeStatus: `${+MODE_RETAIL_STATUS[skuModeRetail.strategy]} - ${
              MODE_RETAIL_POPOVER[skuModeRetail.strategy]['status']
            }`,
          };
        });
        // Build object[sku] = strategy array.
        const groupBySku = _.groupBy(responseData, 'sku');

        // Sort strategy arrays by status code.
        Object.values(groupBySku).forEach((strategyArray) => {
          strategyArray.sort((a, b) => a.statusCode - b.statusCode);
        });

        setModeRetailStatus({ data: groupBySku, isLoading: false });
      })
      .catch((err) => {
        setModeRetailStatus({ data: {}, isLoading: false });
        console.log(err);
      });
  };

  static fetchZoneGroupModeRetailStatus = (
    skuList,
    zoneMultiplierGroupId,
    setZoneGroupModeRetailStatus
  ) => {
    setZoneGroupModeRetailStatus({ data: {}, isLoading: true });
    let request = {
      skus: skuList,
      zoneMultiplierGroupId: zoneMultiplierGroupId,
    };

    SingleAndMultiSkuServices.fetchZoneGroupModeRetailStatus(request)
      .then((response) => {
        let responseData = response.data;
        responseData = responseData.map((skuModeRetail) => {
          return {
            ...skuModeRetail,
            statusCode: `${+MODE_RETAIL_STATUS[skuModeRetail.strategy]}`,
            completeStatus: `${+MODE_RETAIL_STATUS[skuModeRetail.strategy]} - ${
              MODE_RETAIL_POPOVER[skuModeRetail.strategy]['status']
            }`,
          };
        });

        // Build object[zoneGroupId][sku] = strategy array.
        const groupByZoneGroup = _.groupBy(responseData, 'zoneGroupId');
        const groupBySkuZoneGroup = {};
        Object.keys(groupByZoneGroup).forEach(function (zoneGroupId) {
          let group = groupByZoneGroup[zoneGroupId];
          groupBySkuZoneGroup[zoneGroupId] = _.groupBy(group, 'sku');
        });

        // Sort strategy arrays by status code.
        Object.values(groupBySkuZoneGroup).forEach((zoneGroupStrategies) => {
          Object.values(zoneGroupStrategies).forEach((strategyArray) => {
            strategyArray.sort((a, b) => a.statusCode - b.statusCode);
          });
        });

        setZoneGroupModeRetailStatus({
          data: groupBySkuZoneGroup,
          isLoading: false,
        });
      })
      .catch((err) => {
        setZoneGroupModeRetailStatus({ data: {}, isLoading: false });
        console.log(err);
      });
  };

  static fetchCurrentMyPriceZoneGroupCpi = (
    skuList,
    zoneMultiplierGroupData,
    setMyPriceZoneGroupCpi
  ) => {
    setMyPriceZoneGroupCpi({ data: {}, isLoading: true });
    let request = {
      skuZones: DataBarUtil.buildSkuZoneRequest(
        skuList,
        zoneMultiplierGroupData
      ),
      zoneMultiplierGroupId: zoneMultiplierGroupData.id,
    };
    let currentMyPriceCpiByZoneGroup = {};
    SingleAndMultiSkuServices.fetchCurrentMyPriceZoneGroupCpi(request)
      .then((response) => {
        let responseData = response.data;
        responseData.forEach((item) => {
          currentMyPriceCpiByZoneGroup[item.sku] =
            currentMyPriceCpiByZoneGroup[item.sku] || {};
          currentMyPriceCpiByZoneGroup[item.sku][item.zoneGroupId] =
            currentMyPriceCpiByZoneGroup[item.sku][item.zoneGroupId] || {};
          currentMyPriceCpiByZoneGroup[item.sku][item.zoneGroupId][
            item.competitorId
          ] = item.cpi;
        });
        setMyPriceZoneGroupCpi({
          data: currentMyPriceCpiByZoneGroup,
          isLoading: false,
        });
      })
      .catch((err) => {
        setMyPriceZoneGroupCpi({ data: {}, isLoading: false });
        console.log(err);
      });
  };

  static fetchProjectedZoneGroupCpi = (
    skuList,
    zoneMultiplierGroupData,
    newRetails,
    setZoneGroupProjectedCpi
  ) => {
    setZoneGroupProjectedCpi({ data: {}, isLoading: true });
    let zoneMultiplierGroupId = zoneMultiplierGroupData.id;
    let skuTraitIdPrice = this.buildProjectedCpiRequest(
      skuList,
      zoneMultiplierGroupData,
      newRetails
    );
    let request = {
      zoneMultiplierGroupId: zoneMultiplierGroupId,
      skuZonePriceList: skuTraitIdPrice,
    };
    let projectedCpiByZoneGroup = {};
    SingleAndMultiSkuServices.fetchProjectedZoneGroupCpi(request)
      .then((response) => {
        let responseData = response.data;
        responseData.forEach((item) => {
          projectedCpiByZoneGroup[item.sku] =
            projectedCpiByZoneGroup[item.sku] || {};
          projectedCpiByZoneGroup[item.sku][item.zoneGroupId] =
            projectedCpiByZoneGroup[item.sku][item.zoneGroupId] || {};
          projectedCpiByZoneGroup[item.sku][item.zoneGroupId][
            item.competitorId
          ] = item.cpi;
        });
        setZoneGroupProjectedCpi({
          data: projectedCpiByZoneGroup,
          isLoading: false,
        });
      })
      .catch((err) => {
        setZoneGroupProjectedCpi({ data: {}, isLoading: false });
        console.log(err);
      });
  };

  static fetchVendorDetails = (skuList, updateVendorData) => {
    SingleAndMultiSkuServices.fetchVendorDetails(skuList)
      .then((response) => {
        let vendorData = {};
        const responseData = response.data;
        responseData.forEach((item) => {
          vendorData[item.sku] = vendorData[item.sku] || {};
          vendorData[item.sku][item.market] =
            vendorData[item.sku][item.market] || {};
          vendorData[item.sku][item.market][item.vendor] = item || {};
        });
        const vendors = responseData.map((item) => ({
          vendorNumber: item.vendor,
          vendorName: item.vendorName,
        }));
        const uniqueSet = new Set(vendors.map(JSON.stringify));
        const uniqueArray = Array.from(uniqueSet).map(JSON.parse);
        updateVendorData('vendors', uniqueArray);

        const markets = responseData.map((item) => ({
          market: item.market,
          marketName: item.marketName,
        }));
        const uniqueMarketsSet = new Set(markets.map(JSON.stringify));
        const uniqueMarketsArray = Array.from(uniqueMarketsSet).map(JSON.parse);
        updateVendorData('markets', uniqueMarketsArray);

        const defaultSelection = uniqueArray.sort((a, b) =>
          a.vendorName.localeCompare(b.vendorName)
        );
        updateVendorData('selectedVendor', defaultSelection[0]);
        updateVendorData('vendorGroupData', vendorData);
      })
      .catch(() => {});
  };

  static fetchVendorCosts = (skuList, updateVendorData) => {
    SingleAndMultiSkuServices.fetchVendorCosts(skuList)
      .then((response) => {
        const responseData = response.data;
        let newCostsData = {};
        responseData.forEach(
          ({ sku, market, vendor, firstCost, currentCost, blendedCost }) => {
            if (!newCostsData[sku]) {
              newCostsData[sku] = {};
            }

            if (!newCostsData[sku][market]) {
              newCostsData[sku][market] = {};
            }

            newCostsData[sku][market][vendor] = {
              currentCost: currentCost || firstCost,
              blendedCost,
            };
          }
        );
        updateVendorData('costs', newCostsData);
      })
      .catch((err) => {
        console.log(err);
      });
  };
}
