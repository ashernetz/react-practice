import EditPriceUtil from './EditPriceUtil';

const zoneMultiplierGroupId = '323e5e5b-f350-4cc9-b91f-64e07e055482';
const newRetails = {
  193801: {
    'bb0d7467-1ef0-4e13-a985-1de9f55816ca': {
      retail: '10.00873',
      isManualEdit: false,
    },
  },
};
const rules = ['SKU_TO_SKU', 'ZONE_MULTIPLIER', 'TARGET_BASED'];

const targetRules = {
  scope: 'WHOLE_SKU_GROUP',
  strategy: 'PROPORTIONALLY_BY_PERCENT',
  targets: [
    {
      target: 'IMU',
      value: '50',
    },
  ],
};

describe('Edit Price Utils', () => {
  test('Build recommendation request', () => {
    let actualRecommendationRequest = EditPriceUtil.buildRecommendationRequest(
      zoneMultiplierGroupId,
      newRetails,
      rules,
      targetRules
    );
    let mockRecommendationRequest = {
      zoneMultiplierGroupId: '323e5e5b-f350-4cc9-b91f-64e07e055482',
      prices: [
        {
          sku: '193801',
          zoneGroupId: 'bb0d7467-1ef0-4e13-a985-1de9f55816ca',
          price: 1001,
        },
      ],
      recommendationLayers: ['SKU_TO_SKU', 'ZONE_MULTIPLIER', 'TARGET_BASED'],
      targetRules: {
        scope: 'WHOLE_SKU_GROUP',
        strategy: 'PROPORTIONALLY_BY_PERCENT',
        targets: [
          {
            target: 'IMU',
            value: '50',
          },
        ],
      },
    };
    expect(actualRecommendationRequest).toEqual(mockRecommendationRequest);
  });
});
