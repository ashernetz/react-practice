import React from 'react';
import { Row, Modal, Badge, Button } from 'antd';
import { DATA_SAVE_STORAGE } from '../EditPricePage';
import './RestoreSessionModal.scss';

const RestoreSessionModal = ({
  setIsRestoreSessionModalOpen,
  handleRestoreSession,
}) => {
  const parseTime = () => {
    const storage = localStorage.getItem(DATA_SAVE_STORAGE);
    const data = JSON.parse(storage);
    const timeStamp = data.timestamp;
    return new Date(timeStamp).toLocaleDateString('en-us', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Modal
      open
      className="restoreSession-modal"
      data-testid="restoresession-modal"
      okButtonProps={{ disabled: false }}
      closable={false}
      keyboard={false}
      footer={[
        <Button
          key="restore-no"
          type="default"
          size="large"
          onClick={() => setIsRestoreSessionModalOpen(false)}
        >
          No
        </Button>,
        <Button
          key="restore-yes"
          type="primary"
          size="large"
          data-testid="restoresession-modal-okbtn"
          onClick={() => handleRestoreSession(false)}
        >
          Yes
        </Button>,
      ]}
    >
      <Row className="restore-header">
        <Badge
          count={
            <div>
              <i className="material-icons-outlined dashboard-dcs-info">info</i>
            </div>
          }
        />
        Restore Session?
      </Row>
      <Row className="restore-content">
        Your session ended on {parseTime()}.
      </Row>
      <Row className="restore-content">
        All input fields will be cleared after 7 days, would you like to restore
        your last inputs?
      </Row>
    </Modal>
  );
};

export default RestoreSessionModal;
