import React from 'react';
import { render } from '@testing-library/react';
import RestoreSessionModal from './RestoreSessionModal';

describe('Restore Session Modal', () => {
  const mocksetIsRestoreSessionModalOpen = jest.fn(() => {});
  const mockhandleRestoreSession = jest.fn(() => {});

  beforeEach(() => {
    Object.defineProperty(window, 'localStorage', {
      value: {
        getItem: jest.fn(() => JSON.stringify({ timestamp: 1668093160 })),
        setItem: jest.fn(() => null),
      },
      writable: true,
    });
  });

  test('render attributes', () => {
    const restoreSessionModal = render(
      <RestoreSessionModal
        setIsRestoreSessionModalOpen={mocksetIsRestoreSessionModalOpen}
        handleRestoreSession={mockhandleRestoreSession}
      />
    );
    expect(restoreSessionModal.findByText('Restore Session?')).toBeDefined();
    expect(
      restoreSessionModal.findByText('Your seesion ended on Nov 10, 2022.')
    ).toBeDefined();
    expect(
      restoreSessionModal.findByText(
        'All input fields will be cleared after 7 days, would you like to restore your last inputs?'
      )
    ).toBeDefined();
  });
});
