import React from 'react';
import {
  cleanup,
  fireEvent,
  getByTestId,
  render,
  screen,
  waitFor,
} from '@testing-library/react';
import { SKULEVEL_CONTENT } from '../../../../constants/ToolTip';
import EditPricePage, { DATA_SAVE_STORAGE } from '../EditPricePage';
import SkuContext from '../../../../context/SkuContext';
import { SkuDescriptionProvider } from '../Context/SkuDescriptionProvider';
import { act } from 'react-dom/test-utils';
import axios from 'axios';
import { when } from 'jest-when';

jest.mock('axios');
jest.useFakeTimers();

const recommendationResponse = {
  data: [
    {
      sku: '301329',
      zone: {
        traitId: 28283,
        userDefZoneId: '143',
        zoneName: 'BAY CITY',
      },
      recommendation: {
        recommendationType: 'Layered',
        currentPrice: 1057,
        recommendedPrice: 1472,
        recommendationList: [
          {
            recommendationType: 'SkuToSku',
            currentPrice: 1057,
            recommendedPrice: 1047,
            recommendationPath: [
              {
                sourceSku: 301329,
                targetSku: 652539,
                minDelta: 0.3087,
                maxDelta: 0.3087,
                relationType: 'ADDITIVE',
              },
            ],
            added: true,
          },
          {
            recommendationType: 'ZoneMultiplier',
            currentPrice: 1047,
            recommendedPrice: 1472,
            anchorGroup: '4f205b79-45fa-4b36-ab2a-d7c4509afb6c',
            targetGroup: '10b724c2-661b-4a50-846d-cd58d01c8a45',
            effectiveWeight: 1.40625,
          },
        ],
      },
    },
    {
      sku: '301329',
      zone: {
        traitId: 28283,
        userDefZoneId: '143',
        zoneName: 'BAY CITY',
      },
      recommendation: {
        recommendationType: 'Layered',
        currentPrice: 1057,
        recommendedPrice: 1472,
        recommendationList: [
          {
            recommendationType: 'SkuToSku',
            currentPrice: 1057,
            recommendedPrice: 1047,
            recommendationPath: [
              {
                sourceSku: 301329,
                targetSku: 652539,
                minDelta: 0.3087,
                maxDelta: 0.3087,
                relationType: 'ADDITIVE',
              },
            ],
            added: true,
          },
          {
            recommendationType: 'ZoneMultiplier',
            currentPrice: 1047,
            recommendedPrice: 1472,
            anchorGroup: '4f205b79-45fa-4b36-ab2a-d7c4509afb6c',
            targetGroup: '10b724c2-661b-4a50-846d-cd58d01c8a45',
            effectiveWeight: 1.40625,
          },
        ],
      },
    },
  ],
};

const currentRetailResponse = {
  data: [
    { sku: 301329, retail: 3096, occurrences: 3, strategy: 'INACTIVE' },
    { sku: 301329, retail: 3393, occurrences: 98, strategy: 'ACTIVE' },
  ],
};

let skuDetailsResponse = {
  data: [
    { sku: 301329, description: '3/4"X10\' GAL PIPE', dcs: '001-001-001' },
  ],
};

const zoneMultiplierGroupResponse = {
  data: {
    id: '3bf84d52-d3ee-4875-8a1b-c69d695dd7df',
    name: 'myMultiplierGroup',
    description: 'This is a group of zones with multipliers.',
    anchorGroupId: 'a6fdc1b2-4cbf-4103-866d-051c19208531',
    zoneGroups: [
      {
        id: 'c798e82f-f79e-4153-81b6-b7b7e86c4f7b',
        name: 'Premium',
        weight: 1.12,
        zones: [
          {
            traitId: 28283,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
      {
        id: 'b8f6f36c-7182-4df2-b74b-e7a819c1c745',
        name: 'Offshore',
        weight: 1.869,
        zones: [
          {
            traitId: 28267,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
      {
        id: '7165933a-73c3-4ebd-9c7c-0a7cd49f0cfc',
        name: 'Menards',
        weight: 0.939,
        zones: [
          {
            traitId: 28400,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
      {
        id: 'a6fdc1b2-4cbf-4103-866d-051c19208531',
        name: 'Core',
        weight: 1,
        zones: [
          {
            traitId: 28295,
            userDefZoneId: '57',
            zoneName: 'MYRTLE BEACH',
            stores: [3648, 1121, 1122, 8580, 3655, 3609, 1116, 3629],
          },
        ],
      },
    ],
  },
};

const departmentClassMap = new Map();
departmentClassMap.set('86', [45]);

const anchorResponse = { data: [854892] };

const storageOutput = {};

beforeEach(async () => {
  when(axios.get)
    .calledWith(
      `/api/multi-sku/zoneMultiplierGroups?zoneMultiplierGroupId=${zoneMultiplierGroupResponse.data.id}`
    )
    .mockResolvedValue(zoneMultiplierGroupResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/modeRetailStatus`, expect.anything())
    .mockResolvedValue(currentRetailResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/sku/dcs-description`, expect.anything())
    .mockResolvedValue(skuDetailsResponse);
  when(axios.post)
    .calledWith(`/api/dataConnect/sku/anchors`, expect.anything())
    .mockResolvedValue(anchorResponse);

  Object.defineProperty(window, 'localStorage', {
    value: {
      getItem: jest.fn(() =>
        JSON.stringify({
          timestamp: Date.now() - 10000,
          '3bf84d52-d3ee-4875-8a1b-c69d695dd7df': {
            costs: { 301329: '888.00' },
            retails: {
              301329: {
                '7165933a-73c3-4ebd-9c7c-0a7cd49f0cfc': {
                  retail: '938.06',
                  isManualEdit: false,
                },
                'a6fdc1b2-4cbf-4103-866d-051c19208531': {
                  retail: '999.00',
                  isManualEdit: false,
                },
                'b8f6f36c-7182-4df2-b74b-e7a819c1c745': {
                  retail: '1867.13',
                  isManualEdit: false,
                },
                'c798e82f-f79e-4153-81b6-b7b7e86c4f7b': {
                  retail: '1118.88',
                  isManualEdit: false,
                },
              },
            },
          },
        })
      ),
      setItem: jest.fn((key, data) => {
        storageOutput[key] = JSON.parse(data);
      }),
    },
    writable: true,
  });

  await act(async () => {
    const { container } = render(
      <SkuContext.Provider
        value={{
          subDeptDataMap: {
            '0013': {
              name: '13-123',
              deptClassMap: departmentClassMap,
              description: '123',
              longDescription: 'TEST',
            },
          },
          updateShowDimmer: () => {},
        }}
      >
        <SkuDescriptionProvider>
          <EditPricePage
            userId={'MC62YE'}
            userEmail={'Michelle_Cox_Bradford@homedepot.com'}
            backArrowClick={() => {}}
            zoneMultiplierGroupId={zoneMultiplierGroupResponse.data.id}
            skuGroupName={'Galvanized Pipe'}
            skuList={[301329]}
          />
        </SkuDescriptionProvider>
      </SkuContext.Provider>
    );
  });
}, 20000);

describe('EditPricePage local storage test', () => {
  jest.setTimeout(30000);
  test('test load storage data', async () => {
    const modal = await waitFor(
      () => screen.getByTestId('restoresession-modal'),
      3000
    );
    if (modal) {
      const OkBtn = screen.getByTestId('restoresession-modal-okbtn');
      if (OkBtn) {
        fireEvent.click(OkBtn);

        await waitFor(() => {
          expect(
            screen.getByTestId('new-retail-input-888.00')
          ).toBeInTheDocument();
        });

        await waitFor(() => {
          expect(
            screen.getByTestId('new-retail-input-999.00')
          ).toBeInTheDocument();
        });

        await waitFor(() => {
          expect(
            screen.getByTestId('new-retail-input-1118.88')
          ).toBeInTheDocument();
        });

        await waitFor(() => {
          expect(
            screen.getByTestId('new-retail-input-1867.13')
          ).toBeInTheDocument();
        });

        await waitFor(() => {
          expect(
            screen.getByTestId('new-retail-input-938.06')
          ).toBeInTheDocument();
        });
      }
    }
  });

  test('test save storage data', async () => {
    jest.setTimeout(30000);
    const modal = await waitFor(
      () => screen.getByTestId('restoresession-modal'),
      3000
    );
    if (modal) {
      const OkBtn = screen.getByTestId('restoresession-modal-okbtn');
      if (OkBtn) {
        await act(async () => {
          fireEvent.click(OkBtn);
        });

        const costInput = screen.getByTestId('new-retail-input-888.00');
        const retailInput = screen.getByTestId('new-retail-input-999.00');
        await act(async () => {
          fireEvent.change(costInput, { target: { value: '10.00' } });
          fireEvent.change(retailInput, { target: { value: '19.00' } });
        });

        const mockResult = {
          timestamp: storageOutput[DATA_SAVE_STORAGE].timestamp,
          '3bf84d52-d3ee-4875-8a1b-c69d695dd7df': {
            costs: { 301329: '10.00' },
            retails: {
              301329: {
                'c798e82f-f79e-4153-81b6-b7b7e86c4f7b': {
                  retail: '1118.88',
                  isManualEdit: false,
                },
                'b8f6f36c-7182-4df2-b74b-e7a819c1c745': {
                  retail: '1867.13',
                  isManualEdit: false,
                },
                '7165933a-73c3-4ebd-9c7c-0a7cd49f0cfc': {
                  retail: '938.06',
                  isManualEdit: false,
                },
                'a6fdc1b2-4cbf-4103-866d-051c19208531': {
                  retail: '19.00',
                  isManualEdit: true,
                },
              },
            },
          },
        };
        expect(storageOutput[DATA_SAVE_STORAGE]).toEqual(mockResult);
      }
    }
  });
});
