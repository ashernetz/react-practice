import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { Targets } from './Targets';

const options = [
  ['IMU', 'IMU'],
  // ['Markup', 'Markup'],
  // ['Markdown', 'Markdown'],
];

const renderComponent = (props = {}) => {
  return render(
    <Targets title="Test Title" onTargetChange={() => {}} {...props} />
  );
};

describe('Targets component', () => {
  it('renders without crashing', () => {
    renderComponent();
    expect(screen.getByText('Test Title')).toBeInTheDocument();
  });

  // it('handles select change', async () => {
  //   renderComponent();
  //   const select = screen.getByRole('combobox');
  //   fireEvent.mouseDown(select);
  //
  //   const option = await screen.findByText(options[1][0]);
  //   fireEvent.click(option);
  //
  //   expect(
  //     await screen.findByPlaceholderText(options[1][1])
  //   ).toBeInTheDocument();
  // });

  it.each(options)(
    'should update the input field after selecting option %s',
    async (option, placeholder) => {
      renderComponent();
      fireEvent.mouseDown(screen.getByRole('combobox'));
      const optionElements = screen.getAllByText(option);

      if (optionElements.length > 1) {
        await waitFor(() => fireEvent.click(optionElements[1]));
      } else if (optionElements.length === 1) {
        await waitFor(() => fireEvent.click(optionElements[0]));
      }
      expect(
        await screen.findByPlaceholderText(placeholder)
      ).toBeInTheDocument();
    }
  );

  it.each(options)(
    'should accept valid input for option %s',
    async (option, placeholder) => {
      renderComponent();
      fireEvent.mouseDown(screen.getByRole('combobox'));
      const optionElements = screen.getAllByText(option);

      if (optionElements.length > 1) {
        await waitFor(() => fireEvent.click(optionElements[1]));
      } else if (optionElements.length === 1) {
        await waitFor(() => fireEvent.click(optionElements[0]));
      }
      const inputElement = await screen.findByPlaceholderText(placeholder);
      const inputValue = '50.50';
      for (let i = 0; i < inputValue.length; i++) {
        fireEvent.input(inputElement, {
          target: { value: inputValue.slice(0, i + 1) },
        });
      }
      expect(inputElement).toHaveValue(inputValue);
    }
  );

  it.each(options)(
    'should reject invalid input for option %s',
    async (option, placeholder) => {
      renderComponent();
      fireEvent.mouseDown(screen.getByRole('combobox'));
      const optionElements = screen.getAllByText(option);

      if (optionElements.length > 1) {
        await waitFor(() => fireEvent.click(optionElements[1]));
      } else if (optionElements.length === 1) {
        await waitFor(() => fireEvent.click(optionElements[0]));
      }
      const inputElement = await screen.findByPlaceholderText(placeholder);
      fireEvent.input(inputElement, { target: { value: 'invalid input' } });
      expect(inputElement).toHaveValue('');
    }
  );
});
