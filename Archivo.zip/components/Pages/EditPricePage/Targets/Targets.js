import React, { useEffect, useState } from 'react';
import { Col, Input, Row, Select } from 'antd';
import './Targets.scss';
import { TARGET } from '../Context/TargetRulesProvider';

const options = {
  [TARGET.IMU]: 'IMU',
  [TARGET.MARKUP]: 'Markup',
  [TARGET.MARKDOWN]: 'Markdown',
};

export const Targets = ({ title, onTargetChange, target }) => {
  const [selectedOption, setSelectedOption] = useState(
    target ? target.target : TARGET.IMU
  );
  const [inputValue, setInputValue] = useState(target ? target.value : '');

  useEffect(() => {
    if (target) {
      setSelectedOption(target.target);
      setInputValue(target.value);
    }
  }, [target]);

  const handleOptionChange = (value) => {
    setSelectedOption(value);
    setInputValue('');
    onTargetChange(value, '');
  };

  const isValidInput = (value) => {
    const pattern = /^(\d+(\.\d{0,2})?)?$/;
    return pattern.test(value);
  };

  const handleInputChange = (event) => {
    const value = event.target.value;

    if (isValidInput(value)) {
      setInputValue(value);
      onTargetChange(selectedOption, value);
    }
  };

  const isInputVisible = selectedOption !== undefined;

  return (
    <div className="targets">
      <h2 className="targets__title">{title}</h2>
      <Row>
        <Col span={24}>
          <Select
            value={selectedOption}
            onChange={handleOptionChange}
            style={{ width: '100%' }}
            options={Object.keys(options).map((key) => ({
              value: key,
              label: options[key],
            }))}
          />
        </Col>
      </Row>
      {isInputVisible && (
        <Row style={{ marginTop: '16px', marginBottom: '16px' }}>
          <Col span={12}>
            <Input
              addonBefore={selectedOption !== TARGET.IMU && '$'}
              addonAfter={selectedOption === TARGET.IMU && '%'}
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              placeholder={options[selectedOption]}
            />
          </Col>
        </Row>
      )}
    </div>
  );
};
