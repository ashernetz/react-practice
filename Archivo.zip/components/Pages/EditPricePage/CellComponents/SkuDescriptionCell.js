import { Tooltip } from 'antd';
import React, { memo } from 'react';
import PropTypes from 'prop-types';

function arePropsEqual(prevProps, nextProps) {
  return (
    nextProps.sku === prevProps.sku &&
    nextProps.description === prevProps.description
  );
}

function SkuDescriptionCell({ sku, description }) {
  return (
    <div className="description-column-text" data-testid={`description-${sku}`}>
      <Tooltip title={description}>{description}</Tooltip>
    </div>
  );
}

SkuDescriptionCell.propTypes = {
  sku: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  description: PropTypes.string,
};

export default memo(SkuDescriptionCell, arePropsEqual);
