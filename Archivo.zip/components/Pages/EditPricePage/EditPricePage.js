import React, {
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { Layout, Modal, notification, Row, Col } from 'antd';
import './EditPricePage.scss';
import EditPricePageHeader from './EditPricePageHeader/EditPricePageHeader';
import EditPricePageFooter from './EditPricePageFooter/EditPricePageFooter';
import EditPriceUtil from './Util/EditPriceUtil';
import SkuContext from '../../../context/SkuContext';
import DataBarUtil from './EditPricePageDataBar/DataBarUtil';
import { CompetitorNameAndIdList } from '../../../constants/typecode';
import {
  zoneGroupModeRetailColumn,
  ellipsisColumn,
  newRetailColumn,
  zoneGroupMuMdColumn,
  zoneGroupImuColumn,
  zoneGroupProjectedImuColumn,
  zoneGroupRetailStatusColumn,
} from './Columns/ZoneGroupColumns';
import {
  CompetitorPriceColumn,
  CurrentCpiColumn,
  NoDataColumn,
  ProjectedCpiColumn,
} from './Columns/CompetitorColumns';
import PropTypes from 'prop-types';

import RecommendPriceModal from './RecommendPriceModal/RecommendPriceModal';
import _, { trim } from 'lodash';
import RestoreSessionModal from './SessionRestore/RestoreSessionModal';
import { useSkuDescriptions } from './Context/SkuDescriptionProvider';
import {
  skuColumn,
  skuDescriptionColumn,
  dcsColumn,
  imuColumn,
  invoiceCostColumn,
  modeRetailColumn,
  modeRetailStatusColumn,
  muMdColumn,
  newCostColumn,
  projectedImuColumn,
  anchorIconColumn,
} from './Columns/SkuColumns';
import EditPriceColumnCreation from './Columns/EditPriceColumnCreation';
import EditPricePageWrapper from './EditPricePageWrapper';
import { getCustomColumnConfig } from './Columns/CustomColumns';
import {
  ColumnKeys,
  InitialCostColumnsTemplate,
  InitialRetailColumnsTemplate,
  TableTabKeys,
  ZoneGroupColumnTemplates,
} from './Constants/ColumnConstants';
import { useTargetRules } from './Context/TargetRulesProvider';
import { SkuGroupData } from './EditPricePageDataBar/DataBarComponents/SkuGroupDataComponent';
import EditPriceTableTabs from './Components/EditPriceTable/Tabs/EditPriceTableTabs';
import { useVendorData } from './Context/VendorContext';
import {
  marketNameColumn,
  marketNumColumn,
} from './Columns/MarketColumns/MarketColumns';
import { getVendorCostParentColumn } from './Columns/VendorColumns/VendorColumnComponents';
import {
  vendorCostVendorNameColumn,
  vendorCostVendorNumberColumn,
  vendorCostBlendedCost,
  vendorCostCurrentCost,
} from './Columns/CostColumns';

const { Content } = Layout;

export const DATA_SAVE_STORAGE = 'RETAIL_COST_STORAGE';

const openNotification = (data) => {
  if (data) {
    notification.open({
      message: 'Generating your RCW',
      description: 'The generated RCW will be sent to your email shortly!',
    });
  } else {
    Modal.error({
      title: "Uh Oh! That didn't work.",
      content: 'Please try again',
    });
  }
};

const openPasteNotification = (
  successfulSkuCount,
  totalAttemptedPasteSkuCount,
  totalSkuCount,
  lineStructureName
) => {
  notification.open({
    message:
      successfulSkuCount +
      '/' +
      totalAttemptedPasteSkuCount +
      ' SKUs Successfully Pasted',
    description: lineStructureName + ' contains ' + totalSkuCount + ' SKUs',
  });
};

const EditPricePage = ({
  userId,
  userEmail,
  backArrowClick,
  skuGroupName,
  skuList,
  zoneMultiplierGroupId,
  skuGroupId,
  costs,
  retails,
  prevCustomColumns,
  prevColumnTemplates,
}) => {
  const context = useContext(SkuContext);
  const { vendorData, updateVendorData } = useVendorData();

  const [customColumns, setCustomColumns] = useState({});

  const { skuDescriptions, updateSkuDescriptions } = useSkuDescriptions();
  const { targetRules, updateTargetRules } = useTargetRules();
  const [skusDcs, setSkusDcs] = useState({ data: {}, isLoading: false });
  const [anchorSkus, setAnchorSkus] = useState({
    data: new Set(),
    isLoading: false,
  });

  // Zone Multiplier states
  const [zoneMultiplierGroupData, setZoneMultiplierGroupData] = useState({});

  // Current Retails and Cost states
  const [modeRetailStatus, setModeRetailStatus] = useState({
    data: {},
    isLoading: false,
  });
  const [zoneGroupModeRetailStatus, setZoneGroupModeRetailStatus] = useState({
    data: {},
    isLoading: false,
  });
  const [skuInvoiceCost, setSkuInvoiceCost] = useState({
    data: {},
    isLoading: false,
  });

  // New Retails, cost, and recommendation states
  const [newRetails, setNewRetails] = useState(retails || {}); // newRetails[skuNumber][zoneGroupId] = {retail: newRetailString, isManualEdit: bool}
  const [newCosts, setNewCosts] = useState(costs || {}); // newCosts[skuNumber] = newCostString
  const [recommendations, setRecommendations] = useState({});

  // Markup/Markdown state
  const [loadingMuMd, setLoadingMuMd] = useState(false);
  const [skuZoneMuMd, setSkuZoneMuMd] = useState({});
  const [skuMuMd, setSkuMuMd] = useState({});
  const [markUpTotal, setMarkUpTotal] = useState(null);
  const [markDownTotal, setMarkDownTotal] = useState(null);
  const [disasterMarkUpTotal, setDisasterMarkUpTotal] = useState(null);
  const [disasterMarkDownTotal, setDisasterMarkDownTotal] = useState(null);
  const [loadingDisasterMuMd, setLoadingDisasterMuMd] = useState(false);

  // IMU state
  const [loadingImuLineStructureCurrent, setLoadingImuLineStructureCurrent] =
    useState(false);
  const [
    loadingImuLineStructureProjected,
    setLoadingImuLineStructureProjected,
  ] = useState(false);
  const [
    loadingDisasterImuLineStructureProjected,
    setLoadingDisasterImuLineStructureProjected,
  ] = useState(false);
  const [currentImuLineStructure, setCurrentImuLineStructure] = useState(null);
  const [projectedImuLineStructureValue, setProjectedImuLineStructureValue] =
    useState(null);
  const [
    disasterProjectedImuLineStructureValue,
    setDisasterProjectedImuLineStructureValue,
  ] = useState({});
  const [netSkuImu, setNetSkuImu] = useState({ data: {}, isLoading: false });
  const [projectedNetSkuImu, setProjectedNetSkuImu] = useState({
    data: {},
    isLoading: false,
  });
  const [zoneGroupImu, setZoneGroupImu] = useState({
    data: {},
    isLoading: false,
  });
  const [projectedZoneGroupImu, setProjectedZoneGroupImu] = useState({
    data: {},
    isLoading: false,
  });

  // Collapsed Column state
  const [collapsedZoneGroups, setCollapsedZoneGroups] = useState([]);

  // CPI/Competitor Price State
  const [zoneGroupCompetitorPrice, setZoneGroupCompetitorPrice] = useState({
    data: {},
    isLoading: true,
  });
  const [lineStructureCpiData, setLineStructureCpiData] = useState({
    cpiList: CompetitorNameAndIdList,
    isLoading: false,
  });
  const [myPriceCpi, setMyPriceCpi] = useState({ cpiList: [] });
  const [lineStructureProjectedCpiData, setLineStructureProjectedCpiData] =
    useState({ projectedCpi: {}, isProjectedLoading: false });
  const [
    lineStructureProjectedCpiDisasterData,
    setLineStructureProjectedCpiDisasterData,
  ] = useState({ projectedCpi: {}, isProjectedLoading: false });
  const [zoneGroupCurrentCpi, setZoneGroupCurrentCpi] = useState({
    data: {},
    isLoading: false,
  });
  const [myPriceZoneGroupCpi, setMyPriceZoneGroupCpi] = useState({ data: {} });
  const [zoneGroupProjectedCpi, setZoneGroupProjectedCpi] = useState({
    data: {},
    isLoading: false,
  });

  // Filter states
  const [filteredRetailTableSkus, setFilteredRetailTableSkus] =
    useState(skuList);
  const [filteredCostTableSkus, setFilteredCostTableSkus] = useState([]);

  // Modal states
  const [recommendPriceModal, setRecommendPriceModal] = useState(false);
  const [recommendationOverride, setRecommendationOverride] = useState(true);

  // Disaster states
  const [isDisasterBarOpen, setIsDisasterBarOpen] = useState(false);

  const sortSkuList = useMemo(
    () =>
      skuList
        .sort(
          (skuA, skuB) => anchorSkus.data.has(skuB) - anchorSkus.data.has(skuA)
        )
        .map((sku) => {
          return {
            skuNumber: sku,
            key: sku,
          };
        }),
    [skuList, anchorSkus]
  );

  const costTableData = useMemo(
    () =>
      Object.keys(vendorData.vendorGroupData).length > 0 &&
      Object.keys(vendorData.vendorGroupData)
        .map((sku) => {
          let vendorSkuMarkets = vendorData.vendorGroupData[sku];
          return Object.keys(vendorSkuMarkets).map((marketNumber) => {
            const market = vendorData.markets.find(
              (market) => parseInt(market.market) === parseInt(marketNumber)
            );
            return {
              ...market,
              skuNumber: +sku,
              key: `${sku}-${marketNumber}`,
            };
          });
        })
        .flat()
        .filter((item) => {
          return vendorData.vendorGroupData[item.skuNumber][item.market][
            vendorData.selectedVendor.vendorNumber
          ];
        })
        .sort((skuA, skuB) => {
          if (
            anchorSkus.data.has(skuB.skuNumber) ||
            anchorSkus.data.has(skuA.skuNumber)
          ) {
            return (
              anchorSkus.data.has(skuB.skuNumber) -
              anchorSkus.data.has(skuA.skuNumber)
            );
          }

          return skuA.skuNumber - skuB.skuNumber;
        }),
    [vendorData]
  );

  const anchorSku = Math.min(...anchorSkus.data);

  const [isRestoreSessionModalOpen, setIsRestoreSessionModalOpen] =
    useState(false);
  const [draggableColumnWidth, setDraggableColumnWidth] = useState({});
  const [hiddenColumns, setHiddenColumns] = useState([]);

  const [columnTemplates, setColumnTemplates] = useState(
    InitialRetailColumnsTemplate
  );
  const [costColumnTemplates, setCostColumnTemplates] = useState(
    InitialCostColumnsTemplate
  );
  const [selectedTableTab, setSelectedTableTab] = useState(TableTabKeys.RTL);

  useEffect(() => {
    getRetailColumnTemplates();
  }, [zoneMultiplierGroupData, zoneGroupCompetitorPrice, zoneGroupCurrentCpi]);

  const getRetailColumnTemplates = () => {
    if (prevColumnTemplates && prevColumnTemplates.length) {
      setColumnTemplates(prevColumnTemplates);
    } else if (
      !EditPriceColumnCreation.checkIfColumnDataIsLoading(
        zoneMultiplierGroupData,
        zoneGroupCompetitorPrice,
        zoneGroupCurrentCpi
      )
    ) {
      setColumnTemplates(
        InitialRetailColumnsTemplate.concat(getDynamicGroupColumns())
      );
    }
  };

  useEffect(() => {
    handleRestoreSession(true);
    if (zoneMultiplierGroupId) {
      EditPriceUtil.fetchZoneMultiplierGroups(
        zoneMultiplierGroupId,
        setZoneMultiplierGroupData
      );
      EditPriceUtil.fetchZoneGroupModeRetailStatus(
        skuList,
        zoneMultiplierGroupId,
        setZoneGroupModeRetailStatus
      );
    }
    EditPriceUtil.fetchAnchorSkus(skuList, setAnchorSkus);
    EditPriceUtil.fetchModeRetailStatus(skuList, setModeRetailStatus);
    EditPriceUtil.fetchCurrentCostBySkus(skuList, setSkuInvoiceCost);
    EditPriceUtil.fetchSkuDescriptionAndDCS(
      skuList,
      updateSkuDescriptions,
      setSkusDcs
    );
    EditPriceUtil.fetchVendorDetails(skuList, updateVendorData);
    EditPriceUtil.fetchVendorCosts(skuList, updateVendorData);
    // Remove prices for removed skus, so that we don't include them in RCW generation or projected metrics.
    setNewRetails((prevState) => deleteMissingSkuKeys(prevState));
    setNewCosts((prevState) => deleteMissingSkuKeys(prevState));
  }, [skuList]);

  const resetLineStructureMetrics = () => {
    setMarkUpTotal(null);
    setMarkDownTotal(null);
    setDisasterMarkUpTotal(null);
    setDisasterMarkDownTotal(null);
    setLineStructureProjectedCpiData({
      projectedCpi: {},
      isProjectedLoading: false,
    }); //clear projectedCpi when new retail is entered
    setLineStructureProjectedCpiDisasterData({
      projectedCpi: {},
      isProjectedLoading: false,
    });
    resetLineStructureImuMetrics();
  };

  const resetLineStructureImuMetrics = () => {
    setProjectedImuLineStructureValue(null);
    setDisasterProjectedImuLineStructureValue(null);
  };

  const resetSkuMetrics = (sku) => {
    deleteProjectedSkuImu(sku);
  };

  const resetZoneGroupMetrics = (sku, zoneGroupId) => {
    deleteMuMdSkus(sku, zoneGroupId);
    deleteProjectedZoneImu(sku, zoneGroupId);
    deleteProjectedZoneCpi(sku, zoneGroupId);
  };

  useEffect(() => {
    if (zoneGroupDataExists) {
      if (zoneMultiplierGroupId) {
        const data = {};
        data['timestamp'] = Date.now();

        let savedcosts = {};
        let savedretails = {};
        const storage = localStorage.getItem(DATA_SAVE_STORAGE);
        if (storage) {
          const temp = JSON.parse(storage);
          const zone = temp[zoneMultiplierGroupId];
          if (zone) {
            savedcosts = { ...zone['costs'] };
            savedretails = { ...zone['retails'] };
          }
        }
        const newdata = {};
        newdata['costs'] = { ...savedcosts, ...newCosts };
        newdata['retails'] = { ...savedretails, ...newRetails };
        data[zoneMultiplierGroupId] = newdata;

        localStorage.setItem(DATA_SAVE_STORAGE, JSON.stringify(data));
      }
    }
  }, [newCosts, newRetails, zoneMultiplierGroupData]);

  useEffect(() => {
    if (zoneMultiplierGroupData && zoneMultiplierGroupData.zoneGroups) {
      setLoadingImuLineStructureCurrent(true);
      DataBarUtil.getCurrentImuLineStructure(
        skuList,
        zoneMultiplierGroupData,
        setCurrentImuLineStructure,
        setLoadingImuLineStructureCurrent
      );
      EditPriceUtil.fetchSkuLevelImu(
        skuList,
        setNetSkuImu,
        zoneMultiplierGroupData
      );
      EditPriceUtil.fetchZoneGroupImu(
        skuList,
        zoneMultiplierGroupData,
        setZoneGroupImu
      );
      EditPriceUtil.fetchCurrentDataConnectCPI(
        skuList,
        zoneMultiplierGroupData,
        setLineStructureCpiData
      );
      EditPriceUtil.fetchCurrentMyPriceCpi(
        skuList,
        zoneMultiplierGroupData,
        setMyPriceCpi
      );
      EditPriceUtil.fetchZoneGroupCompetitorPrice(
        skuList,
        zoneMultiplierGroupData,
        setZoneGroupCompetitorPrice
      );
      EditPriceUtil.fetchCurrentZoneGroupCpi(
        skuList,
        zoneMultiplierGroupData,
        setZoneGroupCurrentCpi
      );
      EditPriceUtil.fetchCurrentMyPriceZoneGroupCpi(
        skuList,
        zoneMultiplierGroupData,
        setMyPriceZoneGroupCpi
      );
    }
  }, [zoneMultiplierGroupData.id]);

  useEffect(() => {
    if (prevCustomColumns && Object.keys(prevCustomColumns).length) {
      setCustomColumns(prevCustomColumns);
    }
  }, []);

  useEffect(() => {
    if (retails) {
      setNewRetails(retails);
    }
    if (costs) {
      setNewCosts(costs);
    }
  }, [costs, retails]);

  useEffect(() => {
    getCostSkusForSelectedVendor();
  }, [vendorData]);

  const deleteMissingSkuKeys = (skuObject) => {
    let skusToRemove = _.difference(
      Object.keys(skuObject),
      skuList.map((item) => item.toString())
    );
    skusToRemove.forEach((sku) => delete skuObject[sku]);
    return skuObject;
  };

  const deleteProjectedSkuImu = (sku) => {
    setProjectedNetSkuImu((prevState) => {
      let oldData = { ...prevState.data };
      if (oldData[sku]) oldData[sku].imu = '';
      return {
        ...prevState,
        data: oldData,
      };
    });
  };

  const deleteProjectedZoneImu = (sku, groupId) => {
    setProjectedZoneGroupImu((prevState) => {
      return {
        ...prevState,
        data: {
          ...prevState.data,
          [sku]: {
            ...prevState.data[sku],
            [groupId]: undefined,
          },
        },
      };
    });
  };

  const deleteProjectedZoneCpi = (sku, groupId) => {
    setZoneGroupProjectedCpi((prevState) => {
      return {
        ...prevState,
        data: {
          ...prevState.data,
          [sku]: {
            ...prevState.data[sku],
            [groupId]: undefined,
          },
        },
      };
    });
  };

  const onRetailUpdate = useCallback(
    (sku, groupId, inputObject) => {
      setNewRetails((prevState) => ({
        ...prevState,
        [sku]: {
          ...prevState[sku],
          [groupId]: { retail: inputObject.retail, isManualEdit: true },
        },
      }));
      resetSkuMetrics(sku);
      resetZoneGroupMetrics(sku, groupId);
      resetLineStructureMetrics();
    },
    [zoneMultiplierGroupData]
  );

  const deleteMuMdSkus = (sku, groupId) => {
    setSkuZoneMuMd((prevState) => {
      return {
        ...prevState,
        [sku]: {
          ...prevState[sku],
          [groupId]: undefined,
        },
      };
    });
    setSkuMuMd((prevState) => {
      return {
        ...prevState,
        [sku]: undefined,
      };
    });
  };

  const removeMuMdSkus = (skus) => {
    let newSkuZoneMuMd = { ...skuZoneMuMd };
    let newSkuMuMd = { ...skuMuMd };
    skus.forEach((sku) => {
      if (newSkuZoneMuMd[sku]) {
        delete newSkuZoneMuMd[sku];
      }
      if (newSkuMuMd[sku]) {
        delete newSkuMuMd[sku];
      }
    });
    setSkuZoneMuMd(newSkuZoneMuMd);
    setSkuMuMd(newSkuMuMd);
  };

  const onNewCostUpdate = (sku, newCost) => {
    setNewCosts((prevState) => ({ ...prevState, [sku]: newCost }));
    resetLineStructureImuMetrics();
  };

  //2 Columns Paste without header for costs filling
  const pasteCostList = (skuPrices) => {
    let filtered = skuPrices.filter((pasted) => skuList.includes(pasted.sku));

    let newCostsCopy = { ...newCosts };
    let successes = 0;
    filtered.forEach((skuCost) => {
      if (skuCost.data !== 'NaN') {
        newCostsCopy[skuCost.sku] = skuCost.data;
        successes = successes + 1;
      }
    });
    openPasteNotification(
      successes,
      skuPrices.length,
      sortSkuList.length,
      skuGroupName
    );
    setNewCosts(newCostsCopy);
  };

  //paste into a single new retail column without a header being provided
  const pasteRetails = (skuPrices, zoneGroupId) => {
    let filtered = skuPrices.filter((pasted) => skuList.includes(pasted.sku));
    let successes = 0;
    const retailsCopy = { ...newRetails };
    filtered.forEach((skuPrice) => {
      if (skuPrice.data !== 'NaN') {
        if (!retailsCopy[skuPrice.sku]) {
          retailsCopy[skuPrice.sku] = {};
        }
        retailsCopy[skuPrice.sku][zoneGroupId] = {
          retail: skuPrice.data,
          isManualEdit: true,
        };
        successes = successes + 1;
      }
    });

    openPasteNotification(
      successes,
      skuPrices.length,
      sortSkuList.length,
      skuGroupName
    );
    setNewRetails(retailsCopy);
  };

  //paste into a single custom column without a header being provided
  function pasteCustomColumns(skuData, key) {
    let filtered = skuData.filter((pasted) => skuList.includes(pasted.sku));
    let successes = 0;
    let customColumnsCopy = { ...customColumns };

    filtered.forEach((skuPrice) => {
      customColumnsCopy[key] = customColumnsCopy[key] || {};
      customColumnsCopy[key][skuPrice.sku] = skuPrice.data;
      successes = successes + 1;
    });

    openPasteNotification(
      successes,
      skuData.length,
      sortSkuList.length,
      skuGroupName
    );
    setCustomColumns(customColumnsCopy);
  }

  //multiple Columns Paste with header for costs,retails, and custom columns filling
  const pasteMultipleColumns = (columnObj) => {
    const headers = columnObj[0];
    const skuDataObj = columnObj
      .filter((row, index) => index > 0)
      .map((item) => {
        const newrow = {};
        if (item.length === headers.length) {
          for (let j = 0; j < headers.length; j++) {
            const num = item[j].replace(',', '');
            const header = trim(headers[j].toLowerCase());
            if (header === 'sku') {
              newrow['sku'] = !isNaN(num) && parseInt(num);
            } else {
              newrow[header] = num;
            }
          }
        }
        return newrow;
      })
      .filter((x) => !isNaN(x.sku));

    let filtered = skuDataObj.filter((pasted) => skuList.includes(pasted.sku));

    let newCostsCopy = { ...newCosts };
    let newRetailsCopy = { ...newRetails };
    let customColumnsCopy = { ...customColumns };
    let successes = 0;
    filtered.forEach((skuData) => {
      try {
        const skuNumber = skuData['sku'];
        if (skuData['cost'] && skuData['cost'] !== 'NaN') {
          newCostsCopy[skuNumber] = Number(skuData['cost']).toFixed(2);
        }
        zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
          const name = zoneGroup.name.toLowerCase();
          if (skuData[name] && skuData[name] !== '' && !isNaN(skuData[name])) {
            if (!newRetailsCopy[skuNumber]) {
              newRetailsCopy[skuNumber] = {};
            }
            newRetailsCopy[skuNumber][zoneGroup.id] = {
              retail: Number(skuData[name]).toFixed(2),
              isManualEdit: true,
            };
          }
        });
        columnTemplates.forEach((columnObj) => {
          columnObj.children.forEach((childObj) => {
            const columnName =
              childObj && childObj.name && childObj.name.toLowerCase();
            if (
              skuData[columnName] &&
              childObj.templateKey === ColumnKeys.CUSTOM_COL
            ) {
              customColumnsCopy[childObj.colKey] =
                customColumnsCopy[childObj.colKey] || {};
              customColumnsCopy[childObj.colKey][skuNumber] =
                skuData[columnName];
            }
          });
        });
        successes = successes + 1;
      } catch (error) {}
    });
    if (successes > 0) {
      openPasteNotification(
        successes,
        skuDataObj.length,
        sortSkuList.length,
        skuGroupName
      );
      setNewCosts(newCostsCopy);
      setNewRetails(newRetailsCopy);
      setCustomColumns(customColumnsCopy);
    }
  };

  const pasteFunction = (e, inputColumn) => {
    //check if clipboard has \n and \t which is how excel puts values on clipboard coming from multiple columns i.e sku and cost columns.
    if (e.clipboardData.getData('Text').includes('\n' && '\t')) {
      const clipboard = e.clipboardData
        .getData('Text')
        .replace(/\r/g, '')
        .split('\n')
        .map((string) => string.split('\t'));

      if (clipboard.length > 0) {
        const headers = clipboard[0];
        if (headers.length < 2) {
          return;
        }
        if (!isNaN(headers[0])) {
          const skuData = clipboard
            .filter((item) => item.length > 1)
            .map((x) => ({
              sku: parseInt(x[0]),
              data: !inputColumn.includes('new-custom-column-')
                ? parseFloat(x[1].replace(',', '')).toFixed(2)
                : x[1].replace(',', ''),
            }))
            .filter((x) => !isNaN(x.sku));

          if (inputColumn === 'cost') {
            pasteCostList(skuData);
          } else if (inputColumn.includes('new-custom-column-')) {
            pasteCustomColumns(skuData, inputColumn);
          } else {
            pasteRetails(skuData, inputColumn);
          }
        } else {
          pasteMultipleColumns(clipboard);
        }
      }
      e.preventDefault();
    }
  };

  const columnExpandClickHandler = (colKey) => {
    if (collapsedZoneGroups.includes(colKey)) {
      setCollapsedZoneGroups((prevCollapsedZoneGroups) => {
        let copy = [...prevCollapsedZoneGroups];
        copy.splice(prevCollapsedZoneGroups.indexOf(colKey), 1);
        return copy;
      });
    } else {
      setCollapsedZoneGroups((prevCollapsedZoneGroups) => {
        let copy = [...prevCollapsedZoneGroups];
        copy.push(colKey);
        return copy;
      });
    }
  };

  const onFilterChange = (pagination, filters, sorter, extra) => {
    let { currentDataSource, action } = extra;
    if (action !== 'filter') {
      return;
    }
    if (selectedTableTab === TableTabKeys.RTL) {
      setFilteredRetailTableSkus(
        currentDataSource.map((item) => item.skuNumber)
      );
    } else {
      setFilteredCostTableSkus(currentDataSource.map((item) => item.skuNumber));
    }
  };

  const getCostSkusForSelectedVendor = () => {
    let costSkusForVendor = new Set();
    Object.keys(vendorData.vendorGroupData).forEach((sku) => {
      Object.keys(vendorData.vendorGroupData[sku]).forEach((market) => {
        Object.keys(vendorData.vendorGroupData[sku][market]).forEach(
          (vendorNumber) => {
            if (
              parseInt(vendorNumber) === vendorData.selectedVendor.vendorNumber
            ) {
              costSkusForVendor.add(sku);
            }
          }
        );
      });
    });
    setFilteredCostTableSkus(Array.from(costSkusForVendor));
  };

  const updateMetrics = () => {
    //initialize markup
    setMarkUpTotal(null);
    setMarkDownTotal(null);
    setLoadingMuMd(true);
    setDisasterMarkUpTotal(null);
    setDisasterMarkDownTotal(null);
    setLoadingDisasterMuMd(true);

    //initialize imu
    setProjectedImuLineStructureValue(null);
    setDisasterProjectedImuLineStructureValue(null);
    setCurrentImuLineStructure(null);
    setLoadingImuLineStructureProjected(true);
    setLoadingDisasterImuLineStructureProjected(true);
    setLoadingImuLineStructureCurrent(true);
    setIsDisasterBarOpen(true);

    //call mu/md without disaster impact
    EditPriceUtil.fetchMarkUpMarkDownBySku(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      setSkuZoneMuMd,
      setSkuMuMd,
      setMarkUpTotal,
      setMarkDownTotal,
      setLoadingMuMd,
      false,
      setDisasterMarkUpTotal,
      setDisasterMarkDownTotal,
      setLoadingDisasterMuMd
    );
    //call mu/md with disaster impact
    EditPriceUtil.fetchMarkUpMarkDownBySku(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      setSkuZoneMuMd,
      setSkuMuMd,
      setMarkUpTotal,
      setMarkDownTotal,
      setLoadingMuMd,
      true,
      setDisasterMarkUpTotal,
      setDisasterMarkDownTotal,
      setLoadingDisasterMuMd
    );
    DataBarUtil.getCurrentImuLineStructure(
      skuList,
      zoneMultiplierGroupData,
      setCurrentImuLineStructure,
      setLoadingImuLineStructureCurrent
    );
    // call imu without disaster impact
    DataBarUtil.getProjectedImuLineStructure(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts,
      setProjectedImuLineStructureValue,
      setLoadingImuLineStructureProjected,
      setDisasterProjectedImuLineStructureValue,
      setLoadingDisasterImuLineStructureProjected,
      false
    );
    // call imu with disaster impact
    DataBarUtil.getProjectedImuLineStructure(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts,
      setProjectedImuLineStructureValue,
      setLoadingImuLineStructureProjected,
      setDisasterProjectedImuLineStructureValue,
      setLoadingDisasterImuLineStructureProjected,
      true
    );
    EditPriceUtil.fetchProjectedSkuLevelImu(
      skuList,
      setProjectedNetSkuImu,
      zoneMultiplierGroupData,
      newRetails,
      newCosts
    );
    if (Object.values(zoneGroupImu.data).length < 1) {
      //only make call if there is no data
      EditPriceUtil.fetchZoneGroupImu(
        skuList,
        zoneMultiplierGroupData,
        setZoneGroupImu
      );
    }
    EditPriceUtil.fetchProjectedZoneGroupImu(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      newCosts,
      setProjectedZoneGroupImu
    );
    EditPriceUtil.fetchProjectedCpi(
      skuList,
      zoneMultiplierGroupData,
      setLineStructureProjectedCpiData,
      newRetails,
      false
    );
    EditPriceUtil.fetchProjectedCpi(
      skuList,
      zoneMultiplierGroupData,
      setLineStructureProjectedCpiDisasterData,
      newRetails,
      true
    );
    EditPriceUtil.fetchProjectedZoneGroupCpi(
      skuList,
      zoneMultiplierGroupData,
      newRetails,
      setZoneGroupProjectedCpi
    );
  };

  const generateRCW = () => {
    let rcwPrices = [];
    sortSkuList.forEach((skuObject) => {
      let sku = skuObject.skuNumber;
      if (zoneMultiplierGroupData.zoneGroups) {
        zoneMultiplierGroupData.zoneGroups.forEach((zoneGroup) => {
          zoneGroup.zones.forEach((zone) => {
            let retail =
              newRetails[sku] &&
              newRetails[sku][zoneGroup.id] &&
              newRetails[sku][zoneGroup.id].retail;
            if (retail) {
              retail = Math.round(parseFloat(retail) * 100 + Number.EPSILON);
            }
            if (
              recommendations[sku] &&
              recommendations[sku][zoneGroup.id] &&
              retail ===
                recommendations[sku][zoneGroup.id]['recommendation']
                  .recommendedPrice
            ) {
              rcwPrices.push({
                sku: sku,
                zone: zone,
                recommendedPrice: retail,
              });
            } else if (retail) {
              rcwPrices.push({
                sku: sku,
                zone: zone,
                currentPrice: null,
                recommendedPrice: retail,
                reason: 'User entered custom price',
              });
            }
          });
        });
      }
    });

    if (rcwPrices.length < 1) {
      return;
    }

    const hierarchy = EditPriceUtil.splitDcs(skusDcs.data[skuList[0]]);
    let inputData = {
      recommendations: rcwPrices,
      subDepartment: hierarchy.subDepartment,
      subClassNumber: hierarchy.subClassNumber,
      classNumber: hierarchy.classNumber,
    };
    EditPriceUtil.generateRCW(
      userId,
      { ...inputData, email: userEmail },
      (data) => {
        openNotification(data);
      },
      context.updateShowDimmer
    );
  };

  const generateRecRetails = (rules, override, isOldRetailUsed) => {
    setRecommendationOverride(override);
    const inputRetails = getRecommendationRetails(isOldRetailUsed);
    EditPriceUtil.getRecRetails(
      skuList,
      anchorSku,
      zoneMultiplierGroupData,
      inputRetails,
      setNewRetails,
      removeMuMdSkus,
      context.updateShowDimmer,
      setRecommendations,
      rules,
      override,
      targetRules
    );
  };
  const getRecommendationRetails = (isOldRetailUsed) => {
    let currentRetailsObj = { ...zoneGroupModeRetailStatus.data };
    if (!isOldRetailUsed) {
      return newRetails;
    } else {
      let inputRetails = { ...newRetails };
      for (let zoneGroupId in currentRetailsObj) {
        const currentRetail = currentRetailsObj[zoneGroupId];
        for (let sku in currentRetail) {
          inputRetails[sku] = {
            ...inputRetails[sku],
            [zoneGroupId]: {
              retail: currentRetailsObj[zoneGroupId][sku][0].retail / 100,
            },
          };
        }
      }
      return inputRetails;
    }
  };

  const updateZoneGroupMultipliersData = (zoneGroupsData) => {
    const zoneGroupsCopy = [...zoneMultiplierGroupData.zoneGroups];
    zoneGroupsData.forEach((zoneGroup) => {
      let zoneGroupObjIndex = zoneGroupsCopy.findIndex(
        (group) => group.id === zoneGroup.id
      );
      if (zoneGroupObjIndex !== -1) {
        zoneGroupsCopy[zoneGroupObjIndex] = zoneGroup;
      }
    });
    setZoneMultiplierGroupData((prevZoneMultiData) => {
      return {
        ...prevZoneMultiData,
        zoneGroups: zoneGroupsCopy,
      };
    });
  };

  const checkNewRetailsOverride = () => {
    const anchorZoneGroup = Object.values(
      zoneMultiplierGroupData['zoneGroups'] || {}
    ).find((zoneGroup) => zoneGroup.isAnchor);
    const skus = Object.keys(newRetails);
    for (const sku of skus) {
      const zoneGroupIds = Object.keys(newRetails[sku] || {});
      for (const zoneGroupId of zoneGroupIds) {
        if (
          sku === anchorSku.toString() &&
          zoneGroupId === anchorZoneGroup.id
        ) {
          continue;
        }
        if (
          newRetails[sku] &&
          newRetails[sku][zoneGroupId] &&
          newRetails[sku][zoneGroupId].retail &&
          newRetails[sku][zoneGroupId].isManualEdit
        ) {
          return false;
        }
      }
    }
    return true;
  };

  const handleRestoreSession = (check) => {
    const storage = localStorage.getItem(DATA_SAVE_STORAGE);
    if (storage) {
      const data = JSON.parse(storage);
      try {
        const maindata = data[zoneMultiplierGroupId];
        if (maindata) {
          const newcosts = deleteMissingSkuKeys(maindata.costs);
          const newretails = deleteMissingSkuKeys(maindata.retails);

          if (
            (newcosts && Object.keys(newcosts).length > 0) ||
            (newretails && Object.keys(newretails).length > 0)
          ) {
            if (check) {
              const afterWeek = data.timestamp + 7 * 24 * 60 * 60 * 1000;
              const now = Date.now();
              if (afterWeek > now) {
                setIsRestoreSessionModalOpen(true);
              } else {
                localStorage.removeItem(DATA_SAVE_STORAGE);
              }
            } else {
              setNewCosts(newcosts);
              setNewRetails(newretails);
              setIsRestoreSessionModalOpen(false);
            }
          }
        }
      } catch {}
    }
  };

  const disasterData = {
    disasterCpiData: lineStructureProjectedCpiDisasterData,
    disasterMarkUpTotal,
    disasterMarkDownTotal,
    loadingDisasterMuMd,
    disasterProjectedImuLineStructureValue,
    loadingDisasterImuLineStructureProjected,
    setIsDisasterBarOpen: setIsDisasterBarOpen,
    isDisasterBarOpen: isDisasterBarOpen,
  };

  const updateCustomColumnData = (input, colKey, skuNumber) => {
    let updatedCustomColumns = { ...customColumns };
    updatedCustomColumns[colKey] = updatedCustomColumns[colKey] || {};
    updatedCustomColumns[colKey][skuNumber] = input;
    setCustomColumns(updatedCustomColumns);
  };

  const columnDefinitions = {
    [ColumnKeys.ANCHOR_COL]: useMemo(
      () => anchorIconColumn(anchorSku),
      [anchorSkus]
    ),
    [ColumnKeys.SKU_INFO_PARENT_COL]: useMemo(
      () => EditPriceColumnCreation.getSkuInformationParentConfigTemplate(),
      []
    ),
    [ColumnKeys.SKU_NUM_COL_RTL]: useMemo(
      () => skuColumn(filteredRetailTableSkus, anchorSku),
      [filteredRetailTableSkus, anchorSkus]
    ),
    [ColumnKeys.SKU_DESC_COL_RTL]: useMemo(
      () =>
        skuDescriptionColumn(
          filteredRetailTableSkus,
          skuDescriptions,
          anchorSku
        ),
      [filteredRetailTableSkus, skuDescriptions, anchorSkus]
    ),
    [ColumnKeys.SKU_NUM_COL_RTL]: useMemo(
      () => skuColumn(filteredRetailTableSkus, anchorSku),
      [filteredRetailTableSkus, anchorSkus]
    ),
    [ColumnKeys.SKU_DESC_COL_RTL]: useMemo(
      () =>
        skuDescriptionColumn(
          filteredRetailTableSkus,
          skuDescriptions,
          anchorSku
        ),
      [filteredRetailTableSkus, skuDescriptions, anchorSkus]
    ),
    [ColumnKeys.SKU_NUM_COL_COST]: useMemo(
      () => skuColumn(filteredCostTableSkus, anchorSku),
      [filteredCostTableSkus, anchorSkus]
    ),
    [ColumnKeys.SKU_DESC_COL_COST]: useMemo(
      () =>
        skuDescriptionColumn(filteredCostTableSkus, skuDescriptions, anchorSku),
      [filteredCostTableSkus, skuDescriptions, anchorSkus]
    ),
    [ColumnKeys.LINE_STR_MET_PARENT_COL]: useMemo(
      () => EditPriceColumnCreation.getLineStructureParentConfigTemplate(),
      []
    ),
    [ColumnKeys.DCS_COL]: useMemo(
      () => dcsColumn(filteredRetailTableSkus, skusDcs),
      [filteredRetailTableSkus, skusDcs]
    ),
    [ColumnKeys.LINE_STR_MU_MD_COL]: useMemo(
      () => muMdColumn(filteredRetailTableSkus, skuMuMd, loadingMuMd),
      [filteredRetailTableSkus, skuMuMd, loadingMuMd]
    ),
    [ColumnKeys.LINE_STR_NET_IMU_COL]: useMemo(
      () => imuColumn(filteredRetailTableSkus, netSkuImu),
      [filteredRetailTableSkus, netSkuImu]
    ),
    [ColumnKeys.LINE_STR_PROJ_IMU_COL]: useMemo(
      () =>
        projectedImuColumn(
          filteredRetailTableSkus,
          projectedNetSkuImu,
          zoneMultiplierGroupData,
          newRetails
        ),
      [
        filteredRetailTableSkus,
        projectedNetSkuImu,
        zoneMultiplierGroupData,
        newRetails,
      ]
    ),
    [ColumnKeys.LINE_STR_INV_COST_COL]: useMemo(
      () => invoiceCostColumn(filteredRetailTableSkus, skuInvoiceCost),
      [filteredRetailTableSkus, skuInvoiceCost]
    ),
    [ColumnKeys.LINE_STR_NEW_COST_COL]: useMemo(
      () =>
        newCostColumn(newCosts, onNewCostUpdate, setNewCosts, pasteFunction),
      [newCosts]
    ),
    [ColumnKeys.LINE_STR_MODE_RTL_COL]: useMemo(
      () => modeRetailColumn(filteredRetailTableSkus, modeRetailStatus),
      [filteredRetailTableSkus, modeRetailStatus]
    ),
    [ColumnKeys.LINE_STR_MODE_RTL_STS_COL]: useMemo(
      () => modeRetailStatusColumn(filteredRetailTableSkus, modeRetailStatus),
      [filteredRetailTableSkus, modeRetailStatus]
    ),
    [ColumnKeys.CUSTOM_COL]: (colKey, name, className) =>
      getCustomColumnConfig(
        colKey,
        name,
        updateCustomColumnData,
        className,
        customColumns,
        filteredRetailTableSkus,
        pasteFunction,
        draggableColumnWidth,
        setDraggableColumnWidth
      ),
    [ColumnKeys.ZG_PARENT_COL]: (colKey, zoneGroup) =>
      EditPriceColumnCreation.getZoneGroupParentConfigTemplate(
        colKey,
        zoneGroup,
        columnExpandClickHandler,
        collapsedZoneGroups
      ),
    [ColumnKeys.ZG_MODE_RTL_COL]: (colKey, className, zoneGroup) =>
      zoneGroupModeRetailColumn(
        colKey,
        className,
        skuList,
        zoneGroup.id,
        zoneGroupModeRetailStatus
      ),
    [ColumnKeys.ZG_MODE_RTL_STS_COL]: (colKey, className, zoneGroup) =>
      zoneGroupRetailStatusColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        zoneGroupModeRetailStatus
      ),
    [ColumnKeys.ZG_NEW_RTL_COL]: (colKey, className, zoneGroup) =>
      newRetailColumn(
        colKey,
        className,
        zoneGroup,
        newRetails,
        zoneGroupModeRetailStatus,
        anchorSku,
        recommendations,
        onRetailUpdate,
        pasteFunction
      ),
    [ColumnKeys.ZG_MU_MD_COL]: (colKey, className, zoneGroup) =>
      zoneGroupMuMdColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        skuZoneMuMd,
        loadingMuMd
      ),
    [ColumnKeys.ZG_IMU_COL]: (colKey, className, zoneGroup) =>
      zoneGroupImuColumn(colKey, className, skuList, zoneGroup, zoneGroupImu),
    [ColumnKeys.ZG_NEW_IMU_COL]: (colKey, className, zoneGroup) =>
      zoneGroupProjectedImuColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        projectedZoneGroupImu,
        newRetails
      ),

    [ColumnKeys.COMP_ZG_PARENT_COL]: (colKey, zoneGroup) =>
      EditPriceColumnCreation.getCompetitiveParentConfigTemplate(
        colKey,
        zoneGroup,
        columnTemplates,
        columnExpandClickHandler,
        collapsedZoneGroups
      ),
    [ColumnKeys.COMP_ZG_PRICE_COL]: (
      colKey,
      className,
      zoneGroup,
      competitor
    ) =>
      CompetitorPriceColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        competitor,
        zoneGroupCompetitorPrice
      ),
    [ColumnKeys.COMP_ZG_CUR_CPI_COL]: (
      colKey,
      className,
      zoneGroup,
      competitor
    ) =>
      CurrentCpiColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        competitor,
        zoneGroupCurrentCpi
      ),
    [ColumnKeys.COMP_ZG_NEW_CPI_COL]: (
      colKey,
      className,
      zoneGroup,
      competitor
    ) =>
      ProjectedCpiColumn(
        colKey,
        className,
        skuList,
        zoneGroup,
        competitor,
        zoneGroupCurrentCpi,
        myPriceZoneGroupCpi,
        zoneGroupProjectedCpi
      ),
    [ColumnKeys.COMP_ZG_NO_DATA_COL]: (colKey, className, zoneGroup) =>
      NoDataColumn(colKey, className, zoneGroup),
    [ColumnKeys.ELLIPSIS_COL]: (className) => ellipsisColumn(className),
    [ColumnKeys.VEND_COST_PARENT_COL]: useMemo(
      () => getVendorCostParentColumn(vendorData, updateVendorData),
      [vendorData]
    ),
    [ColumnKeys.VEND_COST_VEND_NUM_COL]: () =>
      useMemo(() => vendorCostVendorNumberColumn(vendorData), [vendorData]),
    [ColumnKeys.VEND_COST_VEND_NAME_COL]: () =>
      useMemo(() => vendorCostVendorNameColumn(vendorData), [vendorData]),
    [ColumnKeys.SKU_MKT_PARENT_COL]: useMemo(
      () => EditPriceColumnCreation.getSkuMarketParentConfigTemplate(),
      []
    ),
    [ColumnKeys.MKT_DC_NUM_COL]: useMemo(
      () => marketNumColumn(filteredCostTableSkus, anchorSku, vendorData),
      [vendorData, filteredCostTableSkus, anchorSku]
    ),
    [ColumnKeys.MKT_DC_NAME_COL]: useMemo(
      () => marketNameColumn(filteredCostTableSkus, anchorSku, vendorData),
      [vendorData, filteredCostTableSkus, anchorSku]
    ),
    [ColumnKeys.BLENDED_COST_COL]: () =>
      useMemo(
        () => vendorCostBlendedCost(vendorData),
        [vendorData.costs, vendorData.selectedVendor]
      ),
    [ColumnKeys.CURRENT_COST_COL]: () =>
      useMemo(
        () => vendorCostCurrentCost(vendorData),
        [vendorData.costs, vendorData.selectedVendor]
      ),
  };

  const getDynamicGroupColumns = () => {
    if (!zoneMultiplierGroupData['zoneGroups']) {
      return [];
    }

    return Object.values(zoneMultiplierGroupData['zoneGroups'])
      .sort((a, b) => b.isAnchor - a.isAnchor)
      .map((zoneGroup, index) => {
        let className = EditPriceColumnCreation.getZebraStripeClass(
          zoneMultiplierGroupData,
          index
        );
        return Object.keys(ZoneGroupColumnTemplates).map((templateKey) => {
          if (templateKey === ColumnKeys.ZG_PARENT_COL) {
            return EditPriceColumnCreation.createZoneGroupTemplate(
              templateKey,
              zoneGroup,
              className,
              filteredRetailTableSkus,
              zoneGroupCurrentCpi,
              zoneGroupCompetitorPrice
            );
          } else if (templateKey === ColumnKeys.COMP_ZG_PARENT_COL) {
            return EditPriceColumnCreation.createZoneGroupCompetitorTemplate(
              templateKey,
              zoneGroup,
              className,
              filteredRetailTableSkus,
              zoneGroupCurrentCpi,
              zoneGroupCompetitorPrice
            );
          }
        });
      })
      .flat();
  };

  const getAllRetailTableColumnConfigs = () => {
    const finalColumns = [];
    const templates = [...columnTemplates];
    templates.forEach((template) => {
      let parentConfig;
      if (
        template.templateKey === ColumnKeys.ZG_PARENT_COL ||
        template.templateKey === ColumnKeys.COMP_ZG_PARENT_COL
      ) {
        parentConfig = columnDefinitions[template.templateKey](
          template.colKey,
          template.zoneGroup
        );
      } else {
        parentConfig = columnDefinitions[template.templateKey];
      }
      let finalChildColumns = [];
      let copyOfTemplate = { ...template };
      copyOfTemplate.children = getVisibleColumns(copyOfTemplate);
      if (copyOfTemplate.children.length) {
        if (collapsedZoneGroups.includes(copyOfTemplate.colKey)) {
          parentConfig.colSpan = 2;
          finalChildColumns = getCollapsedGroupChildren(copyOfTemplate);
        } else {
          finalChildColumns = getChildColumnDefinitions(copyOfTemplate);
        }
        parentConfig.children = finalChildColumns;
        finalColumns.push(parentConfig);
      } else if (copyOfTemplate.templateKey === ColumnKeys.ANCHOR_COL) {
        finalColumns.push(parentConfig);
      }
    });
    return finalColumns;
  };

  const getVisibleColumns = (template) => {
    return template.children.filter(
      (child) => !hiddenColumns.includes(child.colKey)
    );
  };

  const getCollapsedGroupChildren = ({
    className,
    children,
    templateKey,
    zoneGroup,
  }) => {
    let collapsedColumns = [
      columnDefinitions[ColumnKeys.ELLIPSIS_COL](className),
    ];
    if (templateKey === ColumnKeys.ZG_PARENT_COL) {
      const newRetailCol = children.find(
        (child) => child.templateKey === ColumnKeys.ZG_NEW_RTL_COL
      );
      collapsedColumns.unshift(
        columnDefinitions[ColumnKeys.ZG_NEW_RTL_COL](
          newRetailCol ? newRetailCol.colKey : null,
          className,
          zoneGroup
        )
      );
    } else if (templateKey === ColumnKeys.COMP_ZG_PARENT_COL) {
      collapsedColumns.unshift(
        columnDefinitions[children[0].templateKey](
          children[0].colKey,
          className,
          zoneGroup,
          children[0].competitor
        )
      );
    }
    return collapsedColumns;
  };

  const getChildColumnDefinitions = ({
    templateKey,
    children,
    className,
    zoneGroup,
  }) => {
    return children.map((child) => {
      if (child.templateKey === ColumnKeys.CUSTOM_COL) {
        return columnDefinitions[ColumnKeys.CUSTOM_COL](
          child.colKey,
          child.name,
          className
        );
      } else if (templateKey === ColumnKeys.ZG_PARENT_COL) {
        return columnDefinitions[child.templateKey](
          child.colKey,
          className,
          zoneGroup
        );
      } else if (templateKey === ColumnKeys.COMP_ZG_PARENT_COL) {
        return child.templateKey === ColumnKeys.COMP_ZG_NO_DATA_COL
          ? columnDefinitions[ColumnKeys.COMP_ZG_NO_DATA_COL](
              className,
              zoneGroup
            )
          : columnDefinitions[child.templateKey](
              child.colKey,
              className,
              zoneGroup,
              child.competitor
            );
      } else {
        return columnDefinitions[child.templateKey];
      }
    });
  };

  const zoneGroupDataExists = Object.keys(zoneMultiplierGroupData).length > 0;

  const retailTableColumns = getAllRetailTableColumnConfigs();

  const getAllCostTableColumnConfigs = () => {
    return costColumnTemplates.map((template) => {
      let parentConfig = columnDefinitions[template.templateKey];
      if (template.templateKey !== ColumnKeys.ANCHOR_COL) {
        parentConfig.children = getCostChildColumnDefinitions(template);
      }
      return parentConfig;
    });
  };

  const getCostChildColumnDefinitions = ({ templateKey, children }) => {
    if (children.length) {
      return children.map((child) => {
        if (templateKey === ColumnKeys.VEND_COST_PARENT_COL) {
          return columnDefinitions[child.templateKey](child.colKey);
        }
        return columnDefinitions[child.templateKey];
      });
    }
    return [];
  };

  const costTableColumns = getAllCostTableColumnConfigs();

  return (
    <Layout id="edit-price-page-layout">
      <EditPricePageHeader
        backArrowClick={backArrowClick}
        zoneMultiplierGroupData={zoneMultiplierGroupData}
        updateZoneGroupMultipliersData={updateZoneGroupMultipliersData}
        skuList={skuList}
        disableSkuToSku={!anchorSku}
        anchorSku={anchorSku}
        userId={userId}
        zoneMultiplierGroupId={zoneMultiplierGroupId}
        skuGroupName={skuGroupId ? skuGroupName : ''}
        skuGroupId={skuGroupId}
        columnTemplates={columnTemplates}
        setColumnTemplates={setColumnTemplates}
        initialCosts={newCosts}
        initialRetails={newRetails}
        zoneGroupCompetitorPrice={zoneGroupCompetitorPrice}
        zoneGroupCurrentCpi={zoneGroupCurrentCpi}
        customColumns={customColumns}
        hiddenColumns={hiddenColumns}
        setHiddenColumns={setHiddenColumns}
      />
      <Content id="edit-price-content">
        <Row className="pls-group-name-row">
          <SkuGroupData
            groupName={skuGroupId ? skuGroupName : ''}
            plsSkuCount={skuList.length}
          />
        </Row>
        <Row>
          <Col span={24}>
            <EditPriceTableTabs
              selectedTableTab={selectedTableTab}
              setSelectedTableTab={setSelectedTableTab}
              retailTableColumns={retailTableColumns}
              costTableColumns={costTableColumns}
              sortSkuList={sortSkuList}
              onFilterChange={onFilterChange}
              costTableData={costTableData}
              // DATA BAR PROPS
              lineStructureCpiData={lineStructureCpiData}
              myPriceCpi={myPriceCpi}
              lineStructureProjectedCpiData={lineStructureProjectedCpiData}
              skuList={skuList}
              skuGroupName={skuGroupName}
              markUpTotal={markUpTotal}
              markDownTotal={markDownTotal}
              loadingMuMd={loadingMuMd}
              currentImuLineStructure={currentImuLineStructure}
              projectedImuLineStructureValue={projectedImuLineStructureValue}
              loadingImuLineStructureCurrent={loadingImuLineStructureCurrent}
              loadingImuLineStructureProjected={
                loadingImuLineStructureProjected
              }
              disasterData={disasterData}
            />
          </Col>
        </Row>
      </Content>
      <EditPricePageFooter
        updateMetrics={updateMetrics}
        setRecommendPriceModal={setRecommendPriceModal}
        generateRCW={generateRCW}
        enableUpdateMetricsButton={zoneGroupDataExists}
        enableRecButton={zoneGroupDataExists}
        enableRCWButton={zoneGroupDataExists}
      />
      {recommendPriceModal && (
        <RecommendPriceModal
          setRecommendPriceModal={setRecommendPriceModal}
          generateRecs={generateRecRetails}
          override={!checkNewRetailsOverride(newRetails)}
        />
      )}
      {isRestoreSessionModalOpen && (
        <RestoreSessionModal
          setIsRestoreSessionModalOpen={setIsRestoreSessionModalOpen}
          handleRestoreSession={handleRestoreSession}
        />
      )}
    </Layout>
  );
};

EditPricePage.propTypes = {
  userId: PropTypes.string.isRequired,
  userEmail: PropTypes.string.isRequired,
  backArrowClick: PropTypes.func.isRequired,
  skuGroupName: PropTypes.string.isRequired,
  skuList: PropTypes.arrayOf(PropTypes.number).isRequired,
  zoneMultiplierGroupId: PropTypes.string.isRequired,
  skuGroupId: PropTypes.string,
  costs: PropTypes.objectOf(PropTypes.string),
  retails: PropTypes.objectOf(PropTypes.string),
};

export default EditPricePageWrapper(EditPricePage);
