import React from 'react';

export function highlightText(text, searchText) {
  const regex = new RegExp(`(${searchText})`, 'gi');

  if (text && text.length) {
    return text.split(regex).map((fragment, i) =>
      regex.test(fragment) ? (
        <mark style={{ padding: '0', backgroundColor: '#fdb689' }} key={i}>
          {fragment}
        </mark>
      ) : (
        fragment
      )
    );
  }

  return null;
}
