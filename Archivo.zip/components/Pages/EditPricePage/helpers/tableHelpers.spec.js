import React from 'react';
import { highlightText } from './tableHelpers';

describe('highlightText function', () => {
  it('should highlight the search text in the given text', () => {
    const text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit';
    const searchText = 'ipsum';
    const expectedOutput = [
      'Lorem ',
      <mark style={{ padding: '0', backgroundColor: '#fdb689' }} key={1}>
        ipsum
      </mark>,
      ' dolor sit amet, consectetur adipiscing elit',
    ];

    expect(highlightText(text, searchText)).toEqual(expectedOutput);
  });

  it('should highlight all occurrences of the search text in the given text', () => {
    const text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit';
    const searchText = 'ip';
    const expectedOutput = [
      'Lorem ',
      <mark style={{ padding: '0', backgroundColor: '#fdb689' }} key={1}>
        ip
      </mark>,
      'sum dolor sit amet, consectetur ad',
      <mark style={{ padding: '0', backgroundColor: '#fdb689' }} key={3}>
        ip
      </mark>,
      'iscing elit',
    ];

    expect(highlightText(text, searchText)).toEqual(expectedOutput);
  });

  it('should return the original text if the search text is not found', () => {
    const text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit';
    const searchText = 'font';
    const expectedOutput = [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    ];

    expect(highlightText(text, searchText)).toEqual(expectedOutput);
  });
});
