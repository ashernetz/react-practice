import React from 'react';

export const TableTabKeys = {
  RTL: 'Retail',
  COST: 'Cost',
};

export const ColumnKeys = {
  CUSTOM_COL: 'customColumn',
  ELLIPSIS_COL: 'ellipsisColumn',
  SKU_INFO_PARENT_COL: 'SKU Information',
  ANCHOR_COL: 'anchor',
  SKU_NUM_COL_RTL: 'skuNumber',
  SKU_DESC_COL_RTL: 'skuDescription',
  SKU_NUM_COL_COST: 'skuNumberCost',
  SKU_DESC_COL_COST: 'skuDescriptionCost',
  LINE_STR_MET_PARENT_COL: 'Line Structure Metrics',
  DCS_COL: 'dcs',
  LINE_STR_MU_MD_COL: 'skuMuMd',
  LINE_STR_NET_IMU_COL: 'lineStructureNetImu',
  LINE_STR_PROJ_IMU_COL: 'lineStructureProjectedImu',
  LINE_STR_INV_COST_COL: 'invoiceCost',
  LINE_STR_NEW_COST_COL: 'newCost',
  LINE_STR_MODE_RTL_COL: 'modeRetail',
  LINE_STR_MODE_RTL_STS_COL: 'modeRetailStatus',
  ZG_PARENT_COL: 'ZoneGroup',
  ZG_MODE_RTL_COL: 'zoneGroupModeRetail',
  ZG_MODE_RTL_STS_COL: 'zoneGroupProjectedImu',
  ZG_NEW_RTL_COL: 'zoneGroupNewRetail',
  ZG_MU_MD_COL: 'zoneGroupMarkUpMarkDown',
  ZG_IMU_COL: 'zoneGroupImu',
  ZG_NEW_IMU_COL: 'zoneGroupNewImu',
  COMP_ZG_PARENT_COL: 'Competitive',
  COMP_ZG_PRICE_COL: 'competitivePrice',
  COMP_ZG_CUR_CPI_COL: 'competitiveCurrentCpi',
  COMP_ZG_NEW_CPI_COL: 'competitiveNewCpi',
  COMP_ZG_NO_DATA_COL: 'noCompetitiveDataColumn',
  VEND_COST_PARENT_COL: 'Vendor/Cost',
  VEND_COST_VEND_NUM_COL: 'vendor',
  VEND_COST_VEND_NAME_COL: 'vendorName',
  BLENDED_COST_COL: 'blendedCost',
  CURRENT_COST_COL: 'firstCost',
  SKU_MKT_PARENT_COL: 'SKU/Market',
  MKT_DC_NUM_COL: 'market',
  MKT_DC_NAME_COL: 'marketName',
};

export const ColumnNames = {
  SKU_NUM: 'SKU',
  SKU_DESC: 'Description',
  DCS: 'DCS',
  NET_MU_MD: 'Net MU/MD',
  NET_IMU: 'Net IMU',
  PROJ_NET_IMU: 'New Net IMU',
  INV_COST: 'Inv. Cost',
  NEW_COST: 'New Cost',
  MODE_RTL: 'Mode Retail',
  MODE_RTL_STS: 'Mode Retail Status',
  NEW_RTL: 'New Retail',
  MU_MD: 'MU/MD',
  IMU: 'IMU',
  NEW_IMU: 'New IMU',
  VEND_COST_VEND_NUM: 'Vendor Number',
  VEND_COST_VEND_NAME: 'Vendor Name',
  BLENDED_COST: 'Current Blended Cost',
  CURRENT_COST: 'Current Cost',
  MKT_DC_NUM: 'Mkt/DC',
  MKT_DC_NAME: 'Mkt/DC Name',
};
export const AnchorColumnTemplate = {
  templateKey: ColumnKeys.ANCHOR_COL,
  colKey: ColumnKeys.ANCHOR_COL,
  children: [],
};

export const SkuInfoColumnTemplate = {
  templateKey: ColumnKeys.SKU_INFO_PARENT_COL,
  colKey: ColumnKeys.SKU_INFO_PARENT_COL,
  name: ColumnKeys.SKU_INFO_PARENT_COL,
  children: [
    {
      templateKey: ColumnKeys.SKU_NUM_COL_RTL,
      colKey: ColumnKeys.SKU_NUM_COL_RTL,
      name: ColumnNames.SKU_NUM,
      parentKey: ColumnKeys.SKU_INFO_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.SKU_DESC_COL_RTL,
      colKey: ColumnKeys.SKU_DESC_COL_RTL,
      name: ColumnNames.SKU_DESC,
      parentKey: ColumnKeys.SKU_INFO_PARENT_COL,
    },
  ],
};

export const SkuMarketColumnGroupTemplate = {
  templateKey: ColumnKeys.SKU_MKT_PARENT_COL,
  colKey: ColumnKeys.SKU_MKT_PARENT_COL,
  name: ColumnKeys.SKU_MKT_PARENT_COL,
  children: [
    {
      templateKey: ColumnKeys.SKU_NUM_COL_COST,
      colKey: ColumnKeys.SKU_NUM_COL_COST,
      name: ColumnNames.SKU_NUM,
      parentKey: ColumnKeys.SKU_MKT_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.SKU_DESC_COL_COST,
      colKey: ColumnKeys.SKU_DESC_COL_COST,
      name: ColumnNames.SKU_DESC,
      parentKey: ColumnKeys.SKU_MKT_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.MKT_DC_NUM_COL,
      colKey: ColumnKeys.MKT_DC_NUM_COL,
      name: ColumnNames.MKT_DC_NUM,
      parentKey: ColumnKeys.SKU_MKT_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.MKT_DC_NAME_COL,
      colKey: ColumnKeys.MKT_DC_NAME_COL,
      name: ColumnNames.MKT_DC_NAME,
      parentKey: ColumnKeys.SKU_MKT_PARENT_COL,
    },
  ],
};

export const LineStructureColumnGroupTemplate = {
  templateKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
  colKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
  name: ColumnKeys.LINE_STR_MET_PARENT_COL,
  children: [
    {
      templateKey: ColumnKeys.DCS_COL,
      colKey: ColumnKeys.DCS_COL,
      name: ColumnNames.DCS,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_MU_MD_COL,
      colKey: ColumnKeys.LINE_STR_MU_MD_COL,
      name: ColumnNames.NET_MU_MD,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_NET_IMU_COL,
      colKey: ColumnKeys.LINE_STR_NET_IMU_COL,
      name: ColumnNames.NET_IMU,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_PROJ_IMU_COL,
      colKey: ColumnKeys.LINE_STR_PROJ_IMU_COL,
      name: ColumnNames.PROJ_NET_IMU,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_INV_COST_COL,
      colKey: ColumnKeys.LINE_STR_INV_COST_COL,
      name: ColumnNames.INV_COST,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_NEW_COST_COL,
      colKey: ColumnKeys.LINE_STR_NEW_COST_COL,
      name: ColumnNames.NEW_COST,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_MODE_RTL_COL,
      colKey: ColumnKeys.LINE_STR_MODE_RTL_COL,
      name: ColumnNames.MODE_RTL,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.LINE_STR_MODE_RTL_STS_COL,
      colKey: ColumnKeys.LINE_STR_MODE_RTL_STS_COL,
      name: ColumnNames.MODE_RTL_STS,
      parentKey: ColumnKeys.LINE_STR_MET_PARENT_COL,
    },
  ],
};

export const VendorCostColumnGroupTemplate = {
  templateKey: ColumnKeys.VEND_COST_PARENT_COL,
  colKey: ColumnKeys.VEND_COST_PARENT_COL,
  name: ColumnKeys.VEND_COST_PARENT_COL,
  children: [
    {
      templateKey: ColumnKeys.VEND_COST_VEND_NUM_COL,
      colKey: ColumnKeys.VEND_COST_VEND_NUM_COL,
      name: ColumnNames.VEND_COST_VEND_NUM,
      parentKey: ColumnKeys.VEND_COST_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.VEND_COST_VEND_NAME_COL,
      colKey: ColumnKeys.VEND_COST_VEND_NAME_COL,
      name: ColumnNames.VEND_COST_VEND_NAME,
      parentKey: ColumnKeys.VEND_COST_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.BLENDED_COST_COL,
      colKey: ColumnKeys.BLENDED_COST_COL,
      name: ColumnNames.BLENDED_COST,
      parentKey: ColumnKeys.VEND_COST_PARENT_COL,
    },
    {
      templateKey: ColumnKeys.CURRENT_COST_COL,
      colKey: ColumnKeys.CURRENT_COST_COL,
      name: ColumnNames.CURRENT_COST,
      parentKey: ColumnKeys.VEND_COST_PARENT_COL,
    },
  ],
};

export const ImmutableColumns = [AnchorColumnTemplate, SkuInfoColumnTemplate];
export const InitialRetailColumnsTemplate = [
  AnchorColumnTemplate,
  SkuInfoColumnTemplate,
  LineStructureColumnGroupTemplate,
];

export const InitialCostColumnsTemplate = [
  AnchorColumnTemplate,
  SkuMarketColumnGroupTemplate,
  VendorCostColumnGroupTemplate,
];

export const ZoneGroupColumnTemplates = {
  [ColumnKeys.ZG_PARENT_COL]: [
    { templateKey: ColumnKeys.ZG_MODE_RTL_COL, name: ColumnNames.MODE_RTL },
    {
      templateKey: ColumnKeys.ZG_MODE_RTL_STS_COL,
      name: ColumnNames.MODE_RTL_STS,
    },
    { templateKey: ColumnKeys.ZG_NEW_RTL_COL, name: ColumnNames.NEW_RTL },
    {
      templateKey: ColumnKeys.ZG_MU_MD_COL,
      name: ColumnNames.MU_MD,
    },
    { templateKey: ColumnKeys.ZG_IMU_COL, name: ColumnNames.IMU },
    { templateKey: ColumnKeys.ZG_NEW_IMU_COL, name: ColumnNames.NEW_IMU },
  ],
  [ColumnKeys.COMP_ZG_PARENT_COL]: [
    { templateKey: ColumnKeys.COMP_ZG_CUR_CPI_COL },
    { templateKey: ColumnKeys.COMP_ZG_NEW_CPI_COL },
    { templateKey: ColumnKeys.COMP_ZG_PRICE_COL },
  ],
};
