import React from 'react';
import { Col, Image, Input, Modal, Row, Space, Typography } from 'antd';
import '../EditPricePage.scss';
import AnchorSku from '../../../../images/AnchorSku.svg';
import { UXSpin } from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import PropTypes from 'prop-types';

const EditPriceInput = ({
  retail,
  onRetailUpdate,
  pasteFunction,
  isDisabled,
}) => {
  return (
    <Row gutter={[8, 0]}>
      <Col className="retail-input-box" span={24}>
        <Input
          type="number"
          disabled={isDisabled}
          onPaste={(e) => {
            if (pasteFunction) {
              pasteFunction(e);
            }
          }}
          prefix="$"
          data-testid={`new-retail-input-${retail}`}
          value={retail ? retail.toString() : retail}
          onChange={(e) => {
            let inputValue = e.target.value;
            const re = /^[0-9]*\.?[0-9]*$/;
            const regDec = /^-?\d*(\.\d{0,3})?$/;
            if (
              inputValue === '' ||
              (re.test(inputValue) && regDec.test(inputValue))
            ) {
              onRetailUpdate(inputValue);
            }
          }}
          onBlur={(e) => {
            let inputValue = e.target.value;
            let formattedValue = inputValue
              ? parseFloat(inputValue.replace(/\$\s?|(,*)/g, '')).toFixed(2)
              : '';
            if (retail !== formattedValue) {
              onRetailUpdate(formattedValue);
            }
          }}
          className="table-cell-input-box-size"
        />
      </Col>
    </Row>
  );
};

const PLSAnchor = () => {
  return (
    <div>
      <img src={AnchorSku} alt="Anchor" className="edit-price-anchor" />
    </div>
  );
};

class StringCell extends React.Component {
  shouldComponentUpdate(nextProps, nextState, nextContext) {
    return (
      nextProps.value !== this.props.value ||
      nextProps.loading !== this.props.loading
    );
  }

  render() {
    if (this.props.value && this.props.value !== 'NaN') {
      return this.props.value;
    } else {
      return this.props.loading ? <UXSpin /> : '--';
    }
  }
}

StringCell.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  loading: PropTypes.bool.isRequired,
};

export { EditPriceInput, PLSAnchor, StringCell };
