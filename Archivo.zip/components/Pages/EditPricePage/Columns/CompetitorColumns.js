import EditPriceFilters from './EditPriceFilters';
import EditPriceSorters from './EditPriceSorters';
import React from 'react';
import { Typography } from 'antd';
import { UXSpin } from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import PropTypes from 'prop-types';
import CompUtil from '../../../Utils/CompUtil';
import EditPriceUtil from '../Util/EditPriceUtil';

const { Text } = Typography;

const NoDataColumn = (colKey, className, zoneGroup) => {
  return {
    key: colKey,
    title: <Text className="child-title-formatter-no-data">No Data</Text>,
    dataIndex: '',
    width: 120,
    className,
    render: () => {
      return <div className="no-competitor-data-cell-text">--</div>;
    },
  };
};

const CompetitorPriceColumn = (
  colKey,
  className,
  skuList,
  zoneGroup,
  competitor,
  zoneGroupCompetitorPrice
) => {
  let allValues = skuList
    .map((sku) => zoneGroupCompetitorPrice.data[sku])
    .map(
      (obj) =>
        (obj &&
          obj[zoneGroup.id] &&
          obj[zoneGroup.id][competitor.competitorId] &&
          obj[zoneGroup.id][competitor.competitorId].toFixed(2)) ||
        'NA'
    );

  return {
    key: colKey,
    title: titleFormatter(competitor.competitorName + '$'),
    dataIndex: '',
    width: 120,
    className,
    filterMode: 'tree',
    filters: EditPriceFilters.redundantFormatFilters(allValues, (item) =>
      isNaN(item) ? 'NA' : '$' + CompUtil.formatPrice(item, true)
    ),
    onFilter: (value, record) => {
      let price = fetchZoneGroupCompetitorData(
        zoneGroupCompetitorPrice,
        record.skuNumber,
        zoneGroup,
        competitor.competitorId
      );
      return value === ((price && price.toFixed(2)) || 'NA');
    },
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.sortCompetitorPriceBySkuZoneGroup(
        a,
        b,
        zoneGroup.id,
        zoneGroupCompetitorPrice.data,
        competitor.competitorId
      ),
    render: (text, row) => {
      let competitorPrice = fetchZoneGroupCompetitorData(
        zoneGroupCompetitorPrice,
        row.skuNumber,
        zoneGroup,
        competitor.competitorId
      );

      return (
        <CompetitorPriceCell
          competitorPrice={competitorPrice}
          loading={zoneGroupCompetitorPrice.isLoading}
        ></CompetitorPriceCell>
      );
    },
  };
};

class CompetitorPriceCell extends React.PureComponent {
  render() {
    if (this.props.competitorPrice) {
      return '$' + Math.round(this.props.competitorPrice) / 100;
    } else {
      return this.props.loading ? <UXSpin /> : '--';
    }
  }
}

CompetitorPriceCell.propTypes = {
  competitorPrice: PropTypes.number,
  loading: PropTypes.bool.isRequired,
};

const CurrentCpiColumn = (
  key,
  className,
  skuList,
  zoneGroup,
  competitor,
  zoneGroupCurrentCpi
) => {
  let allValues = skuList
    .map((sku) => zoneGroupCurrentCpi.data[sku])
    .map(
      (obj) =>
        (obj &&
          obj[zoneGroup.id] &&
          obj[zoneGroup.id][competitor.competitorId] &&
          obj[zoneGroup.id][competitor.competitorId].toFixed(2)) ||
        'NA'
    );
  return {
    key,
    title: titleFormatter(competitor.competitorName),
    dataIndex: '',
    width: 110,
    className: className,
    filterMode: 'tree',
    filters: EditPriceFilters.redundantFormatFilters(allValues),
    onFilter: (value, record) => {
      let cpi = fetchZoneGroupCompetitorData(
        zoneGroupCurrentCpi,
        record.skuNumber,
        zoneGroup,
        competitor.competitorId
      );
      return ((cpi && cpi.toFixed(2)) || 'NA') === value;
    },
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.sortCpiByCompetitor(
        a,
        b,
        zoneGroupCurrentCpi.data,
        zoneGroup.id,
        competitor.competitorId
      ),
    render: (text, row) => {
      let competitorPrice = fetchZoneGroupCompetitorData(
        zoneGroupCurrentCpi,
        row.skuNumber,
        zoneGroup,
        competitor.competitorId
      );
      return (
        <CpiCell
          cpi={competitorPrice}
          loading={zoneGroupCurrentCpi.isLoading}
        />
      );
    },
  };
};

class CpiCell extends React.PureComponent {
  render() {
    if (this.props.cpi) {
      return (
        <Text
          className={
            parseFloat(this.props.cpi.toFixed(2)) <= 1
              ? 'green-cpi-text'
              : 'red-cpi-text'
          }
        >
          {this.props.cpi.toFixed(2)}
        </Text>
      );
    } else {
      return this.props.loading ? <UXSpin /> : '--';
    }
  }
}

CpiCell.propTypes = {
  cpi: PropTypes.number,
  loading: PropTypes.bool.isRequired,
};

const fetchZoneGroupCompetitorData = (
  competitorData,
  skuNum,
  zoneGroup,
  competitorType
) => {
  const id = zoneGroup.id;
  return (
    competitorData.data &&
    competitorData.data[skuNum] &&
    competitorData.data[skuNum][id] &&
    competitorData.data[skuNum][id][competitorType]
  );
};

const titleFormatter = (input) => (
  <Text className="child-title-formatter">{input}</Text>
);

const getProjectedCpi = ({
  skuNumber,
  zoneGroup,
  competitorId,
  zoneGroupCurrentCpi,
  myPriceZoneGroupCpi,
  zoneGroupProjectedCpi,
}) => {
  let dcCpi =
    zoneGroupCurrentCpi &&
    fetchZoneGroupCompetitorData(
      zoneGroupCurrentCpi,
      skuNumber,
      zoneGroup,
      competitorId
    );
  let mpCpi =
    myPriceZoneGroupCpi &&
    fetchZoneGroupCompetitorData(
      myPriceZoneGroupCpi,
      skuNumber,
      zoneGroup,
      competitorId
    );
  let projectedCpi =
    zoneGroupProjectedCpi &&
    fetchZoneGroupCompetitorData(
      zoneGroupProjectedCpi,
      skuNumber,
      zoneGroup,
      competitorId
    );
  let isWithinThreshold = EditPriceUtil.projectedCpiThreshold(
    dcCpi,
    mpCpi,
    projectedCpi
  );
  if (isWithinThreshold) {
    return fetchZoneGroupCompetitorData(
      zoneGroupProjectedCpi,
      skuNumber,
      zoneGroup,
      competitorId
    );
  } else {
    return null;
  }
};

const ProjectedCpiColumn = (
  key,
  className,
  skuList,
  zoneGroup,
  competitor,
  zoneGroupCurrentCpi,
  myPriceZoneGroupCpi,
  zoneGroupProjectedCpi
) => {
  let allValues = skuList.map((sku) => {
    let projectedCpi = getProjectedCpi(
      sku,
      zoneGroup,
      competitor.competitorId,
      zoneGroupCurrentCpi,
      myPriceZoneGroupCpi,
      zoneGroupProjectedCpi
    );
    if (projectedCpi) {
      return projectedCpi.toFixed(2);
    } else {
      return 'NA';
    }
  });

  return {
    key,
    title: titleFormatter('New ' + competitor.competitorName),
    dataIndex: '',
    width: competitor.competitorName === 'AMZ MKT' ? 150 : 140,
    className: className,
    showSorterTooltip: false,
    sorter: (a, b) =>
      getProjectedCpi(
        a.skuNumber,
        zoneGroup,
        competitor.competitorId,
        zoneGroupCurrentCpi,
        myPriceZoneGroupCpi,
        zoneGroupProjectedCpi
      ) -
      getProjectedCpi(
        b.skuNumber,
        zoneGroup,
        competitor.competitorId,
        zoneGroupCurrentCpi,
        myPriceZoneGroupCpi,
        zoneGroupProjectedCpi
      ),
    filterMode: 'tree',
    filters: EditPriceFilters.redundantFormatFilters(allValues),
    onFilter: (value, record) => {
      let cpi = getProjectedCpi(
        record.skuNumber,
        zoneGroup,
        competitor.competitorId,
        zoneGroupCurrentCpi,
        myPriceZoneGroupCpi,
        zoneGroupProjectedCpi
      );
      return (cpi ? cpi.toFixed(2) : 'NA') === value;
    },
    render: (text, row) => {
      let projCpi = getProjectedCpi(
        row.skuNumber,
        zoneGroup,
        competitor.competitorId,
        zoneGroupCurrentCpi,
        myPriceZoneGroupCpi,
        zoneGroupProjectedCpi
      );
      return (
        <CpiCell
          cpi={projCpi}
          loading={
            zoneGroupCurrentCpi.isLoading ||
            myPriceZoneGroupCpi.isLoading ||
            zoneGroupProjectedCpi.isLoading
          }
        />
      );
    },
  };
};
export {
  CompetitorPriceColumn,
  CurrentCpiColumn,
  CpiCell,
  CompetitorPriceCell,
  ProjectedCpiColumn,
  NoDataColumn,
};
