import EditPriceFilters from './EditPriceFilters';
import EditPriceSorters from './EditPriceSorters';
import { EditPriceInput, StringCell } from './ColumnComponents';
import React from 'react';
import { Button, Popover, Tooltip, Typography } from 'antd';
import CompUtil from '../../../Utils/CompUtil';
import { InfoCircleOutlined } from '@ant-design/icons';
import { SKULEVEL_CONTENT } from '../../../../constants/ToolTip';
import PropTypes from 'prop-types';
import { RuleExplainPopover } from '../Components/RuleExplainPopover';
import ModeRetailStatus from '../Components/ModeRetailStatus';

const { Text } = Typography;

const newRetailColumn = (
  colKey,
  className,
  zoneGroup,
  newRetails,
  zoneGroupModeRetailStatus,
  anchorSku,
  recommendations,
  onRetailUpdate,
  pasteFunction
) => {
  return {
    key: colKey,
    title: (
      <Text className="child-title-formatter">
        {'New Retail'}
        <Popover
          content={skuLevelRetailContent('New Retail')}
          trigger="click"
          placement="top"
        >
          <Button
            type="link"
            data-testid="new-retail-info"
            shape="circle"
            size={'small'}
            icon={<InfoCircleOutlined className="imu-data-bar-info-icon" />}
          />
        </Popover>
      </Text>
    ),
    dataIndex: '',
    width: 110,
    className: className,
    showSorterTooltip: false,
    render: (text, row) => {
      let lowestStatusRetail =
        zoneGroupModeRetailStatus.data[zoneGroup.id] &&
        zoneGroupModeRetailStatus.data[zoneGroup.id][row.skuNumber] &&
        zoneGroupModeRetailStatus.data[zoneGroup.id][row.skuNumber][0] &&
        zoneGroupModeRetailStatus.data[zoneGroup.id][row.skuNumber][0].retail;
      return (
        <NewRetailCell
          skuNumber={row.skuNumber}
          zoneGroup={zoneGroup}
          newRetail={
            newRetails[row.skuNumber] &&
            newRetails[row.skuNumber][zoneGroup.id] &&
            newRetails[row.skuNumber][zoneGroup.id].retail
          }
          permRetail={lowestStatusRetail}
          anchorSku={anchorSku}
          recommendations={recommendations}
          onRetailUpdate={onRetailUpdate}
          pasteFunction={(e) => pasteFunction(e, zoneGroup.id)}
        />
      );
    },
  };
};

class NewRetailCell extends React.Component {
  render() {
    let {
      skuNumber,
      zoneGroup,
      newRetail,
      permRetail,
      anchorSku,
      recommendations,
      onRetailUpdate,
      pasteFunction,
    } = this.props;
    let recRules =
      recommendations &&
      recommendations[skuNumber] &&
      recommendations[skuNumber][zoneGroup.id];
    return (
      <Tooltip
        title={
          permRetail ? undefined : 'This SKU is not sold in this zone group'
        }
      >
        <Popover
          content={
            <RuleExplainPopover
              anchorSku={anchorSku}
              retail={newRetail}
              recRules={recRules}
            />
          }
          title={<b>Applied Rules</b>}
          placement="leftTop"
          mouseEnterDelay={1}
          zIndex={newRetail ? 10 : -1}
          trigger="hover"
        >
          <div>
            <EditPriceInput
              pasteFunction={(e) => pasteFunction(e)}
              isDisabled={!permRetail}
              retail={newRetail}
              onRetailUpdate={(value) =>
                onRetailUpdate(skuNumber, zoneGroup.id, { retail: value })
              }
            />
          </div>
        </Popover>
      </Tooltip>
    );
  }

  shouldComponentUpdate(nextProps, nextState, nextContext) {
    return (
      nextProps.skuNumber !== this.props.skuNumber ||
      nextProps.zoneGroup !== this.props.zoneGroup ||
      nextProps.newRetail !== this.props.newRetail ||
      nextProps.permRetail !== this.props.permRetail ||
      nextProps.anchorSku !== this.props.anchorSku ||
      nextProps.recommendations !== this.props.recommendations ||
      nextProps.onRetailUpdate !== this.props.onRetailUpdate
    );
  }
}

NewRetailCell.propTypes = {
  skuNumber: PropTypes.number.isRequired,
  zoneGroup: PropTypes.object.isRequired,
  newRetail: PropTypes.string,
  permRetail: PropTypes.number,
  anchorSku: PropTypes.number,
  recommendations: PropTypes.object,
  onRetailUpdate: PropTypes.func.isRequired,
};

const ellipsisColumn = (className) => {
  return {
    title: titleFormatter('...'),
    dataIndex: '',
    width: 45,
    isEllipsisColumn: true,
    className: className,
    render: () => {
      return '...';
    },
  };
};

const zoneGroupModeRetailColumn = (
  colKey,
  className,
  skuList,
  zoneGroupId,
  zoneGroupModeRetailStatus
) => {
  let skuModeRetails = zoneGroupModeRetailStatus.data[zoneGroupId];
  return {
    key: colKey,
    title: titleFormatter('Mode Retail'),
    dataIndex: '',
    width: 150,
    className: className,
    filterMode: 'tree',
    filters: EditPriceFilters.customModeRetailFilter(
      skuList,
      skuModeRetails,
      'retail'
    ),
    onFilter: (value, record) =>
      (skuModeRetails[record.skuNumber]
        ? skuModeRetails[record.skuNumber][0].retail
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortRetailStatus(a, b, 'retail', skuModeRetails),
    render: (text, row) => {
      let modeRetails = skuModeRetails && skuModeRetails[row.skuNumber];
      return (
        <ModeRetailStatus
          modeRetailStatuses={modeRetails}
          loading={zoneGroupModeRetailStatus.isLoading}
        />
      );
    },
  };
};

const zoneGroupRetailStatusColumn = (
  colKey,
  className,
  skuList,
  zoneGroup,
  zoneGroupModeRetailStatus
) => {
  let skuModeRetails = zoneGroupModeRetailStatus.data[zoneGroup.id];
  return {
    key: colKey, //`zoneGroupRetailStatus-${zoneGroup.id}`,
    title: titleFormatter('Mode Retail Status'),
    dataIndex: '',
    width: 200,
    className: className,
    filterMode: 'tree',
    filters: EditPriceFilters.customRetailStatusFilter(
      skuList,
      skuModeRetails,
      'completeStatus'
    ),
    onFilter: (value, record) =>
      (skuModeRetails[record.skuNumber]
        ? skuModeRetails[record.skuNumber][0].completeStatus
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortRetailStatus(
        a,
        b,
        'statusCode',
        skuModeRetails
      ),
    render: (text, row) => {
      let status =
        skuModeRetails &&
        skuModeRetails[row.skuNumber] &&
        skuModeRetails[row.skuNumber][0]['completeStatus'];
      return (
        <StringCell
          value={status}
          loading={zoneGroupModeRetailStatus.isLoading}
        />
      );
    },
  };
};

const zoneGroupMuMdColumn = (
  colKey,
  className,
  skuList,
  zoneGroup,
  skuZoneMuMd,
  loadingMuMd
) => {
  let allValues = skuList.map(
    (sku) => skuZoneMuMd[sku] && skuZoneMuMd[sku][zoneGroup.id]
  );

  return {
    key: colKey, // `zoneGroupMuMd-${zoneGroup.id}`,
    title: titleFormatter('MU/MD'),
    dataIndex: '',
    width: 110,
    className: className,
    filterMode: 'tree',
    filters: EditPriceFilters.customMuMdFilter(allValues),
    onFilter: (value, record) =>
      (skuZoneMuMd[record.skuNumber] &&
      skuZoneMuMd[record.skuNumber][zoneGroup.id]
        ? skuZoneMuMd[record.skuNumber][zoneGroup.id]
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortNoDataIndex(a, b, zoneGroup.id, skuZoneMuMd),
    render: (text, row) => {
      let muMd =
        skuZoneMuMd[row.skuNumber] && skuZoneMuMd[row.skuNumber][zoneGroup.id];
      return (
        <StringCell
          value={
            muMd &&
            CompUtil.formatMuMdPrice(
              skuZoneMuMd[row.skuNumber][zoneGroup.id],
              true
            )
          }
          loading={loadingMuMd}
        />
      );
    },
  };
};

const zoneGroupImuColumn = (
  colKey,
  className,
  skuList,
  zoneGroup,
  zoneGroupImu
) => {
  return {
    key: colKey, // `zoneGroupCurrentImu-${zoneGroup.id}`,
    title: titleFormatter('IMU'),
    dataIndex: '',
    width: 110,
    className: className,
    filters: EditPriceFilters.customPercentFormatFilter(
      skuList,
      zoneGroupImu.data,
      zoneGroup.id
    ),
    onFilter: (value, record) =>
      (zoneGroupImu.data[record.skuNumber]
        ? zoneGroupImu.data[record.skuNumber][zoneGroup.id]
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortNoDataIndex(
        a,
        b,
        zoneGroup.id,
        zoneGroupImu.data
      ),
    render: (text, row) => {
      let imu =
        zoneGroupImu.data[row.skuNumber] &&
        zoneGroupImu.data[row.skuNumber][zoneGroup.id];
      return (
        <StringCell
          value={
            imu &&
            !isNaN(imu) &&
            Math.round((imu + Number.EPSILON) * 100) / 100 + '%'
          }
          loading={zoneGroupImu.isLoading}
        />
      );
    },
  };
};

const zoneGroupProjectedImuColumn = (
  colKey,
  className,
  skuList,
  zoneGroup,
  projectedZoneGroupImu,
  newRetails
) => {
  return {
    key: colKey, // `zoneGroupProjectedImu-${zoneGroup.id}`,
    title: titleFormatter('New IMU'),
    dataIndex: '',
    width: 140,
    className: className,
    filterMode: 'tree',
    filters: EditPriceFilters.customPercentFormatFilter(
      skuList,
      projectedZoneGroupImu.data,
      zoneGroup.id
    ),
    onFilter: (value, record) =>
      (projectedZoneGroupImu.data[record.skuNumber]
        ? projectedZoneGroupImu.data[record.skuNumber][zoneGroup.id]
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortNoDataIndex(
        a,
        b,
        zoneGroup.id,
        projectedZoneGroupImu.data
      ),
    render: (text, row) => {
      let imu =
        newRetails[row.skuNumber] &&
        newRetails[row.skuNumber][zoneGroup.id] &&
        newRetails[row.skuNumber][zoneGroup.id].retail &&
        projectedZoneGroupImu.data[row.skuNumber] &&
        projectedZoneGroupImu.data[row.skuNumber][zoneGroup.id];
      return (
        <StringCell
          value={
            imu &&
            !isNaN(imu) &&
            Math.round((imu + Number.EPSILON) * 100) / 100 + '%'
          }
          loading={projectedZoneGroupImu.isLoading}
        />
      );
    },
  };
};

const skuLevelRetailContent = (label) => (
  <div className="retail-data-info-content">
    <p>{SKULEVEL_CONTENT[label]}</p>
  </div>
);

const titleFormatter = (input) => (
  <Text className="child-title-formatter">{input}</Text>
);

export {
  zoneGroupModeRetailColumn,
  zoneGroupRetailStatusColumn,
  ellipsisColumn,
  newRetailColumn,
  zoneGroupMuMdColumn,
  zoneGroupImuColumn,
  zoneGroupProjectedImuColumn,
};
