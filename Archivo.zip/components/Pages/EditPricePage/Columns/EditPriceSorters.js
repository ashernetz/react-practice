export default class EditPriceSorters {
  /**
   * This custom string sorter will sort all complex String elements, that have a dataIndex, in descending/ascending order (ex: sku description)
   * @param a first string to be compared
   * @param b second string to be compared
   * @returns {number}
   */
  static customStringSorter(a, b) {
    return (a ? a : '').localeCompare(b ? b : '');
  }

  /**
   * Calculates where items should appear when sorting in descending/ascending order.  Should only be called in EditPricePage columns that have a dataIndex
   * @param a first parameter in sorting algorithm
   * @param b second parameter in sorting algorithm
   * @param dataIndex name of the property in the dataSource
   * @returns {number}
   */
  static customSortWithDataIndex(a, b, dataIndex) {
    let first = isNaN(a[dataIndex]) || !a[dataIndex] ? 0 : a[dataIndex];
    let second = isNaN(b[dataIndex]) || !b[dataIndex] ? 0 : b[dataIndex];

    return first - second;
  }

  /**
   * Calculates where items should appear when sorting in descending/ascending order.  Should only be called in EditPricePage columns that do not have a dataIndex.
   * This will only work if the dataObject is in a friendly format.
   * @param a first parameter to be considered in sorting algorithm
   * @param b second parameter to be considered in sorting algorithm
   * @param dataPoint name of the property in the dataObject
   * @param dataObject name of the state variable that holds the required dataPoint that needs to be displayed
   * @returns {number}
   */
  static customSortNoDataIndex(a, b, dataPoint, dataObject) {
    let first = dataObject[a.skuNumber];
    let second = dataObject[b.skuNumber];

    if (first && !isNaN(parseFloat(first[dataPoint]))) {
      first = first[dataPoint];
    } else {
      first = 0;
    }

    if (second && !isNaN(parseFloat(second[dataPoint]))) {
      second = second[dataPoint];
    } else {
      second = 0;
    }

    return first - second;
  }

  /**
   * Handles sort for all custom columns that are added through the settings popout
   * @param a first parameter to be considered in sorting algorithm
   * @param b second parameter to be considered in sorting algorithm
   * @param sortOrder sorting order 'ascend' or 'descend'
   * @param key the unique key of the child column.  This is used to index the custom column data
   * @param customColumnData the state that gets updated onBlur when a user enters text into an input field on a custom column
   * @returns {number || string}
   */
  static customColumnSort(a, b, sortOrder, key, customColumnData) {
    let first =
      customColumnData && customColumnData[key] && customColumnData[key][a.key];
    let second =
      customColumnData && customColumnData[key] && customColumnData[key][b.key];

    if (first === second) return 0;
    if (!first) return sortOrder === 'ascend' ? 1 : -1;
    if (!second) return sortOrder === 'ascend' ? -1 : 1;

    return first.localeCompare(second, 'en-US', {
      numeric: true,
      sensitivity: 'base',
    });
  }

  static sortNumbers(a, b, dataObject) {
    let first = dataObject[a.skuNumber];
    let second = dataObject[b.skuNumber];

    if (!first || isNaN(first)) {
      first = 0;
    }

    if (!second || isNaN(second)) {
      second = 0;
    }

    return first - second;
  }

  static sortRetailBySkuZoneGroup(a, b, zoneGroupId, dataObject) {
    let first = -1;
    let second = -1;

    if (
      dataObject[a.skuNumber] &&
      dataObject[a.skuNumber][zoneGroupId] &&
      dataObject[a.skuNumber][zoneGroupId].permRetail
    ) {
      first = dataObject[a.skuNumber][zoneGroupId].permRetail;
    }

    if (
      dataObject[b.skuNumber] &&
      dataObject[b.skuNumber][zoneGroupId] &&
      dataObject[b.skuNumber][zoneGroupId].permRetail
    ) {
      second = dataObject[b.skuNumber][zoneGroupId].permRetail;
    }

    return first - second;
  }

  static sortCpiByCompetitor(a, b, cpiDataObject, zoneGroupId, compId) {
    let first = -1;
    let second = -1;

    if (
      cpiDataObject[a.skuNumber] &&
      cpiDataObject[a.skuNumber][zoneGroupId] &&
      cpiDataObject[a.skuNumber][zoneGroupId][compId]
    ) {
      first = cpiDataObject[a.skuNumber][zoneGroupId][compId];
    }

    if (
      cpiDataObject[b.skuNumber] &&
      cpiDataObject[b.skuNumber][zoneGroupId] &&
      cpiDataObject[b.skuNumber][zoneGroupId][compId]
    ) {
      second = cpiDataObject[b.skuNumber][zoneGroupId][compId];
    }

    return first - second;
  }

  static sortCompetitorPriceBySkuZoneGroup(
    a,
    b,
    zoneGroupId,
    competitorPrices,
    competitorId
  ) {
    let first, second;
    if (
      competitorPrices[a.skuNumber] &&
      competitorPrices[a.skuNumber][zoneGroupId]
    ) {
      first = competitorPrices[a.skuNumber][zoneGroupId][competitorId];
    }

    if (
      competitorPrices[b.skuNumber] &&
      competitorPrices[b.skuNumber][zoneGroupId]
    ) {
      second = competitorPrices[b.skuNumber][zoneGroupId][competitorId];
    }
    if (!first || isNaN(parseFloat(first))) {
      first = 0;
    }

    if (!second || isNaN(parseFloat(second))) {
      second = 0;
    }

    return first - second;
  }

  static customSortRetailStatus(a, b, dataPoint, dataObject) {
    let first = dataObject[a.skuNumber]
      ? dataObject[a.skuNumber][0][dataPoint]
      : -1;
    let second = dataObject[b.skuNumber]
      ? dataObject[b.skuNumber][0][dataPoint]
      : -1;

    return first - second;
  }

  static columnSort(extractDataFunc, a, b, sortOrder) {
    const first = extractDataFunc(a);
    const second = extractDataFunc(b);

    if (first === second) return 0;
    if (!first) return sortOrder === 'ascend' ? 1 : -1;
    if (!second) return sortOrder === 'ascend' ? -1 : 1;

    return first.toString().localeCompare(second, 'en-US', {
      numeric: true,
      sensitivity: 'base',
    });
  }
}
