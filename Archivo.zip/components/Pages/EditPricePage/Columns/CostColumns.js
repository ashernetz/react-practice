import { Typography } from 'antd';
import React from 'react';
import { ColumnKeys, ColumnNames } from '../Constants/ColumnConstants';
import EditPriceFilters from './EditPriceFilters';
import EditPriceSorters from './EditPriceSorters';
import CompUtil from '../../../Utils/CompUtil';

const { Text } = Typography;

const titleFormatter = (input) => (
  <Text className={'child-title-formatter'}>{input}</Text>
);

const extractCostDataFunc = (record, costType, costs, vendorNumber) => {
  const { skuNumber, market } = record;
  if (
    costs[skuNumber] &&
    costs[skuNumber][market] &&
    costs[skuNumber][market][vendorNumber]
  ) {
    return costs[skuNumber][market][vendorNumber][costType];
  }
  return undefined;
};

export const vendorCostVendorNumberColumn = (vendorData) => {
  const { vendorGroupData, selectedVendor } = vendorData;
  return {
    key: ColumnKeys.VEND_COST_VEND_NUM_COL,
    width: 180,
    title: (
      <Text className={'child-title-formatter'}>
        {ColumnNames.VEND_COST_VEND_NUM}
      </Text>
    ),
    dataIndex: ColumnKeys.VEND_COST_VEND_NUM_COL,
    render: (text, row) => {
      const item = vendorGroupData[row.skuNumber][row.market];
      if (item) {
        return (
          <Text>
            {item[selectedVendor.vendorNumber][
              ColumnKeys.VEND_COST_VEND_NUM_COL
            ] || '--'}
          </Text>
        );
      }
    },
  };
};

export const vendorCostVendorNameColumn = (vendorData) => {
  const { vendorGroupData, selectedVendor } = vendorData;
  return {
    key: ColumnKeys.VEND_COST_VEND_NAME_COL,
    width: 300,
    title: (
      <Text className={'child-title-formatter'}>
        {ColumnNames.VEND_COST_VEND_NAME}
      </Text>
    ),
    dataIndex: ColumnKeys.VEND_COST_VEND_NAME_COL,
    render: (text, row) => {
      const item = vendorGroupData[row.skuNumber][row.market];
      if (item) {
        return (
          <Text>
            {item[selectedVendor.vendorNumber][
              ColumnKeys.VEND_COST_VEND_NAME_COL
            ] || '--'}
          </Text>
        );
      }
    },
  };
};

export const vendorCostBlendedCost = (vendorData) => {
  const {
    costs,
    selectedVendor: { vendorNumber },
  } = vendorData;

  const extractBlendedCostDataFunc = (record) =>
    extractCostDataFunc(record, 'blendedCost', costs, vendorNumber);

  return {
    title: titleFormatter('Current Blended Cost'),
    dataIndex: 'blendedCost',
    width: 165,
    filterMode: 'tree',
    filters: EditPriceFilters.costColumnFilter(
      costs,
      vendorNumber,
      'blendedCost'
    ),
    onFilter: EditPriceFilters.createOnFilterCostFunction(
      costs,
      vendorNumber,
      'blendedCost'
    ),
    sorter: (a, b, sortOrder) =>
      EditPriceSorters.columnSort(extractBlendedCostDataFunc, a, b, sortOrder),
    render(text, { skuNumber, market }) {
      if (
        costs[skuNumber] &&
        costs[skuNumber][market] &&
        costs[skuNumber][market][vendorNumber]
      ) {
        return (
          '$' +
          CompUtil.formatPrice(
            costs[skuNumber][market][vendorNumber].blendedCost,
            true
          )
        );
      }
      return '--';
    },
  };
};

export const vendorCostCurrentCost = (vendorData) => {
  const {
    costs,
    selectedVendor: { vendorNumber },
  } = vendorData;

  const extractCurrentCostDataFunc = (record) =>
    extractCostDataFunc(record, 'currentCost', costs, vendorNumber);

  return {
    title: titleFormatter('Current Cost'),
    dataIndex: 'currentCost',
    width: 125,
    filterMode: 'tree',
    filters: EditPriceFilters.costColumnFilter(
      costs,
      vendorNumber,
      'currentCost'
    ),
    onFilter: EditPriceFilters.createOnFilterCostFunction(
      costs,
      vendorNumber,
      'currentCost'
    ),
    sorter: (a, b, sortOrder) =>
      EditPriceSorters.columnSort(extractCurrentCostDataFunc, a, b, sortOrder),
    render(text, { skuNumber, market }) {
      if (
        costs[skuNumber] &&
        costs[skuNumber][market] &&
        costs[skuNumber][market][vendorNumber]
      ) {
        return (
          '$' +
          CompUtil.formatPrice(
            costs[skuNumber][market][vendorNumber].currentCost,
            true
          )
        );
      }
      return '--';
    },
  };
};
