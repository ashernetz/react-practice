import EditPriceSorters from './EditPriceSorters';

describe('EditPriceSorters', () => {
  it('should sort custom columns', () => {
    //inputs to function
    const a = {
      skuNumber: 193798,
      key: 193798,
    };

    const b = {
      skuNumber: 193801,
      key: 193801,
    };

    const columnKey = 'new-1684249467646';

    const customColumnData = {
      'new-1684249467646': {
        193798: 'test2',
        193801: 'test1',
      },
    };

    //call function
    const customColumnSort = EditPriceSorters.customColumnSort(
      a,
      b,
      'ascend',
      columnKey,
      customColumnData
    );

    expect(customColumnSort).toEqual(1); // a value of 1 here indicates that 193801(test 1) will be sorted before 193798(test 2)
  });

  describe('columnSort function', () => {
    const costs = {
      100: {
        1: {
          1: {
            blendedCost: 50,
            currentCost: 100,
          },
        },
      },
      101: {
        1: {
          1: {
            blendedCost: 60,
            currentCost: 90,
          },
        },
      },
      102: {
        1: {
          1: {
            blendedCost: undefined,
            currentCost: undefined,
          },
        },
      },
    };

    const extractDataFunc = (record) => {
      const { skuNumber, market } = record;
      if (
        costs[skuNumber] &&
        costs[skuNumber][market] &&
        costs[skuNumber][market][1]
      ) {
        return costs[skuNumber][market][1].blendedCost;
      }
      return undefined;
    };

    test('sorts in ascending order', () => {
      const recordA = { skuNumber: 100, market: 1 };
      const recordB = { skuNumber: 101, market: 1 };
      const result = EditPriceSorters.columnSort(
        extractDataFunc,
        recordA,
        recordB,
        'ascend'
      );
      expect(result).toBeLessThan(0);
    });

    test('sorts records with no cost data to the end in ascending order', () => {
      const recordA = { skuNumber: 102, market: 1 }; // this record doesn't have cost data
      const recordB = { skuNumber: 100, market: 1 };
      const result = EditPriceSorters.columnSort(
        extractDataFunc,
        recordA,
        recordB,
        'ascend'
      );
      expect(result).toBeGreaterThan(0);
    });

    test('sorts in descending order', () => {
      const recordA = { skuNumber: 101, market: 1 };
      const recordB = { skuNumber: 100, market: 1 };
      const result = EditPriceSorters.columnSort(
        extractDataFunc,
        recordA,
        recordB,
        'descend'
      );
      expect(result).toBeGreaterThan(0);
    });

    test('sorts records with no cost data to the end in descending order', () => {
      const recordA = { skuNumber: 102, market: 1 }; // this record doesn't have cost data
      const recordB = { skuNumber: 101, market: 1 };
      const result = EditPriceSorters.columnSort(
        extractDataFunc,
        recordA,
        recordB,
        'descend'
      );
      expect(result).toBeLessThan(0);
    });
  });
});
