import React from 'react';
import { Input } from 'antd';
import EditPriceSorters from './EditPriceSorters';
import EditPriceFilters from './EditPriceFilters';

const getCustomColumnConfig = (
  colKey,
  name,
  inputCallbackFunction,
  columnGroupBackgroundClass,
  customColumnData,
  filteredSkuList,
  pasteFunction,
  draggableColumnWidth,
  setDraggableColumnWidth
) => {
  return {
    name,
    key: colKey,
    className: columnGroupBackgroundClass,
    title: name,
    width: draggableColumnWidth[colKey] || 150,
    ellipsis: true,
    onHeaderCell: (column) => ({
      width: column.width,
      onResize: (_, { size }) => {
        setDraggableColumnWidth((prevState) => ({
          ...prevState,
          [colKey]: Math.max(150, size.width),
        }));
      },
      isCustom: true,
    }),
    isCustom: true,
    filterMode: 'tree',
    filters: EditPriceFilters.customColumnsFilter(
      filteredSkuList,
      colKey,
      customColumnData
    ),
    onFilter: (value, record) =>
      customColumnData &&
      customColumnData[colKey] &&
      customColumnData[colKey][record.skuNumber] === value,
    sorter: (a, b, sortOrder) =>
      EditPriceSorters.customColumnSort(
        a,
        b,
        sortOrder,
        colKey,
        customColumnData
      ),
    render: (text, row) => (
      <Input
        id={`input-${colKey}`}
        className={'custom-column-cell-input'}
        data-testid={`custom-column-input-${row.skuNumber}`}
        onBlur={(e) =>
          inputCallbackFunction(e.target.value, colKey, row.skuNumber)
        }
        onChange={(e) =>
          inputCallbackFunction(e.target.value, colKey, row.skuNumber)
        }
        value={
          customColumnData[colKey]
            ? customColumnData[colKey][row.skuNumber]
            : ''
        }
        onPaste={(e) => pasteFunction(e, colKey)}
      />
    ),
  };
};

export { getCustomColumnConfig };
