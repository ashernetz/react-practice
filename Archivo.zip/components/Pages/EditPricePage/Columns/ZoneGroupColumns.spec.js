import React from 'react';
import {
  fireEvent,
  render,
  screen,
  within,
  waitFor,
} from '@testing-library/react';
import SkuContext from '../../../../context/SkuContext';
import { SkuDescriptionProvider } from '../Context/SkuDescriptionProvider';
import EditPricePage from '../EditPricePage';
import { act } from 'react-dom/test-utils';
import axios from 'axios';
import { when } from 'jest-when';
import { zoneGroups } from '../__fixtures__/zoneGroups';
import { currentZoneGroupRetails } from '../__fixtures__/editPriceFiltersData';

jest.mock('axios');

const currentRetails = {
  data: [
    { sku: 12345, retail: 1000, occurrences: 100, strategy: 'ACTIVE' },
    { sku: 12345, retail: 1000, occurrences: 50, strategy: 'OUT_SEASON' },
    { sku: 23456, retail: 2000, occurrences: 150, strategy: 'IN_SEASON' },
    { sku: 23456, retail: 1, occurrences: 15, strategy: 'CLEARANCE' },
  ],
};

beforeEach(async () => {
  await act(async () => {
    when(axios.get)
      .calledWith(
        `/api/multi-sku/zoneMultiplierGroups?zoneMultiplierGroupId=${zoneGroups.data.id}`
      )
      .mockResolvedValue(zoneGroups);
    when(axios.post)
      .calledWith(`/api/dataConnect/modeRetailStatus`, expect.anything())
      .mockResolvedValue(currentRetails);
    when(axios.post)
      .calledWith(
        `/api/dataConnect/zoneGroupModeRetailStatus`,
        expect.anything()
      )
      .mockResolvedValue(currentZoneGroupRetails);
    const { container } = render(
      <SkuContext.Provider
        value={{
          subDeptDataMap: {
            '0013': {
              name: '001-001',
              deptClassMap: new Map(Object.entries({ 86: [45] })),
              description: 'Test Sub-Dept',
              longDescription: 'Long test description',
            },
          },
          updateShowDimmer: jest.fn(),
        }}
      >
        <SkuDescriptionProvider>
          <EditPricePage
            userId={'MC62YE'}
            userEmail={'Michelle_Cox_Bradford@homedepot.com'}
            backArrowClick={jest.fn()}
            zoneMultiplierGroupId={'3fa85f64-5717-4562-b3fc-2c963f66afa6'}
            skuGroupName={'Test Group'}
            skuList={[12345, 23456]}
          />
        </SkuDescriptionProvider>
      </SkuContext.Provider>
    );
  });
});

describe('Zone Group Columns', () => {
  jest.setTimeout(30000);
  test('Mode Retail Column renders correctly', () => {
    let modeRetailColumns = screen.queryAllByText(/Mode Retail$/m);
    expect(modeRetailColumns.length).toEqual(3);

    let skuRowOne = screen.getByText('12345').closest('tr');
    expect(within(skuRowOne).getAllByText('$10.00').length).toEqual(3); // 1 Sku-level, 2 ZoneGroup level.
    let skuLevelRetail = within(skuRowOne)
      .getAllByText('$10.00')[0]
      .closest('td');
    let zoneGroupOneRetail = within(skuRowOne)
      .getAllByText('$10.00')[1]
      .closest('td');
    let zoneGroupTwoRetail = within(skuRowOne)
      .getAllByText('$10.00')[2]
      .closest('td');

    expect(within(skuLevelRetail).getByText('(100)')).toBeInTheDocument();
    expect(within(zoneGroupOneRetail).getByText('(100)')).toBeInTheDocument();
    expect(within(zoneGroupTwoRetail).getByText('(50)')).toBeInTheDocument();
  });

  test('Mode Retail Status Column renders correctly', () => {
    let modeRetailColumns = screen.queryAllByText(/Mode Retail Status$/m);
    expect(modeRetailColumns.length).toEqual(3);

    let skuRowOne = screen.getByText('12345').closest('tr');
    expect(within(skuRowOne).getAllByText('$10.00').length).toEqual(3); // 1 Sku-level, 2 ZoneGroup level.
    let skuLevelRetail = within(skuRowOne)
      .getAllByText('$10.00')[0]
      .closest('td').nextSibling;
    let zoneGroupOneRetail = within(skuRowOne)
      .getAllByText('$10.00')[1]
      .closest('td').nextSibling;
    let zoneGroupTwoRetail = within(skuRowOne)
      .getAllByText('$10.00')[2]
      .closest('td').nextSibling;

    expect(
      within(skuLevelRetail).getByText('100 - Active')
    ).toBeInTheDocument();
    expect(
      within(zoneGroupOneRetail).getByText('100 - Active')
    ).toBeInTheDocument();
    expect(
      within(zoneGroupTwoRetail).getByText('400 - Inactive')
    ).toBeInTheDocument();
  });

  test('Mode Retail Popover renders on hover', async () => {
    let skuRowOne = screen.getByText('12345').closest('tr');
    expect(within(skuRowOne).getAllByText('$10.00').length).toEqual(3); // 1 Sku-level, 2 ZoneGroup level.
    let skuLevelRetail = within(skuRowOne)
      .getAllByText('$10.00')[0]
      .closest('span');
    let zoneGroupOneRetail = within(skuRowOne)
      .getAllByText('$10.00')[1]
      .closest('td');
    let zoneGroupTwoRetail = within(skuRowOne)
      .getAllByText('$10.00')[2]
      .closest('td');

    expect(screen.queryByText('300 - Out of Season')).not.toBeInTheDocument();

    fireEvent.mouseEnter(skuLevelRetail);

    await waitFor(() => {
      expect(screen.getByText('300 - Out Season')).toBeInTheDocument();
    });
  });
});
