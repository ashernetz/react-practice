import React from 'react';
import { fireEvent, render, screen, within } from '@testing-library/react';
import '@testing-library/jest-dom';
import EditPriceFilters from './EditPriceFilters';
import { act } from 'react-dom/test-utils';
import { when } from 'jest-when';
import axios from 'axios';
import SkuContext from '../../../../context/SkuContext';
import { SkuDescriptionProvider } from '../Context/SkuDescriptionProvider';
import EditPricePage from '../EditPricePage';
import {
  currentRetails,
  currentZoneGroupCPI,
  currentZoneGroupRetails,
  skuData,
  zoneGroups,
} from '../__fixtures__/editPriceFiltersData';

jest.mock('axios');

function setupMocks() {
  when(axios.get)
    .calledWith(
      `/api/multi-sku/zoneMultiplierGroups?zoneMultiplierGroupId=${zoneGroups.data.id}`
    )
    .mockResolvedValue(zoneGroups);
  when(axios.post)
    .calledWith(`/api/dataConnect/modeRetailStatus`, expect.anything())
    .mockResolvedValue(currentRetails);
  when(axios.post)
    .calledWith(`/api/dataConnect/zoneGroupModeRetailStatus`, expect.anything())
    .mockResolvedValue(currentZoneGroupRetails);
  when(axios.post)
    .calledWith(`/api/dataConnect/sku/dcs-description`, expect.anything())
    .mockResolvedValue(skuData);
  when(axios.post)
    .calledWith(`/api/dataconnect/zone-level-current-cpi`, expect.anything())
    .mockResolvedValue(currentZoneGroupCPI);
}

async function renderEPP() {
  await act(async () => {
    const { container } = render(
      <SkuContext.Provider
        value={{
          subDeptDataMap: {
            '0013': {
              name: '001-001',
              deptClassMap: new Map(Object.entries({ 86: [45] })),
              description: 'Test Sub-Dept',
              longDescription: 'Long test description',
            },
          },
          updateShowDimmer: jest.fn(),
        }}
      >
        <SkuDescriptionProvider>
          <EditPricePage
            userId={'MC62YE'}
            userEmail={'Michelle_Cox_Bradford@homedepot.com'}
            backArrowClick={jest.fn()}
            zoneMultiplierGroupId={'3fa85f64-5717-4562-b3fc-2c963f66afa6'}
            skuGroupName={'Test Group'}
            skuList={[12345, 23456, 34567]}
          />
        </SkuDescriptionProvider>
      </SkuContext.Provider>
    );
  });
}

function getFilterMenu() {
  return screen.getByRole('tree').closest('div').parentNode.parentNode;
}

function getFilterMenuItems() {
  let val = getFilterMenu().querySelectorAll(
    '.ant-tree-list .ant-tree-treenode'
  );
  return getFilterMenu().querySelectorAll('.ant-tree-list .ant-tree-treenode');
}

async function clickFilterOk() {
  let filterMenu = getFilterMenu();
  let okButton = within(filterMenu).getByText(/OK/).closest('button');
  await act(async () => {
    fireEvent.click(okButton);
  });
}

async function clickFilterItem(itemRegex) {
  let filterMenu = getFilterMenu();
  console.log('itemRegex', itemRegex);
  let filterItem = within(filterMenu).getByText(itemRegex).closest('span');
  await act(async () => {
    fireEvent.click(filterItem);
  });
}

async function clickColumnFilterButton(columnRegex, index) {
  let columnHeader = screen.queryAllByText(columnRegex)[index].closest('th');
  let filterButton = within(columnHeader).getByRole('button', { hidden: true });
  await act(async () => {
    fireEvent.click(filterButton);
  });
}

describe('EditPriceFilters', () => {
  beforeEach(async () => {
    setupMocks();
    await renderEPP();
  });

  jest.setTimeout(30000);
  test('Mode Retail Filters correctly', async () => {
    await clickColumnFilterButton(/Mode Retail$/m, 0); // Sku Level
    expect(getFilterMenuItems().length).toEqual(3); // $10, $20, and NA

    await clickFilterItem(/\$10.00/);
    await clickFilterOk();

    expect(screen.queryAllByText('$10.00').length).toEqual(4); // 1 Sku-level, 2 ZoneGroup level, 1 filter.
    expect(screen.queryAllByText('$20.00').length).toEqual(0); // Nothing in the table or filters.
  });

  test('ZoneGroup Mode Retail Filters correctly', async () => {
    await clickColumnFilterButton(/Mode Retail$/m, 2); // 1st ZoneGroup

    expect(getFilterMenuItems().length).toEqual(3); // $10, $20, and NA
    await clickFilterItem(/\$10.00/);
    await clickFilterOk();

    expect(screen.queryAllByText('$10.00').length).toEqual(4); // 1 Sku-level, 2 ZoneGroup level, 1 filter.
    expect(screen.queryAllByText('$20.00').length).toEqual(0); // Nothing in the table or filters.
  });

  test('CPI Filters duplicates correctly', async () => {
    await clickColumnFilterButton(/LOW$/m, 1); // 1st ZoneGroup Lowes CPI

    expect(getFilterMenuItems().length).toEqual(2); // 0.90, 0.80, and NA

    await clickFilterItem(/0\.90/);
    await clickFilterOk();

    let skuRowOne = screen.getByText('12345').closest('tr');
    expect(skuRowOne).toBeInTheDocument();
    expect(skuRowOne).toBeVisible();

    let skuRowTwo = screen.queryByText('23456');
    expect(skuRowTwo).toBeNull();
    let skuRowThree = screen.queryByText('34567');
    expect(skuRowThree).toBeNull();
  });

  test('should filter custom columns', () => {
    //inputs
    const skuList = [
      193801, 193798, 193828, 193836, 372764, 372813, 373226, 373249, 649323,
      649337,
    ];

    const columnKey = 'new-1684248303330';

    const customColumnData = {
      'new-1684248303330': {
        193798: 'test1',
        193801: 'test2',
        193828: 'test3',
      },
    };

    //expected output
    const filterOutput = [
      {
        text: 'test1',
        value: 'test1',
      },
      {
        text: 'test2',
        value: 'test2',
      },
      {
        text: 'test3',
        value: 'test3',
      },
    ];

    //call function
    const filterArray = EditPriceFilters.customColumnsFilter(
      skuList,
      columnKey,
      customColumnData
    );

    expect(filterArray).toEqual(filterOutput);
  });

  describe('current/blended cost filters', () => {
    const costs = {
      100: {
        1: {
          1: {
            blendedCost: 50,
            firstCost: 40,
          },
          2: {
            blendedCost: 30,
            firstCost: 20,
          },
        },
        2: {
          3: {
            blendedCost: 70,
            firstCost: 60,
          },
        },
      },
    };

    test('createOnFilterCostFunction filters properly', () => {
      const filterFunc = EditPriceFilters.createOnFilterCostFunction(
        costs,
        1,
        'blendedCost'
      );
      const record = { skuNumber: 100, market: 1 };

      expect(filterFunc(50, record)).toBeTruthy();
      expect(filterFunc(40, record)).toBeFalsy();
      expect(filterFunc('--', record)).toBeFalsy();
    });

    test('createOnFilterCostFunction returns true for non-existing cost when value is --', () => {
      const filterFunc = EditPriceFilters.createOnFilterCostFunction(
        costs,
        1,
        'nonExistingCost'
      );
      const record = { skuNumber: 100, market: 1 };

      expect(filterFunc('--', record)).toBeTruthy();
    });

    test('costColumnFilter generates filter values correctly', () => {
      const filterValues = EditPriceFilters.costColumnFilter(
        costs,
        '1',
        'blendedCost'
      );

      expect(filterValues).toEqual([
        { text: '$0.50', value: 50 },
        { text: '--', value: '--' },
      ]);
    });
  });
});
