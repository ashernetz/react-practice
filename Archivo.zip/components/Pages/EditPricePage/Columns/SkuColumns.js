import EditPriceFilters from './EditPriceFilters';
import EditPriceSorters from './EditPriceSorters';
import { UXSpin } from '../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';
import CompUtil from '../../../Utils/CompUtil';
import { EditPriceInput, PLSAnchor, StringCell } from './ColumnComponents';
import { Button, Layout, Tooltip, Typography } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';
import ModeRetailStatus from '../Components/ModeRetailStatus';
import React from 'react';
import SkuDescriptionCell from '../CellComponents/SkuDescriptionCell';
import { TableTabKeys } from '../Constants/ColumnConstants';

const { Text } = Typography;
const { Content } = Layout;

const anchorIconColumn = (anchorSku) => {
  return {
    title: '',
    align: 'left',
    className: 'anchor-parent-header-placeholder',
    children: [
      {
        title: '',
        dataIndex: 'skuNumber',
        className: 'anchor-icon-column',
        width: 25,
        fixed: 'left',
        onCell: (record, index) => {
          return {
            style: {
              background: record.skuNumber === anchorSku ? '#f0f0f0' : '',
            },
          };
        },
        render(text, row) {
          return row.skuNumber === anchorSku ? <PLSAnchor /> : '';
        },
      },
    ],
  };
};

const skuColumn = (filteredSkuList, anchorSku) => {
  const uniqueSkusList = [...new Set(filteredSkuList)];

  return {
    title: titleFormatter('SKU'),
    dataIndex: 'skuNumber',
    className: 'sku-column',
    width: 125,
    filterMode: 'tree',
    filters: uniqueSkusList.map((sku) => {
      return { text: sku, value: sku };
    }),
    onFilter: (value, record) => record.skuNumber === value,
    fixed: 'left',
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortWithDataIndex(a, b, 'skuNumber'),
    onCell: (record, index) => {
      return {
        style: {
          background: record.skuNumber === anchorSku ? '#f0f0f0' : '',
        },
      };
    },
    render(text, row) {
      return <div>{row.skuNumber}</div>;
    },
  };
};

const skuDescriptionColumn = (
  filteredSkuList,
  skuDescriptions,
  anchorSku,
  selectedTableTab
) => {
  return {
    title: titleFormatter('Description'),
    key: 'Description',
    dataIndex: '',
    width: 325,
    filters: EditPriceFilters.customSkuFilter(
      filteredSkuList,
      skuDescriptions.data
    ),
    onFilter: (value, record) =>
      skuDescriptions.data[record.skuNumber] === value,
    filterMode: 'tree',
    fixed: 'left',
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customStringSorter(
        skuDescriptions.data[a.skuNumber],
        skuDescriptions.data[b.skuNumber]
      ),
    onCell: (record, index) => {
      return {
        style: {
          background: record.skuNumber === anchorSku ? '#f0f0f0' : '',
        },
      };
    },
    render: (text, row) => (
      <SkuDescriptionCell
        sku={row.skuNumber}
        description={skuDescriptions.data[row.skuNumber]}
      />
    ),
  };
};

const dcsColumn = (filteredSkuList, skusDcs) => {
  return {
    key: 'DCS',
    title: titleFormatter('DCS'),
    dataIndex: '',
    width: 150,
    filterMode: 'tree',
    filters: EditPriceFilters.customSkuFilter(filteredSkuList, skusDcs.data),
    onFilter: (value, record) => skusDcs.data[record.skuNumber] === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customStringSorter(
        skusDcs.data[a.skuNumber],
        skusDcs.data[b.skuNumber]
      ),
    render: (text, row) =>
      (skusDcs.data[row.skuNumber] || '').replace(/-+/g, ' | '),
  };
};

const muMdColumn = (filteredSkuList, skuMuMd, loadingMuMd) => {
  return {
    key: 'SkuMuMd',
    title: titleFormatter('Net MU/MD'),
    dataIndex: '',
    width: 175,
    filterMode: 'tree',
    filters: EditPriceFilters.customMuMdFilter(
      filteredSkuList.map((sku) => skuMuMd[sku])
    ),
    onFilter: (value, record) =>
      (skuMuMd[record.skuNumber] ? skuMuMd[record.skuNumber] : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) => EditPriceSorters.sortNumbers(a, b, skuMuMd),
    render: (text, row) =>
      loadingMuMd ? (
        <UXSpin />
      ) : skuMuMd && skuMuMd[row.skuNumber] ? (
        CompUtil.formatMuMdPrice(skuMuMd[row.skuNumber], true)
      ) : (
        '--'
      ),
  };
};

const imuColumn = (filteredSkuList, netSkuImu) => {
  return {
    key: 'SkuIMU',
    title: titleFormatter('Net IMU'),
    dataIndex: '',
    width: 150,
    filterMode: 'tree',
    filters: EditPriceFilters.customPercentFormatFilter(
      filteredSkuList,
      netSkuImu.data,
      'imu'
    ),
    onFilter: (value, record) =>
      (netSkuImu.data[record.skuNumber]
        ? netSkuImu.data[record.skuNumber].imu
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortNoDataIndex(a, b, 'imu', netSkuImu.data),
    render: (text, row) => {
      let imu =
        netSkuImu.data[row.skuNumber] && netSkuImu.data[row.skuNumber].imu;
      return (
        <StringCell
          value={
            imu &&
            !isNaN(imu) &&
            Math.round((imu + Number.EPSILON) * 100) / 100 + '%'
          }
          loading={netSkuImu.isLoading}
        />
      );
    },
  };
};

const projectedImuColumn = (
  filteredSkuList,
  projectedNetSkuImu,
  zoneMultiplierGroupData,
  newRetails
) => {
  return {
    key: 'SkuProjectedMuMd',
    title: titleFormatter('New Net IMU'),
    dataIndex: '',
    width: 190,
    filterMode: 'tree',
    filters: EditPriceFilters.customPercentFormatFilter(
      filteredSkuList,
      projectedNetSkuImu.data,
      'imu'
    ),
    onFilter: (value, record) =>
      (projectedNetSkuImu.data[record.skuNumber]
        ? projectedNetSkuImu.data[record.skuNumber].imu
        : 'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortNoDataIndex(
        a,
        b,
        'imu',
        projectedNetSkuImu.data
      ),
    render: (text, row) => {
      let imu =
        zoneMultiplierGroupData.zoneGroups &&
        zoneMultiplierGroupData.zoneGroups.some(
          (zoneGroup) =>
            newRetails[row.skuNumber] &&
            newRetails[row.skuNumber][zoneGroup.id] &&
            newRetails[row.skuNumber][zoneGroup.id].retail
        ) &&
        projectedNetSkuImu.data[row.skuNumber] &&
        projectedNetSkuImu.data[row.skuNumber].imu;
      return (
        <StringCell
          value={
            imu &&
            !isNaN(imu) &&
            Math.round((imu + Number.EPSILON) * 100) / 100 + '%'
          }
          loading={projectedNetSkuImu.isLoading}
        />
      );
    },
  };
};

const invoiceCostColumn = (filteredSkuList, skuInvoiceCost) => {
  return {
    key: 'SkuInvoiceCost',
    title: titleFormatter('Inv. Cost'),
    dataIndex: '',
    filters: EditPriceFilters.customPriceFormatFilter(
      filteredSkuList,
      skuInvoiceCost.data
    ),
    width: 130,
    filterMode: 'tree',
    onFilter: (value, record) =>
      skuInvoiceCost.data[record.skuNumber] === value ||
      (isNaN(skuInvoiceCost.data[record.skuNumber]) && isNaN(value)),
    showSorterTooltip: false,
    sorter: (a, b) => EditPriceSorters.sortNumbers(a, b, skuInvoiceCost.data),
    render: (text, row) => (
      <Text>
        {skuInvoiceCost.isLoading ? (
          <UXSpin />
        ) : !skuInvoiceCost.data[row.skuNumber] ? (
          '--'
        ) : (
          '$' + CompUtil.formatPrice(skuInvoiceCost.data[row.skuNumber])
        )}
      </Text>
    ),
  };
};

const newCostColumn = (newCosts, onNewCostUpdate, setNewCosts, onPaste) => {
  return {
    key: 'SkuNewCost',
    title: (
      <Text>
        New Cost
        <Button
          className="clear-new-cost"
          size={'small'}
          type={'text'}
          icon={<DeleteOutlined />}
          onClick={() => {
            setNewCosts({});
          }}
        />
      </Text>
    ),
    dataIndex: '',
    width: 120,
    render: (text, row) => (
      <EditPriceInput
        pasteFunction={(e) => onPaste(e, 'cost')}
        retail={newCosts[row.skuNumber] ? newCosts[row.skuNumber] : null}
        onRetailUpdate={(newCost) => onNewCostUpdate(row.skuNumber, newCost)}
      />
    ),
  };
};

const modeRetailColumn = (filteredSkuList, modeRetailStatus) => {
  return {
    key: 'SkuModeRetail',
    title: titleFormatter('Mode Retail'),
    dataIndex: '',
    width: 150,
    filterMode: 'tree',
    filters: EditPriceFilters.customModeRetailFilter(
      filteredSkuList,
      modeRetailStatus.data,
      'retail'
    ),
    onFilter: (value, record) =>
      ((modeRetailStatus.data[record.skuNumber] &&
        modeRetailStatus.data[record.skuNumber][0].retail) ||
        'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortRetailStatus(
        a,
        b,
        'retail',
        modeRetailStatus.data
      ),
    render: (text, row) => (
      <ModeRetailStatus
        modeRetailStatuses={modeRetailStatus.data[row.skuNumber]}
        loading={modeRetailStatus.isLoading}
      />
    ),
  };
};

const modeRetailStatusColumn = (filteredSkuList, modeRetailStatus) => {
  return {
    key: 'SkuModeRetailStatus',
    title: titleFormatter('Mode Retail Status'),
    dataIndex: '',
    width: 200,
    filterMode: 'tree',
    filters: EditPriceFilters.customRetailStatusFilter(
      filteredSkuList,
      modeRetailStatus.data,
      'completeStatus'
    ),
    onFilter: (value, record) =>
      ((modeRetailStatus.data[record.skuNumber] &&
        modeRetailStatus.data[record.skuNumber][0].completeStatus) ||
        'NA') === value,
    showSorterTooltip: false,
    sorter: (a, b) =>
      EditPriceSorters.customSortRetailStatus(
        a,
        b,
        'statusCode',
        modeRetailStatus.data
      ),
    render: (text, row) => {
      let status =
        modeRetailStatus.data[row.skuNumber] &&
        modeRetailStatus.data[row.skuNumber][0]['completeStatus'];
      return <StringCell value={status} loading={modeRetailStatus.isLoading} />;
    },
  };
};

const titleFormatter = (input) => (
  <Text className={'child-title-formatter'}>{input}</Text>
);

export {
  anchorIconColumn,
  skuColumn,
  skuDescriptionColumn,
  dcsColumn,
  muMdColumn,
  imuColumn,
  projectedImuColumn,
  invoiceCostColumn,
  newCostColumn,
  modeRetailColumn,
  modeRetailStatusColumn,
};
