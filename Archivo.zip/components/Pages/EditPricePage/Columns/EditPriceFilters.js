import CompUtil from '../../../Utils/CompUtil';
import { ColumnKeys } from '../Constants/ColumnConstants';

export default class EditPriceFilters {
  /**
   * Makes the text and values that are displayed in the ant filter components of the EditPricePage.  This custom filter is formatted to work on Strings
   * @param dataObject name of the state variable that holds the required dataPoint that needs to be displayed
   * @param dataPoint name of the property in the dataObject
   * @returns {{text: *, value: *}[]}
   */
  static customFilter(dataObject, dataPoint) {
    if (dataObject) {
      let items = Object.values(dataObject).map((obj) => obj[dataPoint]);
      return this.redundantFormatFilters(items);
    }
  }

  static customSkuFilter(skuList, dataObject) {
    if (dataObject) {
      let items = skuList.map((sku) => dataObject[sku]);
      return this.redundantFormatFilters(items);
    }
  }

  static customColumnsFilter(skuList, key, customColumnData) {
    if (customColumnData) {
      let items = skuList.map(
        (sku) => customColumnData[key] && customColumnData[key][sku]
      );
      return this.redundantFormatFiltersCustomColumns(items);
    }

    return null;
  }

  /**
   * Makes the text and values that are displayed in the ant filter components of the EditPricePage.  This custom filter is formatted to work on prices (ex: $12.34)
   * @param skuList list of skus to pull values of.
   * @param dataObject name of the state variable that holds the required dataPoint that needs to be displayed
   * @returns {{text: string|number, value: *}[]}
   */
  static customPriceFormatFilter(skuList, dataObject) {
    if (dataObject) {
      let items = skuList.map((sku) => dataObject[sku]);
      return this.redundantFormatFilters(items, (item) =>
        isNaN(item) ? 'NA' : '$' + CompUtil.formatPrice(item, false)
      );
    }
  }

  /**
   * Makes the text and values that are displayed in the ant filter components of the EditPricePage.  This custom filter is formatted to work on percentages (ex: 12.34%)
   * @param skuList list of skus to pull values of.
   * @param dataObject name of the state variable that holds the required dataPoint that needs to be displayed
   * @param dataPoint name of the property in the dataObject
   * @returns {{text: string, value: *}[]}
   */
  static customPercentFormatFilter(skuList, dataObject, dataPoint) {
    if (dataObject) {
      let items = skuList.map(
        (sku) => (dataObject[sku] && dataObject[sku][dataPoint]) || 'NA'
      );
      return this.redundantFormatFilters(items, (item) =>
        isNaN(item)
          ? 'NA'
          : CompUtil.formatCompData(
              Math.round((item + Number.EPSILON) * 100) / 100
            )
      );
    }
  }

  static customMuMdFilter(muMdList) {
    if (muMdList.length > 0) {
      let items = muMdList.map((item) => item || 'NA');
      return this.redundantFormatFilters(items, (item) =>
        item ? CompUtil.formatMuMdPrice(item, true) : 'NA'
      );
    }
  }

  static customModeRetailFilter(skuList, dataObject, dataPoint) {
    if (dataObject) {
      let items = skuList.map(
        (sku) =>
          dataObject[sku] &&
          dataObject[sku][0] &&
          parseFloat(dataObject[sku][0][dataPoint])
      );
      return this.redundantFormatFilters(items, (item) =>
        isNaN(item) ? 'NA' : '$' + CompUtil.formatPrice(item, true)
      );
    }
  }

  static customRetailStatusFilter(skuList, dataObject, dataPoint) {
    if (dataObject) {
      let items = skuList.map(
        (sku) =>
          dataObject[sku] && dataObject[sku][0] && dataObject[sku][0][dataPoint]
      );
      return this.redundantFormatFilters(items);
    }
  }

  static redundantFormatFilters(itemList, formatFunc = undefined) {
    let filters = new Set(itemList);
    let filterArray = [...filters].sort((a, b) =>
      (a || '').toString().localeCompare((b || '').toString(), 'en', {
        numeric: true,
        sensitivity: 'base',
      })
    );

    return filterArray.map((obj) => ({
      text: obj ? (formatFunc ? formatFunc(obj) : obj) : 'NA',
      value: obj ? obj : 'NA',
    }));
  }

  static redundantFormatFiltersCustomColumns(itemList, formatFunc = undefined) {
    let filters = new Set(itemList);
    let filterArray = [...filters].sort((a, b) =>
      (a || '').toString().localeCompare((b || '').toString(), 'en', {
        numeric: true,
        sensitivity: 'base',
      })
    );

    return filterArray
      .filter((val) => val !== undefined && val !== '')
      .map((obj) => ({
        text: obj && (formatFunc ? formatFunc(obj) : obj),
        value: obj,
      }));
  }

  static getSkuMarketColumnFilterOptions(skuList, dataPoint, vendorData) {
    const { selectedVendor, vendorGroupData } = vendorData;
    let uniqueMarkets = new Set();
    skuList.forEach((sku) => {
      Object.keys(vendorGroupData[sku]).forEach((market) => {
        const marketData = vendorGroupData[sku] && vendorGroupData[sku][market];
        if (marketData && marketData[selectedVendor.vendorNumber]) {
          uniqueMarkets.add(marketData[selectedVendor.vendorNumber][dataPoint]);
        }
      });
    });
    return this.redundantFormatFilters(Array.from(uniqueMarkets));
  }

  static costColumnFilter(costs = {}, selectedVendor = '', costType) {
    let noCostExists = false;

    const filterValues = Object.keys(costs).reduce((values, skuNumber) => {
      Object.keys(costs[skuNumber]).forEach((market) => {
        Object.keys(costs[skuNumber][market]).forEach((vendor) => {
          if (vendor === selectedVendor.toString()) {
            const cost = costs[skuNumber][market][vendor][costType];
            values.add(cost);
          } else {
            noCostExists = true;
          }
        });
      });
      return values;
    }, new Set());

    if (noCostExists) {
      filterValues.add('--');
    }

    return Array.from(filterValues).map((value) => ({
      text: value === '--' ? value : '$' + CompUtil.formatPrice(value, true),
      value: value,
    }));
  }

  static createOnFilterCostFunction =
    (costs, vendorNumber, costType) => (value, record) => {
      const { skuNumber, market } = record;

      if (value === '--') {
        return (
          !costs[skuNumber] ||
          !costs[skuNumber][market] ||
          !costs[skuNumber][market][vendorNumber] ||
          !costs[skuNumber][market][vendorNumber][costType]
        );
      }

      if (
        costs[skuNumber] &&
        costs[skuNumber][market] &&
        costs[skuNumber][market][vendorNumber]
      ) {
        const cost = costs[skuNumber][market][vendorNumber][costType];

        return cost === value;
      }

      return false;
    };
}
