import {
  CompetitorGroupParentColumnTitle,
  NoDataParentColumnTitle,
  ParentTitle,
  ZoneGroupParentColumnTitle,
} from '../Components/EditPriceTable/ColumnTitleComponents/ColumnTitleComponents';
import React from 'react';
import {
  ColumnKeys,
  ZoneGroupColumnTemplates,
} from '../Constants/ColumnConstants';
import _ from 'lodash';
import { CompetitorNameAndIdList } from '../../../../constants/typecode';

export default class EditPriceColumnCreation {
  static getZebraStripeClass = (zoneMultiplierGroupData, index) => {
    if (
      Object.values(zoneMultiplierGroupData['zoneGroups']).length > 1 &&
      index % 2 === 0
    ) {
      return 'dynamic-column-dark';
    } else {
      return 'dynamic-column-light';
    }
  };
  static checkIfColumnDataIsLoading = (
    zoneMultiplierGroupData,
    zoneGroupCompetitorPrice,
    zoneGroupCurrentCpi
  ) => {
    return (
      _.isEmpty(zoneMultiplierGroupData) &&
      zoneGroupCompetitorPrice.isLoading &&
      zoneGroupCurrentCpi.isLoading
    );
  };
  static checkIfCompetitorCpiDataExists = (
    competitor,
    zoneGroupId,
    filteredSkuList,
    zoneGroupCurrentCpi,
    zoneGroupCompetitorPrice
  ) => {
    let competitorDataExists = filteredSkuList.some(
      (sku) =>
        (zoneGroupCurrentCpi &&
          zoneGroupCurrentCpi.data[sku] &&
          zoneGroupCurrentCpi.data[sku][zoneGroupId] &&
          zoneGroupCurrentCpi.data[sku][zoneGroupId][
            competitor.competitorId
          ]) ||
        (zoneGroupCompetitorPrice &&
          zoneGroupCompetitorPrice.data[sku] &&
          zoneGroupCompetitorPrice.data[sku][zoneGroupId] &&
          zoneGroupCompetitorPrice.data[sku][zoneGroupId][
            competitor.competitorId
          ])
    );
    return (
      competitorDataExists ||
      zoneGroupCurrentCpi.isLoading ||
      zoneGroupCompetitorPrice.isLoading
    );
  };

  static createZoneGroupTemplate = (
    templateKey,
    zoneGroup,
    className,
    filteredSkuList,
    zoneGroupCurrentCpi,
    zoneGroupCompetitorPrice
  ) => {
    const parentKey = `${templateKey}-${zoneGroup.id}`;
    return {
      colKey: parentKey,
      templateKey,
      zoneGroup,
      className,
      name: zoneGroup.name,
      children: this.createZoneGroupChildren(
        parentKey,
        templateKey,
        zoneGroup,
        className,
        filteredSkuList,
        zoneGroupCurrentCpi,
        zoneGroupCompetitorPrice
      ),
    };
  };

  static createZoneGroupCompetitorTemplate = (
    templateKey,
    zoneGroup,
    className,
    filteredSkuList,
    zoneGroupCurrentCpi,
    zoneGroupCompetitorPrice
  ) => {
    const parentKey = `${templateKey}-${zoneGroup.id}`;
    return {
      colKey: parentKey,
      templateKey,
      zoneGroup,
      className,
      name: `${zoneGroup.name} Competitive`,
      children: this.determineCompetitorChildren(
        ZoneGroupColumnTemplates[templateKey],
        parentKey,
        zoneGroup.id,
        className,
        filteredSkuList,
        zoneGroupCurrentCpi,
        zoneGroupCompetitorPrice
      ),
    };
  };

  static createZoneGroupChildren = (
    parentKey,
    parentTemplateKey,
    zoneGroup,
    className
  ) => {
    return ZoneGroupColumnTemplates[parentTemplateKey].map((child) => {
      return {
        ...child,
        ...{
          colKey: `${parentKey}-${child.templateKey}`,
          parentKey,
          className,
        },
      };
    });
  };

  static determineCompetitorChildren = (
    childTemplates,
    parentKey,
    zoneGroupId,
    className,
    filteredSkuList,
    zoneGroupCurrentCpi,
    zoneGroupCompetitorPrice
  ) => {
    let children = CompetitorNameAndIdList.flatMap((competitor) => {
      if (
        this.checkIfCompetitorCpiDataExists(
          competitor,
          zoneGroupId,
          filteredSkuList,
          zoneGroupCurrentCpi,
          zoneGroupCompetitorPrice
        )
      ) {
        return childTemplates.map((template) => {
          return {
            templateKey: template.templateKey,
            colKey: `${parentKey}-${competitor.competitorId}-${template.templateKey}`,
            name: this.getCompetitorChildColumnName(
              template.templateKey,
              competitor.competitorName
            ),
            competitor,
            className,
            parentKey,
          };
        });
      }
      return [];
    });

    if (!children.length) {
      children = [
        {
          templateKey: ColumnKeys.COMP_ZG_NO_DATA_COL,
          colKey: `${parentKey}-noDataColumn`,
        },
      ];
    }

    return children;
  };

  static getCompetitorChildColumnName(templateKey, competitorName) {
    switch (templateKey) {
      case ColumnKeys.COMP_ZG_CUR_CPI_COL:
        return competitorName;
      case ColumnKeys.COMP_ZG_NEW_CPI_COL:
        return `New ${competitorName}`;
      case ColumnKeys.COMP_ZG_PRICE_COL:
        return `${competitorName}$`;
      default:
        return '';
    }
  }

  static getSkuInformationParentConfigTemplate = () => {
    return {
      title: <ParentTitle input={ColumnKeys.SKU_INFO_PARENT_COL} />,
      key: ColumnKeys.SKU_INFO_PARENT_COL,
      align: 'left',
      className: 'custom-column-group-border',
    };
  };

  static getLineStructureParentConfigTemplate = () => {
    return {
      title: <ParentTitle input={ColumnKeys.LINE_STR_MET_PARENT_COL} />,
      key: ColumnKeys.LINE_STR_MET_PARENT_COL,
      align: 'left',
      width: 450,
      className: 'custom-column-group-border',
    };
  };

  static getSkuMarketParentConfigTemplate = () => {
    return {
      title: <ParentTitle input={ColumnKeys.SKU_MKT_PARENT_COL} />,
      key: ColumnKeys.SKU_MKT_PARENT_COL,
      align: 'left',
      className: 'custom-column-group-border',
    };
  };

  static getZoneGroupParentConfigTemplate = (
    colKey,
    zoneGroup,
    columnExpandClickHandler,
    collapsedZoneGroups
  ) => {
    return {
      key: colKey,
      title: (
        <ZoneGroupParentColumnTitle
          colKey={colKey}
          zoneGroup={zoneGroup}
          columnExpandClickHandler={columnExpandClickHandler}
          collapsedZoneGroups={collapsedZoneGroups}
        />
      ),
      align: 'left',
      className: 'custom-column-group-border',
    };
  };

  static getCompetitiveParentConfigTemplate = (
    colKey,
    zoneGroup,
    columnTemplates,
    columnExpandClickHandler,
    collapsedZoneGroups
  ) => {
    return {
      key: colKey,
      title: this.getCompetitorGroupParentTitle(
        colKey,
        zoneGroup,
        columnTemplates,
        columnExpandClickHandler,
        collapsedZoneGroups
      ),
      align: 'left',
      className: 'custom-column-group-border',
    };
  };

  static getCompetitorGroupParentTitle = (
    colKey,
    zoneGroup,
    columnTemplates,
    columnExpandClickHandler,
    collapsedZoneGroups
  ) => {
    const matchingParent = columnTemplates.find((el) => el.colKey === colKey);
    if (
      matchingParent &&
      matchingParent.children &&
      matchingParent.children.length > 0
    ) {
      return (
        <CompetitorGroupParentColumnTitle
          colKey={colKey}
          zoneGroup={zoneGroup}
          columnExpandClickHandler={columnExpandClickHandler}
          collapsedZoneGroups={collapsedZoneGroups}
        />
      );
    } else {
      return <NoDataParentColumnTitle zoneGroup={zoneGroup} />;
    }
  };
}
