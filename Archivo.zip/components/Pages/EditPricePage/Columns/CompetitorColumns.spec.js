import React from 'react';
import { render, screen } from '@testing-library/react';
import { CompetitorPriceCell, CpiCell } from './CompetitorColumns';
import '@testing-library/jest-dom';

describe('CompetitorColumns', () => {
  test('render competitor price column', () => {
    render(<CompetitorPriceCell competitorPrice={2} loading={false} />);
    expect(screen.getByText('$0.02')).toBeInTheDocument();
  });

  test('render red current cpi', () => {
    render(<CpiCell cpi={1.0112345} loading={false} />);
    expect(screen.getByText('1.01')).toBeInTheDocument();
    expect(screen.getByText('1.01')).toHaveClass('ant-typography red-cpi-text');
  });

  test('render green current cpi', () => {
    render(<CpiCell cpi={0.9812345} loading={false} />);
    expect(screen.getByText('0.98')).toBeInTheDocument();
    expect(screen.getByText('0.98')).toHaveClass(
      'ant-typography green-cpi-text'
    );
  });

  test('render null current cpi', () => {
    render(<CpiCell cpi={null} loading={false} />);
    expect(screen.getByText('--')).toBeInTheDocument();
  });
});
