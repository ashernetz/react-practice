import SingleAndMultiSkuServices from '../../../../services/SingleAndMultiSkuServices';

export default class EditPricePageHeaderUtil {
  static editZoneGroups(zoneMultiplierGroupData) {
    let zoneGroupData = {};
    //need to add updated weight into this zoneGroupData object
    zoneMultiplierGroupData.length > 0 &&
      zoneMultiplierGroupData.forEach((zoneGroupObj) => {
        zoneGroupData[zoneGroupObj.id] =
          {
            id: zoneGroupObj.id,
            name: zoneGroupObj.name,
            weight: zoneGroupObj.weight,
            zones: zoneGroupObj.zones.map((zoneObj) => zoneObj.userDefZoneId),
          } || {};
      });
    Object.keys(zoneGroupData).map((eachObj) => {
      SingleAndMultiSkuServices.updateGroupMultipliers(
        zoneGroupData[eachObj]
      ).then((response) => {
        let responseData = response.data;
      });
    });
  }

  static getSkuToSkuRulesBySkuList = (
    skuList,
    setAnchorSku,
    setRules,
    setLineStructureId,
    toggleSkuToSkuRulesLoading
  ) => {
    toggleSkuToSkuRulesLoading(true);
    SingleAndMultiSkuServices.fetchSkuToSkuRules(skuList)
      .then((response) => {
        let responseData = response.data;
        setAnchorSku(responseData[0].anchorSku);
        setLineStructureId(responseData[0].id);
        setRules(responseData[0].rules);
      })
      .catch((err) => {
        console.log(err);
        setRules([]);
      })
      .finally(() => {
        toggleSkuToSkuRulesLoading(false);
      });
  };

  static editSkuToSkuRules = (id, rules, setIsLoading) => {
    setIsLoading(true);
    SingleAndMultiSkuServices.fetchSkuToSkuRuleEdit(id, rules)
      .then((response) => {
        let responseData = response.data;
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  static getPriceEndingRulesBySkuList = (
    skuList,
    setPriceEndingRules,
    togglePriceEndingRulesLoading
  ) => {
    togglePriceEndingRulesLoading(true);
    SingleAndMultiSkuServices.fetchPriceEndingRulesBySku(skuList)
      .then((response) => {
        let responseData = response.data;
        skuList.forEach((sku) => {
          if (!responseData.find((rule) => rule.sku === sku)) {
            responseData.push({ sku: sku, ruleType: 'NONE', endings: [] });
          }
        });
        setPriceEndingRules(responseData);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        togglePriceEndingRulesLoading(false);
      });
  };

  static updatePriceEndingRules = (
    endingRules,
    togglePriceEndingRulesLoading
  ) => {
    togglePriceEndingRulesLoading(true);
    SingleAndMultiSkuServices.updatePriceEndingRules(endingRules)
      .then(() => {})
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        togglePriceEndingRulesLoading(false);
      });
  };
}
