import React, { useState } from 'react';
import { PageHeader, Row, Col, Button, Drawer, Space } from 'antd';
import './EditPricePageHeader.scss';
import HeaderCrumbs from '../../../GlobalComponents/HeaderCrumbs/HeaderCrumbs';
import { SettingFilled, ShareAltOutlined } from '@ant-design/icons';
import LinksPopout from './PopoutComponents/LinksPopout';
import SkuToSkuPopout from './PopoutComponents/SkuToSkuPopout';
import ZoneMultiplierPopout from './PopoutComponents/ZoneMultiplierPopout';
import { sidebarState } from '../../../../constants/eppSidebarConstants';
import PriceEndingRulesPopout from './PopoutComponents/PriceEndingRulesPopout';
import PricingSkuGroupPopout from './PopoutComponents/PricingSkuGroupPopout';
import ColumnSettingsPopout from './PopoutComponents/ColumnSettingsPopout/ColumnSettingsPopout';
import { encryptSharedCode } from '../../../Helper/ShareCode';
import ShareSessionModal from './ShareSessionModal';
import TargetBasedPopout from './PopoutComponents/TargetBasedRulesPopout/TargetBasedRulesPopout';

const EditPricePageHeader = (props) => {
  const {
    skuList,
    anchorSku,
    zoneMultiplierGroupData: { subclass, id, zoneGroups },
    userId,
    skuGroupName,
    skuGroupId,
    columnTemplates,
    setColumnTemplates,
    customColumns,
    initialCosts: costs,
    initialRetails: retails,
    zoneGroupCompetitorPrice,
    zoneMultiplierGroupData,
    zoneGroupCurrentCpi,
    hiddenColumns,
    setHiddenColumns,
  } = props;
  const [sidebar, setSidebar] = useState(null);
  const [isShareSessionModalOpen, setIsShareSessionModalOpen] = useState(false);
  const [encodedJsonString, setEncodedJsonString] = useState('');
  const onClose = () => {
    setSidebar(null);
  };
  const findVisibleComponent = () => {
    //this means if sidebar is null return false, if sidebar has value return true
    return !!sidebar;
  };

  const drawerContents = () => {
    if (sidebar) {
      if (sidebar === sidebarState.LINKS) {
        return (
          <LinksPopout
            setSidebar={setSidebar}
            disableSkuToSku={props.disableSkuToSku}
          />
        );
      } else if (sidebar === sidebarState.SKU_TO_SKU) {
        return (
          <SkuToSkuPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            skuList={props.skuList}
          />
        );
      } else if (sidebar === sidebarState.ZONE_MULTIPLIER) {
        return (
          <ZoneMultiplierPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            zoneGroupData={props.zoneMultiplierGroupData}
            updateZoneGroupMultipliersData={
              props.updateZoneGroupMultipliersData
            }
          />
        );
      } else if (sidebar === sidebarState.PRICE_ENDING_RULES) {
        return (
          <PriceEndingRulesPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            skuList={props.skuList}
            anchorSku={props.anchorSku}
          />
        );
      } else if (sidebar === sidebarState.PRICING_SKU_GROUP) {
        return (
          <PricingSkuGroupPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            skuList={skuList}
            anchorSku={anchorSku}
            zoneMultiplierGroupSubClass={subclass}
            zoneMultiplierGroupId={id}
            userId={userId}
            skuGroupName={skuGroupName}
            skuGroupId={skuGroupId}
          />
        );
      } else if (sidebar === sidebarState.COLUMN_SETTINGS) {
        return (
          <ColumnSettingsPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            columnTemplates={columnTemplates}
            setColumnTemplates={setColumnTemplates}
            hiddenColumns={hiddenColumns}
            setHiddenColumns={setHiddenColumns}
          />
        );
      } else if (sidebar === sidebarState.TARGET_BASED_SETTINGS) {
        return (
          <TargetBasedPopout
            sidebar={sidebar}
            setSidebar={setSidebar}
            zoneGroups={zoneGroups}
          />
        );
      }
    }
  };
  const handleSharedCode = () => {
    setIsShareSessionModalOpen(true);
    let shareableData = {
      skuGroupId,
      skuGroupName,
      skus: skuList,
      zoneGroupMultiplierId: id,
    };
    if (Object.keys(costs).length) {
      shareableData = { ...shareableData, costs };
    }
    if (Object.keys(retails).length) {
      shareableData = { ...shareableData, retails };
    }
    if (columnTemplates.length) {
      shareableData = { ...shareableData, columnTemplates };
    }
    if (Object.keys(customColumns).length) {
      shareableData = { ...shareableData, customColumns };
    }
    const b64Str = encryptSharedCode(shareableData);
    setEncodedJsonString(b64Str);
  };

  const areSettingsDisabled =
    zoneGroupCompetitorPrice.isLoading ||
    !zoneMultiplierGroupData ||
    zoneGroupCurrentCpi.isLoading;

  // online-page-header
  return (
    <PageHeader ghost={false} className="edit-price-page-header">
      <Row align="middle" justify="space-between">
        <Col>
          <HeaderCrumbs
            isOnlyTitle={true}
            headerData={{ mainHeading: 'Edit Prices' }}
            backArrowClick={props.backArrowClick}
          />
        </Col>

        <Col>
          <Space size="middle">
            <Button
              type={'primary'}
              onClick={() => handleSharedCode()}
              icon={<ShareAltOutlined />}
              ghost
            >
              Get Share Code
            </Button>
            <Button
              type={'primary'}
              data-testid="edit-price-page-settings"
              onClick={() => setSidebar(sidebarState.LINKS)}
              icon={<SettingFilled />}
              loading={areSettingsDisabled}
              disabled={areSettingsDisabled}
              ghost
            >
              Settings
            </Button>
          </Space>
          <Drawer
            title="Settings"
            placement="right"
            width={sidebar === sidebarState.COLUMN_SETTINGS ? '736px' : '25%'}
            className="settings-drawer"
            onClose={onClose}
            open={findVisibleComponent()}
            closable={false}
          >
            {drawerContents()}
          </Drawer>
        </Col>
      </Row>
      {isShareSessionModalOpen && (
        <ShareSessionModal
          setIsShareSessionModalOpen={setIsShareSessionModalOpen}
          encodedJsonString={encodedJsonString}
        />
      )}
    </PageHeader>
  );
};

export default EditPricePageHeader;
