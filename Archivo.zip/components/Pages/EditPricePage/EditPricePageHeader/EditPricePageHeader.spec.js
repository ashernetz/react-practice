import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import LinksPopout from './PopoutComponents/LinksPopout';
import PopoutBreadCrumbs from './PopoutComponents/PopoutBreadCrumbs';
import '@testing-library/jest-dom';
import { sidebarState } from '../../../../constants/eppSidebarConstants';
import EditPricePageHeader from './EditPricePageHeader';
import { shareCodeResponse } from '../__fixtures__/shareCodeResponse';

describe('EditPricePageHeader', () => {
  test('render header', () => {
    render(
      <EditPricePageHeader
        zoneMultiplierGroupData={{ subclass: '026P' }}
        zoneGroupCompetitorPrice={jest.fn()}
        zoneGroupCurrentCpi={jest.fn()}
        columnTemplates={[]}
      />
    );
    expect(screen.getByText(/Edit Prices/)).toBeInTheDocument();
    expect(screen.getByText(/Settings/)).toBeInTheDocument();
  });

  test('click settings button and navigate through popup', () => {
    render(
      <EditPricePageHeader
        zoneMultiplierGroupData={{ subclass: '026P' }}
        zoneGroupCompetitorPrice={jest.fn()}
        zoneGroupCurrentCpi={jest.fn()}
        columnTemplates={[]}
      />
    );
    expect(screen.getByText(/Settings/)).toBeInTheDocument();
    fireEvent.click(screen.getByText('Settings'));
    expect(screen.getByText(/SKU-SKU Multiplier/)).toBeInTheDocument();
    expect(screen.getByText('Zone Multiplier')).toBeInTheDocument();

    fireEvent.click(screen.getByText(/SKU-SKU Multiplier/));
    expect(screen.getByText(/Back/)).toBeInTheDocument();
    expect(screen.getByText(/SKU-SKU Multiplier/)).toBeInTheDocument();

    //expect NOT
    expect(screen.queryByText('Zone Multiplier')).not.toBeInTheDocument();
  });

  test('render links popout', () => {
    render(<LinksPopout setSidebar={sidebarState.LINKS} />);
    expect(screen.getByText(/Zone Multiplier/)).toBeInTheDocument();
  });

  test('render bread crumbs component in sku to sku', () => {
    render(
      <PopoutBreadCrumbs
        sidebar={sidebarState.SKU_TO_SKU}
        setSidebar={sidebarState.SKU_TO_SKU}
      />
    );
    expect(screen.getByText(/Back/)).toBeInTheDocument();
    expect(screen.getByText(/SKU-SKU Multiplier/)).toBeInTheDocument();

    //expect NOT
    expect(screen.queryByText(/Zone Multiplier/)).not.toBeInTheDocument();
  });

  test('render bread crumbs component in zone multiplier', () => {
    render(
      <PopoutBreadCrumbs
        sidebar={sidebarState.ZONE_MULTIPLIER}
        setSidebar={sidebarState.ZONE_MULTIPLIER}
      />
    );
    expect(screen.getByText(/Back/)).toBeInTheDocument();
    expect(screen.getByText(/Zone Multiplier/)).toBeInTheDocument();

    //expect NOT
    expect(screen.queryByText(/SKU-SKU Multiplier/)).not.toBeInTheDocument();
  });

  test('render Get share Code Modal', () => {
    render(
      <EditPricePageHeader
        initialCosts={{}}
        initialRetails={{}}
        zoneMultiplierGroupData={{
          subclass: '026P',
          id: '7c0b7834-03c8-4783-b557-f4ed987ff7d5',
        }}
        zoneGroupCompetitorPrice={jest.fn()}
        zoneGroupCurrentCpi={jest.fn()}
        columnTemplates={[]}
        customColumns={{}}
      />
    );
    const getShareCodeText = screen.getByText('Get Share Code');
    expect(getShareCodeText).toBeInTheDocument();
    fireEvent.click(getShareCodeText);
    expect(screen.getByText('Share This Session')).toBeInTheDocument();
  });

  test('render EncryptedString', () => {
    const { skuGroupName, skus, zoneGroupMultiplierId, costs, retails } =
      shareCodeResponse;
    render(
      <EditPricePageHeader
        skuGroupName={skuGroupName}
        skus={skus}
        zoneMultiplierGroupData={{ id: zoneGroupMultiplierId }}
        initialCosts={costs}
        initialRetails={retails}
        zoneGroupCompetitorPrice={jest.fn()}
        zoneGroupCurrentCpi={jest.fn()}
        columnTemplates={[]}
        customColumns={{}}
      />
    );
    const getShareCodeText = screen.getByText('Get Share Code');
    fireEvent.click(getShareCodeText);
    expect(
      screen.getByText(/The following text can be shared with/)
    ).toBeInTheDocument();
    expect(screen.getByText(/Copy to Clipboard/)).toBeInTheDocument();
    expect(screen.getByText(/Cancel/)).toBeInTheDocument();
  });
});
