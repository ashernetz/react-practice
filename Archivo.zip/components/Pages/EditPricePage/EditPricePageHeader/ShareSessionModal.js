import React from 'react';
import { Row, Button, Modal, Typography, Space, Input } from 'antd';

import './ShareSessionModal.scss';
const { Text } = Typography;
const { TextArea } = Input;
const ShareSessionModal = ({
  setIsShareSessionModalOpen,
  encodedJsonString,
}) => {
  return (
    <Modal
      className="share-session-modal"
      open
      title={<Text className="share-session-heading">Share This Session</Text>}
      footer={[
        <Row align="middle" justify="end">
          <Button
            key="back"
            type="primary"
            size="large"
            ghost
            onClick={() => setIsShareSessionModalOpen(false)}
          >
            Cancel
          </Button>

          <Button
            key="submit"
            type="primary"
            size="large"
            className="copy-to-clipboard-btn"
            onClick={() => {
              navigator.clipboard.writeText(
                encodedJsonString.replace(/['"]+/g, '')
              );
              setIsShareSessionModalOpen(false);
            }}
          >
            Copy to Clipboard
          </Button>
        </Row>,
      ]}
    >
      <Space direction="vertical" size="middle">
        <p className="share-session-description">
          The following text can be shared with anyone with Mpulse access to
          view this price ending session. Simply copy and paste it and send it
          ti anyone who you wish to view this session. They can access it by
          pasting it into the Quick Edit workflow available by clicking the
          search bar and selecting "Change/Review Prices."
        </p>

        <TextArea
          className="share-code-text"
          rows={6}
          value={encodedJsonString}
          disabled
        />
      </Space>
    </Modal>
  );
};
export default ShareSessionModal;
