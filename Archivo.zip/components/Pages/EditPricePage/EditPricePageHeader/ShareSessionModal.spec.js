import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ShareSessionModal from './ShareSessionModal';

describe('ShareSessionModal', () => {
  const encodedJson =
    'eyJza3VHcm91cElkIjoiYjg2YjM3ZDUtOWI4Mi00YmVlLTljNWUtNjU1ZmI4OTkwMjdkIiwic2t1R3JvdXBOYW1lIjoiQUJTIE9ubHkgUGlwZSIsInNrdXMiOlsxOTM4MDEsMTkzNzk4LDE5MzgyOCwxOTM4MzYsMzcyNzY0LDM3MjgxMywzNzMyMjYsMzczMjQ5LDY0OTMyMyw2NDkzMzddLCJ6b25lR3JvdXBNdWx0aXBsaWVySWQiOiIzMjNlNWU1Yi1mMzUwLTRjYzktYjkxZi02NGUwN2UwNTU0ODIifQ==';
  test('render Get share Code Modal', () => {
    render(
      <ShareSessionModal
        setIsShareSessionModalOpen={() => {}}
        encodedJsonString={encodedJson}
      />
    );
    expect(screen.getByText('Share This Session')).toBeInTheDocument();
    expect(
      screen.getByText(/The following text can be shared with/)
    ).toBeInTheDocument();
    expect(screen.getByText(/Copy to Clipboard/)).toBeInTheDocument();
    expect(screen.getByText(/Cancel/)).toBeInTheDocument();
    expect(screen.getByDisplayValue(encodedJson)).toBeInTheDocument();
  });
});
