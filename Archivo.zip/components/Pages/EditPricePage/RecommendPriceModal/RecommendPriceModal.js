import React, { useEffect, useState } from 'react';
import { Row, Col, Modal, Space, Checkbox, Divider, Button, Badge } from 'antd';
import './RecommendPriceModal.scss';
import { useTargetRules } from '../Context/TargetRulesProvider';

const RecommendPriceModal = ({
  setRecommendPriceModal,
  override,
  generateRecs,
}) => {
  const [newRetailCheckBox, setNewRetailCheckBox] = useState(false);

  const getCheckedList = () => {
    const list = [];
    for (let rule of chkRules) {
      if (rule.checked) {
        list.push(rule.key);
      }
    }
    return list;
  };

  const footerButtons = override
    ? [
        <Button
          key={'back'}
          type="default"
          size="large"
          onClick={() => setRecommendPriceModal(false)}
        >
          Cancel
        </Button>,
        <Button
          key={'doNotOverride'}
          type="primary"
          size="large"
          ghost
          data-testid={'doNotOverride'}
          onClick={() => {
            setRecommendPriceModal(false);
            generateRecs(getCheckedList(), false, newRetailCheckBox);
          }}
        >
          Do Not Override
        </Button>,
        <Button
          key={'override'}
          type="primary"
          size="large"
          ghost
          data-testid={'override'}
          onClick={() => {
            setRecommendPriceModal(false);
            generateRecs(getCheckedList(), true, newRetailCheckBox);
          }}
        >
          Override
        </Button>,
      ]
    : [
        <Button
          key={'back-2'}
          type="default"
          size="large"
          onClick={() => setRecommendPriceModal(false)}
        >
          Cancel
        </Button>,
        <Button
          key={'recommend'}
          type="primary"
          size="large"
          ghost
          data-testid={'recommend'}
          onClick={() => {
            setRecommendPriceModal(false);
            generateRecs(getCheckedList(), true, newRetailCheckBox);
          }}
        >
          Recommend Prices
        </Button>,
      ];

  const rules = [
    {
      name: 'SKU-SKU',
      checked: false,
      id: 1,
      key: 'SKU_TO_SKU',
      isDisabled: false,
    },
    {
      name: 'Zone Group Multiplier',
      checked: false,
      id: 2,
      key: 'ZONE_MULTIPLIER',
      isDisabled: false,
    },
    {
      name: 'Target Based Rules',
      checked: false,
      id: 3,
      key: 'TARGET_BASED',
      isDisabled: true,
    },
    {
      name: 'Custom Price Ending',
      checked: false,
      id: 4,
      key: 'CUSTOM_PRICE_ENDING',
      isDisabled: false,
    },
    {
      name: 'THD Price Ending',
      checked: false,
      id: 5,
      key: 'THD_PRICE_ENDING',
      isDisabled: false,
    },
  ];

  const [chkRules, setChkRules] = useState(rules);
  const { targetRules, updateTargetRules } = useTargetRules();

  useEffect(() => {
    updateDisabledCheckBox();
  }, [targetRules]);

  const toggleRetailCheckBox = () => {
    setNewRetailCheckBox((prevState) => !prevState);
  };

  const updateDisabledCheckBox = () => {
    setChkRules((prevState) =>
      prevState.map((obj) => {
        if (obj.name === 'Target Based Rules') {
          return {
            ...obj,
            isDisabled:
              targetRules &&
              targetRules.targets &&
              targetRules.targets.length === 0,
          };
        }
        return obj;
      })
    );
  };

  return (
    <Modal
      open
      className="recommendprice-modal"
      onCancel={() => setRecommendPriceModal(false)}
      closable={false}
      okButtonProps={{ disabled: false }}
      footer={footerButtons}
    >
      <Space size="small" direction="horizontal">
        {override && (
          <Badge
            count={
              <div>
                <i className="material-icons-outlined dashboard-dcs-info">
                  info
                </i>
              </div>
            }
          />
        )}
        <Space size="small" direction="vertical">
          <Row>
            Select which rules will apply to your system generated
            recommendations:
          </Row>
          {chkRules.map((rule, index) => (
            <Row key={rule.id}>
              <Space size="small" direction="vertical">
                <Checkbox
                  onClick={() => {
                    chkRules[index].checked = !chkRules[index].checked;
                    setChkRules([...chkRules]);
                  }}
                  value={rule.id}
                  checked={rule.checked}
                  data-testid={rule.name}
                  disabled={rule.isDisabled}
                >
                  {rule.name}
                </Checkbox>
              </Space>
            </Row>
          ))}
          <Row>
            <Divider />
            <Col>
              <Checkbox
                onClick={() => {
                  toggleRetailCheckBox();
                }}
              >
                {' '}
                Recommend prices with Mode Retail where New Retail is blank.
              </Checkbox>
            </Col>
          </Row>
          {override && (
            <Row align={'top'}>
              <Divider />
              <Col>
                <div>
                  <b>Some new retail prices have been manually edited</b>
                </div>
                <div>
                  Select "Override" to&nbsp;<b>clear all</b>&nbsp;manually
                  edited prices and&nbsp;<b>replace</b>&nbsp;with system
                  generated recommendataions.
                </div>
                <p>
                  Select "Do Not Override" to&nbsp;<b>keep all</b>
                  &nbsp;manually edited prices and only generate recommendations
                  for&nbsp;
                  <b>new prices</b>&nbsp;that have&nbsp;
                  <b>not been manually edited.</b>
                </p>
              </Col>
            </Row>
          )}
        </Space>
      </Space>
    </Modal>
  );
};

export default RecommendPriceModal;
