import React from 'react';
import { render, screen } from '@testing-library/react';
import RecommendPriceModal from './RecommendPriceModal';
import * as mockTargetBasedRulesContext from '../Context/TargetRulesProvider';
import { SCOPE, STRATEGY } from '../Context/TargetRulesProvider';
import '@testing-library/jest-dom';

describe('RecommendPriceModal component', () => {
  test('render rules based om recommendations', () => {
    render(
      <mockTargetBasedRulesContext.TargetRulesProvider>
        <RecommendPriceModal
          setRecommendPriceModal={() => {}}
          override={true}
          generateRecs={() => {}}
        />
      </mockTargetBasedRulesContext.TargetRulesProvider>
    );
    expect(
      screen.getByText(
        'Select which rules will apply to your system generated recommendations:'
      )
    ).toBeInTheDocument();
    expect(screen.getByText('SKU-SKU')).toBeInTheDocument();
    expect(screen.getByText('Zone Group Multiplier')).toBeInTheDocument();
    expect(screen.getByText('Custom Price Ending')).toBeInTheDocument();
    expect(screen.getByText('Target Based Rules')).toBeInTheDocument();
    expect(screen.getByText('THD Price Ending')).toBeInTheDocument();
    expect(screen.queryByLabelText('Target Based Rules')).toBeDisabled();
    expect(
      screen.getByText(
        'Recommend prices with Mode Retail where New Retail is blank.'
      )
    ).toBeInTheDocument();
  });

  test('render disable target based rules based on targets', () => {
    jest.spyOn(mockTargetBasedRulesContext, 'useTargetRules').mockReturnValue({
      targetRules: {
        scope: SCOPE.WHOLE_SKU_GROUP,
        method: STRATEGY.BY_PERCENT,
        targets: [
          {
            target: 'IMU',
            value: '24',
          },
        ],
      },
      updateTargetRules: () => {},
    });
    render(
      <mockTargetBasedRulesContext.TargetRulesProvider>
        <RecommendPriceModal
          setRecommendPriceModal={() => {}}
          override={true}
          generateRecs={() => {}}
        />
      </mockTargetBasedRulesContext.TargetRulesProvider>
    );
    expect(
      screen.getByText(
        'Select which rules will apply to your system generated recommendations:'
      )
    ).toBeInTheDocument();

    expect(screen.queryByLabelText('Target Based Rules')).not.toBeDisabled();
  });
});
