import Cookies from 'universal-cookie';
import Authentication from './authHelper';
import localStorage from 'mock-local-storage'
import sessionStorage from 'mock-local-storage'

beforeAll(() => {
    //global.window = {}
    global.RadioGroup = function () { };
    global.RadioGroup.prototype.init = function () { };
    global.LoaderBtn = function () { };
    global.LoaderBtn.create = function () { };
    global.LoaderBtn.prototype.init = function () { };
    // global.sessionStorage = {
    //     setItem: () => { },
    //     getItem: () => { },
    //     removeItem: () => { }
    // };
})

describe('AuthHelper', () => {

    describe('isAuthenticated', () => {
        let spy;
        let cookies = new Cookies();

        it('should return false if no "thdsso" cookie', () => {
            Authentication.isAuthenticated();
        });

        it('should call "checkIsSessionValid" if "thdsso" cookie exists', () => {
            cookies.set('THDSSO');
            spy = jest.spyOn(Authentication, 'checkIsSessionValid').mockImplementationOnce(() => {
                return Promise.resolve(true);
            });
            Authentication.isAuthenticated();
            expect(spy).toBeCalled();
            spy.mockReset();
            spy.mockRestore();
        });
    });

    describe('getUserProfile', () => {
        let state, userProfile;

        beforeEach(() => {
            state = {};
        });

        it('should set userProfile to passed in userProfile', () => {
            state.user = { name: 'name' };

            userProfile = Authentication.getUserProfile(state);
            expect(userProfile).toBe(state.user);

        });

        it('should return null if no userProfile found', () => {

            userProfile = Authentication.getUserProfile(state);
            expect(userProfile).toBe(null);

        });

        it('should return userProfile from sessionStorage if !state.user', () => {
            let state = {"user": { "user": "user" }};
            const profile = JSON.stringify({ "user": "user" });
            // global.sessionStorage.getItem = () => {
            //     return btoa(profile);
            // };
            userProfile = Authentication.getUserProfile(state);
            expect(userProfile).toEqual(JSON.parse(profile));

        });
    });
});