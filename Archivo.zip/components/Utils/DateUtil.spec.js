import {
    determineIfDateIsInDateRange
} from './DateUtil';
import moment from 'moment';

describe("DateUtil", () => {
    describe("determineIfDateIsInDateRange()", () => {
        let startDate = moment().subtract(3, 'months');
        let endDate = moment();
        it("returns false if date is before range", () => {
            let date = moment().subtract(3, 'months').subtract(1, 'day');
            expect(determineIfDateIsInDateRange(startDate, endDate, date)).toBe(false);
        })
        it("returns true if date is on range start", () => {
            expect(determineIfDateIsInDateRange(startDate, endDate, startDate)).toBe(true);
        })
        it("returns true if date is in range", () => {
            let date = moment().subtract(2, 'months');
            expect(determineIfDateIsInDateRange(startDate, endDate, date)).toBe(true);
        })
        it("returns true if date is on range end", () => {
            expect(determineIfDateIsInDateRange(startDate, endDate, endDate)).toBe(true);
        })
        it("returns false if date is after range", () => {
            let date = moment().add(1, 'day');
            expect(determineIfDateIsInDateRange(startDate, endDate, date)).toBe(false);
        })
    })
})