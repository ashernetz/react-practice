import {Modal} from "antd";
import React from "react";

const modal = Modal;

export default class AlertUtil {

  static showAlert(type,title,content,onOkay,onCancel){

    let modalProps = {
      title,
      content,
      onOk : onOkay? onOkay: ()=>{},
      onCancel : onCancel?onCancel:()=>{}
    };

    modal[type](modalProps);
  }

  static getErrorMessage=(action)=>{
    return (
      <div>{"Something on our end is keeping us from processing this request while "+action+". Please contact us with the information below and the actions you took to help us resolve this issue.\n"}<br />
      <b>Pricing_Solutions_Team@homedepot.com</b></div>
    );
      
  }
}