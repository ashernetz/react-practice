export default class CloserLookDropdownUtil {
        static HIGH_TO_LOW = "High to Low";
        static LOW_TO_HIGH = "Low to High";
        static ABOVE_CLASS = "Trending above Class";
        static BELOW_CLASS = "Trending below Class";
        static sorting_Dropdown = [
                { key: this.HIGH_TO_LOW, title: 'High to Low' },
                { key: this.LOW_TO_HIGH, title: 'Low to High' },
        ];
        static sales_$ = "Sales $";
        static sales_Percent = "Sales Comp %";
        static units = "Units";
        static units_Percent = "Units Comp %"
        static aur = "AUR";
        static aur_Percent = "AUR Comp %";
        static metrics_Dropdown = [
                { key: this.sales_$, title: 'Sales $' },
                { key: this.sales_Percent, title: 'Sales Comp %' },
                { key: this.units, title: 'Units' },
                { key: this.units_Percent, title: 'Units Comp %' },
                { key: this.aur, title: 'AUR' },
                { key: this.aur_Percent, title: 'AUR Comp %' }
        ];
        static CLOSER_LOOK_METRICS = {
                'Sales $': this.sales_$,
                'Sales Comp %': this.sales_Percent,
                'Units': this.units,
                'Units Comp %': this.units_Percent,
                'AUR': this.aur,
                'AUR Comp %': this.aur_Percent
        }
}




