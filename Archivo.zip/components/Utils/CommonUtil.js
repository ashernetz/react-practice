import CompUtil from "./CompUtil";
import _ from 'lodash';
import {ArrowUpOutlined, ArrowDownOutlined} from '@ant-design/icons';
import React from 'react';
import {UXSpin} from '../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin'

function dcsFormatCheck(input, appendString, zeroPadCount) {
  return (input && !isNaN(input) ? appendString + Number.parseInt(
      input).toString().padStart(zeroPadCount, "0") : "")
}

function formatNumberToCompact (value)  {
  return Intl.NumberFormat('en-US', { notation: "compact" , compactDisplay: "short",maximumFractionDigits: 2,minimumFractionDigits: 2}).format(Number.parseFloat(value));
}

function minMaxRetailFormatter  (minRetail, maxRetail)  {
  if (!isFinite(minRetail) || !isFinite(maxRetail)) {
    return "-";
  } else if (minRetail === maxRetail) {
    return `$${CompUtil.formatPrice(minRetail)}`;
  } else {
    return `$${(CompUtil.formatPrice(minRetail))} - $${CompUtil.formatPrice(maxRetail)}`;
  }
}

function customGenericDateFormatter (inputMillis,customDelimiter="/"){
  let output = "";
  if(inputMillis){
    let inputDate = new Date(inputMillis);
    output = inputDate.toString() === "Invalid Date" ? "" :inputDate.getMonth()+1 + customDelimiter + inputDate.getDate() + customDelimiter + inputDate.getFullYear();
  }
  return output;
}

function dcsFormatter (department,classNumber,subClass){
  return dcsFormatCheck(department,"D-",3)
      .concat(dcsFormatCheck(classNumber," C-",3))
      .concat(dcsFormatCheck(subClass," S-",3));
}

function dcsFormatterWithoutHyphen (department,classNumber,subClass){
  return dcsFormatCheck(department,"D",2)
      .concat(dcsFormatCheck(classNumber," C",2))
      .concat(dcsFormatCheck(subClass," S",2));
}

function dcsFormatterWithBar (department,classNumber,subClass){
  return dcsFormatCheck(department,"D",3)
      .concat(dcsFormatCheck(classNumber," | C",3))
      .concat(dcsFormatCheck(subClass," | S",3));
}

function convertSearchTextToItemList(searchText){
  let skuNumberList = [];
  let omsIdList = [];

  searchText.trim().split(/[ ,\n]+/).forEach(k=> {
    let parsedInt = Number.parseInt(k);
    let noOfDigits = k.trim().length;
    if(noOfDigits >= 6 && noOfDigits <=10){
      if(k.trim().length === 9){
        omsIdList.push(parsedInt);
      }else {
        skuNumberList.push(parsedInt);
      }
    }
  });
  return {skuNumberList,omsIdList};
}

function convertSkuSearchTextToList(searchText){
  let skuNumberList = [];

  searchText.trim().split(/[ ,\n]+/).forEach(k=> {
    let parsedInt = Number.parseInt(k);
    if (!Number.isNaN(parsedInt)) {
      skuNumberList.push(parsedInt);
    }
  });
  return {skuNumberList};
}

function isErroredResponse (error){
  let isError = true;
  if (error && error.response && error.response.status
      && !error.response.status.toString().match("^[5][0-9][0-9]$")) {
    isError = false;
  }
  return isError;
}

function combineDataSets(data1, data2) {
  return _.concat(data1, data2)
}

function sortDataByValue(data, key) {
  return _.orderBy(data, key)
}

function getUniqueList(data, key) {
  return [...new Set(data.map(el => el[key]))];
}

function getSubClassDescription (dcsDataMap,departmentNumber,classNumber,subClassNumber){
  let subClassDescription = "";
  try {
    let classMap = dcsDataMap.get(departmentNumber).get("classes").get(classNumber);
    subClassDescription = classMap.get("subclasses").get(subClassNumber).get(
        "longDescription");
  }catch (e) {
    console.log(e);
  }
  return subClassDescription;
}

function getClassDescription (dcsDataMap,departmentNumber,classNumber){
  let classDescription = "";
  try{
    let classMap = dcsDataMap.get(departmentNumber).get("classes").get(classNumber);
    classDescription = classMap.get("description");
  }catch (e){
    console.log(e);
  }
  return classDescription;
}

function mergeAndRemoveDuplicates(array1,array2,checkAttribute){
    let firstArray = Array.isArray(array1)?array1:[];
    let secondArray = Array.isArray(array2)?array2:[];
    let combineArray = _.concat(firstArray,secondArray);
    return _.uniqBy(combineArray,checkAttribute);
}

function formatCamelCaseString (inputText) {
  let outputString = "";
  if (inputText) {
    outputString = inputText
    .toLowerCase()
    .split(" ")
    .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
    .join(" ");
  }
  return outputString;
};


function getCompactedAmount(amount, isSales) {
  return isSales ? `$${formatNumberToCompact(amount)}` : formatNumberToCompact(amount);
}

function getPercentageChanged(percentage) {
  return {
    text: percentage && !isNaN(percentage) ? `${percentage.toFixed(2)}%` : percentage === null ?  "N/A": <UXSpin/>,
    color: percentage ? percentage > 0 ? "green" : "red" : ""
  }
}

function getPercentageFormat(percentage) {
  return {
    text: percentage && !isNaN(percentage) ? `${percentage.toFixed(2)}%` : percentage === null ?  "-": <UXSpin/>,
    color: percentage ? percentage > 0 ? "green" : "red" : ""
  }
}

function getChangeArrow(percentage) {
  return percentage ? percentage > 0 ? <ArrowUpOutlined className="green"/> :
      <ArrowDownOutlined className="red"/> : null
}

function getChangeColor(percentage) {
  return percentage ? percentage > 0 ? "green" : "red" : null;
}

 function findNewMinMax (oldMinMax, newMinMax) {
  let minRetail = "";
  let maxRetail = "";
  if (oldMinMax.minRetail && newMinMax.minRetail) {
    minRetail = newMinMax.minRetail < oldMinMax.minRetail ? newMinMax.minRetail : oldMinMax.minRetail;
  } else {
    minRetail = newMinMax.minRetail ? newMinMax.minRetail : oldMinMax.minRetail;
  }
  if (oldMinMax.maxRetail && newMinMax.maxRetail) {
    maxRetail = newMinMax.maxRetail > oldMinMax.maxRetail ? newMinMax.maxRetail : oldMinMax.maxRetail;
  } else {
    maxRetail = newMinMax.maxRetail ? newMinMax.maxRetail : oldMinMax.maxRetail;
  }
  minRetail = minRetail ? minRetail : "";
  maxRetail = maxRetail ? maxRetail : "";
  return {minRetail, maxRetail, minMaxRetail: minMaxRetailFormatter(minRetail, maxRetail)}
}

export {
  formatNumberToCompact,
  minMaxRetailFormatter,
  customGenericDateFormatter,
  dcsFormatter,
  dcsFormatterWithoutHyphen,
  convertSearchTextToItemList,
  isErroredResponse,
  combineDataSets,
  sortDataByValue,
  getUniqueList,
  getSubClassDescription,
  mergeAndRemoveDuplicates,
  getClassDescription,
  formatCamelCaseString,
  findNewMinMax,
  getChangeArrow,
  getPercentageChanged,
  getCompactedAmount,
  getChangeColor,
  dcsFormatterWithBar,
  convertSkuSearchTextToList,getPercentageFormat
}
