export default class PriceChangeHistoryUtil {

    static getPriceChangeHistoryForStore(storeId, priceChangeHistoryMap) {
        let count = 0;
        return priceChangeHistoryMap[storeId] ? priceChangeHistoryMap[storeId].map(obj=> ({ ...obj, key: count++ })): [];

    }
    static findRetailChangeUpOrDown  (value)  {
        let className = "";
        if (value !== null) {
            if (value.toLowerCase() === "up") { className = "arrow-up"; }
            else if (value.toLowerCase() === "down") {className = "arrow-down"; }
        } 
        return className;
      };

    static reverse(priceChangeHistoryMap) {
        let reversed = [];
        let count = 0;

        if(priceChangeHistoryMap) {
            for (let index = priceChangeHistoryMap.length - 1; index >= 0;
                index--) {
                reversed[count] = priceChangeHistoryMap[index];
                count++;
            }
        }
        return reversed;
    }
}