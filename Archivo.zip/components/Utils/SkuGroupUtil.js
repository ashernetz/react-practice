import SkuGroupService from "../../services/SkuGroupService";

const specialCharRegex=/[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;

export default class SkuGroupUtil {
  static getSkuGroups = () => {
    return SkuGroupService.getSkuGroups()
      .then((response) => {
        if (response && response.data) {
          let skuGroups ={};

          response.data.forEach(k => {
            skuGroups[k.skuGroupId] = k.skuNumbers;
          });

          return skuGroups;
        }
      }).catch((e) => {
        console.log("Error with SkuGroupService.getSkuGroups:", e);
      });
  }
}

export function isGroupNameValid(value) {
  return specialCharRegex.test(value);
}
