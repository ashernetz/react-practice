export default class FilterUtil {
  static getSkuStoreStatusMap(allowedSet) {

    let defaultSkuStoreStatusMap = this.getStaticSkuStatusMap();
    // if (allowedSet.length === 1) {
    //   defaultSkuStoreStatusMap.get(
    //       allowedSet[0]).isChecked = true;
    // }
    return new Map(
        [...defaultSkuStoreStatusMap].filter(([k, v]) => allowedSet.includes(k)));
  }

  static formDefaultSkuStatus(distinctSkuSet) {
    let defaultSelectedStatus = [100,200];
    let initialSelectedSkuList = [];
    if(distinctSkuSet.length ===1){
      initialSelectedSkuList = distinctSkuSet;
  }else {
      distinctSkuSet.forEach(status => {
        if(defaultSelectedStatus.includes(status)){
          initialSelectedSkuList.push(status);
        }
      })
    }
    return initialSelectedSkuList;
  }
  static getStaticSkuStatusMap() {
    let defaultSkuStoreStatusMap = new Map();
    defaultSkuStoreStatusMap.set(100,
        {status: 100, value: "Active", isChecked: true});
    defaultSkuStoreStatusMap.set(200,
        {status: 200, value: "Seasonal", isChecked: true});
    defaultSkuStoreStatusMap.set(300,
        {status: 300, value: "Out of Season", isChecked: false});
    defaultSkuStoreStatusMap.set(400,
        {status: 400, value: "Inactive", isChecked: false});
    defaultSkuStoreStatusMap.set(500,
        {status: 500, value: "Clearance", isChecked: false});
    defaultSkuStoreStatusMap.set(600,
        {status: 600, value: "Delete", isChecked: false});

    return defaultSkuStoreStatusMap;
  }

  static getInitialFilterValues = () => {
    return {
      selectedSkuStatusList: [],
      selectedDisasterValue: "Include",
      isMapClusteringChecked: true,
      isPerformanceFilterChecked: false,
      selectedCompSales: 0,
      selectedCompUnits: 0,
      selectedCompetitors : [],
      selectedMarkets:[],
      selectedZones:[],
      isOffsideRangeChecked: false,
      minMaxDefaultOffsideRange:[-10,10],
      minMaxSelectedOffsideRange:[-10,10],
      offsideMap:{},
      isFilterValuesLoaded:false,
      selectedSkuAvailability:"All"

    }
  };

  static getDisasterDropdownData (){
    return ["Include","Exclude","Show Only"]
  }

  static isAllowDisaster(selectedValue,disasterFlag) {
    let isDisaster = disasterFlag ? disasterFlag : false;
    let allowStore = true;
    if (selectedValue === "Show Only" && isDisaster === false) {
      allowStore = false;
    } else if (selectedValue === "Exclude" && isDisaster === true) {
      allowStore = false;
    }

    return allowStore;
  }

  static filteredStoresBasedOnMarket(selectedMarkets,storeData){

    let allowStore = true;
    if(selectedMarkets.length !== 0 && !selectedMarkets.includes(storeData.mktId.toString())){
      allowStore = false;
    }

    return allowStore;
  }
  static filteredStoresBasedOnZone(selectedZones,storeData){

    let allowStore = true;
    let zoneId = storeData.zoneId ? storeData.zoneId.toString() : "";
    if(selectedZones.length !== 0 && !selectedZones.includes(zoneId)){
      allowStore = false;
    }

    return allowStore;
  }

  static filteredStoresBasedOnStatus(selectedStatusList,storeData){

    let allowStore = true;
    if(selectedStatusList.length !== 0 && !selectedStatusList.includes(storeData.skuStoreStatus)){
      allowStore = false;
    }

    return allowStore;
  }
  static filteredStoresBasedOnCompData (filterValues,storeData) {
    let compSales = filterValues.selectedCompSales;
    let compUnits = filterValues.selectedCompUnits;

    let isAllow = false;

    if(!filterValues.isPerformanceFilterChecked || ( compUnits===0 && compSales === 0)){
      isAllow = true;
    }else if((compUnits === 1 && storeData.compUnits > 0)
          || ( compUnits === -1 && storeData.compUnits < 0)
          || ( compSales ===1  && storeData.compSales>0)
          || ( compSales === -1  && storeData.compSales<0))
      {
        isAllow = true;
      }

    return isAllow;
  };

  static checkIfFilterIsApplied = (defaultFilterValue,currentFilterValue,excludeList) => {
    let isFilterApplied = false;
    excludeList = [...excludeList,...["minMaxDefaultOffsideRange","minMaxSelectedOffsideRange","offsideMap","isFilterValuesLoaded"]];
    if(defaultFilterValue){
      Object.keys(defaultFilterValue).some(eachFilter => {
        if(!excludeList.includes(eachFilter)){
          let currentValue = currentFilterValue[eachFilter];
          let defaultValue = defaultFilterValue[eachFilter];

          if(defaultValue instanceof Array){
            if( defaultValue.length !== currentValue.length || !defaultValue.every(v => currentValue.includes(v)) ) {
              isFilterApplied = true;
            }
          }else if(defaultValue !== currentValue){
            isFilterApplied = true;
          }
             }
        return isFilterApplied;

      });
    }

    return defaultFilterValue.isFilterValuesLoaded && isFilterApplied;

  };

  static filteredStoresBasedOnOffside(isOffsideChecked,allowedStores,storeId){

    let allowStore = true;
    if(isOffsideChecked && allowedStores){
      allowStore = allowedStores.includes(storeId);
    }

    return allowStore;
  }

  static offsideEligibleStores(selectedCompetitor,minMaxSelectedRange,defaultRange,isOffsideChecked,offsideMap){

    if (minMaxSelectedRange) {
      let minimumRange = isNaN(minMaxSelectedRange[0]) ? "" : Number.parseFloat(
          minMaxSelectedRange[0]);
      let maximumRange = isNaN(minMaxSelectedRange[1]) ? "" : Number.parseFloat(
          minMaxSelectedRange[1]);

      if (isOffsideChecked && minimumRange !== "" && maximumRange !== "" && Object.keys(offsideMap).length > 0 && offsideMap[selectedCompetitor]) {
        let allowedThdStores = new Set();
        let allowedCompetitorStores = new Set();

        offsideMap[selectedCompetitor].forEach((value, key) => {
          let allowStore = false;
          if (minimumRange === defaultRange[0] && maximumRange === defaultRange[1]) {
            allowStore = true;
          } else if (minimumRange === defaultRange[0] || maximumRange === defaultRange[1]) {
            if (minimumRange === defaultRange[0] && key <= maximumRange) {
              allowStore = true;
            } else if (maximumRange === defaultRange[1] && key >= minimumRange ) {
              allowStore = true;
            }
          } else if (key >= minimumRange && key <= maximumRange) {
            allowStore = true;
          }
          if (allowStore) {
            value["thdStores"].forEach(item => allowedThdStores.add(item));
            value["competitorStores"].forEach(
                item => allowedCompetitorStores.add(item));
          }

        });

        return {
          allowedThdStores: [...allowedThdStores],
          allowedCompetitorStores: [...allowedCompetitorStores]
        };
      } else {
        return "";
      }
    } else {
      return "";
    }

  }

  static getSkuAvailabilityDropdownData (){
    return ["All","Out of Stock","In Stock"];
  }

  static filteredStoresBasedOnSkuAvailability(selectedValue,onHandQuantity) {
    if (selectedValue === "All") {
      return true;
    } else {
      let allowStore = true;

      if (selectedValue === "In Stock") {
        let tempOnHand = onHandQuantity ? (isNaN(onHandQuantity) ? 0
            : onHandQuantity) : 0;
        allowStore = tempOnHand > 0;
      } else if (selectedValue === "Out of Stock") {
        allowStore = onHandQuantity === 0;
      }
      return allowStore;
    }
  }
}