export default class PricePointUtil {

  static addExtraDetailsToPricePoint(skuData,user,distinctSkuStatusSet) {
    let pricePointDetails = skuData.pricePointDetails;
    let pricePointStoreCountList = [];
    let marketMap  = {};
    let availableZoneMap = {};
    let availableStores = [];
    let storeRetailMap = new Map();
    let priceRangeCountMap = {};
    let offsideStoreConsideration = [];
    Object.keys(pricePointDetails).forEach(retail => {
      let price = Number.parseFloat(retail.split("-")[0]);
      let storeDetails = Object.values(
          pricePointDetails[retail].storeDetails);
      let activeSeasonalStoreCount = 0;
      storeDetails.forEach(store=> {
        if([100,200].includes(store.skuStoreStatus) || (!distinctSkuStatusSet.includes(100) && !distinctSkuStatusSet.includes(200))){
          activeSeasonalStoreCount =activeSeasonalStoreCount+1;
          priceRangeCountMap[price] = priceRangeCountMap.hasOwnProperty(price) ?  priceRangeCountMap[price]+1 : 1;
          if([100,200].includes(store.skuStoreStatus)){offsideStoreConsideration.push(store.storeId); }
        }
        availableStores.push(store.storeId);
        storeRetailMap.set(store.storeId.toString(),retail);
        marketMap[store.mktId]=store.mktName;
        availableZoneMap[store.zoneId] = store.zoneId + "-" + store.zoneName;
        store.retailKey = retail;
        store.effectiveEndDateForPending = pricePointDetails[retail].effectiveEndDateForPending;
             });
      pricePointStoreCountList.push({
        retail,
        storeCount: storeDetails.length,
        activeSeasonalStoreCount
      })
    });
    this.setColorGradientForPrice(pricePointStoreCountList, pricePointDetails);
    let minMaxPriceRange = [];
    minMaxPriceRange.push(Math.min(...Object.keys(priceRangeCountMap)));
    minMaxPriceRange.push(Math.max(...Object.keys(priceRangeCountMap)));

    let isSubmitEnabled = user.accesses ? user.accesses.isSubmitEnabled ?  user.accesses.isSubmitEnabled :false : false;
    skuData.allowExecution = isSubmitEnabled && skuData.pacManSKU;
    skuData.marketMap = marketMap;
    skuData.availableZoneMap = availableZoneMap;
    skuData.availableStores=availableStores;
    skuData.storeRetailMap= storeRetailMap;
    skuData.allowStorePriceChange = skuData.storeTempSKU;
    skuData.allowZonePriceChange = skuData.zoneTempSKU;
    skuData.mostCommonRetails =this.getMostCommonRetail(priceRangeCountMap);
    skuData.pricePointRelevantCount = Object.keys(priceRangeCountMap).length;
    skuData.minMaxPriceRange = minMaxPriceRange;
    skuData.offsideStoreConsideration = offsideStoreConsideration;
    skuData.assortedActiveStoreCount = offsideStoreConsideration.length
  }

  static setColorGradientForPrice(pricePointStoreCountList, pricePointDetails) {

    pricePointStoreCountList = pricePointStoreCountList.sort((a, b) => {
      return b.activeSeasonalStoreCount - a.activeSeasonalStoreCount
    });
    //setting most CommonPricePoint detail
    pricePointDetails[pricePointStoreCountList[0].retail].pointerColor = "#fa6304";
    pricePointStoreCountList.splice(0,1);

     pricePointStoreCountList = pricePointStoreCountList.sort((a, b) => {
      return b.storeCount - a.storeCount
    });
    pricePointStoreCountList.forEach(retailData => {
      pricePointDetails[retailData.retail].pointerColor = this.getColorGradientForPrice(
          pricePointStoreCountList.indexOf(retailData));
    });

  }
  static getColorGradientForPrice(index) {
    let tempIndex = index;
    //let colorGradients = ["#6baed6","#2171b5","#08519c","#08306b"];
    let colorGradients = this.getColorGradients();
   
    if (tempIndex > colorGradients.length) {
      tempIndex = tempIndex % colorGradients.length;
    }
   
    if( colorGradients[tempIndex] === undefined)
      return colorGradients[tempIndex-1];
    else
      return colorGradients[tempIndex];
  }

  static getColorGradients() {
   return ["#740aff","#008f9c","#fa0087","#66b0ff","#a75740","#6b6882","#005f39","#00ff78","#b500ff","#683d3b","#620e00","#00ffc6","#620e00","#bb8800","#968ae8","#004754","#0e4ca1","#788231","#004754","#ff74a3","#001544","#9e008e","#00b917","#bdd393","#263400","#bdc6ff","#7544b1","#00ae7e","#ff0056","#1cbe4f","#009bff","#85a900","#7a4782","#fe8900","#6a826c","#ffe502","#0076ff","#90fb92","#774d00","#007db5","#95003a","#010067","#006401","#01fffe","#0000ff","#00ff00","#c4451c"];
  }


  static getPendingCount(stores, pendingStoreDetailsMap) {

    let pendingCount = 0;
    stores.forEach(store=> {
      if(pendingStoreDetailsMap.has(store.storeId)){
        pendingCount = pendingCount + pendingStoreDetailsMap.get(store.storeId).count
      }
    });

    return pendingCount;
  }

  static getDisasterCount (stores) {

      return stores.filter(store=> store.disaster === true).length
  }
  static getCompDataForSkuAndRetailLevel (skuStoreStatusList,stores, skuStorePerformanceData){

    let lastYearTotalUnits = 0;
    let currentYearTotalUnits = 0;
    let lastYearTotalSales = 0;
    let currentYearTotalSales = 0;
    let rawSales = 0;
    let rawUnits= 0;

    let totalCount = 0;
    let filteredStoreSet = [];
    stores.forEach(store => {
        if(skuStorePerformanceData.rawSalesAndUnitsMap && skuStorePerformanceData.rawSalesAndUnitsMap[store.storeId]){
          let rawData = skuStorePerformanceData.rawSalesAndUnitsMap[store.storeId];
          rawSales = rawSales + (rawData.rawSales ? rawData.rawSales : 0);
          rawUnits = rawUnits + (rawData.rawUnits ? rawData.rawUnits :0);
        }
        filteredStoreSet.push(store.storeId);
        // if( skuStorePerformanceData.storeLevelPerformance[store.storeId]){
        if (skuStorePerformanceData.currentYearPerformanceMap
            && skuStorePerformanceData.lastYearPerformanceMap) {
          totalCount = totalCount + 1;
          currentYearTotalUnits = currentYearTotalUnits
          + (skuStorePerformanceData.currentYearPerformanceMap[store.storeId]
              ? skuStorePerformanceData.currentYearPerformanceMap[store.storeId]["netUnitSales"]
              : 0);
          currentYearTotalSales = currentYearTotalSales
          + (skuStorePerformanceData.currentYearPerformanceMap[store.storeId]
              ? skuStorePerformanceData.currentYearPerformanceMap[store.storeId]["netRetailSales"]
              : 0);
          lastYearTotalUnits = lastYearTotalUnits
          + (skuStorePerformanceData.lastYearPerformanceMap[store.storeId]
              ? skuStorePerformanceData.lastYearPerformanceMap[store.storeId]["netUnitSales"]
              : 0);
          lastYearTotalSales = lastYearTotalSales
          + (skuStorePerformanceData.lastYearPerformanceMap[store.storeId]
              ? skuStorePerformanceData.lastYearPerformanceMap[store.storeId]["netRetailSales"]
              : 0);
        }

      //}
    });



    let resultantMap = {"compSales" : "-","compUnits" : "-"};
    if (totalCount !== 0){
      // lastYearSkuCompData["netUnitSales"] = lastYearSkuCompData["netUnitSales"]+lastYearTotalUnits;
      // lastYearSkuCompData["netRetailSales"] = lastYearSkuCompData["netRetailSales"]+lastYearTotalSales;
      // currentYearSkuCompData["netUnitSales"] = currentYearSkuCompData["netUnitSales"]+currentYearTotalUnits;
      // currentYearSkuCompData["netRetailSales"] = currentYearSkuCompData["netRetailSales"]+currentYearTotalSales;

      resultantMap = {
        "compSales":this.findPercentage(currentYearTotalSales,lastYearTotalSales),
        "compUnits": this.findPercentage(currentYearTotalUnits,lastYearTotalUnits),
        rawSales,
        rawUnits
      };
    }
    resultantMap["filteredStoreSet"] = filteredStoreSet;
    return resultantMap;

  };

  static getCompDataForFilteredZoneLevel (stores, skuStorePerformanceData){

    let lastYearTotalUnits = 0;
    let currentYearTotalUnits = 0;
    let lastYearTotalSales = 0;
    let currentYearTotalSales = 0;

    let totalCount = 0;
    stores.forEach(storeId => {

        //if( skuStorePerformanceData.storeLevelPerformance[storeId]){
          if (skuStorePerformanceData.currentYearPerformanceMap
              && skuStorePerformanceData.lastYearPerformanceMap) {
            totalCount = totalCount + 1;
            currentYearTotalUnits = currentYearTotalUnits
                + (skuStorePerformanceData.currentYearPerformanceMap[storeId]
                    ? skuStorePerformanceData.currentYearPerformanceMap[storeId]["netUnitSales"]
                    : 0);
            currentYearTotalSales = currentYearTotalSales
                + (skuStorePerformanceData.currentYearPerformanceMap[storeId]
                    ? skuStorePerformanceData.currentYearPerformanceMap[storeId]["netRetailSales"]
                    : 0);
            lastYearTotalUnits = lastYearTotalUnits
                + (skuStorePerformanceData.lastYearPerformanceMap[storeId]
                    ? skuStorePerformanceData.lastYearPerformanceMap[storeId]["netUnitSales"]
                    : 0);
            lastYearTotalSales = lastYearTotalSales
                + (skuStorePerformanceData.lastYearPerformanceMap[storeId]
                    ? skuStorePerformanceData.lastYearPerformanceMap[storeId]["netRetailSales"]
                    : 0);
          }
        //}


    });

    let resultantMap = {"compSales" : "-","compUnits" : "-"};
    if (totalCount !== 0){
         resultantMap = {"compSales":this.findPercentage(currentYearTotalSales,lastYearTotalSales),
        "compUnits": this.findPercentage(currentYearTotalUnits,lastYearTotalUnits)};
    }
    return resultantMap;

  };

  static fillStoreCompData(currentYearStoreMap,lastYearStoreMap,storeSet) {
    let compDataMap = {};
    storeSet.forEach(store => {
      this.setCompUnitsAndSalesPercentage(
          currentYearStoreMap[store],
          lastYearStoreMap[store],compDataMap,store);
    });

    return compDataMap;
  };

  static setCompUnitsAndSalesPercentage (currentYearCompPerformanceDTO,lastYearCompPerformanceDTO,compDataMap,store) {


    if(currentYearCompPerformanceDTO && lastYearCompPerformanceDTO ){
      if(currentYearCompPerformanceDTO.netUnitSales !== 0 && currentYearCompPerformanceDTO.netRetailSales !== 0 &&
          lastYearCompPerformanceDTO.netUnitSales !== 0 && lastYearCompPerformanceDTO.netRetailSales !== 0 ){
        let resultantPercentageMap = {};
        resultantPercentageMap["compUnits"] = this.findPercentage(currentYearCompPerformanceDTO.netUnitSales,
            lastYearCompPerformanceDTO.netUnitSales);
        resultantPercentageMap["compSales"] =
            this.findPercentage(currentYearCompPerformanceDTO.netRetailSales,
                lastYearCompPerformanceDTO.netRetailSales);

        compDataMap[store] = resultantPercentageMap;
      }
    }
  };

  static findPercentage ( currentYearValue,  lastYearValue) {
    if(lastYearValue){
      let numerator = (currentYearValue - lastYearValue) * 100;
      let finalValue = numerator/lastYearValue;
      return finalValue.toFixed(2);
    }else {
      return 0;
    }

  };

  static isPricePointFallsInSelectedStatus(storeDetails,skuStatusList) {
    let allowPricePoint = true;

    if (skuStatusList.length !== 0) {
      allowPricePoint = storeDetails.some(store => {
        return skuStatusList.includes(store.skuStoreStatus);
      })
    }
    return allowPricePoint;
  }

  static getMostCommonRetail(inputRetailCountMap) {
    let maxCount = 0;
    let finalRetailAmounts = [];
    Object.keys(inputRetailCountMap).forEach(retailAmount => {
      if(inputRetailCountMap[retailAmount] > maxCount){
        maxCount = inputRetailCountMap[retailAmount];
        finalRetailAmounts =[];
        finalRetailAmounts.push(retailAmount);
      }else if(maxCount === inputRetailCountMap[retailAmount]){
        finalRetailAmounts.push(retailAmount);
      }
    });

    return finalRetailAmounts.sort();
  }
 }