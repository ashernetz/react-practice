import React from "react";
import {Select} from "antd";
const { Option } = Select;
export default class DCSUtil {

  static getDeptDropdownData  (dcsDataMap) {
    let deptDropdownData = [];
    dcsDataMap.forEach((value, key) => {
      deptDropdownData.push(<Option key={key} value={key}>{value.get("name")}</Option>);
    });
    return deptDropdownData;
  };

  static getClassDropdownData (dcsDataMap, deptNumber){
    let classDropdownData = [];
    if (dcsDataMap.has(deptNumber)) {
      dcsDataMap.get(deptNumber).get("classes").forEach(
          (value, key) => {
            classDropdownData.push(<Option key={key} value={key}>{value.get("name")}</Option>);
          });
    }
    return classDropdownData;
  };

  static getSubClassDropdownData(dcsDataMap, deptNumber, classNumber) {
    let subclassDropdownData = [<Option key={0} value={0}>{"None"}</Option>];
    if (dcsDataMap.has(deptNumber) && dcsDataMap.get(
        deptNumber).get("classes").has(classNumber)) {
      dcsDataMap.get(deptNumber).get("classes").get(classNumber).get("subclasses").forEach(
          (value, key) => {
            subclassDropdownData.push(<Option key={key} value={key}>{value.get("name")}</Option>);
          });
    }
    return subclassDropdownData;
  };

  static getHyphenatedDCS(departmentNumber, classNumber, subclassNumber) {
    return departmentNumber + "-" + classNumber + "-" + subclassNumber;

  }

  static getHierarchyName(dcsDataMap, dcsKey, defaultValue) {
    let hierarchyName = defaultValue ? defaultValue : "Sub Class";
    if(dcsKey && dcsDataMap){
      try {
        let dcs = dcsKey.split("-").map(k => Number.parseInt(k.trim()));
        if (dcs[2] !== 0) {
          hierarchyName = dcsDataMap.get(dcs[0]).get("classes").get(dcs[1]).get(
              "subclasses").get(dcs[2]).get("name").split(/-(.+)/)[1];
        } else if (dcs[1] !== 0) {
          hierarchyName = dcsDataMap.get(dcs[0]).get("classes").get(dcs[1]).get(
              "name").split(/-(.+)/)[1];

        }

      } catch (e) {
       //console.log("Wrong DCS key : " + dcsKey);
      }
    }


    return this.getFormattedCamelSpaceString(hierarchyName);
  }

  static getSubclassesList (dcsDataMap, dcsKey) {
    let subclassList = [];
    if(dcsKey && dcsDataMap){
      try{
        let dcs = dcsKey.split("-").map(k => Number.parseInt(k.trim()));
        if(dcs[2]===0){
          subclassList = [...dcsDataMap.get(dcs[0]).get("classes").get(dcs[1]).get("subclasses").keys()]
        }
      }catch(e){
        //console.log("Wrong DCS key : " + dcsKey);
      }
    }
    return subclassList;
  }

  static getFormattedCamelSpaceString = (inputText) => {
    let outputString = "";
    if(inputText){
      outputString = inputText.toLowerCase()
          .split(' ')
          .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
          .join(' ');
    }
    return outputString;
  };

  static getSubDept (subDeptDataMap,departmentNumber,classNumber){
    return Object.keys(subDeptDataMap).find(k => {
      let deptClassMap = subDeptDataMap[k].deptClassMap;
      return deptClassMap.has(departmentNumber) && deptClassMap.get(
          departmentNumber).includes(classNumber);
    });
  }

  static getFormattedDCSObject = (hyphenatedDcsString) => {
    let dcsArray = hyphenatedDcsString.split("-", 3);
    let formattedDCSObject = {
      subDept: dcsArray.length > 0 && dcsArray[0],
      classNumber: dcsArray.length > 1 ? dcsArray[1] : "000",
      subclass: dcsArray.length > 2 ? dcsArray[2] : "000",
    };

    return formattedDCSObject;
  }
}