function getHierarchy (selectedDCS, subDeptDataMap, dcsDataMap){

    try {
        let subDepartment = "";
        let subDepartmentName = "";
        let departmentNumber = 0;
        let departmentName = "";
        let classNumber = 0;
        let className = "";
        let subClassNumber = 0;
        let subClassName = "";

        if (subDeptDataMap && dcsDataMap && selectedDCS && selectedDCS.split("-")[0] !== 0) {
            let dcs = selectedDCS;
            departmentNumber = Number.parseInt(dcs.split("-")[0]);
            classNumber = Number.parseInt(dcs.split("-")[1]);
            subClassNumber = Number.parseInt(dcs.split("-")[2]);
            subDepartment = Object.keys(subDeptDataMap).find(k => {
                let deptClassMap = subDeptDataMap[k].deptClassMap;
                return deptClassMap.has(departmentNumber) && deptClassMap.get(
                    departmentNumber).includes(classNumber);
            });
            subDepartmentName = subDeptDataMap.hasOwnProperty(subDepartment)
                ? subDeptDataMap[subDepartment].longDescription : "";

            let deptMap = dcsDataMap.get(departmentNumber);
            let classMap = dcsDataMap.get(departmentNumber).get("classes").get(classNumber);

            departmentName = deptMap.get("longDescription");
            if (classNumber) {
                className = classMap.get("longDescription");
            }

            if (subClassNumber) {
                subClassName = classMap.get("subclasses").get(subClassNumber).get(
                    "longDescription");
            }

        }

        return {
            subDepartment,
            subDepartmentName,
            departmentNumber,
            departmentName,
            classNumber,
            className,
            subClassNumber,
            subClassName
        }
    } catch (e) {
        //console.log("Wrong DCS key : " + dcsKey);
        return {};
    }


}

function formatDCSData(dcs){
    let selectedDCS= dcs? dcs.split("-")[0]:'';
    let dept = selectedDCS.split("|")[0].trim();
    let cls = selectedDCS.split("|")[1]?selectedDCS.split("|")[1].trim():'0';
    let subCls = selectedDCS.split("|")[2]?selectedDCS.split("|")[2].trim():'0';
    return dept+"-"+cls+"-"+subCls;

}

function getParentDCSList(parentList, isClassType){
    let formattedParents = [];

    parentList.forEach(parent=>{
        let department = parent.dept.toString().padStart(3, "0");
        let clazz = parent.clazz.toString().padStart(3, "0");
        let subclass = parent.subClass.toString().padStart(3, "0");
        if(!isClassType) {
            formattedParents.push(department + "-" + clazz + "-" + subclass + "-" + parent.subclassName);
        }
        formattedParents.push(department + "-" + clazz + "-" + parent.className);
    })

    return formattedParents;
}

function formattedInputDCS(dcs,isClassType){
    let selectedDCS= dcs? dcs.split("-")[0]:'';
    let dept = selectedDCS.split("|")[0].trim().padStart(3, "0") ;
    let cls = selectedDCS.split("|")[1]?selectedDCS.split("|")[1].trim().padStart(3, "0"):'0';
    let dcsName = dcs.split("-")[1]? dcs.split("-")[1].trim(): '';
    if(!isClassType) {
        let subCls = selectedDCS.split("|")[2] ? selectedDCS.split("|")[2].trim().padStart(3, "0") : '0';
        return dept + "-" + cls + "-" + subCls + "-" + dcsName;
    }
    return dept + "-" + cls + "-" + dcsName;
}


export {
    formatDCSData,getHierarchy,formattedInputDCS, getParentDCSList
}