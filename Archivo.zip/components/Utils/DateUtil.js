import Moment from 'moment';
import { extendMoment } from 'moment-range';

const moment = extendMoment(Moment);

function determineIfDateIsInDateRange(startDate, endDate, comparisonDate) {
    return moment.range(startDate, endDate).contains(comparisonDate);
}

export {
    determineIfDateIsInDateRange
}