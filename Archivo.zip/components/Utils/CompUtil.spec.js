import CompUtil from './CompUtil';

describe("CompUtil", () => {
    describe("formatPrice()", () => {
        it("returns the price formatted to two decimal places", () => {
            expect(CompUtil.formatPrice(4.3)).toEqual("4.30");
        })
        it("does not break if it receives null or undefined", () => {
            expect(CompUtil.formatPrice(null)).toBe(null);
            expect(CompUtil.formatPrice(undefined)).toBe(undefined);
        })
        it("still returns 0 if it receives 0 like it was set up to do for markup/markdown data", () => { // Why not return 0.00?
            expect(CompUtil.formatPrice(0)).toEqual("0.00");
        })
    })
})