import TableUtil from "./TableUtil";

describe("TableUtil", () => {
    describe("getDynamicScrollableColumnsAreaWidth()", () => {
        it("gets the width for the scroll.x configuration of the table", () => {
            expect(TableUtil.getDynamicScrollableColumnsAreaWidth(90, 2, 5)).toEqual(900);
        })
    })

    describe("customRankSorter()", () => {
        it("sorts the ranks correctly ascending", () => {
            expect(TableUtil.customRankSorter(1200, 2004, "ascend")).toEqual(1);
        })
    })

    describe("customRankSorter()", () => {
        it("sorts the ranks correctly with null", () => {
            expect(TableUtil.customRankSorter({"rank" : null}, 2004, "ascend")).toEqual(1);
        })
    })

    describe("customRankSorter()", () => {
        it("sorts the ranks correctly with null", () => {
            expect(TableUtil.customRankSorter({"rank" : null}, 2004, "descend")).toEqual(-1);
        })
    })

    describe("customRankSorter()", () => {
        it("sorts the ranks correctly with null", () => {
            expect(TableUtil.customRankSorter(2004, {"rank" : null}, "ascend")).toEqual(1);
        })
    })
})