import {isGroupNameValid} from "./SkuGroupUtil";

describe("SkuGroupUtil", () => {
    describe("isGroupNameValid()", () => {
        it("check string with special character", () => {
            expect(isGroupNameValid("Sku Group 123!@#")).toEqual(true);
        })
    })

    describe("isGroupNameValid()", () => {
        it("check string without special character", () => {
            expect(isGroupNameValid("Sku Group 123")).toEqual(false);
        })
    })

})
