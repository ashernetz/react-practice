export const initializeMixPanel = (key) => {

    //TODO: Read token from a config file based on the enviroment.
  
    // const token = getMixPanelToken();
  
    // if (token) {
      window.mixpanel.init(key);
      window.mixpanel.set_config({ignore_dnt: true});
    // }
  };
  
  export const setCurrentUserInfo = (userData) => {
    
    window.mixpanel.identify(userData.userId);
    window.mixpanel.people.set({
      '$first_name': userData.userId, 
      '$TITLE': userData.jobTitle
    });
  
    //TODO: Update these with the desired people properties
  
    // window.mixpanel.people.set({
    //   '$first_name': userData.ldap,   // NOTE: Mixpanel uses $first_name and $last_name to display Name in the list of
    //   '$last_name': userData.id || userData.userId,      //      users in User > Explore page. If this is not desired, remove these 2 fields.
    //   role: userData.role,
    //   'Current # of Classes': userData.subClasses && userData.subClasses.length || 0
    // });
  };
  
  /**
   * Common function to track events.
   *
   * @param eventName         Required. String. The event name label (e.g `download_sku_list`).
   * @param properties        Optional. Object. A set of properties to include with the event you're sending. This will
   *                              directly be passed on to `window.mixpanel.track()` method.
   * @param callback          Optional. Function. If provided, the callback function will be called after tracking the
   *                              event. This will be directly be passed on to `window.mixpanel.track()` method.
   */
  export const trackEvent = (eventName, properties, callback) => {
  
    //TODO: Consider prefixing the eventName with something that distinguishes MPulse events. Eg: eventName = `MPulse ${eventName}`;
  
    window.mixpanel.people.set_once({
      [`First ${eventName} event`]: new Date()
    });
  
    window.mixpanel.people.set({
      [`Last ${eventName} event`]: new Date()
    });
  
    window.mixpanel.people.increment(`# of ${eventName} events`);
  
    window.mixpanel.track(eventName, properties, callback);
  };
  
  
  
  
  