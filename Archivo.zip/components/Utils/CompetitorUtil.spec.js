import CompetitorUtil from "./CompetitorUtil";

describe("CompetitorUtil Tests", () => {
  describe("sortCompetitors Tests", () => {
    it("returns when input is not a valid object", () => {
      expect(CompetitorUtil.sortCompetitors(undefined)).toEqual(undefined);
      expect(CompetitorUtil.sortCompetitors(null)).toEqual(null);
      expect(CompetitorUtil.sortCompetitors([])).toEqual([]);
      expect(CompetitorUtil.sortCompetitors(1)).toEqual(1);
      expect(CompetitorUtil.sortCompetitors("1")).toEqual("1");
    });

    it("sorts all known competitors", () => {
      let comps = [
        {
          id: 3141,
          name: "Lowe's",
        },
        {
          id: 527,
          name: "Walmart",
        },
        {
          id: 6488,
          name: "Menards",
        },
        {
          id: 18214,
          name: "Amazon",
        },
        {
          id: 588623,
          name: "F&D",
        },
      ];

      const expected = [
        {
          id: 3141,
          name: "Lowe's",
        },
        {
          id: 6488,
          name: "Menards",
        },
        {
          id: 588623,
          name: "F&D",
        },
        {
          id: 18214,
          name: "Amazon",
        },
        {
          id: 527,
          name: "Walmart",
        },
      ];

      expect(CompetitorUtil.sortCompetitors(comps)).toEqual(expected);
    });
  });
  describe("getCompetitorName Tests", () => {
    it("returns empty string when input is invalid", () => {
      expect(CompetitorUtil.getCompetitorName(null)).toEqual("");
      expect(CompetitorUtil.getCompetitorName(undefined)).toEqual("");
      expect(CompetitorUtil.getCompetitorName("")).toEqual("");
      expect(CompetitorUtil.getCompetitorName(1111)).toEqual("");
      expect(CompetitorUtil.getCompetitorName("Lowes")).toEqual("");

    });
    it("returns the long form of competitor name when no option is passes", () => {
      expect(CompetitorUtil.getCompetitorName(3141)).toEqual("Lowes");
      expect(CompetitorUtil.getCompetitorName(6488)).toEqual("Menards");
      expect(CompetitorUtil.getCompetitorName(588623)).toEqual("Floor & Decor");
      expect(CompetitorUtil.getCompetitorName(18214)).toEqual("Amazon");
      expect(CompetitorUtil.getCompetitorName(527)).toEqual("Walmart");
    });
    it("returns the short form of competitor name when additional option is passes", () => {
      expect(CompetitorUtil.getCompetitorName(3141, true)).toEqual("Low");
      expect(CompetitorUtil.getCompetitorName(6488, true)).toEqual("Men");
      expect(CompetitorUtil.getCompetitorName(588623, true)).toEqual("F&D");
      expect(CompetitorUtil.getCompetitorName(18214, true)).toEqual("Amz");
      expect(CompetitorUtil.getCompetitorName(527, true)).toEqual("Wal");
    })
  })
});
