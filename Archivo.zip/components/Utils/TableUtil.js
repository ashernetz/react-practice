export default class TableUtil {
  static alphabetSort(value1, value2) {

      if (value1 > value2) {
        return 1;
      }
      if (value2 > value1) {
        return -1;
      }
      return 0;
    }

  static getDynamicScrollableColumnsAreaWidth(minColWidth, numStaticColumns, numDynamicColumns) {
    return minColWidth * (numStaticColumns * numDynamicColumns);
  }

  static customRankSorter(a,b, sortDirection) {
    if (sortDirection == "ascend") {
        if (!a.rank) {
            return 1;
        }
        if (!b.rank) {
            return -1;
        }
    } else {
        if (!a.rank) {
            return -1;
        }
        if (!b.rank) {
            return 1;
        }
    }
    return a.rank - b.rank;    
  };
}