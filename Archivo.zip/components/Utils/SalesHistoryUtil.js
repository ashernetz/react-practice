export default class SalesHistoryUtil {

    static reverse(salesHistoryMap) {
        let reversed = [];
        let count = 0;

        if(salesHistoryMap != null) {
            for (let index = salesHistoryMap.length - 1; index >= 0;
                index--) {
                reversed[count] = salesHistoryMap[index];
                count++;
            }
        }
        return reversed;
    }
}