import { sortByFiscalWeek, formatSalesNumber } from '../DiscountsUtils';

describe('sortByFiscalWeek() function', () => {
  it('sorts by week', () => {
    const weeks = [
      { week: 'Fiscal Week 2 of 2023' },
      { week: 'Fiscal Week 1 of 2023' },
    ];

    const expected = [
      { week: 'Fiscal Week 1 of 2023' },
      { week: 'Fiscal Week 2 of 2023' },
    ];

    expect(sortByFiscalWeek(weeks)).toEqual(expected);
  });

  it('sorts by year', () => {
    const weeks = [
      { week: 'Fiscal Week 1 of 2023' },
      { week: 'Fiscal Week 1 of 2022' },
    ];

    const expected = [
      { week: 'Fiscal Week 1 of 2022' },
      { week: 'Fiscal Week 1 of 2023' },
    ];

    expect(sortByFiscalWeek(weeks)).toEqual(expected);
  });

  it('sorts by extra condition', () => {
    const weeks = [
      { week: 'Fiscal Week 1 of 2023', order: 2 },
      { week: 'Fiscal Week 1 of 2023', order: 1 },
    ];

    const expected = [
      { week: 'Fiscal Week 1 of 2023', order: 1 },
      { week: 'Fiscal Week 1 of 2023', order: 2 },
    ];

    const extraCondition = (a, b) => a.order - b.order;

    expect(sortByFiscalWeek(weeks, extraCondition)).toEqual(expected);
  });
});

describe('formatSalesNumber() function', () => {
  it.each([
    [{ salesDollars: 11, graphUnit: 42 }, '$11.00'],
    [{ graphUnit: 42 }, '$42.00'],
    [{}, 'No Data'],
  ])('formats sales number - case %#', (value, expected) => {
    expect(formatSalesNumber(value)).toEqual(expected);
  });
});
