export default class ProfileUtil {
  static userPositionList = ["Analyst", "Merchant", "Merchant Planner",
    "Other"];

  static getFirstName(user) {
    return user && user.firstName
        ? user.firstName.charAt(0).toUpperCase()
        + user.firstName.toLowerCase().slice(1) : null;
  }

  static getLastName(user) {
    return user && user.lastName
        ? user.lastName.charAt(0).toUpperCase()
        + user.lastName.toLowerCase().slice(1) : null;
  }

}