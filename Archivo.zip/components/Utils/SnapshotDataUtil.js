export default class SnapshotDataUtil {

  static FISCAL_WEEK_TIME_TRANSFORM = "Last WK";
  static QUARTER_TO_DATE = "QTD";
  static YEAR_TO_DATE = "YTD";
  static ROLLING_12_TIME_TRANSFORM = "Rolling 12 Periods";
  static ROLLING_3_PERIODS = "Rolling 3 Periods";
  static ROLLING_4_Week = "Rolling 4 Week";

  static TIME_TRANSFORM_TYPES = [
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "Sales",amount: "sales_FW",percentage:"sales_COMP_FW"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "Units",amount: "unit_FW",percentage:"unit_COMP_FW"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "AUR",amount: "aur_FW",percentage:"aur_PERCENT_FW"},

    {key: this.ROLLING_3_PERIODS, title: "Sales",amount: "sales_R3",percentage:"sales_COMP_R3"},
    {key: this.ROLLING_3_PERIODS, title: "Units",amount: "unit_R3",percentage:"unit_COMP_R3"},
    {key: this.ROLLING_3_PERIODS, title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.ROLLING_3_PERIODS, title: "AUR",amount: "aur_R3",percentage:"aur_PERCENT_R3"},

    {key: this.ROLLING_4_Week, title: "Sales",amount: "sales_R4",percentage:"sales_COMP_R4"},
    {key: this.ROLLING_4_Week, title: "Units",amount: "unit_R4",percentage:"unit_COMP_R4"},
    {key: this.ROLLING_4_Week, title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.ROLLING_4_Week, title: "AUR",amount: "aur_R4",percentage:"aur_PERCENT_R4"},

    {key: this.QUARTER_TO_DATE,title: "Sales",amount: "sales_QTD",percentage:"sales_COMP_QTD"},
    {key: this.QUARTER_TO_DATE,title: "Units",amount: "unit_QTD",percentage:"unit_COMP_QTD"},
    {key: this.QUARTER_TO_DATE,title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.QUARTER_TO_DATE,title: "AUR",amount: "aur_QTD",percentage:"aur_PERCENT_QTD"},

    {key: this.YEAR_TO_DATE, title: "Sales",amount: "sales_YTD",percentage:"sales_COMP_YTD"},
    {key: this.YEAR_TO_DATE, title: "Units",amount: "unit_YTD",percentage:"unit_COMP_YTD"},
    {key: this.YEAR_TO_DATE, title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.YEAR_TO_DATE, title: "AUR",amount: "aur_YTD",percentage:"aur_PERCENT_YTD"},

    {key: this.ROLLING_12_TIME_TRANSFORM, title: "Sales",amount: "sales_R12",percentage:"sales_COMP_R12"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "Units",amount: "unit_R12",percentage:"unit_COMP_R12"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "GM",amount: "grossMargin",percentage:"grossMarginPercent"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "AUR",amount: "aur_R12",percentage:"aur_PERCENT_R12"}

  ];

  static TIME_TRANSFORM_TYPES_TWO_YEAR = [
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "Sales",amount: "sales_FW", percentage: "comp_PERCENT_TWO_YEAR_FW"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "Units",amount: "unit_FW", percentage: "comp_UNITS_PERCENT_TWO_YEAR_FW"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "AUR",amount: "aur_FW"},


    {key: this.ROLLING_3_PERIODS, title: "Sales",amount: "sales_R3", percentage: "comp_PERCENT_TWO_YEAR_R3"},
    {key: this.ROLLING_3_PERIODS, title: "Units",amount: "unit_R3", percentage: "comp_UNITS_PERCENT_TWO_YEAR_R3"},
    {key: this.ROLLING_3_PERIODS, title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.ROLLING_3_PERIODS, title: "AUR",amount: "aur_R3"},


    {key: this.ROLLING_4_Week, title: "Sales",amount: "sales_R4", percentage: "comp_PERCENT_TWO_YEAR_R4"},
    {key: this.ROLLING_4_Week, title: "Units",amount: "unit_R4", percentage: "comp_UNITS_PERCENT_TWO_YEAR_R4"},
    {key: this.ROLLING_4_Week, title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.ROLLING_4_Week, title: "AUR",amount: "aur_R4"},


    {key: this.QUARTER_TO_DATE,title: "Sales",amount: "sales_QTD", percentage: "comp_PERCENT_TWO_YEAR_QTD"},
    {key: this.QUARTER_TO_DATE,title: "Units",amount: "unit_QTD", percentage: "comp_UNITS_PERCENT_TWO_YEAR_QTD"},
    {key: this.QUARTER_TO_DATE,title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.QUARTER_TO_DATE,title: "AUR",amount: "aur_QTD"},


    {key: this.YEAR_TO_DATE, title: "Sales",amount: "sales_YTD", percentage: "comp_PERCENT_TWO_YEAR_YTD"},
    {key: this.YEAR_TO_DATE, title: "Units",amount: "unit_YTD", percentage: "comp_UNITS_PERCENT_TWO_YEAR_YTD"},
    {key: this.YEAR_TO_DATE, title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.YEAR_TO_DATE, title: "AUR",amount: "aur_YTD"},


    {key: this.ROLLING_12_TIME_TRANSFORM, title: "Sales",amount: "sales_R12", percentage: "comp_PERCENT_TWO_YEAR_R12"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "Units",amount: "unit_R12", percentage: "comp_UNITS_PERCENT_TWO_YEAR_R12"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "GM",amount: "grossMargin", percentage: "grossMarginPercent"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "AUR",amount: "aur_R12"}
  ];
}