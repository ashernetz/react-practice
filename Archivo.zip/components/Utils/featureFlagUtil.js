function isFeatureEnabledForUser(arrayOfUsers, loggedInLDAP) {
    let enabled;
    if (Array.isArray(arrayOfUsers)) {
        if (arrayOfUsers.length > 0) {
            let ldaps = arrayOfUsers.map(ldap => ldap.toUpperCase())
            enabled = ldaps.includes(loggedInLDAP.toUpperCase());
        } else {
            enabled = true
        }
    }
    // This is worth keeping for screenshots to prove your feature toggle works
        // console.log("Enabled Users: ", arrayOfUsers, "Logged in User: ", loggedInLDAP, "Show new chart: ", enabled)
    return enabled
}

export {
    isFeatureEnabledForUser
}