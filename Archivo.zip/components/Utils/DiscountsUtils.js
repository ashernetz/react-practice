import { formatNumberToCompact } from './CommonUtil';

const sortByFiscalWeek = (fiscalWeekArray, extraCondition) => {
    return fiscalWeekArray.sort((codeRowA, codeRowB) => {
        const [fiscalStringA, weekAndYearA] = codeRowA.week.split("Fiscal Week");
        const [weekA, yearA] = weekAndYearA.split("of").map(number => parseInt(number));

        const [fiscalStringB, weekAndYearB] = codeRowB.week.split("Fiscal Week");
        const [weekB, yearB] = weekAndYearB.split("of").map(number => parseInt(number));
        if (extraCondition && weekA === weekB && yearA === yearB) {
            return extraCondition(codeRowA, codeRowB)
        }
        if (yearA === yearB) {
            return weekA > weekB ? 1 : -1;
        }
        return yearA > yearB ? 1 : -1;
    })
}

function formatSalesNumber({ salesDollars, graphUnit }) {
  const sales = salesDollars || graphUnit;

  return typeof sales === 'number'
    ? `$${formatNumberToCompact(sales)}`
    : 'No Data';
}

export { sortByFiscalWeek, formatSalesNumber }