export default class CPIUtil {

  static findCPIColor = (cpiDaily) => {
    let cpiColor = "-black"
    if (cpiDaily) {
      cpiColor = cpiDaily < 1 ? "-green" : "-red"
    }
    return cpiColor;
  }

  static formatCPI = (cpiDaily) => {
    return  cpiDaily.toFixed(2);
  };

  static defaultCPIData = (defaultValue="-") => {
      return ["3141", "6488", "588623", "18214", "527", "1"].reduce((total, current) => {
          total[current] = defaultValue;
          return total;
      }, {});
  };

  static  competitorCPIName = {

      "3141": "Low",
      "6488": "Men",
      "588623": "F&D",
      "18214": "Amz",
      "527":"Wal",
      "1":"Amz Mkt"
  };

  static displayCPIOrder = ["3141", "6488", "588623", "18214", "527", "1"];

  static cpiThresholdFilter = (salesCoverage) => {
    return salesCoverage >= 25;
  }

  static mergeCPIData = (defaultValue="-",cpiData=[])=> {
    let aggregatedData = cpiData.reduce((total, current) => {
      if(this.cpiThresholdFilter(current.cpiSalesCovDlyPercentage)){
        total[current.competitorId] = current;
      }
      return total;
    }, {});

    return {...this.defaultCPIData(defaultValue),...aggregatedData};
  };

  };
