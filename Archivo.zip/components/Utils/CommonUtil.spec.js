import {
    formatNumberToCompact,
    minMaxRetailFormatter,
    customGenericDateFormatter,
    dcsFormatter,
    dcsFormatterWithoutHyphen,
    convertSearchTextToItemList,
    isErroredResponse,
    combineDataSets,
    sortDataByValue,
    getUniqueList, formatCamelCaseString,
} from './CommonUtil';

describe("CommonUtil", () => {

    describe("combineDataSets()", () => {
        let array1 = ["Jithu", "Joe"];
        let array2 = ["Then", "Cole"];
        it("returns a concatenated version of two arrays", () => {
            expect(combineDataSets(array1, array2)).toEqual(["Jithu", "Joe", "Then", "Cole"]);
        })
    });

    describe("sortDataByValue()", () => {
        let arrayOfObjects = [{age: 65}, {age: 23}, {age: 12}, {age: 34}];
        it("sorts an array of objects by the specified value of each object", () => {
            expect(sortDataByValue(arrayOfObjects, "age")).toEqual([{age: 12}, {age: 23}, {age: 34}, {age: 65}])
        })
    });

    describe("getUniqueList()", () => {
        it("returns unique values from an array of objects given a key", () => {
            let array = [
                {company: "Low", price: 23.2},
                {company: "THD", price: 23.2},
                {company: "Low", price: 23.2},
                {company: "Men", price: 23.2},
                {company: "F&D", price: 23.2},
                {company: "F&D", price: 23.2},
                {company: "Shw", price: 23.2}
            ]
            expect(getUniqueList(array, "company")).toEqual(["Low", "THD", "Men", "F&D", "Shw"])
        })
    });

    describe("formatNumberToCompact()-thousands", () => {
        it('correctly compacts thousands = #.##K', () => {
            expect(formatNumberToCompact(1000)).toEqual("1.00K")
        })
    });

    describe("formatNumberToCompact()-millions", () => {
        it('correctly compacts millions = #.##M', () => {
            expect(formatNumberToCompact(1000000)).toEqual("1.00M")
        })
    });

    describe("formatNumberToCompact()-billions", () => {
        it('correctly compacts billions = #.##B', () => {
            expect(formatNumberToCompact(1000000000)).toEqual("1.00B")
        })

    });

    describe("formatNumberToCompact()-trillions", () => {
        it('correctly compacts trillions = #.##T', () => {
            expect(formatNumberToCompact(1000000000000)).toEqual("1.00T")
        })
    });

    describe("formatCamelCaseString()", () => {
        let inputText = 'tom';
        it('format camel case', () => {
            expect(formatCamelCaseString(inputText)).toEqual("Tom")
        })
    })

})
