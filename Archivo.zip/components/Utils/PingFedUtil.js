import axios from 'axios';
export default class PingFedUtil {

  static getAccessToken = async (ssoCode) => {

    return await axios.post("/api/sso/ssoLogin", {
        params: {code: ssoCode},
        headers: {
          headers: {"Content-type": "application/x-www-form-urlencoded"},
        }
      })


  };

  // static verifyAccessToken = async (access_token) => {
  //   return await axios.post('/api/sso/verifyToken', {
  //     params: {access_token},
  //     credentials: true,
  //     headers: {
  //       headers: {'Content-type': 'application/x-www-form-urlencoded'},
  //     },
  //   });
  // };

  static  redirectToLoginPingFed = (pingFedUrl, queryParams) => {
    let redirectPingFedUrl = pingFedUrl+"/as/authorization.oauth2?scope=openid&response_type=code&" + Object.entries(queryParams)
        .map(function([key, value]) {
          return [key, value].join('=');
        })
        .join('&');

    global.window && (global.window.location.href = redirectPingFedUrl);

  };

  static isCookiePresent = async () => {
    return await axios.get('/api/sso/check-cookie', {
      credentials: true,
    }).then(k => k.data.toString() === 'true').catch(k => false);
  };

  // static clearCookie = () => {
  //   let isCookieCleared = false;
  //   axios.get('/api/sso/clear-cookie', {
  //     credentials: true,
  //   }).then(k => isCookieCleared = true)
  // };
};
