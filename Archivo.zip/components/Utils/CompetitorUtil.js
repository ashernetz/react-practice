import LowersLocationData from "../MapComponent/CompetitorLocations/Lowes";
import MenardsLocationData from "../MapComponent/CompetitorLocations/Menards";
import FloorAndDecorLocationData from "../MapComponent/CompetitorLocations/FloorAndDecor";
import SherwinWilliamsLocationData from "../MapComponent/CompetitorLocations/SherwinWilliams";
import FloorAndDecorLogo from "../../images/FloorAndDecorLogo.svg";
import MenardsLogo from "../../images/MenardsLogo.svg";
import LowesLogo from "../../images/LowesLogo.svg";
import * as turf from "@turf/turf";
import SvgUtil from "./SvgUtil";
import ColorConstants from '../../constants/ColorConstants';

export default class CompetitorUtil {

  static getCompetitorPrimaryColor(competitor) {
    let id = competitor ? competitor.toString().toUpperCase() : null
    switch(id) {
      // LOWES
      case "LOWES":
        return ColorConstants.competitorPrimaryColors.Lowes;
      case "LOW":
        return ColorConstants.competitorPrimaryColors.Lowes;
      case "3141":
        return ColorConstants.competitorPrimaryColors.Lowes;
      
      // MENARDS
      case "MENARDS":
        return ColorConstants.competitorPrimaryColors.Menards;
      case "MEN":
        return ColorConstants.competitorPrimaryColors.Menards;
      case "6488":
        return ColorConstants.competitorPrimaryColors.Menards;
      
      // FLOOR & DECOR
      case "FLOOR & DECOR":
        return ColorConstants.competitorPrimaryColors["F&D"];
      case "F&D":
        return ColorConstants.competitorPrimaryColors["F&D"];
      case "588623":
        return ColorConstants.competitorPrimaryColors["F&D"];

      // SHERWIN WILLIAMS (NEED ID)
      case "SHERWIN":
        return ColorConstants.competitorPrimaryColors.Sherwin;
      case "SHW":
        return ColorConstants.competitorPrimaryColors.Sherwin;
      // case "####":
      //   return ColorConstants.competitorPrimaryColors.Sherwin;

      // AMAZON
      case "AMAZON":
        return ColorConstants.competitorPrimaryColors.Amazon;
      case "AMZ":
        return ColorConstants.competitorPrimaryColors.Amazon;
      case "18214":
        return ColorConstants.competitorPrimaryColors.Amazon;

      // WALMART
      case "WALMART":
        return ColorConstants.competitorPrimaryColors.Walmart;
      case "WAL":
        return ColorConstants.competitorPrimaryColors.Walmart;
      case "527":
        return ColorConstants.competitorPrimaryColors.Walmart;

      // AMAZON MARKET
      case "AMAZON MARKET":
        return ColorConstants.competitorPrimaryColors.Amazon_Market;
      case "AMAZON MKT":
        return ColorConstants.competitorPrimaryColors.Amazon_Market;
      case "AMZ MKT":
        return ColorConstants.competitorPrimaryColors.Amazon_Market;
      case "1":
        return ColorConstants.competitorPrimaryColors.Amazon_Market;

      default:
        return "";
    }
    
  }

  static getCompetitorData(competitor) {
    switch (competitor) {
      case "Lowes":
        return LowersLocationData;
      case "Menards":
        return MenardsLocationData;
      case "Floor & Decor":
        return FloorAndDecorLocationData;
      case "Sherwin Williams":
        return SherwinWilliamsLocationData;
      default:
        return [];
    }
  }

  static getCompetitorPointerColor(competitor) {
    switch (competitor) {
      case "Lowes":
        return "#0471af";
      case "Menards":
        return "#008938";
      case "Floor & Decor":
        return "#000";
      case "Sherwin Williams":
        return "#BE0000";
      default:
        return "";
    }
  }

  static findMarkerType(isDisaster, type) {
    return type ? type : isDisaster ? "disaster" : "pin-point";
  }
  static getCompetitorsList() {
    return [
      {
        competitor: "Lowes",
        isChecked: false,
        pointerColor: "#0471af",
      },
      {
        competitor: "Menards",
        isChecked: false,
        pointerColor: "#008938",
      },
      {
        competitor: "Floor & Decor",
        isChecked: false,
        pointerColor: "#ED1C24",
      },
      {
        competitor: "Sherwin Williams",
        isChecked: false,
        pointerColor: "#6a0dad",
      },
    ];
  }

  static getCompetitorName(competitorId, needShortName=false) {

    if (!competitorId) return "";
    
    let tempCompetitor = competitorId.toString();
    switch (tempCompetitor) {
      case "3141":
        return needShortName ? "Low" : "Lowes";
      case "6488":
        return needShortName ? "Men" : "Menards";
      case "588623":
        return needShortName ? "F&D" : "Floor & Decor";
      case "18214":
        return needShortName ? "Amz" : "Amazon";
      case "527":
        return needShortName ? "Wal" : "Walmart";
      case "1":
        return needShortName ? "Amz Mkt" : "Amazon Market";
      default:
        return "";
    }
  }

  static getCompetitorId(competitorName) {
    switch (competitorName) {
      case "Lowes":
        return "3141";
      case "Menards":
        return "6488";
      case "Floor & Decor":
        return "588623";
      case "Amazon":
        return "18214";
      case "Walmart":
        return "527";
      case "Amazon MKT":
        return "1";
      default:
        return "";
    }
  }

  static getStoreNameReplaceString(competitorId) {
    let tempCompetitor = competitorId.toString();
    switch (tempCompetitor) {
      case "3141":
        return "LOWE'S OF";
      case "588623":
        return "F&D OF";
      default:
        return "";
    }
  }
  static getCompetitorImage(competitorId) {
    let tempCompetitor = competitorId.toString();
    switch (tempCompetitor) {
      case "3141":
        return LowesLogo;
      case "6488":
        return MenardsLogo;
      case "588623":
        return FloorAndDecorLogo;
      default:
        return "";
    }
  }
  static getCompetitorLogoSvg(competitorId) {
    let tempCompetitor = competitorId.toString();
    switch (tempCompetitor) {
      case "3141":
        return SvgUtil.getLowesLogo();
      case "6488":
        return SvgUtil.getMenardsLogo();
      case "588623":
        return SvgUtil.getFnDLogo();
      case "18214":
        return SvgUtil.getAmazonLogo();
      case "527":
        return SvgUtil.getWalmartLogo();
      case "1":
        return SvgUtil.getAmazonMarketLogo();
      default:
        return "";
    }
  }

  static getCompetitorMarkerColor(competitorId) {
    let tempCompetitor = competitorId.toString();
    switch (tempCompetitor) {
      case "3141":
        return "0x0471af";
      case "6488":
        return "0x008938";
      case "588623":
        return "0x000000";
      default:
        return "";
    }
  }

  static getDateInStandardFormat = (inputDate) => {
    let convertedDate = new Date(inputDate);
    convertedDate.setTime(
      convertedDate.getTime() + convertedDate.getTimezoneOffset() * 60 * 1000
    );
    return (
      convertedDate.getMonth() +
      1 +
      "/" +
      convertedDate.getDate() +
      "/" +
      convertedDate.getFullYear()
    );
  };

  static availableCompetitorDataList = ["Lowes", "Floor & Decor", "Menards"];

  static getMilesBetweenTwoPointsInMap = (pointX, pointY) => {
    let from = turf.point([pointX.lng, pointX.lat]);
    let to = turf.point([pointY.lng, pointY.lat]);
    return turf.distance(from, to, { units: "miles" }).toFixed(2);
  };

  static convertDateStringToMillis = (inputDate) => {
    try {
      return new Date(inputDate).getTime();
    } catch (e) {
      return 0;
    }
  };

  static getFormattedCamelSpaceString = (inputText) => {
    let outputString = "";
    if (inputText) {
      outputString = inputText
        .toLowerCase()
        .split(" ")
        .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
        .join(" ");
    }

    let lastCommaIndex = outputString.lastIndexOf(",");
    if (lastCommaIndex > 0) {
      let firstPart = outputString.slice(0, lastCommaIndex);
      let secondPart = outputString.slice(lastCommaIndex).toUpperCase();
      outputString = firstPart + secondPart;
    }
    return outputString;
  };

  static competitorPriceDifferenceData = (competitorPrice, thdPrice) => {
    let priceDifference = 0;
    let cardShadeClassName = "";
    let priceDifferenceText = "Difference";
    let avgPrice = Number.parseFloat(competitorPrice);
    let thdSkuPrice = Number.parseFloat(thdPrice);
    if (avgPrice < thdSkuPrice) {
      cardShadeClassName = "-red";
      priceDifference = thdSkuPrice - avgPrice;
      priceDifferenceText = "Higher";
    } else if (avgPrice > thdSkuPrice) {
      cardShadeClassName = "-green";
      priceDifference = avgPrice - thdSkuPrice;
      priceDifferenceText = "Lower";
    }
    return { priceDifference, cardShadeClassName, priceDifferenceText };
  };

  static sortCompetitors(competitors) {
    /**
     * Sorts all the competitors based on the order defined below.
     * Assumes the input to be an array of objects.
     */

    if (!competitors || !Array.isArray(competitors)) {
      return competitors;
    }

    const SORT_ORDER = {
      3141: 1, // Lowe's
      6488: 2, // Menards
      588623: 3, // F&D
      18214: 4, // Amazon
      527: 5, // Walmart
      1: 6, //Amazon Market
    };

    competitors = competitors.map((competitor) => ({
      index:
        SORT_ORDER[
          competitor.competitorId || competitor.enemyId || competitor.id
        ] || Number.POSITIVE_INFINITY,
      targetObject: competitor,
    }));

    const sortedCompetitors = competitors.sort((c1, c2) => c1.index - c2.index);

    return sortedCompetitors.map((c) => c.targetObject);
  }

  static isCompetitorAllowed(competitorId) {
      return (["3141","6488","588623","18214","527","1"].includes(competitorId.toString()));
  }
}
