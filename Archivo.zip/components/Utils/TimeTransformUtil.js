export default class TimeTransformUtil {
  static FISCAL_WEEK_TIME_TRANSFORM = "Last WK";
  static QUARTER_TO_DATE = "QTD";
  static YEAR_TO_DATE = "YTD";
  static ROLLING_12_TIME_TRANSFORM = "Rolling 12 Periods";
  static ROLLING_3_PERIODS = "Rolling 3 Periods";
  static ROLLING_4_Week = "Rolling 4 Week";

  static COMP_YEAR_ONE = "1";

  static COMP_YEAR_TWO = "2";
  static TIME_TRANSFORM_TYPES = [
    {key: this.FISCAL_WEEK_TIME_TRANSFORM, title: "Fiscal Week "},
    {key: this.ROLLING_3_PERIODS, title: "Rolling 3 (R3)"},
    {key: this.ROLLING_4_Week, title: "Rolling 4 (R4)"},
    {key: this.QUARTER_TO_DATE, title: "Quarter to Date"},
    {key: this.YEAR_TO_DATE, title: "Year to Date"},
    {key: this.ROLLING_12_TIME_TRANSFORM, title: "Rolling 12 (R12)"}

  ];

  static TIME_TRANSFORM_YEARS = [
    {key: this.COMP_YEAR_ONE, title: "vLY"},
    {key: this.COMP_YEAR_TWO, title: "v2Y"}
  ]

  static perfWidgetTimeTransformObject = {
    [this.FISCAL_WEEK_TIME_TRANSFORM] : "FW",
    [this.ROLLING_3_PERIODS] : "R3",
    [this.ROLLING_4_Week] : "R4",
    [this.QUARTER_TO_DATE] : "QTD",
    [this.YEAR_TO_DATE] : "YTD",
    [this.ROLLING_12_TIME_TRANSFORM]:"R12"
  }
}
