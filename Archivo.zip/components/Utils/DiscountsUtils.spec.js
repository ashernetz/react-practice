import {sortByFiscalWeek} from './DiscountsUtils';

describe("sortByFiscalWeek", () => {
    it("sorts the fiscal week array correctly without extra condition", () => {
        const fiscalWeekArray = [
            {week: "Fiscal Week10 of 2023"},
            {week: "Fiscal Week7 of 2022"},
            {week: "Fiscal Week2 of 2023"},
            {week: "Fiscal Week5 of 2021"},
        ];

        const sortedArray = sortByFiscalWeek(fiscalWeekArray);

        const expectedSortedArray = [
            {week: "Fiscal Week5 of 2021"},
            {week: "Fiscal Week7 of 2022"},
            {week: "Fiscal Week2 of 2023"},
            {week: "Fiscal Week10 of 2023"},
        ];

        expect(sortedArray).toEqual(expectedSortedArray);
    });

    it("sorts fiscal week array in ascending order by year and week", () => {
        const fiscalWeekArray = [
            {week: "Fiscal Week2 of 2022"},
            {week: "Fiscal Week1 of 2023"},
            {week: "Fiscal Week4 of 2021"},
            {week: "Fiscal Week3 of 2022"},
        ];
        const sortedArray = sortByFiscalWeek(fiscalWeekArray);
        const expectedArray = [
            {week: "Fiscal Week4 of 2021"},
            {week: "Fiscal Week2 of 2022"},
            {week: "Fiscal Week3 of 2022"},
            {week: "Fiscal Week1 of 2023"},
        ];
        expect(sortedArray).toEqual(expectedArray);
    });

    it("sorts fiscal week array based on custom extra condition", () => {
        const fiscalWeekArray = [
            { week: "Fiscal Week2 of 2022", data: "A" },
            { week: "Fiscal Week1 of 2023", data: "D" },
            { week: "Fiscal Week1 of 2022", data: "C" },
            { week: "Fiscal Week2 of 2022", data: "B" },
        ];

        const customCondition = (rowA, rowB) => {
            return rowB.data.localeCompare(rowA.data, undefined, { sensitivity: 'base' });
        };

        const sortedArray = sortByFiscalWeek(fiscalWeekArray, customCondition);
        const expectedArray = [
            { week: "Fiscal Week1 of 2022", data: "C" },
            { week: "Fiscal Week2 of 2022", data: "B" },
            { week: "Fiscal Week2 of 2022", data: "A" },
            { week: "Fiscal Week1 of 2023", data: "D" },
        ];

        expect(sortedArray).toEqual(expectedArray);
    });
});
