function excelDownload(fileName,response) {
    if (typeof window.navigator.msSaveBlob !== "undefined") {
      // IE workaround
      window.navigator.msSaveBlob(response, fileName);
    } else {
      let fileURL = URL.createObjectURL(response);
      let a = document.createElement("a");
      a.href = fileURL;
      a.setAttribute("download", fileName);
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
}

function appendTimeToFileName(fileName) {
  let currentTime = new Date();
  return fileName + "_" + (currentTime.getMonth() + 1) + "-" + currentTime.getDate()
  + "-" + currentTime.getFullYear() + "_" + currentTime.getHours() + "-"
  + currentTime.getMinutes() + "-" + currentTime.getSeconds();
}

export {excelDownload,appendTimeToFileName}