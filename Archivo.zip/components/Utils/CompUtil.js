import React from "react";
import CompetitorUtil from './CompetitorUtil';
import {ArrowDownOutlined, ArrowUpOutlined} from "@ant-design/icons";
export default class CompUtil {

  static findPercentageUpOrDown  (value)  {
    let className = "";
    if (value && !isNaN(value)) {
      className = value > 0 ? "arrow-up" : "arrow-down";
    }
    return className;
  };

  static getArrowUpDownComponent = (upDownValue,extraProps) => {
    if(upDownValue ==="arrow-up"){
      return <ArrowUpOutlined {...extraProps}/>;
    }else if(upDownValue ==="arrow-down"){
      return <ArrowDownOutlined {...extraProps}/>;
    }else return null;
  };

  static findCompDataUpOrDown  (value)  {
    let className = "text-endson";
    if (value && !isNaN(value) && value !== 0) {
      className = value > 0 ? "text-endson-up" : "text-endson-down";
    }
    return className;
  };


  static formatCompData  (value)  {
    let output = "N/A";
    if (value && !isNaN(value) && value !== 0) {
      output = value + "%"
    }
    return output;
  };

  static isCompDataAvailable  (value)  {
    let output = false;
    if (value && !isNaN(value) && value !== 0) {
      output = true;
    }
    return output;
  };

  static formatPrice  (value, isPennies)  {
    let output = 0;
    if (value && !isNaN(value)) {
      if (isPennies) {
        output = Number((value/100).toFixed(2)).toLocaleString('en',{ minimumFractionDigits: 2 });
      } else {
        output = Number(value.toFixed(2)).toLocaleString('en',{ minimumFractionDigits: 2 });
      }
    }
    else {
      output = value
    }
    return output === 0 ? "0.00" : output;
  };

 
  static formatLocationFromCompetitorName(name) {
    let output = "";
    if(name){
      output = name.replace(/Lowe's/gi, "").replace(/F&D/gi, "").replace(/Menards/gi, "").replace(/of/gi, "");
    }
    return CompetitorUtil.getFormattedCamelSpaceString(output);
  }

  static formatMuMdPrice(value,isCompact) {
    let result = 0;
    if (value && !isNaN(value)) {
      let compactOption = { notation: "compact" , compactDisplay: "short"};
      let generalOption = {style: 'currency', currency: 'USD',maximumFractionDigits: 2,minimumFractionDigits: 2 };
      if(isCompact){
        generalOption = {...generalOption,...compactOption}
      }
      result = Intl.NumberFormat('en-US', { ...generalOption}).format(Number.parseFloat(value));
    } else {
      result = value
    }
    return result === 0 ? "$ --" : result;
  }

  static findCompColor  (value)  {
    let color = "black";
    if (value && !isNaN(value) && value !== 0) {
      color = value > 0 ? "green" : "red";
    }
    return color;
  };

};
