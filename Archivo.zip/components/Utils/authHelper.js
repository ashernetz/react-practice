import Cookies from 'universal-cookie';
import LoginServices from '../../services/LoginServices'
export default class Authentication {

    static async isAuthenticated() {
        let cookies = new Cookies();
        let thdsso = cookies.get('THDSSO');

        if (thdsso) {
            return this.checkIsSessionValid();
        } else {
            this.clearSession();
            return  Promise.resolve(false);
        }
    }

    static async checkIsSessionValid() {
        return await LoginServices.isSessionValid()
            .then(  (json) => {
                return json.data.Valid;
            })
            .catch( (error) => {
                console.log("isSessionValid error", error);
                return false;
            });
    }

    static async getUserProfileFromToken() {
        return LoginServices.getUserProfileFromToken().then( json => {
                return json.data;

            }

        ).catch(error => {
            console.log(error);
            return {};
        })
    }

    static clearSession() {
        let cookies = new Cookies();
        cookies.remove('THDSSO', {'domain': '.homedepot.com'});
        sessionStorage.removeItem('user');
    }

    static getUserProfile(state) {
        let userProfile = null;

        if (state.user) {
            userProfile = state.user;
        } else if (sessionStorage.getItem('user')) {
            userProfile = JSON.parse(atob(sessionStorage.getItem('user')));
        }

        return userProfile;
    }
}