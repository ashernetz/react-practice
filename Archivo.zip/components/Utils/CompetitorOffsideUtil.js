import * as turf from "@turf/turf";
import thdStores from "../MapComponent/CompetitorLocations/THDstores";
import CompetitorUtil from "./CompetitorUtil";
import nearbyStores
  from "../MapComponent/CompetitorLocations/offside-data/NearbyStores";

const calculateNearbyStoresData = (mileRadius) => {
  let nearbyStoreMap = {"Lowes": {}, "Menards": {}, "Floor & Decor": {}};
  Object.keys(nearbyStoreMap).forEach(competitor => {

    CompetitorUtil.getCompetitorData(competitor).forEach(compStore => {
      let storeList = [];
      let from = turf.point([compStore.longitudeNumber, compStore.latitudeNumber]);
      let buffered = turf.buffer(from, mileRadius, {units: 'miles'});

      Object.values(thdStores).forEach(thdStore => {
        if (thdStore.longitudeNumber && thdStore.latitudeNumber) {
          let to = turf.point([thdStore.longitudeNumber, thdStore.latitudeNumber]);

          if (turf.booleanPointInPolygon(to, buffered)) {
            storeList.push(thdStore.storeId);
          }
        }

      });

      nearbyStoreMap[competitor][compStore.storeId] = storeList;
    });
  });

  console.log("test="+ JSON.stringify(nearbyStoreMap));

};

const findOffsideValue=(offsideMap,thdStoreRetailMap,retailAmount,compStore,competitorName) =>{
  if (retailAmount) {
    let competitorAmount = Number.parseFloat(retailAmount);
    if(nearbyStores[competitorName] && nearbyStores[competitorName][compStore]){
    nearbyStores[competitorName][compStore].forEach(thdStore => {
      if (thdStoreRetailMap.has(thdStore.toString())) {
        let offSidePercent = (((Number.parseFloat(thdStoreRetailMap.get(thdStore.toString()))
            - competitorAmount) / competitorAmount) * 100);
        offSidePercent = Math.floor(offSidePercent * 100) / 100;
        if (offsideMap[competitorName].has(offSidePercent)) {
          offsideMap[competitorName].get(offSidePercent)["thdStores"].push(thdStore);
          offsideMap[competitorName].get(offSidePercent)["competitorStores"].push(Number.parseInt(compStore));

        } else {
          offsideMap[competitorName].set(offSidePercent, {thdStores:[thdStore],competitorStores:[Number.parseInt(compStore)]});
        }
      }
    });
    }
  }
};

// const getDefaultOffsidePercentage = (percentages) => {
//   if (percentages) {
//     percentages.sort((a,b)=>a-b);
//     return [percentages[0], percentages[percentages.length - 1]];
//   } else {
//     return [0, 0];
//   }
// };

// const getHistoslideDataOld = (offsideMap) => {
//
// let data = [];
//   if (offsideMap) {
//     let percentages = [...offsideMap.keys()];
//
//     percentages.sort((a,b)=>a-b);
// data.push({x0:percentages[0]-5,x:percentages[0],y:0});
//
//     let count = 0;
//     while(count !== percentages.length-1){
//
//         data.push({
//           x0: percentages[count],
//           x:  percentages[count+1],
//           y: offsideMap.get(percentages[count])["thdStores"].length
//         });
//
//
//       count = count+1;
//
//     }
//     data.push({x0:percentages[percentages.length-1],x:percentages[percentages.length-1]+5,y:0});
//
//   };
//   return data;
// ;}

// const getHistoslideData2nd = (offsideMap) => {
//
//   let data = [];
//   let minimum = 0;
//   let maximum = 0;
//   if (offsideMap) {
//     let percentages = [...offsideMap.keys()];
//     percentages.sort((a,b)=>a-b);
//     // let minDiff = percentages[1]-percentages[0];
//     // for (let i = 2 ; i != percentages.length ; i++) {
//     //   minDiff = Math.min(minDiff, percentages[i]-percentages[i-1]);
//     // }
//     // minDiff = minDiff/2;
//     let minDiff=1;
//     minimum = parseFloat(Number(percentages[0]-minDiff).toFixed(2));
//     maximum = parseFloat(Number(percentages[percentages.length-1]+minDiff).toFixed(2));
//     let totalCount = percentages.length;
//     //let addWidth = (percentages[totalCount-1]-percentages[0])/(totalCount*2);
//
//
//     let count = 0;
//     while(count !== percentages.length-1){
//       // if(count === 0){
//       //   data.push({
//       //     x0: percentages[count]-5,
//       //     x:  percentages[count],
//       //     y: offsideMap.get(percentages[count])["thdStores"].length
//       //   });
//       // }else {
//       data.push({
//         x0: parseFloat(Number(percentages[count]-minDiff).toFixed(2)),
//         x: parseFloat(Number(percentages[count]+minDiff).toFixed(2)),
//         y: offsideMap.get(percentages[count])["thdStores"].length + 100
//       });
//       //}
//
//       count = count+1;
//
//     }
//
//   };
//   return {data,minimum,maximum};
// };

// const getHistoslideData3rd = (offsideMap) => {
//
//   let data = [];
//   let minimum = 0;
//   let maximum = 0;
//   if (offsideMap) {
//     let percentages = [...offsideMap.keys()];
//
//     percentages.sort((a,b)=>a-b);
//
//     minimum = parseFloat(Number(percentages[0]-5).toFixed(2));
//     maximum = parseFloat(Number(percentages[percentages.length-1]+5).toFixed(2));
//
//     data.push({x0:percentages[0]-5,x:percentages[0],y:0});
//
//     let count = 0;
//     while(count !== percentages.length-1){
//
//       data.push({
//         x0: percentages[count],
//         x:  parseFloat(Number(percentages[count+1]-0.1).toFixed(2)),
//         y: offsideMap.get(percentages[count])["thdStores"].length + 30
//       });
//
//       count = count+1;
//
//     }
//     data.push({x0:percentages[percentages.length-1],x:percentages[percentages.length-1]+5,y:0});
//
//   };
//   return {data,minimum,maximum};
//   ;}

// const getHistoslideDataChange= (offsideMap,minMaxValue) => {
//
//   let data = [];
//   let barGraphDataMap = new Map();
//   let minMaxStoreCount = [0,0];
//
//   if (offsideMap) {
//
//     offsideMap.forEach((v, k) => {
//       let flooredValue = Math.floor(k);
//       let storeCount = v.thdStores.length;
//
//       if (flooredValue <= minMaxValue[0]) {
//         minMaxStoreCount[0] = minMaxStoreCount[0] + storeCount;
//       } else if (flooredValue >= minMaxValue[1]) {
//         minMaxStoreCount[1] = minMaxStoreCount[1] + storeCount;
//       } else {
//         if (barGraphDataMap.has(flooredValue)) {
//           storeCount = storeCount + barGraphDataMap.get(flooredValue);
//         }
//         barGraphDataMap.set(flooredValue, storeCount);
//       }
//     });
//
//     data.push({x0:minMaxValue[0],x:minMaxValue[0]+1,y:minMaxStoreCount[0]});
//     data.push({x0:minMaxValue[1]-1,x:minMaxValue[1],y:minMaxStoreCount[1]});
//
//     barGraphDataMap.forEach((v,k)=>{
//       data.push({
//         x0: k,
//         x: k+1,
//         y: v> 500 ? 100 : v
//       });
//     });
//
//   }
//   return {data};
// };

const getHistoslideData= (offsideMap,minMaxValue) => {

  let data = [];
  let differenceInInterval = {5:0.5,10:1,15:1.5,20:2,25:2.5};

  let barStartingCount = minMaxValue[0];
  let difference = differenceInInterval[minMaxValue[1].toString()];
  if (offsideMap) {
    let isFinalDataAdded = false;
  let totalPointRange = [...offsideMap.keys()];

    // data.push({x0:minMaxValue[0],x:minMaxValue[0]+difference,y:minMaxStoreCount[0]});
    // data.push({x0:minMaxValue[1]-difference,x:minMaxValue[1],y:minMaxStoreCount[1]});

    let filterPoints = (point) => {return point <= barStartingCount+difference};
    let filterPointsWithDiff = (point) => {return point > barStartingCount &&  point <= barStartingCount+difference};
    while(barStartingCount+difference<=minMaxValue[1]-difference && totalPointRange.length !== 0){
      if(barStartingCount === minMaxValue[0]){
        let totalStores = new Set();
        let filteredPoints = totalPointRange.filter(filterPoints);
        filteredPoints.forEach(point=>{
          offsideMap.get(point).thdStores.forEach(k=>totalStores.add(k));
          totalPointRange.splice(totalPointRange.indexOf(point),1)});
        data.push({x0:minMaxValue[0],x:minMaxValue[0]+difference,y: totalStores.size});
      }else {
        let totalStores = new Set();
        let filteredPoints = totalPointRange.filter(filterPointsWithDiff);
        filteredPoints.forEach(point=>{
          offsideMap.get(point).thdStores.forEach(k=>totalStores.add(k));
          totalPointRange.splice(totalPointRange.indexOf(point),1)});
        if(totalStores.size!==0){
          if(barStartingCount+difference  === minMaxValue[1]){
            isFinalDataAdded = true;
          }
          data.push({x0:barStartingCount,x:barStartingCount+difference,y:totalStores.size});

        }
      }
      barStartingCount = barStartingCount + difference;


    }

    if(totalPointRange.length !== 0){
      let totalStores = new Set();
      totalPointRange.forEach(point => {
        offsideMap.get(point).thdStores.forEach(k=>totalStores.add(k));

      });
      isFinalDataAdded = true;
      data.push({x0:minMaxValue[1]-difference,x:minMaxValue[1],y:totalStores.size});

    }

    if(!isFinalDataAdded){
      data.push({x0:minMaxValue[1]-difference,x:minMaxValue[1],y:0});

    }


  }
  return {data};
};
export {calculateNearbyStoresData,findOffsideValue,getHistoslideData};