import React, {Component} from 'react';
import SkuContext from "../../../context/SkuContext";
import SalesHistoryChart from "../../ChartsComponent/SalesHistoryChart";

export default class SalesHistory extends Component {

    static contextType = SkuContext;

    render() {
        return(
          this.context.salesHistoryMap.get(this.props.storeId) && this.props.dataset === "salesHistoryLastTwelveWeeks" ?
            <SalesHistoryChart
              storeId = {this.props.storeId}
              pricePointColor = {this.props.pricePointColor}
              dataKey = {this.props.dataKey}
              dataset = {this.context.salesHistoryMap.get(this.props.storeId).salesHistoryLastTwelveWeeks}>
            </SalesHistoryChart> 
          :
            <SalesHistoryChart
              storeId = {this.props.storeId}
              pricePointColor = {this.props.pricePointColor}
              dataKey = {this.props.dataKey}
              dataset = {this.context.salesHistoryMap.get(this.props.storeId) ? this.context.salesHistoryMap.get(this.props.storeId).salesHistoryForecast : null}>
            </SalesHistoryChart>
        )
    }
}