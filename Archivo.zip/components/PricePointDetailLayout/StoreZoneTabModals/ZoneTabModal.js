import React, {Component} from 'react';
import { Table, Button, Row, Col, Typography, Modal, Divider } from 'antd';
import './StoreZoneTabModal.scss';
import SkuContext from "../../../context/SkuContext";
import SkuCard from "../../SkuDetailComponent/SkuCard/SkuCard";
import CompUtil from "../../Utils/CompUtil";


const {Text} = Typography;
const storePriceColumns = [
    {
      title: 'Store#',
      dataIndex: 'storeId',

    },
    {
      title: 'Store Name',
      dataIndex: 'storeName',
    },
    {
      title: 'Markets',
      dataIndex: 'markets',
    },
    {
      title: 'Price',
      dataIndex: 'price',
      render: (text, record) => {
        return <Text>${record.price}</Text>
      }
    },
    {
      title: 'Status',
      dataIndex: 'status',
    }
  ];

const totalStoreColumns = [
  {
    title: 'Store#',
    dataIndex: 'storeId',

  },
  {
    title: 'Store Name',
    dataIndex: 'storeName',
  },
  {
    title: 'Markets',
    dataIndex: 'markets',
  },

];

export default class ZoneTabModal extends Component {
    static contextType = SkuContext;

    render() {
      let onlineUrl = "https://www.homedepot.com/s/"+this.context.skuNumber;
        return (
          <Modal
              open={true}
          onCancel={this.props.onClose}
          style={{width:"800px"}}
          footer={null}>
          <Row style={{marginBottom: 18}}>
          <Col span = {4} align="center">  <i className="material-icons storeModalIcon">blur_on</i> </Col>
           <Col span={20} className="modalHeaderTextCont">
           <Row>
            <Text type="zoneName">Zone: {this.props.zoneName}</Text><br />
            </Row>
            <Row type="flex">
              <Col span = {4}><Text type="secondary">Stores:</Text> <Text strong> {Object.keys(this.props.totalStoresMap).length}</Text>
              </Col>
              <Col span = {2}/>
              <Col>
              <Text type="secondary">Legacy Markets: </Text> <Text strong>{this.props.marketsCount}</Text>
              </Col>
            </Row>
            <Col/>
             </Col>
            <Divider/>
          </Row>
        <SkuCard isZoneModalOpen={true} retail={this.props.retail.split('-')[0]}/>
        <Row style={{padding:"10px 10px 0px 10px"}}> <Col span={11}>
       <Button key="back" ghost='true' type="primary" href={onlineUrl} target="blank" size="large" block>
      View Online
    </Button> 
    </Col>
    <Col span={1} />
      <Col span={11}>
       {this.context.skuData.allowExecution && this.context.skuData.allowZonePriceChange ? 
        <Button size="large" key="submit" type="primary" ghost='true' block onClick={this.props.onEditPriceClick}>
        Edit Price
      </Button> : null} </Col>
    </Row>
      <Divider />

      <div className="modalSection">
      <Row style={{padding:"2px", marginBottom: 12 , marginTop:12}}>
        <Col span={10}><Text className="modalHeading" align='right'>Zone Performance </Text></Col>
      </Row>
      <Row>
      
        <Col span={12} align="center"><Text className="storeModalPerfNum">{CompUtil.formatCompData(this.props.compSales) }{CompUtil.isCompDataAvailable(this.props.compSales) ? CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(this.props.compSales)) : null} </Text></Col>
        <Col span={12} align="center"><Text className="storeModalPerfNum">{CompUtil.formatCompData(this.props.compUnits) } {CompUtil.isCompDataAvailable(this.props.compUnits) ? CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(this.props.compUnits)) : null}</Text></Col>
      </Row>
      <Row style={{marginBottom: 12 }}>
        <Col span={12} align="center"><Text align='right' type="secondary"> Comp </Text></Col>
        <Col span={12} align="center"><Text align='right' type="secondary"> Units </Text></Col>
      </Row>
      </div>
      <Divider />

        <Row style={{padding:"2px", marginBottom: 12, marginTop: 12}}>
          <Col span={24} className="modalHeadingSpacer">
            <Text className="modalHeading">Price Discrepancies({Object.keys(this.props.priceDiscrepenciesMap).length})</Text><br />
          </Col>

          <Col span={24}>
            <Table columns={storePriceColumns} dataSource={this.props.priceDiscrepenciesMap} />
          </Col>
          </Row>
          <Row style={{padding:"2px", marginBottom: 12 , marginTop:12}}>
          <Col span={24} className="modalHeadingSpacer">
            <Text className="modalHeading">Total Stores({Object.keys(this.props.totalStoresMap).length})</Text><br />
          </Col>

          <Col span={24}>
            <Table columns={totalStoreColumns} dataSource={this.props.totalStoresMap} />
          </Col>
        </Row>
      
      </Modal>
        );
    }
}