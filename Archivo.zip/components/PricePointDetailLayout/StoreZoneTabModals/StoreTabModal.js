import React, {Component, Fragment} from "react";
import Icon from "@ant-design/icons";
import { Button, Card, Row, Col, Typography, Modal, Divider, Radio, Empty } from "antd";
import "./StoreZoneTabModal.scss";
import SkuContext from "../../../context/SkuContext";
import CompUtil from "../../Utils/CompUtil";
import { Table } from "antd";
import PriceChangeHistoryUtil from "../../Utils/PriceChangeHistoryUtil";
import PriceDataServices from "../../../services/PriceDataServices";
import SvgUtil from "../..//Utils/SvgUtil";
import { UXGraphSpin } from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXGraphSpin";
import NoSkuImage from "../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import SalesHistory from "./SalesHistory";
import StaticMap from "../../MapComponent/StaticMap/StaticMap";
import CompetitivePrice from "../../CompetitivePriceComponent/CompetitivePrice";
import CompetitorUtil from "../../Utils/CompetitorUtil";
import PriceHistoryChart from '../../GlobalComponents/PriceHistoryChart/PriceHistoryChart';
import moment from 'moment';
import {UXSpin} from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import THDPriceHistory from "../../GlobalComponents/PriceHistoryChart/THDPriceHistory";
import SkuApiHelper from "../../Helper/SkuApiHelper";

const { Text } = Typography;
const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;

const priceChangeHistoryColumns = [
  {
    title: "Date",
    dataIndex: "changeDate",
  },
  {
    title: "Event",
    dataIndex: "eventType",
  },
  {
    title: "Price",
    dataIndex: "retail",
    render: (text, record) => {
      let arrowUpOrDown = PriceChangeHistoryUtil.findRetailChangeUpOrDown(
          record.priceChange
      );
      return (
          <Text>
            ${record.retail}
            {CompUtil.getArrowUpDownComponent(arrowUpOrDown)}
          </Text>
      );
    },
  },
];

const NoData = (props) => {
  return (
      <Fragment>
        <Row justify="center" align="middle" >
          <Col span={14} offset={10}>{SvgUtil.getNoData()}</Col>
        </Row>
        <Row justify="center" align="middle">
          <Col span={13} offset={9} style={{paddingBottom:'4em'}}>
            <Text style={{fontSize: 'h4', color: '#BCBCBC'}}>
              No History Data Available
            </Text>
          </Col>
        </Row>
      </Fragment>
  );
};


export default class StoreTabModal extends Component {
  static contextType = SkuContext;
  state = {
    selectedTab: "performance-tab",
    nearestCompetitorData: [],
    competitorPriceHistoryData: [],
    loadingCompPriceHistoryData: false,
    loadingSalesHistory:true,
    loadingBayInfo: true
  };


  componentDidMount() {
    this.fetchNearestCompData();
    if (!this.context.storeBayMap.has(this.props.storeId)) {
      PriceDataServices.getAisleBay(this.context.skuNumber, this.props.storeId)
      .then((k) => {
        let storeBayMap = new Map(this.context.storeBayMap);
          storeBayMap.set(
              this.props.storeId,
              (k.data.storeSkus) ? k.data.storeSkus[0].aisleBayInfo : ""
          );
          this.context.updateStateFields({ storeBayMap });
      })
      .catch((e) => {
        console.log("Error in calling Aisle API" + e);
      }).finally(()=>  {this.setState({loadingBayInfo:false});});
    }else {
      this.setState({loadingBayInfo:false});
    }

    if (!this.context.storePlanogramUrlMap.has(this.props.storeId)) {
      PriceDataServices.getPlanogramInfo(
          this.context.skuNumber,
          this.props.storeId
      )
      .then((response) => {
        let storePlanogramUrlMap = new Map(this.context.storePlanogramUrlMap);

        storePlanogramUrlMap.set(
            this.props.storeId,
            this.formPlanogramUrl(response)
        );
        this.context.updateStateFields({ storePlanogramUrlMap });
      })
      .catch((error) => {
        console.log("Errorr on calling POG Info " + error);
      });
    }

    if (!this.context.storeVelocityMap.has(this.props.storeId)) {
      PriceDataServices.getSkuVelocity(
          this.context.skuNumber,
          this.props.storeId
      )
      .then((response) => {
        let storeVelocityMap = new Map(this.context.storeVelocityMap);
        storeVelocityMap.set(this.props.storeId, response.data);
        this.context.updateStateFields({ storeVelocityMap });
      })
      .catch((error) => {
        console.log(error);
      });
    }
    if (!this.context.salesHistoryMap.has(this.props.storeId)) {
      PriceDataServices.getSalesHistory(
          this.context.skuNumber,
          this.props.storeId,
          this.props.userId
      )
      .then((response) => {
        let salesHistoryMap = new Map(this.context.salesHistoryMap);
        salesHistoryMap.set(this.props.storeId, response.data);
        this.context.updateSalesHistory(salesHistoryMap);
      })
      .catch((error) => {
        console.log("Errorr on calling sales history endpoint " + error);
      })
      .finally(()=>  {this.setState({loadingSalesHistory:false});});
    }else {
      this.setState({loadingSalesHistory:false});
    }

    if (!this.context.storeContactsMap.has(this.props.storeId)) {
      PriceDataServices.getContacts(this.props.storeId)
      .then((response) => {
        if (response.data && Object.keys(response.data).length) {
          let storeContactsMap = new Map(this.context.storeContactsMap);
          storeContactsMap.set(this.props.storeId, response.data);
          this.context.updateStateFields({ storeContactsMap });
        }
      })
      .catch((error) => {
        console.log(error);
      });
    }

    if(!this.context.skuPriceChangeHistoryMap.storeHistoryMap.hasOwnProperty(this.props.storeId)){
      SkuApiHelper.fetchThdSkuStorePriceChangeHistory(this.context.skuNumber,this.props.storeId,this.context);
    }
    this.context.updateShowDimmer(false);
  }
  insertMissingCompetitors = (competitorStores) => {
    const updatedCompetitors = [...competitorStores];

    let walmartScrapeExists = false;
    let amazonScrapeExists = false;
    let amazonMktScrapeExists = false;

    updatedCompetitors.forEach((c) => {
      if (c.competitorId === 527) walmartScrapeExists = true;
      if (c.competitorId === 18214) amazonScrapeExists = true;
      if (c.competitorId === 1) amazonMktScrapeExists = true;
    });

    if (!walmartScrapeExists)
      updatedCompetitors.push({ competitorId: 527, name: "Walmart" });
    if (!amazonScrapeExists)
      updatedCompetitors.push({ competitorId: 18214, name: "Amazon" });
    if (!amazonMktScrapeExists)
      updatedCompetitors.push({ competitorId: 1, name: "Amazon Market" });

    return updatedCompetitors;
  };

  fetchNearestCompData = () => {
    let resultantData = {
      3141: { competitorId: 3141, name: "Lowe's" },
      6488: { competitorId: 6488, name: "Menards" },
      588623: { competitorId: 588623, name: "FnD" },
      18214: { competitorId: 18214, name: "Amazon" },
      527: { competitorId: 527, name: "Walmart" },
      1: { competitorId: 1, name: "Amazon Market" },
    };
    let thdSkuPrice = this.getRetailPrice();
    PriceDataServices.getNearestCompetitorData(
        this.context.skuNumber,
        this.props.storeId,
        this.props.config.competitorDataUrl
    )
    .then((response) => {
      let nearestCompetitorData =
          response.data && response.data.competitors
              ? Object.keys(response.data.competitors).map((key) => {
                let competitorData = response.data.competitors[key][0];

                if (competitorData.scaledPricePennies) {
                  competitorData.avgPrice =
                      competitorData.scaledPricePennies / 100;
                  competitorData = {
                    ...CompetitorUtil.competitorPriceDifferenceData(
                        competitorData.avgPrice,
                        thdSkuPrice
                    ),
                    ...competitorData,
                  };
                }

                return competitorData;
              })
              : Object.values(resultantData);

      nearestCompetitorData = this.insertMissingCompetitors(
          nearestCompetitorData.filter((row) => (CompetitorUtil.isCompetitorAllowed(row.competitorId)))
      );

      const sortedCompetitors = CompetitorUtil.sortCompetitors(
          nearestCompetitorData
      );

      this.setState((prevState) => ({
        ...prevState,
        nearestCompetitorData: sortedCompetitors,
      }));
    })
    .catch((error) => {
      const sortedCompetitors = CompetitorUtil.sortCompetitors(
          Object.values(resultantData)
      );
      this.setState((prevState) => ({
        ...prevState,
        nearestCompetitorData: sortedCompetitors,
      }));
      console.log(error);
    });
  };

  fetchCompetitorPriceHistory = (numberOfMonths) => {
    this.setState({loadingCompPriceHistoryData: true});
    let startDate, endDate;
    if (numberOfMonths) {
      startDate = moment().subtract(numberOfMonths, "months").format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    }

    PriceDataServices.getThdSkuStorePriceHistory(this.context.skuNumber, this.props.storeId, startDate, endDate)
    .then((response)=> {
      if(response.data && response.data.length > 0){
        response.data.forEach(row =>{
          row['priceHistory'] = row['priceHistory'].filter((history) => (CompetitorUtil.isCompetitorAllowed(history.competitorId)));
        })
      }
      this.setState({competitorPriceHistoryData: response.data})
    })
    .catch((error) => {
      console.log(error);
    }).finally(() => {
      this.setState({loadingCompPriceHistoryData: false});
    })
  };

  formPlanogramUrl(response) {
    let baseUrl =
        "http://webapps.homedepot.com/MST_IFC/rs/router/getDocumentum?";
    let params = new URLSearchParams();
    let storeId = this.props.storeId.toString().padStart(4, "0");
    if (response.data.resultSet.mocPlanogramTO.length > 0) {
      let isCorePresent = false;
      response.data.resultSet.mocPlanogramTO.forEach((data) => {
        if (data.dctmName.toUpperCase().includes("CORE")) {
          isCorePresent = true;
          params.append("dctm_id", data.dctmID);
          params.append("dctmttl", data.dctmTitleText);
        }
      });
      if (!isCorePresent) {
        params.append(
            "dctm_id",
            response.data.resultSet.mocPlanogramTO[0].dctmID
        );
        params.append(
            "dctmttl",
            response.data.resultSet.mocPlanogramTO[0].dctmTitleText
        );
      }
    } else {
      params.append("dctm_id", response.data.resultSet.mocPlanogramTO.dctmID);
      params.append(
          "dctmttl",
          response.data.resultSet.mocPlanogramTO.dctmTitleText
      );
    }
    params.append("str_id", storeId);
    params.append("dev_id", "MOTOROLA");

    return baseUrl + params;
  }

  promotionChartData = () => {
    let chartData = [];
    let store = this.props.storeId.toString();
    let storeDataMap = this.context.salesMetricsMap["storeKVIPricePointData"];
    if (storeDataMap && storeDataMap.hasOwnProperty(store)) {
      Object.keys(storeDataMap[store])
      .sort()
      .forEach((dataType) => {
        chartData.push({
          type: dataType,
          retail: storeDataMap[store][dataType],
        });
      });
    }
    return chartData;
  };

  initialGenerator = (name) => {
    let resultantInitial = "";
    let initials = name ? name.trim().split(" ") || [] : [];

    if (initials.length > 1) {
      resultantInitial =
          initials[0].substring(0, 1) +
          initials[initials.length - 1].substring(0, 1);
    }
    return resultantInitial;
  };

  nameGenerator = (name) => {
    let resultantName = "";
    if (name.length > 1) {
      resultantName = name.replace(/\(([^)]+)\)/g, "");
    }
    return resultantName;
  };

  scrollToElement = (data) => {
    this.setState({ selectedTab: data });
    document
    .getElementById(data + "-id")
    .scrollIntoView({ behavior: "smooth", block: "center" });
  };

  getRetailPrice = () => {
    let retailPrice = this.context.selectedPricePoint.split("-")[0];
    if (this.props.storeRetail) {
      retailPrice = this.props.storeRetail;
      if (retailPrice.includes("-") > 0) {
        retailPrice = retailPrice.split("-")[0];
      }
    }
    return retailPrice;
  };

  render() {
    let retailPrice = this.getRetailPrice();
    let onlineUrl = "https://www.homedepot.com/s/" + this.context.skuNumber;
    let onHandQuantity;
    let thdStoreHistory = PriceChangeHistoryUtil.getPriceChangeHistoryForStore(this.props.storeId, this.context.skuPriceChangeHistoryMap.storeHistoryMap);

    if (
        Object.keys(this.context.unitsOnHandMap).includes(
            this.props.storeId.toString()
        )
    ) {
      onHandQuantity = this.context.unitsOnHandMap[
          this.props.storeId.toString()
          ];
    }

    let storeContactInfo = this.context.storeContactsMap.has(this.props.storeId)
        ? this.context.storeContactsMap.get(this.props.storeId)
        : "";

    return (
        <Modal
            open={this.props.isOpen}
            onCancel={this.props.onClose}
            //destroyOnClose={true}
            footer={null}
        >
          <Row
              align="middle"
              style={{ marginBottom: 10 }}
              type="flex"
              gutter={[40, 0]}
          >
            <Col className="ant-col-18">
              <Row type="flex">
                <Col>
                  <i className="icon_hd-store-outlined storeModalIcon"></i>
                </Col>

                <Col className="modalHeaderTextCont">
                  <Row type="flex">
                    {" "}
                    <Col>
                      <Text type="storeName">
                        {this.props.storeName} #{this.props.storeId}
                      </Text>
                    </Col>
                  </Row>
                  <Row type="flex">
                    {" "}
                    <Col>
                      <Text type="storeAddress">{this.props.storeAddress} </Text>
                    </Col>
                  </Row>
                  {/* <Row><Text type="secondary">Store Sales Volume: <strong>High</strong></Text></Row> */}
                </Col>
              </Row>
            </Col>
            <Col className="ant-col-6">
              <Row type="flex" gutter={[22, 0]} justify="start" align="middle">
                {/* <Col>
                <Button
                    disabled={!this.context.storePlanogramUrlMap.has(this.props.storeId).toString()}
                    href={this.context.storePlanogramUrlMap.get(this.props.storeId)}
                    target= "_blank">
                   <Icon type="bank" style={{fontSize: 'xx-large',color: '#fa6304'}} />
                </Button>
                </Col> */}
                {/* <Col >

                  <Row type="flex" justify="center" align = "middle" ><Col className = {true? 'col-not-allowed':null}><a disabled={true}><Icon component = {() => SvgUtil.getBayIcon()}/></a>   </Col>  </Row>
                  <Row type="flex" justify="center" align = "middle"><Col><Text strong>Bay</Text>   </Col>  </Row>

                </Col> */}
                <Col>
                  {this.context.storePlanogramUrlMap.has(this.props.storeId) ? (
                      <div className="planogram">
                        <Row type="flex" justify="center" align="middle">
                          <Col>
                            <a
                                target="_blank"
                                rel="noopener noreferrer"
                                href={this.context.storePlanogramUrlMap.get(
                                    this.props.storeId
                                )}
                            >
                              <Icon component={() => SvgUtil.getPlanogramIcon()} />
                            </a>
                          </Col>
                        </Row>
                        <Row type="flex" justify="center" align="middle">
                          <Col>
                            <Text strong>Planogram</Text>
                          </Col>
                        </Row>
                      </div>
                  ) : null}
                </Col>
                {/* <Col>

                  <Row type="flex" justify="center" align = "middle" ><Col className = {true? 'col-not-allowed':null} ><Icon component = {() => SvgUtil.getDownloadIcon()}/>   </Col>  </Row>
                  <Row type="flex" justify="center" align = "middle" ><Col><Text strong>Download</Text>   </Col>  </Row>

                </Col> */}
                <Col />
              </Row>
            </Col>
          </Row>
          <Divider />

          <Row style={{ marginBottom: 24, marginTop: 24 }}>
            <Col span={4}>
              <img
                  src={
                    this.context.skuImageUrl === "no-sku-image"
                        ? NoSkuImage
                        : this.context.skuImageUrl
                  }
                  alt="SKU"
              />
            </Col>
            <Col className="modalProductTextCont" span={16}>
              <Row>
                <Text type="secondary skuVendorName">
                  {this.context.skuVendors}
                </Text>
              </Row>
              <Row>
                <Text className="skuProductName">
                  {this.context.skuDescription}
                </Text>
              </Row>
              <Row>
                <Text type="secondary">SKU {this.context.skuNumber}</Text>
              </Row>
              <Row className="storeModalDetailsCont" type="flex" gutter={20}>
                <Col>
                  <Text type="secondary">Units on Hand </Text>
                  <Text className="storeModalDM">{onHandQuantity===undefined?"":onHandQuantity}</Text>
                </Col>
                <Col>
                  <Text type="secondary">Aisle </Text>
                  {this.state.loadingBayInfo ? <UXSpin/> : <Text className="storeModalDM">
                    {(this.context.storeBayMap.get(this.props.storeId)) ? this.context.storeBayMap.get(this.props.storeId).aisle : 'NA'},
                  </Text>}

                  <Text type="secondary"> Bay </Text>
                  {this.state.loadingBayInfo ? <UXSpin/> :
                      <Text className="storeModalDM">
                        {(this.context.storeBayMap.get(this.props.storeId)) ? this.context.storeBayMap.get(this.props.storeId).bay : 'NA'}
                      </Text>
                  }
                </Col>
                <Col>
                  <Text type="secondary">Sku Velocity </Text>
                  <Text className="storeModalDM">
                    {" "}
                    {this.context.storeVelocityMap.get(this.props.storeId)}{" "}
                  </Text>
                </Col>
              </Row>
            </Col>
            <Col span={4}>
              <Row></Row>
              <Row>
                <Text className="storeModalPrice" align="right">
                  ${retailPrice}
                </Text>
              </Row>
              <Row>
                <Text className="storeModalStatus">
                  {" "}
                  {this.props.storeStatus}
                </Text>
              </Row>
            </Col>
          </Row>
          <Row className="viewOnlineRow">
            {" "}
            <Col span={11}>
              <Button
                  key="back"
                  type="primary"
                  ghost="true"
                  href={onlineUrl}
                  target="blank"
                  size="large"
                  block
              >
                View Online
              </Button>
            </Col>
            <Col span={2} />
            <Col span={11}>
              {this.context.skuData.allowExecution &&
              this.context.skuData.allowStorePriceChange ? (
                  <Button
                      key="submit"
                      size="large"
                      type="primary"
                      ghost="true"
                      block
                      onClick={this.props.onEditPriceClick}
                  >
                    Edit Price
                  </Button>
              ) : null}
            </Col>
          </Row>
          <div className="modalSection">
            <Row type="flex" gutter={[40, 0]}>
              <Divider />
            </Row>
            {/* <Tabs type="flex" justify="space-between" align="middle" size="large" style={{ textAlign: "center"}}
                  defaultActiveKey="performance-tab"
                  onTabClick={this.scrollToElement} selectedKeys={this.state.selectedTab}>
              <TabPane key="performance-tab" tab="Performance"/>
               <TabPane disabled key="competitive-tab" tab="Competitive"/>
              <TabPane key="price-history-tab" tab="Price History"/>
              <TabPane key="contacts-tab" tab="Contacts"/>
            </Tabs> */}

            <Row id="performance-tab-id" className="storePerfRow">
              <Col span={10}>
                <Text className="modalHeading" align="right">
                  Store Performance{" "}
                </Text>
              </Col>
            </Row>

            {/* !!!!   Add this back when we have more data that will need subheaders !!!!!
        <Row  style={{padding:"2px", marginBottom: 12 , marginTop:12}}><Col span={10}>
       <Text align='right' className="modalSubHeading"> Overview </Col>
        </Row></Text>*/}
            <Row>
              <Col span={12} align="center">
                <Text className="storeModalPerfNum">
                  {CompUtil.formatCompData(this.props.selectedComp)}
                  {CompUtil.isCompDataAvailable(this.props.selectedComp)
                      ? CompUtil.getArrowUpDownComponent(
                          CompUtil.findPercentageUpOrDown(this.props.selectedComp)
                      )
                      : null}{" "}
                </Text>
              </Col>
              <Col span={12} align="center">
                <Text className="storeModalPerfNum">
                  {CompUtil.formatCompData(this.props.selectedUnitComp)}{" "}
                  {CompUtil.isCompDataAvailable(this.props.selectedUnitComp)
                      ? CompUtil.getArrowUpDownComponent(
                          CompUtil.findPercentageUpOrDown(
                              this.props.selectedUnitComp
                          )
                      )
                      : null}
                </Text>
              </Col>{" "}
            </Row>
            <Row>
              <Col span={12} align="center">
                <Text type="secondary"> Sales </Text>
              </Col>
              <Col span={12} align="center">
                <Text type="secondary"> Units </Text>
              </Col>{" "}
            </Row>
          </div>

          <Row>
            <Col span={18}>
              <Text align="right"> Last 12 Weeks of Sales</Text>{" "}
            </Col>

            {this.context.salesHistoryMap.get(this.props.storeId) ? (
                <RadioGroup defaultValue="lastTwelveSales">
                  <RadioButton
                      onClick={this.props.changeChartType}
                      value="lastTwelveSales"
                  >
                    Sales
                  </RadioButton>
                  <RadioButton
                      onClick={this.props.changeChartType}
                      value="lastTwelveUnits"
                  >
                    Units
                  </RadioButton>
                </RadioGroup>
            ) : (
                this.state.loadingSalesHistory?<UXGraphSpin />:null
            )}

            {!this.state.loadingSalesHistory && <SalesHistory
                storeId={this.props.storeId}
                pricePointColor={this.props.pricePointColor}
                dataKey={this.props.lastTwelveChartType}
                dataset={"salesHistoryLastTwelveWeeks"}
            ></SalesHistory>}
          </Row>
          {!this.state.loadingSalesHistory && !this.context.salesHistoryMap.get(this.props.storeId) && <NoData/>}
          <Row>
            <Col span={18}>
              <Text align="right"> 12 Weeks Outlook from Last Year </Text>{" "}
            </Col>
            {this.context.salesHistoryMap.get(this.props.storeId) ? (
                <RadioGroup defaultValue="forecastSales">
                  <RadioButton
                      onClick={this.props.changeChartType}
                      value="forecastSales"
                  >
                    Sales
                  </RadioButton>
                  <RadioButton
                      onClick={this.props.changeChartType}
                      value="forecastUnits"
                  >
                    Units
                  </RadioButton>
                </RadioGroup>
            ) : (
                this.state.loadingSalesHistory?<UXGraphSpin />:null          )}

            {!this.state.loadingSalesHistory && <SalesHistory
                storeId={this.props.storeId}
                pricePointColor={this.props.pricePointColor}
                dataKey={this.props.forecastChartType}
                dataset={"salesHistoryForecast"}
            ></SalesHistory>}
          </Row>
          {!this.state.loadingSalesHistory && !this.context.salesHistoryMap.get(this.props.storeId) && <NoData/>}

          {/*<Divider />*/}

          {/*<Row align="middle" style={{marginBottom: 18}} type="flex"*/}
          {/*     gutter={[40, 0]}>*/}
          {/*  <Col span={24}>*/}
          {/*    <Row type="flex">*/}
          {/*      <Col className="modalHeaderTextCont">*/}
          {/*        <Row> <Text type="storeName">Competitive Price</Text></Row>*/}
          {/*      </Col>*/}
          {/*    </Row>*/}
          {/*  </Col>*/}
          {/*</Row>*/}

          <Divider />
          <Row id="price-history-tab-id" className="storePriceHistory">
            <Col span={24}>
              <Text className="modalHeading" align="right">
                Nearby Competitive Prices
              </Text>{" "}
            </Col>
          </Row>
          {this.state.nearestCompetitorData.filter(competitor => competitor.avgPrice).length > 0?(
              <CompetitivePrice
                  showLocationDetails
                  competitorDetails={this.state.nearestCompetitorData}
              />
          ):(
              <Row type="flex" gutter={[24, 24]}>
                <Col span={12}>
                  <Card>
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE}
                           description = "No Scrape Data">

                    </Empty>
                  </Card>
                </Col>
              </Row>
          )}
          <Divider />

          <PriceHistoryChart
              thdStorePriceHistory={PriceChangeHistoryUtil.reverse(thdStoreHistory)}
              competitorPriceHistory={this.state.competitorPriceHistoryData}
              fetchCompetitorPriceHistory={this.fetchCompetitorPriceHistory}
              headerTitle={"Competitive History"}
              loadingData={this.state.loadingCompPriceHistoryData}
          />

          <Divider />

              <THDPriceHistory
                  priceChangeHistory={PriceChangeHistoryUtil.reverse(thdStoreHistory)}
                  pricePointColor={this.props.pricePointColor}
                  isLoading={!this.context.skuPriceChangeHistoryMap.storeHistoryMap.hasOwnProperty(this.props.storeId)}
              />

          <Table
              columns={priceChangeHistoryColumns}
              dataSource={thdStoreHistory}
          />

          {/*<Divider />*/}
          {/*<Row style={{ padding: "2px", marginBottom: 12, marginTop: 15 }}>*/}
          {/*  <Col span={24}>*/}
          {/*    <Text className="modalHeading" align="right">*/}
          {/*      Price Point Distribution*/}
          {/*    </Text>{" "}*/}
          {/*  </Col>*/}
          {/*</Row>*/}
          {/*<Row>*/}
          {/*  <Col>*/}
          {/*    <ScatterChart*/}
          {/*        className="priceHistoryGraph"*/}
          {/*        width={700}*/}
          {/*        height={300}*/}
          {/*        margin={{ top: 20, right: 30, left: 10, bottom: 10 }}*/}
          {/*    >*/}
          {/*      <CartesianGrid trokeDasharray="3 3" />*/}
          {/*      <XAxis dataKey="type" />*/}
          {/*      <YAxis dataKey="retail" tickFormatter={(k) => "$" + k} />*/}
          {/*      <Tooltip*/}
          {/*          cursor={{ strokeDasharray: "3 3" }}*/}
          {/*          content={<CustomTooltip />}*/}
          {/*      />*/}
          {/*      <Scatter*/}
          {/*          data={this.promotionChartData()}*/}
          {/*          fill={this.props.pricePointColor}*/}
          {/*      />*/}
          {/*    </ScatterChart>*/}
          {/*  </Col>*/}
          {/*</Row>*/}


          <Divider />
          <Row
              id="contacts-tab-id"
              style={{ padding: "2px", marginBottom: 30, marginTop: 15 }}
          >
            <Col span={24}>
              {" "}
              <Text className="modalHeading">Contacts</Text>{" "}
            </Col>
          </Row>
          {storeContactInfo ? (
              <Row type="flex" justify="space-around" style={{ marginBottom: 60 }}>
                <Col span={1} />
                <Col span={11}>
                  <Row gutter={[0, 32]} style={{marginBottom: "32px"}}>
                    <Col span={24}>
                      <ContactCard
                          name={this.nameGenerator(storeContactInfo.storeManager)}
                          roleType="Store Manager"
                          phoneNumber={storeContactInfo.phoneNumber}
                          initials={this.initialGenerator(
                              storeContactInfo.storeManager
                          )}
                      />
                    </Col>
                  </Row>
                  <Row gutter={[0, 32]} style={{marginBottom: "32px"}}>
                    <Col span={24}>
                      <ContactCard
                          name={this.nameGenerator(storeContactInfo.districtManager)}
                          roleType="District Manager"
                          initials={this.initialGenerator(
                              storeContactInfo.districtManager
                          )}
                      />
                    </Col>
                  </Row>
                </Col>
                <Col span={1} />
                <Col span={11}>
                  <Row gutter={[0, 32]} style={{marginBottom: "32px"}}>
                    <Col span={24}>
                      <ContactCard
                          name={this.nameGenerator(
                              storeContactInfo.regionalMerchantManager
                          )}
                          roleType="Regional Merchant Manager"
                          initials={this.initialGenerator(
                              storeContactInfo.regionalMerchantManager
                          )}
                      />
                    </Col>
                  </Row>
                  <Row gutter={[0, 32]} style={{marginBottom: "32px"}}>
                    <Col span={24}>
                      <ContactCard
                          name={this.nameGenerator(
                              storeContactInfo.regionalVicePresident
                          )}
                          roleType="Regional Vice President"
                          initials={this.initialGenerator(
                              storeContactInfo.regionalVicePresident
                          )}
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>
          ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
          <Divider/>
          <div className="staticMapSection">
            <StaticMap
              apiKey={this.props.apiKey}
              zoom={17}
              scale={4}
              format={"png32"}
              mapWidth={"640"}
              mapHeight={"229"}
              storeAddress={this.props.storeAddress}
              storeLatitude={this.props.storeLatitude}
              storeLongitude={this.props.storeLongitude}
              markers={[
                {
                  color: "0xF96302",
                  size: "tiny",
                  scale: 2,
                  address: this.props.storeAddress,
                },
              ]}
            />
          </div>
          {/* <Modal
                destroyOnClose={true}
                title="Modify Price"
                visible={this.state.visibleModifyPrice}
                onOk={this.handleOkSendtoPacman}
                onCancel={this.handleCancelSendtoPacman}
                footer={[
                  <Row> <Col span={10}>
                    <Button key="back" block onClick={this.handleCancelSendtoPacman}>
                      Cancel
                    </Button>,
                  </Col> <Col span = {2}/> ,
                    <Col span={10}> <Button key="submit" block type="primary"
                    onClick={this.handleOkSendtoPacman}>
                      Send to PacMan
                    </Button></Col>
                  </Row>,
                ]}
            >
              <Row style={{ marginBottom: 18 }}>
                <Col span={8}><img src="https://images.homedepot-static.com/productImages/b86f780a-978b-48d0-a95a-614ea0e95943/svn/southwire-thermostat-wires-64162142-64_65.jpg" alt="skuimage" /></Col>
                <Col span={14}> <Text type="secondary">East Wing</Text><br />
                  <Text strong>200z Straight Claw Rip </Text><br />
                  <Text type="secondary">SKU 362217</Text></Col>
              </Row>
              <Row style={{ marginBottom: 18 }}>
                <Col span={14}>
                  <Text strong >Pricing </Text><br />
                </Col>
                <Col>
                  <Text strong>Zone </Text><br />

                </Col>
              </Row>
              <Row style={{ marginBottom: 18 }}>
                <Col span={12}> <input id="price"
                                       name="Price"
                                       title="Price"
                                       placeholder="$ Enter Price"
                /> </Col>
                <Col span={12}>
                  <Select mode="multiple" placeholder="Choose Zone" style={{ width: '100%' }} >
                    <Option value="Battle">Battle</Option>
                    <Option value="Battle Test1">Battle Test1</Option>
                    <Option value="Battle Test2">Battle Test2</Option>
                    <Option value="Battle Test3">Battle Test3</Option>
                    <Option value="Battle Test4">Battle Test4</Option>
                    <Option value="Battle Tes5t">Battle Test5</Option>
                  </Select>
                </Col>

              </Row>
            </Modal> */}
        </Modal>

        /* <Row style={{marginBottom: 18}}>
             <Col span={8}><img
                 src={this.context.skuImageUrl}
                 alt="SKU"/></Col>
             <Col span={8}> <Text type="secondary">East Wing</Text><br/>
               <Text strong>200z Straight Claw Rip </Text><br/>
               <Text type="secondary">SKU 362217</Text><br/></Col>
             <Col span={8}>
               <Text strong align='right'>$11.47</Text>
             </Col>
           </Row>*/
    );
  }
}

export const CustomTooltip = ({ active, payload, label }) => {
  if (active) {
    return (
        <div>
          <p>{`retail : $${payload[1].value}`}</p>
        </div>
    );
  }

  return null;
};

export const ContactCard = (props) => {
  return (
      <Row type="flex" align="middle" gutter={[16, 0]}>
        <Col sm={5}>
          <div className="contact-badge" style={{ padding: "16px 0px" }}>
            {" "}
            {props.initials}{" "}
          </div>
        </Col>
        <Col sm={19}>
          <Row type="flex">
            <Col span={24}>
              <Text className="contactName">{props.name} </Text>
            </Col>
          </Row>
          <Row>
            <Col span={24}>
              <Text className="contactTitle">{props.roleType}</Text>
            </Col>
          </Row>
          <Row type="flex">
            <Col span={24}>
              <Text type="secondary" className="contactNumber">
                {props.phoneNumber ? props.phoneNumber : ""}
              </Text>
            </Col>
          </Row>
        </Col>
      </Row>
  );
};
