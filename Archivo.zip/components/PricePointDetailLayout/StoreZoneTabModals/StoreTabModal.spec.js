import React from 'react';
import {shallow,render} from 'enzyme';

describe('<StoreTabModal/>',()=> {

  it('should not show cards with Nearby Competitor Pricing', () => {
    const FakeComponent = () => <p>Nearby Competitive Prices</p>;
    const wrapper = shallow(<FakeComponent
    />);
    expect(wrapper.contains("Nearby Competitive Prices")).toBe(true);
  });
});
