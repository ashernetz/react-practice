import React, { Component } from 'react';
import {Alert, Drawer, Layout, Space, Tabs, Typography} from "antd";
import {isMobile} from "react-device-detect";
import PricePointCard from "./PricePointCard/PricePointCard";
import SkuContext from "../../context/SkuContext";
import CompUtil from "../Utils/CompUtil";
import StoreTabModal from "./StoreZoneTabModals/StoreTabModal"
import MapContext from "../../context/MapContext";
import ModifyPriceModal from "../ModifyPriceModal/ModifyPriceModal";
import ZoneTabModal from "./StoreZoneTabModals/ZoneTabModal";
import './PricePointDetailLayout.scss';
import PriceChangeHistoryUtil from '../Utils/PriceChangeHistoryUtil';
import PricePointUtil from "../Utils/PricePointUtil";
import TableUtil from "../Utils/TableUtil";
import AdvancedTable from "../GlobalComponents/AdvancedTable/AdvancedTable";
import FilterUtil from "../Utils/FilterUtil";
import { trackEvent } from '../Utils/mixpanel';
import {formatNumberToCompact} from "../Utils/CommonUtil";

const { TabPane } = Tabs;

const { Text } = Typography;
const { Content } = Layout;

const storeColumns = [
  {
    title: '#',
    dataIndex: 'storeId',
    sorter: (a, b) => a.storeId - b.storeId,
    isCustomFilter:true

  },
  {
    title: 'Name',
    dataIndex: 'storeName',
    sorter: (a, b) => TableUtil.alphabetSort(a.storeName,b.storeName),
    isCustomFilter:true,
    width:50
  },
  {
    title: 'Sales',
    dataIndex: 'compSales',
    render:(compSales,record)=> <Space direction="vertical" size={0}>
      <Text strong>{record.rawSales?CompUtil.formatMuMdPrice(record.rawSales,true):"N/A"}</Text>
      <Text>{CompUtil.formatCompData(compSales) ? <Text className={CompUtil.findCompDataUpOrDown(compSales)}>{CompUtil.formatCompData(compSales)}{CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(compSales))}</Text> : null}</Text>
    </Space>,
    sorter: (a, b) => (CompUtil.isCompDataAvailable(a.rawSales)?a.rawSales:0) - (CompUtil.isCompDataAvailable(b.rawSales)?b.rawSales:0)

  },
  {
    title: 'Units',
    dataIndex: 'compUnits',
    render:(compUnits,record)=> <Space direction="vertical" size={0}>
      <Text strong>{record.rawUnits?formatNumberToCompact(record.rawUnits):"N/A"}</Text>
      <Text>{CompUtil.formatCompData(compUnits) ? <Text className={CompUtil.findCompDataUpOrDown(compUnits)}>{CompUtil.formatCompData(compUnits)}{CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(compUnits))}</Text> : null}</Text>
    </Space>,
    sorter: (a, b) => (CompUtil.isCompDataAvailable(a.rawUnits)?a.rawUnits:0) - (CompUtil.isCompDataAvailable(b.rawUnits)?b.rawUnits:0)
  },
  {
    title: 'Pending',
    dataIndex: 'pendingOn',

  },
];

const zoneColumns = [
  {
    title: '#',
    dataIndex: 'zoneId',
    sorter: (a, b) => a.zoneId - b.zoneId,
    isCustomFilter:true
  },
  {
    title: 'Name',
    dataIndex: 'zoneName',
    sorter: (a, b) =>  TableUtil.alphabetSort(a.zoneName,b.zoneName),
    isCustomFilter:true
  },
  {
    title: 'Stores',
    dataIndex: 'filteredStoreCount',
    render : (filterCount,record)=><Text>{filterCount}/{record.zoneStoreCount}</Text>,


  },
  {
    title: 'Markets',
    dataIndex: 'markets',
    render: (mkt) => mkt.length,
    sorter: (a, b) => a.markets.length - b.markets.length,


  },

  {
    title: 'Disaster',
    dataIndex: 'disasterCount',
    sorter: (a, b) => a.disasterCount - b.disasterCount,


  }
];


export default class PricePointDetailLayout extends Component {

  static contextType = SkuContext;

  state = {
    isStoreModalOpen: false,
    selectedStoreId:'',
    selectedStoreAddress:'',
    selectedStoreStatus:'',
    selectedStoreName : '',
    visibleZones: false,
    totalStoresMap:[],
    priceDiscrepenciesMap:[],
    zoneData:{},
    isZoneTabSelected:false,
    isModifyPriceModalOpen:false,
    isZoneModalOpen:false,
    forecastChartType: 'salesAmount',
    lastTwelveChartType: 'salesAmount'
  };


  showStoreModal = (row) => {
    this.setState({
      isStoreModalOpen: true,
      selectedStoreId: row.storeId,
      selectedStoreAddress:row.address,
      selectedStoreStatus:row.status,
      selectedStoreName:row.storeName,
      selectedUnitComp: row.compUnits,
      selectedComp: row.compSales,
      selectedStoreLatitude: row.latitudeNumber,
      selectedStoreLongitude: row.longitudeNumber,
      // priceChangeHistoryMap: PriceChangeHistroyUtil.getPriceChangeHistoryForStore(row.storeId, this.context.skuPriceChangeHistoryMap),
      isZoneTabSelected: false
    });
  };

  showZoneModal = (zoneData,selectedPricePointRowData) => {
    let storeMap = {};
    let storeDiscrepencies = {};
    let pricePointData = this.context.skuData.pricePointDetails[selectedPricePointRowData.retail];
    let storeDetails = Object.values(pricePointData.storeDetails);
    storeDetails.forEach(store=>{
      if(store.zoneId === zoneData.key){
        storeMap[store.storeId]={key: store.storeId,
          storeId:store.storeId,
          storeName:store.storeName,
          markets:store.mktName
        };
      }
    });
    Object.keys(this.context.skuData.pricePointDetails).forEach(key => {
      if(key !== selectedPricePointRowData.retail){
        let storeDetailData =this.context.skuData.pricePointDetails[key].storeDetails;
        Object.values(storeDetailData).forEach(storeData=>{
          if(storeData.zoneId === zoneData.key){
            storeDiscrepencies[storeData.storeId]={key: storeData.storeId,
              storeId:storeData.storeId,
              storeName:storeData.storeName,
              markets:storeData.mktName,
              price:key,
              status:storeData.status
            };
          }
        });
      }

    });
    this.setState({
      isZoneModalOpen:true,
      totalStoresMap: Object.values(storeMap),
      priceDiscrepenciesMap: Object.values(storeDiscrepencies),
      zoneData,
      isZoneTabSelected:true
    });
  };

  changeChartType = e => {
    let value = e.target.value;
    if (value === 'lastTwelveSales') {
      this.setState({lastTwelveChartType: 'salesAmount'});
    }
    else if (value === 'lastTwelveUnits') {
      this.setState({lastTwelveChartType: 'unitSales'});
    }
    else if (value === 'forecastSales') {
      this.setState({forecastChartType: 'salesAmount'});
    }
    else if (value === 'forecastUnits') {
      this.setState({forecastChartType: 'unitSales'});
    }
  }

  formPricePointDetailData = (filteredStoreSet) => {
    let selectedPricePointRowData = {...this.props.selectedPricePointRowData};
    let pricePointData = this.context.skuData.pricePointDetails[selectedPricePointRowData.retail];
    if(pricePointData){
      //let zoneDetails = pricePointData.zoneDetails;
      let storeDetails = Object.values(pricePointData.storeDetails);
      selectedPricePointRowData["pendingCount"] = 0;
      let storeZoneRows = this.formZoneStoreData(storeDetails,filteredStoreSet,this.context.skuData.zoneDetails);
      selectedPricePointRowData.zoneRows=Object.values(storeZoneRows.zoneMap);
      selectedPricePointRowData.storeRows = Object.values(storeZoneRows.storeMap);
    }
    return selectedPricePointRowData;
  };

  formZoneStoreData = (originalStores,filteredStoreSet,zoneDetails) => {
    let zoneMap = {};
    let storeMap = {};
    let skuStorePerfData = this.context.skuStorePerformanceData;
    originalStores.forEach(store => {
      if(filteredStoreSet.includes(store.storeId)){
        if (store.zoneId) {
        if(!zoneMap.hasOwnProperty(store.zoneId)) {
            zoneMap[store.zoneId] = {
              key: store.zoneId,
              zoneId: store.zoneId,
              zoneName: store.zoneName,
              zoneStoreCount: zoneDetails[store.zoneId]
                  ? zoneDetails[store.zoneId].storeCount : 0,
              filteredStoreCount: 0,
              markets: [],
              disasterCount: 0,
              stores:[]
            }
          }

          zoneMap[store.zoneId].filteredStoreCount = zoneMap[store.zoneId].filteredStoreCount
              + 1;
        zoneMap[store.zoneId].stores.push(store.storeId);
          if (store.disaster) {
            zoneMap[store.zoneId].disasterCount = zoneMap[store.zoneId].disasterCount
                + 1;
          }
          if (!zoneMap[store.zoneId].markets.includes(store.mktId)) {
            zoneMap[store.zoneId].markets.push(store.mktId);
          }
        }
        let performanceData = skuStorePerfData.storeLevelPerformance[store.storeId];
        let rawSalesUnitsData = skuStorePerfData.rawSalesAndUnitsMap[store.storeId];

        let {compSales = "-",compUnits = "-"} = performanceData?performanceData:{};
        let {rawSales ,rawUnits } = rawSalesUnitsData?rawSalesUnitsData:{};

        let pendingStoreDetailsMap = this.context.pendingStoreDetailsMap;
        let pendingOnDate = "";

          if (pendingStoreDetailsMap.has(store.storeId)) {
            pendingOnDate = pendingStoreDetailsMap.get(store.storeId).pendingDate.substring(0, 10);
          }

        storeMap[store.storeId] = {
          key:store.storeId,
          storeId:store.storeId,
          storeName:store.storeName,
          latitudeNumber: store.latitudeNumber,
          longitudeNumber: store.longitudeNumber,
          address:store.address,
          status:store.status,
          pendingOn: pendingOnDate,
          compSales,
          compUnits,
          rawSales,
          rawUnits,
          isDisaster: store.disaster
        };
      }
    });
    Object.keys(zoneMap).forEach(zoneId => {
      let {compSales="-", compUnits="-"} =
          Object.keys(this.context.skuStorePerformanceData).length === 0
              ? {} : PricePointUtil.getCompDataForFilteredZoneLevel(zoneMap[zoneId].stores,
              this.context.skuStorePerformanceData);
      zoneMap[zoneId].compSales = compSales;
      zoneMap[zoneId].compUnits = compUnits;
    });
    return {zoneMap,storeMap};
  };

  handleClickingEditPrice = (zoneOrStore) => {
    this.props.verifyAccessToken();
    trackEvent("CLICKED_EDIT_PRICE_BUTTON", {'ORIGIN': zoneOrStore});
    if (zoneOrStore === "zoneTab") {
      this.setState({isZoneModalOpen:false, isModifyPriceModalOpen: true})
    } else if (zoneOrStore === "storeTab") {
      this.setState({isStoreModalOpen:false, isModifyPriceModalOpen: true})
    }
  }

  render() {
    let selectedPricePointRowData = this.props.selectedPricePointRowData ? this.formPricePointDetailData(this.props.selectedPricePointRowData.filteredStoreSet):{};
    return (
        <Drawer
            keyboard={true}
            className = "price-detail-drawer"
            width={isMobile ? 360 : 540}
            mask={false}
            placement='left'
            closable={false}
            open={this.props.isOpen}
        >
          <Content>
            {FilterUtil.checkIfFilterIsApplied(this.props.defaultMapFilterValues, this.context.filterValues, ["selectedCompetitors", "isMapClusteringChecked"]) &&
              <Alert className="filter-alert" showIcon message="Filters are applied to the results below" type="warning" closeText="Clear Filters" banner  onClose={()=>this.context.updateFilterSelection(this.props.defaultMapFilterValues)} />
            }
            <PricePointCard pricePointDetail={selectedPricePointRowData} togglePricePointView={this.props.togglePricePointView}/>
            <MapContext.Consumer>
              { mapState => (
                  <Tabs defaultActiveKey="1" className="fwTabs">
                    <TabPane id = "storeTab" tab="Stores" key="1">
                      <AdvancedTable
                        tableClassName="store-tab-table"
                        key = {this.props.isOpen + "store"}
                        columns={storeColumns} 
                        dataSource={selectedPricePointRowData.storeRows}
                        pagination={{ pageSize: 60 ,showSizeChanger:false}} scroll={{ y: 460,scrollToFirstRowOnChange:true  }}
                        onRow={(record) => ({
                          onClick: () => { this.showStoreModal(record) },
                          onMouseOver : () => {mapState.updateHoverState({store:record.key})},
                          onMouseLeave: () => {mapState.updateHoverState({store:''})}
                        })} 
                      />
                    </TabPane>
                    <TabPane tab="Zones" key="2" >
                      <AdvancedTable
                        tableClassName="zone-tab-table"
                        key = {this.props.isOpen + "zone"}
                        columns={zoneColumns}
                        dataSource={selectedPricePointRowData.zoneRows}
                        pagination={{ pageSize: 50 ,showSizeChanger:false}} scroll={{ y: 460,scrollToFirstRowOnChange:true }}
                        onRow={(record) => ({
                          onClick: () => { this.showZoneModal(record,selectedPricePointRowData) },
                          onMouseOver : () => {mapState.updateHoverState({zone:record.key})},
                          onMouseLeave: () => {mapState.updateHoverState({zone:''})}
                        })}
                      />
                    </TabPane>
                    <TabPane id = "disasterTab" tab="Disaster" key="3">
                      <AdvancedTable
                        tableClassName="disaster-tab-table"
                        key = {this.props.isOpen + "disaster"}
                        columns={storeColumns} 
                        dataSource={selectedPricePointRowData.storeRows ? selectedPricePointRowData.storeRows.filter(k=>k.isDisaster): []}
                        pagination={{ pageSize: 60, showSizeChanger:false }} scroll={{ y: 460,scrollToFirstRowOnChange:true  }}
                        onRow={(record) => ({
                          onClick: () => { this.showStoreModal(record) },
                          onMouseOver : () => {mapState.updateHoverState({store:record.key})},
                          onMouseLeave: () => {mapState.updateHoverState({store:''})}
                        })}
                      />
                    </TabPane>
                  </Tabs>
              )}
            </MapContext.Consumer>
            { this.state.isStoreModalOpen ?
                <StoreTabModal
                    config={this.props.config}
                    userId={this.props.userId}
                    apiKey={this.context.config.apiKey}
                    isOpen = {this.state.isStoreModalOpen}
                    storeName={ this.state.selectedStoreName}
                    storeId={this.state.selectedStoreId}
                    selectedUnitComp = {this.state.selectedUnitComp}
                    selectedComp = {this.state.selectedComp}
                    storeAddress={this.state.selectedStoreAddress}
                    storeStatus={this.state.selectedStoreStatus}
                    storeLatitude={this.state.selectedStoreLatitude}
                    storeLongitude={this.state.selectedStoreLongitude}
                    pricePointColor=  {"#F96302"}
                    forecastChartType= {this.state.forecastChartType}
                    lastTwelveChartType= {this.state.lastTwelveChartType}
                    changeChartType={this.changeChartType}
                    onClose={() => this.setState({
                      isStoreModalOpen: false, forecastChartType: 'salesAmount',
                      lastTwelveChartType: 'salesAmount'
                    })}                    
                    onEditPriceClick = {() => this.handleClickingEditPrice("storeTab")}
                />
              :
                null
            }
            { this.state.isModifyPriceModalOpen ? 
                <ModifyPriceModal
                  isOpen={this.state.isModifyPriceModalOpen}
                  onClose={()=> this.setState({isModifyPriceModalOpen:false})}
                  storeStatus={this.state.selectedStoreStatus}
                  storeRetail = {selectedPricePointRowData.retail}
                  zone= {this.state.isZoneTabSelected ? this.state.zoneData.zoneId + "-" + this.state.zoneData.zoneName : null} 
                  store={!this.state.isZoneTabSelected?this.state.selectedStoreId + "-" + this.state.selectedStoreName:null}
                /> 
              : 
                null
            }
            { this.state.isZoneModalOpen ?
                <ZoneTabModal
                  totalStoresMap={this.state.totalStoresMap}
                  priceDiscrepenciesMap={this.state.priceDiscrepenciesMap}
                  zoneName={this.state.zoneData.zoneName}
                  marketsCount={this.state.zoneData.markets.length}
                  compSales = {this.state.zoneData.compSales}
                  compUnits = {this.state.zoneData.compUnits}
                  retail={selectedPricePointRowData.retail}
                  onClose = {() => this.setState({isZoneModalOpen: false})}
                  onEditPriceClick = {() => this.handleClickingEditPrice("zoneTab")}
                />
              :
                null
            }
          </Content>
        </Drawer>

    );
  }
}



