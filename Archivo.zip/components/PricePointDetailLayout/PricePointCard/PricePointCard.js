import { ArrowLeftOutlined } from '@ant-design/icons';
import {Col, Row, Space, Typography} from "antd";
import React, {Component,Fragment} from 'react';
import SkuContext from "../../../context/SkuContext";
import './PricePointCard.scss';
import CompUtil from "../../Utils/CompUtil";
import MapContext from "../../../context/MapContext";
import {formatNumberToCompact} from "../../Utils/CommonUtil";
const { Text} = Typography;


export default class PricePointCard extends Component {

static contextType = SkuContext;


  render() {

    return (<Fragment>
      <Row className='ppdHeading' style={{backgroundColor:this.props.pricePointDetail.color,color:'white'}}>

        <Col span={1}>
          <MapContext.Consumer>
            {mapState => ( <ArrowLeftOutlined
                style={{ fontSize: '20px', color: '#fff' }}
                className='backArrow'
                onClick={(e)=> {
                  mapState.updateSelectedState({retail:''});
                  this.props.togglePricePointView()}} />)}

          </MapContext.Consumer>
        </Col>
        <Col span={16}>
          <Text className='ppdPriceText' >${this.props.pricePointDetail.retail ? this.props.pricePointDetail.retail.split('-')[0]: ""}</Text><br/>
          <Text className='ppdPriceTextStores'>{this.props.pricePointDetail.storeCount} of {this.context.skuData.totalStoreCount} Stores</Text>
        </Col>
        <Col span={7}>
          {this.props.pricePointDetail.endsOn ? <Text className="ppdPendingText">{this.props.pricePointDetail.endsOn}</Text>: null}
        </Col>
      </Row>
      <Row className='ppdHeadingMetrics'>

        <Col span={6}>
          <Space direction="vertical" size={2}>
          <Space direction="vertical" size={0}>
            <Text strong>{this.props.pricePointDetail.rawSales?CompUtil.formatMuMdPrice(this.props.pricePointDetail.rawSales,true):"N/A"}</Text>
            <Text className={CompUtil.findCompDataUpOrDown(this.props.pricePointDetail.compSales)}>{CompUtil.formatCompData(this.props.pricePointDetail.compSales)} {CompUtil.isCompDataAvailable(this.props.pricePointDetail.compSales)?CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(this.props.pricePointDetail.compSales)):null}</Text>
          </Space>
            <Text className="skuCardLabels ant-typography-secondary" >Sales</Text>
          </Space>
        </Col>
        <Col span={6}>
          <Space direction="vertical" size={2}>
          <Space direction="vertical" size={0}>
            <Text strong>{this.props.pricePointDetail.rawUnits?formatNumberToCompact(this.props.pricePointDetail.rawUnits):"N/A"}</Text>
            <Text className={CompUtil.findCompDataUpOrDown(this.props.pricePointDetail.compUnits)}>{CompUtil.formatCompData(this.props.pricePointDetail.compUnits)} {CompUtil.isCompDataAvailable(this.props.pricePointDetail.compUnits) ?CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(this.props.pricePointDetail.compUnits)) : null}</Text>
          </Space>
            <Text className="skuCardLabels ant-typography-secondary">Units</Text>
          </Space>
        </Col>
        <Col span={6}>
          <Text className="skuCardNumbers">{this.props.pricePointDetail.pendingPriceChangeCount}</Text><br/>
          <Text className="skuCardLabels ant-typography-secondary">Pending Changes</Text>
        </Col>
        <Col span={6}>
          <Text className="skuCardNumbers">{this.props.pricePointDetail.disasterCount}</Text><br/>
          <Text className="skuCardLabels ant-typography-secondary">Disaster</Text>
        </Col>
        </Row>
      </Fragment>
    );
  }

}


