import React, {Component} from 'react';
import {Row, Col, Typography, Modal, Divider, Empty} from 'antd';
import SkuContext from "../../context/SkuContext";
import {UXGraphSpin} from '../GlobalComponents/GlobalReactComponents/UXComponents/UXGraphSpin';
import "./SalesMetricsModal.scss";
import SalesWhiskerChart from "../ChartsComponent/SalesWhiskerChart";
import CompetitivePrice from '../CompetitivePriceComponent/CompetitivePrice';
import CompetitorUtil from "../Utils/CompetitorUtil";
import UXImage
  from "../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import NoSkuImage from "../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import CompUtil from "../Utils/CompUtil";


const {Text} = Typography;
export default class SalesMetricsModal extends Component {
  static contextType = SkuContext;

   SalesMetricSkuInfo = (props) => {
    let skuImageUrl = this.context.skuImageUrl;
    return(
      <Row className="skuCardRow" type="flex" align="middle">
        <Col span={6} className="productImageCont">
          <UXImage imageUrl={skuImageUrl === "no-sku-image" ? NoSkuImage:skuImageUrl} classNames="productImage" />
        </Col>
        <Col span={12}>
              <Text className="skuVendorName" type="secondary">{this.context.skuVendors}</Text><br/>
              <Text className="skuProductName textShortener">{this.context.skuDescription}</Text><br/>
              <Text type="secondary">SKU {this.context.skuNumber}</Text><br/>
        </Col>
        <Col span={6}>
          <Row type="flex" justify="end" align="middle"><Col>
            <Text className="productPrice">${props.thdSkuCommonRetail}</Text></Col>
          </Row>
          <Row type="flex" justify="end" align="middle"><Col><Text>Most Common Retail</Text></Col></Row>
        </Col>

      </Row>);
  };

  formCompetitorDetailData=()=>{
  
    let thdSkuPrice = Number.parseFloat(this.context.skuData.mostCommonRetails[0]);
    let resultantData = {
      "Lowes":{id:"3141",name:"lowe"},"Floor & Decor":{id:"588623",name:"FnD"},"Menards":{id:"6488",name:"Menards"}
    };
    
    Object.values(this.context.competitorData.aggregatedDataMap).forEach(competitor=>{
      let avgPrice =Number.parseFloat(competitor.mostCommonRetails[0]);

      resultantData[competitor.competitorName]={
        id:competitor.competitorId,
        name: competitor.competitorName,
        avgPrice,
        numberOfStoresThisSkuIsIn: competitor.storeCount,
        totalNumberOfStores: competitor.totalStoreCount,
        CPI: null,
        ...CompetitorUtil.competitorPriceDifferenceData(avgPrice,thdSkuPrice),
        lastUpdated: CompetitorUtil.getDateInStandardFormat(competitor.latestScrapeDateInMillis)};

     

    });
    return Object.values(resultantData);
  };

  render() {
    let salesMetricsData = this.context.salesMetricsMap["salesMetricBoxPlotList"];
    let competitorDetails =this.formCompetitorDetailData();
    let thdSkuCommonRetail = CompUtil.formatPrice(Number.parseFloat(this.context.skuData.mostCommonRetails[0]));
    return (
        <Modal
            className="salesMetrics"
            open={this.props.isOpen}
            onCancel={this.props.onClose}
            footer={null}
        >
          <Row align="middle" style={{marginBottom: 18}} type="flex" gutter={[40, 0]}>
            <Col span={24}>
              <Row type="flex">
                <Col className="modalHeaderTextCont">
                  <Row> <Text type="storeName">Sales Metrics for FW{this.context.lastFiscalWeek}</Text></Row>
                </Col>
              </Row>
            </Col>
          </Row>
          <this.SalesMetricSkuInfo thdSkuCommonRetail ={thdSkuCommonRetail}/>

          <Divider/>

           <Row align="middle" style={{marginBottom: 18}} type="flex"
               gutter={[40, 0]}>
            <Col span={24}>
              <Row type="flex">
                <Col className="modalHeaderTextCont">
                  <Row> <Text type="storeName">Competitive Price</Text></Row>
                </Col>
              </Row>
            </Col>
          </Row>

          {competitorDetails.length === 0 ? <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} /> : <CompetitivePrice competitorDetails ={competitorDetails} />}

          <Divider />

          <Row align="middle" style={{marginBottom: 18}} type="flex"
               gutter={[40, 0]}>
            <Col span={24}>
              <Row type="flex">
                <Col className="modalHeaderTextCont">
                  <Row> <Text type="storeName">Price Point Distribution</Text></Row>
                </Col>
              </Row>
            </Col>
          </Row>

          {salesMetricsData ?
              <SalesWhiskerChart salesMetricsData={salesMetricsData}/>

            :
              <UXGraphSpin/>
          }

        </Modal>
    );
  }
}