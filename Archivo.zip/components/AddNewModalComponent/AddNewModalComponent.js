import React, { Component } from 'react';
import {  Button, Row, Col, Typography} from 'antd';
import SkuContext from "../../context/SkuContext";
import ModifyPriceModal from "../ModifyPriceModal/ModifyPriceModal";
import SalesMetricsModal from "../SalesMetricsModal/SalesMetricsModal";
import './AddNewModalComponent.scss';
import {trackEvent} from '../Utils/mixpanel'

const { Text } = Typography;


export default class AddNewModalComponent extends Component {

    state = { 
        isModifyPriceModalOpen:false, 
        isSalesMetricsModalOpen:false,
    };
    static contextType = SkuContext;
    
    handleClickingSalesMetricsButton = () => {
        trackEvent("clicked_sales_metrics_button");
        this.setState({isSalesMetricsModalOpen:true});
    }

    render() {
        return (
            <div>
                <Row className='ppContainer'>
                    <Col span={17}>
                        <Text className='pricePointHeading'>{this.props.pricePointCount} Price Points </Text><br />
                        <Text className='pricePointSubheading' type="secondary">Across {this.props.acrossStoreCount} of {this.props.activeStoresCount} stores</Text></Col>
                    <Col span={7} className="ppBtnCol" >
                      {this.context.skuData.allowExecution && this.context.skuData.allowZonePriceChange ? 
                      <Button block type="primary" ghost='true' size='large' onClick={()=>this.setState({isModifyPriceModalOpen:true})}>
                        Add New  </Button>
                    : null}
                    </Col>
                </Row>
                {this.state.isSalesMetricsModalOpen ? <SalesMetricsModal
                    isSalesMetrics
                    data={this.context.salesMetricsMap["salesMetricBoxPlotList"]}
                    isOpen={this.state.isSalesMetricsModalOpen}
                    onClose={()=> this.setState({isSalesMetricsModalOpen:false})} /> : null}
                {this.state.isModifyPriceModalOpen ? <ModifyPriceModal
                    isAddNew
                    isOpen={this.state.isModifyPriceModalOpen}
                    onClose={()=> this.setState({isModifyPriceModalOpen:false})} /> : null}
            </div>
        );
    }
}    
