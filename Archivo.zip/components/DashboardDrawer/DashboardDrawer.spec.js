import React from 'react';
import {shallow,render} from 'enzyme';
import DashboardDrawer from './DashboardDrawer';

describe('<DashboardDrawer/>',()=> {

  it('renders test component', () => {
    const TestComponent = () => <div>test</div>;
    const wrapper = shallow(<TestComponent/>);
    expect(wrapper.text()).toEqual("test");
  });
});
//     let wrapper;
//     let context = {
//         dcsDataMap: {},
//         dashboardData: {
//             subClassNumber: 21,
//             departmentNumber: 1,
//             classNumber: 1,
//             topPerformers: {
//
//             },
//             bottomPerformers: {
//
//             }
//         },
//         profileData: {
//
//         },
//
//     };
//     let state = {
//         selectedPerformanceType: "topPerformersSalesMap",
//         performanceFilterData: {
//
//         }
//     };
//     let props = {
//
//     };
//     it('renders <DashboardDrawer />', () => {
//         const wrapper = shallow(<DashboardDrawer />);
//         wrapper.setContext({ context });
//         wrapper.setState({ state });
//         wrapper.setProps({ props });
//
//         expect(wrapper.find('.regContainer').length).toEqual(1);
//     });
// });