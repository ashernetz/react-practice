import React, { Component, Fragment } from 'react';
import { Row, Col, Typography } from 'antd';
import CompUtil from "../../components/Utils/CompUtil";
import "./SkuInfoCard.scss"
import NoSkuImage from "../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import UXImage
  from "../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import { UXSpin } from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
const { Text } = Typography;
export default class SkuInfoCard extends Component {
  render() {
    let skuDescription = this.props.skuDescription;
    let skuVendors = this.props.skuVendors;
    let skuImageUrl = this.props.skuImageUrl;
    let skuCompSales = this.props.skuCompSales;
    let skuCompUnits = this.props.skuCompUnits;
    let skuNumber = this.props.skuNumber;

    let compSalesUpOrDown = CompUtil.findPercentageUpOrDown(skuCompSales);
    let compUnitsUpOrDown = CompUtil.findPercentageUpOrDown(skuCompUnits);
    let compSales = CompUtil.formatCompData(skuCompSales);
    let compUnits = CompUtil.formatCompData(skuCompUnits);
    let compSalesTextColor = CompUtil.findCompDataUpOrDown(skuCompSales);
    let compUnitsTextColor = CompUtil.findCompDataUpOrDown(skuCompUnits);

    return (
      <Fragment>
        <Row type="flex" align="middle">
          <Col sm={6}>{skuImageUrl === "no-sku-image" ? <UXImage imageUrl={NoSkuImage} classNames="sku-img" /> : <img className="productPhoto" src={skuImageUrl} alt="skuimage" />}</Col>
          <Col sm={18}>
            <Row type="flex" gutter={[24, 0]}><Col sm={12} className="textShortener"><Text type="secondary" className="skuCardVendor">{skuVendors}</Text></Col><Col sm={12}><Text className="skuCardSKUNumber" type="secondary">SKU {skuNumber}</Text></Col></Row>
            <Row><Col className="textShortener">
              <Text className="sku-info-desc">{skuDescription}</Text></Col></Row>
            <Row type="flex" gutter={[24, 0]}>
              <Col sm={12}>
                <Text type="secondary" className="skuCardCompUnitLabel">Sales </Text>
                {skuCompSales === "no-comp-data" ? <UXSpin /> :
                  <Text className={compSalesTextColor}>{compSales}
                    {CompUtil.isCompDataAvailable(skuCompSales) && CompUtil.getArrowUpDownComponent(compSalesUpOrDown, { className: "skuCardArrows", style: { padding: "0px 5px" } })}</Text>}
              </Col>

              <Col sm={12}>
                <Text type="secondary" className="skuCardCompUnitLabel">Units </Text>
                {skuCompUnits === "no-comp-data" ? <UXSpin /> :
                  <Text className={compUnitsTextColor}>{compUnits}
                    {CompUtil.isCompDataAvailable(skuCompUnits) && CompUtil.getArrowUpDownComponent(compUnitsUpOrDown, { className: "skuCardArrows", style: { padding: "0px 5px" } })}</Text>}
              </Col>
            </Row>   
            </Col>
        </Row>
      </Fragment>
    );
  }
}

