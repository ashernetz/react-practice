import React, {Component} from "react";
import {
  Row,
  Col,
  Modal,
  Select,
  Typography,
  Checkbox,
} from "antd";
import DCSUtil from "../../Utils/DCSUtil";
import "./DCSOverviewModal.scss";
import {trackEvent} from '../../Utils/mixpanel';

const {Text} = Typography;

export default class DCSOverviewModal extends Component {
  dcsKey = (this.props.selectedDCS ? this.props.selectedDCS : "0-0-0").split("-");
  state = {
    departmentNumber:Number.parseInt(this.dcsKey[0]),
    classNumber:Number.parseInt(this.dcsKey[1]),
    subclassNumber:Number.parseInt(this.dcsKey[2]),
    isPrimaryChecked:false
  };

  onSaveChanges = () => {
    this.props.onClose();
    let hyphenatedDCS = DCSUtil.getHyphenatedDCS(this.state.departmentNumber, this.state.classNumber,
      this.state.subclassNumber);
    if(this.state.isPrimaryChecked){
      trackEvent("CLICKED_UPDATE_BUTTON_DCS_MODAL", {"DCS": hyphenatedDCS});
      this.props.updateUserProfile(this.props.profileData.title, hyphenatedDCS, this.props.profileData);
    } else {
      this.props.onDCSChange(hyphenatedDCS);
    }
  };

  isUpdateDisabled = (isPrimary) => {
    if (!isPrimary && this.state.isPrimaryChecked && this.state.classNumber !== 0) {
      return false;
    } else {
      return this.state.classNumber === 0 ||
          DCSUtil.getHyphenatedDCS(this.state.departmentNumber,
              this.state.classNumber,
              this.state.subclassNumber) === this.props.selectedDCS
    }
  };

  handleDepartmentChange = (value) => {
    trackEvent("CHANGED_DEPARTMENT", {'SELECTED_DEPARTMENT': value});
    this.setState({departmentNumber: value, subclassNumber: 0, classNumber: 0})
  }

  handleClassChange = (value) => {
    trackEvent("CHANGED_CLASS", {'SELECTED_CLASS': value});
    this.setState({classNumber: value, subclassNumber: 0})
  }

  handleSubclassChange = (value) => {
    trackEvent("CHANGED_SUBCLASS", {'SELECTED_SUBCLASS': value});
    this.setState({subclassNumber: value})
  }

  handleSetAsPrimaryToggling = () => {
    trackEvent("CLICKED_SET_AS_PRIMARY_CHECKBOX", {'CHECKED': !this.state.isPrimaryChecked});
    this.setState({isPrimaryChecked:!this.state.isPrimaryChecked})
  }

  render() {
    let isPrimary = this.props.profileData.subClassDetails === DCSUtil.getHyphenatedDCS(this.state.departmentNumber, this.state.classNumber,
        this.state.subclassNumber);
    return (
      <Modal
          open={this.props.isOpen}
          className="dcs-modal"
          onCancel={this.props.onClose}
          title="Change Product Hierarchy"
          okButtonProps={{ size: 'large', disabled:this.isUpdateDisabled(isPrimary) }}
          cancelButtonProps={{size: 'large' }}
          okText="Update"
          cancelText="Cancel"
          onOk={this.onSaveChanges}
      >
        <Row type="flex" justify="space-between" align="middle" gutter={[16, 8]} style={{marginBottom: "8px"}}>
          <Col span={12}>
            <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
              <Col span={24}><Text  className = "dcs-text">Department*</Text></Col></Row>
            <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
              <Col span={24}>
                <Select
                  showSearch
                  size={"large"}
                  placeholder={"Select Dept"}
                  style={{width: "100%"}}
                  optionFilterProp="children"
                  value={this.state.departmentNumber === 0 ? [] : this.state.departmentNumber}
                  onChange={(value) => this.handleDepartmentChange(value)}
                  filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                >
                  {DCSUtil.getDeptDropdownData(this.props.dcsDataMap)}
                </Select>
              </Col>
            </Row>
          </Col>
          <Col span={12}>
            <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
              <Col span={24}><Text  className = "dcs-text" >Class*</Text></Col></Row>
            <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
              <Col span={24}>
                <Select
                  size={"large"}
                  showSearch
                  disabled={this.state.departmentNumber === 0}
                  placeholder={"Select Class"}
                  style={{width: "100%"}}
                  optionFilterProp="children"
                  value={this.state.classNumber === 0 ? [] : this.state.classNumber}
                  onChange={(value) => this.handleClassChange(value)}
                  filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                >
                  {DCSUtil.getClassDropdownData(this.props.dcsDataMap, this.state.departmentNumber)}
                </Select>
              </Col>
            </Row>
          </Col>
        </Row>
        <Row type="flex" justify="start" align="middle" gutter={[0, 8]} style={{marginBottom: "8px"}}>
          <Col><Text className = "dcs-text" >Sub Class</Text></Col>
        </Row>
        <Row type="flex" justify="start" align="middle" gutter={[0, 32]} style={{marginBottom: "32px"}}>
          <Col span={24}>
            <Select
              size={"large"}
              showSearch
              disabled={this.state.classNumber === 0}
              placeholder={"Select Subclass"}
              style={{width: "100%"}}
              optionFilterProp="children"
              value={this.state.subclassNumber === 0 ? [] : this.state.subclassNumber}
              onChange={(value) => this.handleSubclassChange(value)}
              filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            >
              {DCSUtil.getSubClassDropdownData(this.props.dcsDataMap,this.state.departmentNumber, this.state.classNumber)}
            </Select>
          </Col>
        </Row>
        <Row type="flex" justify="space-between" align="middle" gutter={[0, 8]} style={{marginBottom: "8px"}}>
          <Col>
              <Checkbox
                className = "dcs-text"
                disabled={isPrimary}
                onChange={this.handleSetAsPrimaryToggling}
                checked={isPrimary ? isPrimary : this.state.isPrimaryChecked}>Set as Primary</Checkbox>
          </Col>
        </Row>
       
      </Modal>
    )
  }
}
