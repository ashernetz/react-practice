import React, { Component, Fragment } from "react";
import { CaretDownOutlined } from '@ant-design/icons';
import {
  Divider,
  Drawer,
  Layout,
  Row,
  Col,
  Typography,
  Menu,
  Dropdown,
  Badge,
  Tooltip,
} from "antd";
import { isMobile } from "react-device-detect";
import "./DashboardDrawer.scss";
import SkuInfoCard from "./SkuInfoCard";
import SkuContext from "../../context/SkuContext";
import { UXSpin } from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import DCSOverviewModal from "./DCSOverviewModal/DCSOverviewModal";
import DCSUtil from "../Utils/DCSUtil";
import SvgUtil from "../Utils/SvgUtil";
import {trackEvent} from '../Utils/mixpanel';

const { Content } = Layout;
const { Text,Paragraph } = Typography;

const getPerfFilterData = () => {
  let performanceFilterData = new Map();
  performanceFilterData.set("topPerformersSalesMap",
      {enable: true, value: 'Top Comp by KVI SKU'});
  performanceFilterData.set("bottomPerformersSalesMap",
      {enable: true, value: 'Bottom Comp by KVI SKU'});
  performanceFilterData.set("topPerformersUnitsMap",
      {enable: true, value: 'Top Unit by KVI SKU'});
  performanceFilterData.set("bottomPerformersUnitsMap",
      {enable: true, value: 'Bottom Unit by KVI SKU'});
  performanceFilterData.set("topPerformersFavSkusSalesMap",
      {enable: true, value: 'Top Comp by Favorite SKU'});
  performanceFilterData.set("bottomPerformersFavSkusSalesMap",
      {enable: true, value: 'Bottom Comp by Favorite SKU'});
  performanceFilterData.set("topPerformersFavSkusUnitsMap",
      {enable: true, value: 'Top Unit by Favorite SKU'});
  performanceFilterData.set("bottomPerformersFavSkusUnitsMap",
      {enable: true, value: 'Bottom Unit by Favorite SKU'});
 
  // performanceFilterData.set("3",
  //     {enable: false, value: 'Top Performers by Bay'});
  // performanceFilterData.set("4",
  //     {enable: false, value: 'Bottom Performers by Bay'});
  return performanceFilterData;
};
export default class DashboardDrawer extends Component {
  static contextType = SkuContext;
  state = {
    isDCSModalOpen: false,
    performanceFilterData: getPerfFilterData(),
    selectedPerformanceType: "topPerformersSalesMap"
  };

  getToolTipData = () => {
    let tooltipData = "";

    let subClassNumber = this.context.dashboardData.subClassNumber;
    let deptNumber = this.context.dashboardData.departmentNumber;
    let classNumber = this.context.dashboardData.classNumber;
    let dcsKey = deptNumber + "-" + classNumber + "-" + subClassNumber;
    let hierarchyName = DCSUtil.getHierarchyName(
        this.context.dcsDataMap,
        dcsKey,
        ""
    );

    tooltipData = hierarchyName + " belongs to D" + deptNumber;

    if (classNumber !== 0) {
      tooltipData = tooltipData + " C" + classNumber;
    }
    if (subClassNumber !== 0) {
      tooltipData = tooltipData + " S" + subClassNumber;
    }

    return tooltipData;
  };

  formSkuDataList =(skuDataList,skuList)=>{

    return skuDataList.forEach(sku => {
       skuList.push(
           <Row
               key={sku.skuNumber}
               type="flex"
               className="dashboard-antrow-cursor"
               justify="space-between"
               align="middle"
               onClick={() => this.props.onSearchClick(sku.skuNumber, "CLICKED_KVI_LIST")}
           >
             <Col span={22}>
               <SkuInfoCard
                   skuNumber={sku.skuNumber}
                   skuDescription={sku.skuDescription?sku.skuDescription:sku.skuDesc}
                   skuVendors={sku.vendorName}
                   skuImageUrl={sku.skuImage? sku.skuImage : "no-sku-image"}
                   skuCompSales={sku.netSalesComp}
                   skuCompUnits={sku.netUnitsComp}
               />
             </Col>
             <Col span={2}>
               <i className="material-icons dashChevrons">chevron_right</i>
             </Col>
           </Row>
       );
     });
   }

  getSkuDetails = () => {
    let performanceType = this.state.selectedPerformanceType;
    let skuList = [];
    let favSkuMap = this.context.favSkuMap;

    if(this.state.selectedPerformanceType.includes("FavSkus")){
      performanceType = "favSkuMap";
    }

    if(this.context.dashboardData.hasOwnProperty(performanceType)&&Object.keys(this.context.dashboardData[performanceType]).length>0){
      let skuMap = this.context.dashboardData[performanceType];

      let skuDataList = Object.values(skuMap).sort((a,b) => {
        if(this.state.selectedPerformanceType === "topPerformersSalesMap") {
          return b.netSalesComp - a.netSalesComp;
        }
        else if(this.state.selectedPerformanceType === "bottomPerformersSalesMap") {
          return a.netSalesComp - b.netSalesComp;
        }
        else if(this.state.selectedPerformanceType === "topPerformersUnitsMap") {
          return b.netUnitsComp - a.netUnitsComp;
        }
        else if(this.state.selectedPerformanceType === "bottomPerformersUnitsMap") {
          return a.netUnitsComp - b.netUnitsComp;
        }
        else {
          return b.netSalesComp - a.netSalesComp;
        }
      });

      this.formSkuDataList(skuDataList,skuList);

    } else if(performanceType === "favSkuMap"){

      if(favSkuMap && Object.keys(favSkuMap).length>0){

      let skuDataList = Object.values(favSkuMap).sort((a,b) => {
      if(this.state.selectedPerformanceType === "topPerformersFavSkusUnitsMap") {
          return b.netUnitsComp - a.netUnitsComp;
        }
        else if(this.state.selectedPerformanceType === "bottomPerformersFavSkusUnitsMap") {
          return a.netUnitsComp - b.netUnitsComp;
        }
        else if(this.state.selectedPerformanceType === "topPerformersFavSkusSalesMap") {
          return b.netSalesComp - a.netSalesComp;
        }
        else if(this.state.selectedPerformanceType === "bottomPerformersFavSkusSalesMap") {
          return a.netSalesComp - b.netSalesComp;
        }else {
          return 0;
      }
        
      });

      if((this.state.selectedPerformanceType.includes("FavSkus")) 
      && skuDataList.length > 5){
        skuDataList = skuDataList.slice(0,5);
      }

      this.formSkuDataList(skuDataList,skuList);
     }
    }
    let selectedDCS = this.subclassDropdownValue();
    if (
        skuList.length === 0 &&
        this.context.selectedDCS !== "" &&
        selectedDCS !== "Choose Class/Sub Class" &&
        selectedDCS !== "no-subclass"
    ) {
      skuList = (
          <Fragment>
            <Row justify="center" align="middle" type="flex">
              <Col className="noKVI">
                {SvgUtil.getNoData()}
              </Col>
            </Row>
            <Row justify="center" align="middle" type="flex" style={{paddingTop: "10px" }}>
              <Col>
                <Text className="no-kvi">
                  No KVI SKU's Available for this Class or Subclass
                </Text>
              </Col>
            </Row>
            <Paragraph/>
            <Row justify="center" align="middle" type="flex">
              <Col>
                <Text className="no-kvi-bold">
                  Looking for a specific product?
                </Text>
              </Col>
            </Row>
            <Row justify="center" align="middle" type="flex">
              <Col>
                <Text className="no-kvi">
                  You can search any SKU from the top search bar
                </Text>
              </Col>
            </Row>
          </Fragment>
      );
    }
    return skuList;
  };

  subclassDropdownValue = () => {
    let selectedDCS = "no-subclass";
    if (this.context.dcsDataMap.size > 0) {
      selectedDCS = DCSUtil.getHierarchyName(
          this.context.dcsDataMap,
          this.props.selectedDCS,
          "Choose Class/Sub Class"
      );
    }
    return selectedDCS;
  };

  handleClickingCurrentClassOverviewText = () => {
    trackEvent("clicked_current_class_overview_text")
    this.setState({ isDCSModalOpen: true })
  }

  render() {
    let menu = [];

    this.state.performanceFilterData.forEach((v, k) => {
      menu.push(
          <Menu.Item disabled={!v.enable} key={k}>
            <Text>{v.value}</Text>
          </Menu.Item>
      );
    });
    menu = (
        <Menu
            onClick={item => {
              this.setState({ selectedPerformanceType: item.key });
            }}
        >
          {menu}
        </Menu>
    );

    return (
      <Drawer
          placement="left"
          closable={false}
          keyboard={true}
          open={this.props.isOpen}
          style={{ zIndex: "auto", marginTop: "130px" }}
          width={isMobile ? 360 : 540}
          className="dcs-dashboard"
          mask={false}
      >
        {this.state.isDCSModalOpen ? (
            <DCSOverviewModal
                selectedDCS={this.context.selectedDCS}
                isOpen={this.state.isDCSModalOpen}
                onClose={() => this.setState({ isDCSModalOpen: false })}
                dcsDataMap={this.context.dcsDataMap}
                onDCSChange={this.props.onDCSChange}
                profileData={this.context.profileData}
                updateUserProfileAndReadDashboardData={this.props.updateUserProfileAndReadDashboardData}
            />
        ) : null}
        <Content>
          <Row className="regContainer">
            <Row style={{ paddingTop: "10px" }} type="flex" gutter={[8, 0]}>
              <Col>
                <Text className="subclass-overview"> Overview of </Text>
              </Col>
              <Col>
                {this.subclassDropdownValue() === "no-subclass" ? (
                    <UXSpin />
                ) : (
                    <Row
                        onClick={this.handleClickingCurrentClassOverviewText}
                        type="flex"
                        justify="space-between"
                        align="middle"
                    >
                      <Col>
                        <Text className="subclass-dropdown subclass-dotted">
                          {" "}
                          {DCSUtil.getFormattedCamelSpaceString(this.subclassDropdownValue())}
                        </Text>
                      </Col>
                    </Row>
                )}
              </Col>
              <Col>
                {" "}
                <Badge
                    offset={[15, 0]}
                    count={
                      <div>
                        <Tooltip title={this.getToolTipData()} placement="bottom">
                          <i className="material-icons-outlined subclassInfoIcon">
                            info
                          </i>
                        </Tooltip>
                      </div>
                    }
                ></Badge>
              </Col>
            </Row>
            {/*need to convert justify to spaceAround when comp data is ready*/}
            <Row
                gutter={[60, 32]}
                className="regContainer"
                type="flex"
                justify="start"
                align="middle"
            >
              <Col>
                <Row type="flex" justify="space-around" align="middle">
                  <Col>
                    <Text className="subclass-detail">
                      {this.context.dashboardData.hasOwnProperty("fiscalWeek")
                          ? this.context.dashboardData.fiscalWeek
                          : "-"}
                    </Text>
                  </Col>
                </Row>
                <Row type="flex" justify="space-around" align="middle">
                  <Col>Fiscal Week</Col>
                </Row>
              </Col>
              <Col>
                <Row type="flex" justify="space-around" align="middle">
                  <Col>
                    <Text className="subclass-detail">
                      {this.context.dashboardData.hasOwnProperty(
                          "disasterStoreMap"
                      )
                          ? Object.values(
                              this.context.dashboardData.disasterStoreMap
                          ).length
                          : 0}
                    </Text>
                  </Col>
                </Row>
                <Row type="flex" justify="space-around" align="middle">
                  <Col>Disaster Stores</Col>
                </Row>
              </Col>
              {/*will be added later*/}
              {/*<Col><Row type="flex" justify="space-around"*/}
              {/*          align="middle"><Col><Text*/}
              {/*    className="subclass-detail">3.2%</Text></Col></Row><Row*/}
              {/*    type="flex" justify="space-around"*/}
              {/*    align="middle"><Col>Comp</Col></Row></Col>*/}
              {/*<Col><Row type="flex" justify="space-around"*/}
              {/*          align="middle"><Col><Text*/}
              {/*    className="subclass-detail">2.9%</Text></Col></Row><Row*/}
              {/*    type="flex" justify="space-around"*/}
              {/*    align="middle"><Col>Units</Col></Row></Col>*/}
            </Row>
          </Row>
          <Row gutter={[8, 32]}>
            <Col>
              <Divider className="dividerNoGap" />
            </Col>
          </Row>
          <Dropdown
              overlay={menu}
              trigger={["click"]}
              className="perf-dropdown"
          >
            <Row
                className="regContainer"
                gutter={[8, 32]}
                type="flex"
                justify="space-between"
                align="middle"
            >
              <Col className="perfomanceDropdown">
                <Text className="subclass-overview">
                  {" "}
                  {
                    this.state.performanceFilterData.get(
                        this.state.selectedPerformanceType
                    ).value
                  }{" "}
                </Text>
              </Col>
              <Col>
                <CaretDownOutlined />
              </Col>
            </Row>
          </Dropdown>
          <Row gutter={[8, 32]}>
            <Col>
              <Divider className="dividerNoGap" />
            </Col>
          </Row>
          {this.getSkuDetails()}
        </Content>
      </Drawer>
    );
  }
}
