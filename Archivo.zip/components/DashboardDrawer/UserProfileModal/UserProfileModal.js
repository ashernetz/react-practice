import React, { Component } from 'react';
import {Button, Row, Col, Typography, Modal, Select,Layout} from 'antd';
import SkuContext from "../../../context/SkuContext";
import PriceDataServices from "../../../services/PriceDataServices";
import AlertUtil from "../../Utils/AlertUtil";
import Mpulse from './Mpulse.png';
import './UserProfileModal.scss';
import ProfileUtil from "../../Utils/ProfileUtil";
import DCSUtil from "../../Utils/DCSUtil";

const { Text } = Typography;
const { Option } = Select;
const {Content} = Layout;


export default class UserProfileModal extends Component {
  static contextType = SkuContext;
  state = {
    title: "",
    deptNumber:0,
    classNumber:0,
    subclassNumber:0
  };

  onMpulseLaunch=()=>{
    this.context.updateShowDimmer(true);
    this.props.onClose();
    PriceDataServices.createUserProfileData(this.state.title,DCSUtil.getHyphenatedDCS(this.state.deptNumber,this.state.classNumber,this.state.subclassNumber),this.props.user).then(response=>{
      //let dcsKey = response.data.departmentNumber + '-' + response.data.classNumber + '-' +response.data.subClassNumber;
      // this.context.updateProfileData({
      //   ...response.data,
      //   subClassDetails:dcsKey
      // });
      this.props.readUserProfile();
      //this.props.loadDcsDetails(dcsKey);

      //this.context.updateShowDimmer(false);
      //this.context.updateStateFields({dashboardData: response.data});
     
      //this.props.readPerformersDCSDetails(dcsKey);
      
      //this.context.updateShowDimmer(false);

    }).catch(error => {
      this.context.updateShowDimmer(false);
      let alertMessage =  AlertUtil.getErrorMessage("creating user profile");
      if (error.response.status === 422) {
        // if (error.response.data.includes("No SKUs exist")) {
        //   AlertUtil.showAlert("warning", "No Data",
        //       error.response.data + " Please select different subClass");
        // } else {
          this.props.onOpen();
          console.log(error.response.data);
          AlertUtil.showAlert("error", "Error", alertMessage);
           // }
      } else {
        this.props.onOpen();
        console.log(error.response.data);
        AlertUtil.showAlert("error", "Error", alertMessage);
      }

      console.log(error);
    });

  };


  render() {

    return (
      
      <Content>
        <Modal 
            open={this.props.isOpen}
            centered={true}
            closable={false}
            width={'auto'}
            footer={[
              <Button disabled={ !(this.state.classNumber !== 0  && this.state.title)} key="submit"  type="primary" size='large' onClick={this.onMpulseLaunch}>
                Launch Mpulse
              </Button>,
            ]}
        >
          {/* <Row gutter={[0,40]} type="flex" justify="center" align="middle">
                    <Col><img src={logoColor} alt="" style={{ width: '80%' }} /></Col></Row> */}
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle">
            <Col justify="center" align="middle">
              <img className="image-impulse" alt = "mpulse" src={Mpulse} />
            </Col>
          </Row>         
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle">
                  <Col><Text className="userModal">Welcome to MPulse </Text><Text className="userModal">{ProfileUtil.getFirstName(this.props.user)}!</Text></Col>
         </Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle">
            <Col span={20} align="center"><Text style={{ fontSize: 'medium',fontWeight:"400"}}>To help give you a personalized experience we need to know some quick information.</Text></Col>
          </Row>
          <Row style={{marginBottom:'16px'}} type="flex" justify="center" align="middle">
            <Col><Text className="userModal">What is your Title?</Text></Col>
          </Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle"><Col span={10}>

                  <Select size='large' placeholder={<Text strong>Select Title</Text>} style={{ width: "100%"}}
                    onChange={(value) => this.setState({title:value})}>
              {ProfileUtil.userPositionList.map(titleLabel =>
                  (<Option key={titleLabel} value={titleLabel} >{titleLabel}</Option>))
              }
            </Select></Col></Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle">
            <Col><Text className="userModal">What is your primary Hierarchy?</Text></Col></Row>


          <Row style={{marginBottom:'8px'}} type="flex" justify="center" align="middle">
            <Col span={10}><Text className="userModal">Department</Text></Col>
          </Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle"><Col span={10}>
            <Select 
                size={"large"}
                showSearch
                placeholder={"Select Dept"}
                disabled={this.state.title === 0}
                style={{ width: "100%" }}
                optionFilterProp="children"
                onChange={(value) => this.setState({ deptNumber: value, subclassNumber: 0, classNumber: 0 })}
                filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
            >
              {DCSUtil.getDeptDropdownData(this.context.dcsDataMap)}
            </Select>
          </Col></Row>
          <Row style={{marginBottom:'8px'}} type="flex" justify="center" align="middle">
            <Col span={10}><Text className="userModal">Class</Text></Col>
          </Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle"><Col span={10}>
            <Select
                size="large"
                showSearch
                disabled={this.state.deptNumber === 0}
                placeholder={"Select Class"}
                style={{ width: "100%"}}
                block
                optionFilterProp="children"
                value={this.state.classNumber === 0 ? [] : this.state.classNumber}
                onChange={(value) => this.setState({ classNumber: value, subclassNumber: 0 })}
                filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
            >
              {DCSUtil.getClassDropdownData(this.context.dcsDataMap,this.state.deptNumber)}
            </Select>
          </Col></Row>

          <Row style={{marginBottom:'8px'}} type="flex" justify="center" align="middle">
            <Col span={10}><Text className="userModal" >Subclass</Text></Col></Row>
          <Row style={{marginBottom:'20px'}} type="flex" justify="center" align="middle"><Col span={10}>
            <Select
                size="large"
                showSearch
                disabled={this.state.classNumber === 0}
                placeholder={"Select Subclass"}
                style={{ width: "100%" }}
                optionFilterProp="children"
                value={this.state.subclassNumber === 0 ? [] : this.state.subclassNumber}
                onChange={(value) => this.setState({ subclassNumber: value })}
                filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
            >{
              DCSUtil.getSubClassDropdownData(this.context.dcsDataMap,this.state.deptNumber, this.state.classNumber)
            }
            </Select>
          </Col></Row>
        </Modal>
        
        </Content>

    );
  }
}