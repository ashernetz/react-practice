import React, { Component , Fragment } from 'react';
import { Button, Row, Col, Typography, Modal, Divider, Tooltip, Badge} from 'antd';
import './CompetitorStoreModal.scss';
import CompetitorUtil from "../../Utils/CompetitorUtil";
import SkuContext from "../../../context/SkuContext";
import UXImage
  from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import CompUtil from "../../Utils/CompUtil";
import StaticMap from '../../MapComponent/StaticMap/StaticMap';
import SvgUtil from "../../Utils/SvgUtil";
import PriceDataServices from "../../../services/PriceDataServices";
import PriceHistoryChart from '../../GlobalComponents/PriceHistoryChart/PriceHistoryChart';
import moment from 'moment';
import PriceChangeHistoryUtil from '../../Utils/PriceChangeHistoryUtil';

const { Text,Paragraph } = Typography;

export default class CompetitorStoreModal extends Component {

  static contextType = SkuContext;
  state = {
    snapshotdata: false,
    storeRetailAmount : "",
    thdNearestStoreName: "",
    competitorSkuStorePriceHistory: [],
    loadingCompPriceHist: false,
    errorLoadingCompPriceHist: false,
    thdStorePriceHistory:[]
  };

  fetchCompSnapshotData = () => {
    PriceDataServices.getCompetitorSnapshotData(this.props.competitorData.competitorId, this.props.competitorData.cacheerId, this.props.config.compSnapshotUrl)
      .then(response => {

        //console.log("comp snap  ",response.data);
        this.setState({snapshotdata: true})
      })
      .catch(error => {
        this.setState({snapshotdata: false})
        console.log(error)
      })
  };

  fetchCompetitorNearestTHDStore = () => {
    PriceDataServices.getCompetitorNearestTHDStore(
        this.props.competitorData.store, this.props.competitorData.competitorId,
        this.props.config.thdStoreCompetitorUrl).then(response => {

      let thdStore = response.data ? (response.data.thdStore ? response.data.thdStore.toString() : "") : "";
      Object.values(this.context.skuData.pricePointDetails).forEach(priceObject => {
        Object.values(priceObject.storeDetails).forEach(storeObject => {
          if(storeObject.storeId.toString() === thdStore){
            let storeRetailAmount = storeObject.retail;
            let thdNearestStoreName = `${storeObject.storeName}#${thdStore}`;
            let thdStorePriceHistory = PriceChangeHistoryUtil.getPriceChangeHistoryForStore(thdStore, this.context.skuPriceChangeHistoryMap.storeHistoryMap);
            this.setState({storeRetailAmount,thdNearestStoreName,thdStorePriceHistory});

          }
        })
      });
    }).catch(error => {
      console.log(error);
    })
  };

  fetchCompetitorSkuStorePriceHistory = (numberOfMonths) => {
    this.setState({loadingCompPriceHist: true});
    let startDate, endDate;
    if (numberOfMonths) {
      startDate = moment().subtract(numberOfMonths, "months").format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    }
    let scrapeId = this.props.competitorData.scrapeId;
    if (scrapeId) {
      PriceDataServices.getCompetitorSkuStorePriceHistory(this.context.skuNumber, this.props.competitorData.competitorId, this.props.competitorData.storeId, scrapeId, startDate, endDate).then(response => {
        this.setState({competitorSkuStorePriceHistory: response.data,loadingCompPriceHist: false});
      }).catch(err => {
        console.log("Error fetching competitor price history: ", err);
        this.setState({errorLoadingCompPriceHist: true,loadingCompPriceHist: false})
      })
    } else {
      this.setState({loadingCompPriceHist: false, errorLoadingCompPriceHist: true})
    }
    
  }

  componentDidMount() {
    
    this.fetchCompSnapshotData();
    this.fetchCompetitorNearestTHDStore();
  }

  inferredInfo = () => {
    return (
        <>
          <Row>
            <Col className="inferred-tooltip-text">
              <Text>
                This SKU is designated as "nationally priced" at Lowe's since the price
                was the same at every Lowe's store scraped for at least the past 30
                days. This logic optimally uses scrape capacity while maintaining high
                confidence in the inferred prices.
              </Text>
            </Col>
          </Row>
          <Row>
            <Col className="inferred-tooltip-bullet-title"><Text className="inferred-price-header-text">Nationally Priced SKUs:</Text></Col>
          </Row>
          <Row>
            <Col className="inferred-tooltip-text">
              <Row align="top" gutter={[0,8]} style={{marginBottom: "8px"}}>
                <Col span={1}><Badge color="#000000"  className="inferred-tooltip-badge"/></Col>
                <Col span={23} className="tooltip-col-space">
                  <Text>Prices are scraped at a subset of randomized Lowe’s locations daily to enable continuous monitoring of competitor pricing</Text>
                </Col>
              </Row>
              <Row align="top" gutter={[0,8]} style={{marginBottom: "8px"}}>
                <Col span={1}><Badge color="#000000"  className="inferred-tooltip-badge"/></Col>
                <Col span={23} className="tooltip-col-space">
                  <Text>Every location is scraped at least once every 30 days</Text>
                </Col>
              </Row>
              <Row align="top" gutter={[0,8]} style={{marginBottom: "8px"}}>
                <Col span={1}><Badge color="#000000"  className="inferred-tooltip-badge"/></Col>
                <Col span={23} className="tooltip-col-space">
                  <Text>SKUs are removed from the nationally priced list if we observe different prices across locations</Text>
                </Col>
              </Row>
            </Col>
          </Row>
          <Row>
            <Col><Text className="inferred-price-header-text">Non-Nationally Priced SKUs:</Text></Col>
          </Row>
          <Row>
            <Col className="inferred-tooltip-text">
              <Row align="top" gutter={[0,8]} style={{marginBottom: "8px"}}>
                <Col span={1}><Badge color="#000000"  className="inferred-tooltip-badge"/></Col>
                <Col span={23} className="tooltip-col-space">
                  <Text>
                    Prices are scraped at ~400 Lowe's locations on a regular cadence of 2-14 days
                  </Text>
                </Col>
              </Row>
            </Col>
          </Row>
        </>

    );
  }
  

  render() {

    let competitorData = this.props.competitorData;
    let snapshoturl = "snapshot.html?compid="+this.props.competitorData.competitorId+"&cachid="+this.props.competitorData.cacheerId;
    let compheading = competitorData.name === 'F&D' ? "F&D "+ CompetitorUtil.getFormattedCamelSpaceString(competitorData.storeName) + " #" + competitorData.store : CompetitorUtil.getFormattedCamelSpaceString(competitorData.name+" "+competitorData.storeName) + " #" + competitorData.store;
    return (
      <Modal
        style={{ width: "800px" }}
        open={this.props.isOpen}
        onCancel={this.props.onClose}
        closable={true}
        maskClosable={true}
        footer={null}
        destroyOnClose ={true}>
        <Row align="middle" type="flex" gutter={[16, 24]} style={{paddingBottom:"24px"}} >
          <Col>
            <img className="competitorImgSize" alt="competitor" src={CompetitorUtil.getCompetitorImage(competitorData.competitorId)} />
          </Col>
          <Col className="modalHeaderTextCont" >
            <Row type="flex"> <Col><Text type="storeName">
            {compheading}
              
            </Text></Col></Row>
          </Col>

        </Row>
                <Divider />
        <Row type="flex" gutter={[0, 32]} style={{marginBottom: "32px"}}>
          <Col>
            {(competitorData.name.trim().startsWith('Lowe') &&
                competitorData.scrapeReason && competitorData.scrapeReason === 'national price') ?<>
                <Text className="modalHeading">Matched SKU Comparison (Nationally Inferred Price)</Text>
                <Tooltip arrowPointAtCenter={true} title = {this.inferredInfo} placement ='bottom' color="#ffffff"
                                                          overlayClassName="inferred-tooltip-arrow"
                                                          overlayInnerStyle={{
                                                            padding: '27px ',
                                                            width: '510px',
                                                            height: '315px',
                                                            marginLeft: '-127px',
                                                          }} >
              <i className="material-icons-outlined inferred-tooltip-info">info</i>
            </Tooltip> </> :  <Text className="modalHeading">Matched SKU Comparison </Text>}

          </Col>
        </Row>
        {competitorData.type === 'competitor-detail'?
        <Fragment>
        <Row type="flex" gutter={[0, 24]} style={{marginBottom: "24px"}} justify="space-around" >
          <Col span={11} style={{padding:"12px"}}>
            <ProductCard
              skuImage={competitorData.skuImageUrl}
              skuNumber={competitorData.sku}
              skuName={competitorData.skuName}
              dollar={"$" +(competitorData.scaledPricePennies / 100).toFixed(2)}
              scrapeType= {competitorData.scrapeType}
              lastScrape={competitorData.scrapeDate}
              heading={competitorData.name + " Product Match"}
              thdNearestStoreName = ""

            /></Col>
          <Col span={2} style={{textAlign:"center"}}><Divider type="vertical" className="verticalDivider" /></Col>
          <Col span={11} style={{padding:"12px"}}>
            <ProductCard
              skuImage={this.context.skuImageUrl}
              skuNumber={this.context.skuNumber}
              skuName={this.context.skuDescription}
              dollar={this.state.storeRetailAmount?`$${CompUtil.formatPrice(this.state.storeRetailAmount)}`:`$${CompUtil.formatPrice(competitorData.minMaxPriceRange[0])} - $${CompUtil.formatPrice(competitorData.minMaxPriceRange[1])}`}
              heading="Nearby THD Product"
              thdNearestStoreName={this.state.thdNearestStoreName}
            /></Col>
          
        </Row>

        <Row className="viewOnlineRow" gutter={[0, 24]} style={{marginBottom: "24px"}} justify="start">
          <Col span={11}>
            <Button key="back" type="primary" ghost='true' href={competitorData.skuUrl} target="blank" size="large" block>
              View Online
              </Button>
          </Col>
          <Col span={2}/>
          <Col span={11}>
            {this.state.snapshotdata ?
              <Button key="back"  href={snapshoturl} target="blank" size="large" type="primary" ghost='true' block >
              View Snapshot
              </Button>
              :  <Button key="back"  href={snapshoturl} target="blank" size="large" type="primary" ghost='true' block  disabled>
              View Snapshot
              </Button>
            }  
          </Col>
        </Row>
        </Fragment>
        :  <Fragment>
        <Row justify="center" align="middle" type="flex">
          <Col className="noKVI">
            {SvgUtil.getNoData()}
          </Col>
        </Row>
        <Row justify="center" align="middle" type="flex" style={{paddingTop: "10px" }}>
          <Col>
            <Text className="no-kvi-bold">
              No Match or Prices found for this Location
            </Text>
          </Col>
        </Row>
        <Paragraph/>
       
        <Row justify="center" align="middle" type="flex">
          <Col>
            <Text className="no-kvi">
               Please select a location with a price point to get matched sku
            </Text>
          </Col>
        </Row>
        <Row justify="center" align="middle" type="flex">
          <Col>
            <Text className="no-kvi">
               information
            </Text>
          </Col>
        </Row>
        <Paragraph/>
      </Fragment>
        }
        
        <Divider />
        <PriceHistoryChart
          competitorPriceHistory={this.state.competitorSkuStorePriceHistory}
          thdStorePriceHistory={PriceChangeHistoryUtil.reverse(this.state.thdStorePriceHistory)}
          fetchCompetitorPriceHistory={this.fetchCompetitorSkuStorePriceHistory}
          headerTitle={"Price History"}
          isLoading = {this.state.loadingCompPriceHist?"Y":"N"}
          isNoData = {(competitorData.type !== 'competitor-detail'|| this.state.errorLoadingCompPriceHist)?"Y":"N"}
        />

        <Divider/>
        <StaticMap
          apiKey={this.props.apiKey}
          zoom={17}
          scale={4}
          format={"png32"}
          mapWidth={"640"}
          mapHeight={"229"}
          storeLatitude={competitorData.latitude}
          storeLongitude={competitorData.longitude}
          markers={[{
            color:CompetitorUtil.getCompetitorMarkerColor(competitorData.competitorId) ,
            size: "tiny",
            scale: 2,
            lat: competitorData.latitude,
            lng: competitorData.longitude
          }]}
        />


        {/* 
          <Row type="flex" gutter={[40, 0]}><Divider /></Row>

          <div className="modalSection">
            <Row id="price-history-tab-id" className="storePriceHistory"><Col span={10}>
              <Text className="modalHeading" align='right'>Price History</Text> </Col>
            </Row>
            <div id="container">
              <ScatterChart width={666} height={149} margin={{ top:30, right: 10, bottom: 30, left: 10 }}>
                <CartesianGrid />
                <XAxis type="number" dataKey={'x'} name='stature' />
                <YAxis type="number" dataKey={'y'} name='weight'  />
                <ZAxis range={[25]} />
                <Tooltip cursor={{ strokeDasharray: '2 2' }} />
                <Legend align="right" />
                <Scatter name='THD' data={data01} fill='#fa6304' line />
                <Scatter name='F&D' data={data02} fill='#333333' line />
              </ScatterChart>
            </div>
            <Table columns={columns} dataSource={data} />
          </div> */}



      </Modal>

    );
  }
}

export const ProductCard = props => {
  return (

    <Row type="flex" align="middle" gutter={[16, 0]} style={{marginBottom: "16px"}}>
      <Col>
        <Row type="flex" justify="start" align="middle" >
          <Col><Text className="competitorHeading">{props.heading}</Text></Col>
        </Row>
        <Row type="flex" justify="start" align="middle" gutter={[0, 24]} style={{marginBottom: "24px",alignItems:'center',minHeight:'25px'}}>
          <Col><Text className="competitorHeading">{props.thdNearestStoreName}</Text></Col>
        </Row>
        <Row type="flex" justify="space-around" align="middle" gutter={[0, 24]} style={{marginBottom: "24px",alignItems:'center',minHeight:'200px'}}>
          <Col><UXImage classNames ="rowCompetitorImgSize" imageUrl={props.skuImage}/></Col>
        </Row>
        <Row type="flex" justify="space-around" align="middle" gutter={[0, 24]} style={{marginBottom: "24px"}}>
          <Col><Text>SKU {props.skuNumber}</Text></Col>
        </Row>
        <Row gutter={[0, 24]} style={{marginBottom: "24px"}}>
          <Col><Text className="quickreteHeading">{props.skuName.toUpperCase()}</Text></Col>
        </Row>
        <Row gutter={[0, 24]} style={{marginBottom: "24px"}}>
          <Col><Text>Shelf Price</Text></Col>
        </Row>
        <Row>
          <Col><Text className="dollarHeading">{props.dollar}</Text></Col>
        </Row>
        <Row >
         
          {props.lastScrape ? <Col><Text>Last Scrape:  {props.scrapeType === "actual" ?  CompetitorUtil.getDateInStandardFormat(props.lastScrape) : "Store Not Scraped"} </Text></Col> : <Col />}
        </Row>
      </Col>
    </Row>
  );
};
