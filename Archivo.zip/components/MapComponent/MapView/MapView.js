import React, {Component} from 'react';
import GoogleMapReact from 'google-map-react';
import Marker from '../Marker/Marker';
import './MapView.scss';
import ReactDOM from 'react-dom';
import MapStyle from "./MapStyle";
import supercluster from 'points-cluster';
import Icon, { SearchOutlined,ArrowLeftOutlined } from '@ant-design/icons';
import SkuContext from "../../../context/SkuContext";
import LocationDropdown from "./../LocationDropdown/LocationDropdown";
import {Button} from "antd";

const MAP = {
  defaultZoom: 5,
  defaultCenter: {
    lat:40.98832580000001,
    lng:-98.2643519000000,
    // lat: 38.5266,
    // lng: -96.726486
  },
  options: {
    styles: MapStyle.getMapStyle(),
    maxZoom: 16,
    minZoom: 3,
    zoomControl:true
  },
};
let searchIcon = document.createElement('div');
//let topCenterDiv = document.createElement('div');

// ReactDOM.render( <div className="disasterOverlay"><i className="material-icons disasterOI">
//   warning</i> <div className="disasterOverlayText">Disaster Stores Overview</div></div>,topCenterDiv);


export default class MapView extends Component {

  static contextType = SkuContext;
  storeDropDownRef = React.createRef();
  state = {
    mapOptions: {
      center: MAP.defaultCenter,
      zoom: MAP.defaultZoom,
    },
    zoomControlOptions:{},
    clusters: [],
    isShowMapToolTip : false,
    toolTipStyle : {},
    isSearchLocationEnabled : false
  };

  componentDidUpdate(prevProps, prevState, snapshot) {
    if (this.props !== prevProps) {
      if(this.props.locationFilterData !== prevProps.locationFilterData && this.storeDropDownRef.current){
          this.storeDropDownRef.current.setState({locationFilterData :this.props.locationFilterData});
        }
      if (this.props.skuNumber !== prevProps.skuNumber ) {
        let mapOptions = {...this.state.mapOptions};
        mapOptions.center = MAP.defaultCenter;
        mapOptions.zoom = MAP.defaultZoom;
        this.setState({mapOptions });
      }
      //if(this.props.isDashboardOpen !== prevProps.isDashboardOpen){
        //topCenterDiv.style.display = this.props.isDashboardOpen ? "block" : "none";
      //}
      this.createClusters(this.props, this.props.markersData);

    }
  }

  getClusters = (markers) => {
    let finalMarkers = markers;
    if(this.state.mapOptions.bounds && this.state.maps){
      let bounds = new this.state.maps.LatLngBounds(
          this.state.mapOptions.bounds.sw, this.state.mapOptions.bounds.ne);
      finalMarkers =  markers.filter(k=> bounds.contains({lat: k.lat, lng: k.lng}));
    }

    const clusters = supercluster(finalMarkers, {
      maxZoom: 16,
      radius: 40,
    });

    return clusters(this.state.mapOptions);
  };

  createClusters = (props,markers) => {
    this.setState({
      clusters: this.state.mapOptions.bounds
          ? this.getClusters(markers).map(({ wx, wy, numPoints, points }) => ({
            lat: wy,
            lng: wx,
            numPoints,
            id: `${numPoints}_${points[0].id}`,
            points,
          }))
          : [],
    });
  };

  handleMapChange = (totalValues) => {
    let { center, zoom, bounds } = totalValues;
    if(this.props.isMapClusteringChecked){
      this.setState(
          {
            mapOptions: {
              center,
              zoom,
              bounds,
            },
          },
          () => {
            this.createClusters(this.props,this.props.markersData);
          }
      );
    }else {
      this.setState(
          {
            mapOptions: {
              center,
              zoom,
              bounds,
            },
          }
      );
    }



  };

  onChildMouseEnter = (key,childProps,e) => {
    if (key.toString().includes("store")) {
      let xMax = this.props.isFilterDrawerOpen? 700: 1000;

      let yThreshold = 400;
      let toolTipStyle = e.clientX < xMax ? {left:0} : {right:0};
      e.clientY > yThreshold ? toolTipStyle.bottom = 0 : toolTipStyle.top = 0;
      this.setState({
        isShowMapToolTip: true,
        toolTipLat: childProps.lat,
        toolTipLng: childProps.lng,
        toolTipData: childProps.store,
        toolTipStyle
      });

    } };

  onChildMouseLeave = () => {
    this.setState({isShowMapToolTip:false});

  };

  getMarkers = (points) => {
    let maps = this.state.maps;
    //let totalSize = points.length;
    let slices = [];
    if (maps) {
      let colorMap = {};

      points.forEach(slice => {
        if (colorMap.hasOwnProperty(slice.pointerColor)) {
          colorMap[slice.pointerColor]["slice"]=null;
          colorMap[slice.pointerColor]["count"] = colorMap[slice.pointerColor]["count"]
              + 1;
          colorMap[slice.pointerColor]["polygonCoords"].push(
              new maps.LatLng(slice.lat, slice.lng))
        } else {
          colorMap[slice.pointerColor] = {
            count: 1,
            key: slice.id,
            lat: slice.lat,
            lng: slice.lng,
            polygonCoords: [new maps.LatLng(slice.lat, slice.lng)],
            slice
          };
        }
      });
      Object.keys(colorMap).forEach(color => {
        let bounds = new maps.LatLngBounds();

        for (let i = 0; i < colorMap[color].polygonCoords.length; i++) {
          bounds.extend(colorMap[color].polygonCoords[i]);
        }
        //let radius = colorMap[color]["count"]*0.16 + 20;
        let radius = 35;
        if (colorMap[color]["count"] > 50) {
          radius = colorMap[color]["count"] * 0.08 + 20;
        }
        radius = radius < 35 ? 35 : radius;
        // let radius = colorMap[color]["count"]*60/totalSize;
        // radius = radius < 20 ? 20 : radius>40 ? 40 :radius;
        let storeCount = colorMap[color]["count"];
        //this.getIndividualStoreMarkers(item.points[0],item.id,animate)
        if(storeCount === 1){
          slices.push(this.getIndividualStoreMarkers(colorMap[color].slice,colorMap[color].slice.id,this.state.animateStore === colorMap[color].slice.store.storeId));
        }else {
          slices.push( <Marker
              isFilterDrawerOpen = {this.props.isFilterDrawerOpen}
              key={colorMap[color].key + "bubble"}
              valueKey={colorMap[color].key + "bubble"}
              latt={colorMap[color].lat}
              lngg={colorMap[color].lng}
              lat={bounds.getCenter().lat()}
              lng={bounds.getCenter().lng()}
              pointerColor={color}
              shape="bubble"
              onMapPointerClick={this.onMapPointerClick}
              onMapPointerEnter = {this.onChildMouseEnter}
              onMapPointerLeave = {this.onChildMouseLeave}
              storeCount = {storeCount}
              radius={radius}/>
          )
        }


      });
    }
    return slices;
  };

  pointsRenderBasedOnBounds = (markers) => {

    let finalMarkers= [];
    let bounds = new this.state.maps.LatLngBounds(
        this.state.mapOptions.bounds.sw, this.state.mapOptions.bounds.ne);

    this.props.markersData.forEach(marker =>
    {
      if(bounds.contains({lat: marker.lat, lng: marker.lng})){
        let animate = false;
        if(this.state.animateStore === marker.store.storeId){
          animate = true;
        }
        finalMarkers.push( this.getIndividualStoreMarkers(marker,marker.id,animate)
        //     <Marker
        //     store = {marker.store}
        //     shape={marker.shape}
        //     key={"store" + marker.id}
        //     valueKey = {"store" + marker.id}
        //     lat={marker.lat}
        //     lng={marker.lng}
        //     pointerColor={marker.pointerColor}
        //     onMapPointerClick = {this.onMapPointerClick}
        //
        //     onMapPointerEnter = {this.onChildMouseEnter}
        //     onMapPointerLeave = {this.onChildMouseLeave}
        //     animate = {animate}
        // />
        );
      }

    });
    return finalMarkers;
  };
  onMapPointerClick = (key,childProps)=> {
    this.setState({isShowMapToolTip:false});

    if (childProps.valueKey.toString().includes("bubble")) {

      let mapOptions = {...this.state.mapOptions};
      mapOptions.zoom = mapOptions.zoom + 4;
      mapOptions.center = {lat:childProps.latt,lng:childProps.lngg};
      this.setState({mapOptions});
    }else if (childProps.valueKey.toString().includes("store")) {
      if (!["dashboard","competitor"].includes(childProps.store.type)) {
          this.props.onMapPointerClick(childProps.valueKey,childProps);

      }
    }

  };

  onMapBubbleClick = (lat,lng) => {
    let mapOptions = {...this.state.mapOptions};
    mapOptions.zoom = mapOptions.zoom + 3;
    mapOptions.center = {lat,lng};
    this.setState({mapOptions});
  }

  onLocationDropdownSelect = (value, option) => {
    let that = this;
    let mapOptions = {...this.state.mapOptions};
    mapOptions.zoom = 12;
    mapOptions.center = {lat:Number.parseFloat(value.split("|")[0]),lng:Number.parseFloat(value.split("|")[1])};
    //that.props.clusterControl(false);
    this.setState({mapOptions,animateStore:Number.parseInt(option.key)});
    setTimeout(function(){ that.setState({animateStore:0}) }, 7000);
  };

  getIndividualStoreMarkers=(marker,id,animate)=> {
   return <Marker
    isFilterDrawerOpen = {this.props.isFilterDrawerOpen}
    store = {marker.store}
    shape={marker.shape}
    key={"store" + marker.id}
    valueKey = {"store" + marker.id}
    lat={marker.lat}
    lng={marker.lng}
    pointerColor={marker.store.pointerColor}
    onMapPointerClick = {this.onMapPointerClick}
    onMapPointerEnter = {this.onChildMouseEnter}
    onMapPointerLeave = {this.onChildMouseLeave}
    animate = {animate}
    />

  };

  render() {

    let that = this;
    let mapOptions = {...MAP.options,zoomControlOptions:this.state.zoomControlOptions};
    let clusters  = [];
    if(this.state.clusters.length === 0){
      clusters = this.state.mapOptions.bounds ? this.getClusters(this.props.markersData).map(({ wx, wy, numPoints, points }) => ({
        lat: wy,
        lng: wx,
        numPoints,
        id: `${numPoints}_${points[0].id}`,
        points,
      })) : [];
    }else {
      clusters = this.state.clusters;
    }


    return (
      <div id ="map-component" style={this.props.mapDivStyle}>


        <GoogleMapReact
            options={mapOptions}
            onChange={this.handleMapChange}
            onChildMouseLeave = {()=>this.onChildMouseLeave()}
            onGoogleApiLoaded={
              ({ map, maps }) =>

              {


                let centerControlDiv = document.createElement('div');
                centerControlDiv.addEventListener('click', function() {
                  let mapOptions = {...that.state.mapOptions};
                  mapOptions.center = MAP.defaultCenter;
                  mapOptions.zoom = MAP.defaultZoom;
                  that.setState({mapOptions });
                  that.props.clusterControl(true);
                });

                ReactDOM.render(<Icon className="mapZoomOut" style={{
                  alignContent: 'center'}}
                                      component={ () => <svg
                                          viewBox="0 0 500 300" width="25" height="25"
                                      >
                                        <path d="M497 16.066h-16.066c-3.98 0-7.793 1.582-10.606 4.395l-75.941 75.937H380.18l-13.227-52.902a14.996 14.996 0 00-14.55-11.363h-33.2V15c0-8.285-6.719-15-15-15H47.133a15.002 15.002 0 00-14.23 10.258L.77 106.656a14.929 14.929 0 00-.618 6.864L16.22 225.988a15.01 15.01 0 005.847 9.88l64.27 48.198c2.594 1.946 5.754 3 9 3h58.05l11.673 11.672a15.012 15.012 0 0010.609 4.395h24.105l27.68 41.52a15.001 15.001 0 0012.48 6.679h32.133a14.997 14.997 0 0014.23-10.258l12.65-37.941h13.288c5.68 0 10.875-3.211 13.414-8.293l3.891-7.774h48.781l43.809 43.809c5.855 5.855 15.351 5.855 21.21 0l32.134-32.137a14.997 14.997 0 001.875-18.925l-21.176-31.766a9.113 9.113 0 011.137-11.477l18.164-18.164a15.003 15.003 0 004.394-10.605v-44.66l30.551-61.098A15 15 0 00512 95.332V31.066c0-8.285-6.715-15-15-15zm-15 75.727l-30.55 61.098a14.988 14.988 0 00-1.583 6.71v41.985l-13.765 13.766c-13.145 13.132-15.2 33.882-4.891 49.335l14.355 21.536-12.832 12.832-37.593-37.594a15.005 15.005 0 00-10.61-4.395h-64.265c-5.68 0-10.875 3.211-13.418 8.293l-3.887 7.774h-14.828a15.002 15.002 0 00-14.23 10.258l-12.65 37.945h-13.292l-27.68-41.524a15.001 15.001 0 00-12.48-6.68h-25.922l-11.672-11.671a15.003 15.003 0 00-10.605-4.395h-59.27l-55.293-41.472-14.687-102.809L57.945 30H289.2v17.133c0 8.285 6.719 15 15 15h36.489l13.226 52.906a14.997 14.997 0 0014.55 11.36h32.138c3.976 0 7.793-1.579 10.605-4.391L482 51.21zm0 0"></path>
                                      </svg>}/>,centerControlDiv);

                ReactDOM.render( <SearchOutlined
                  onClick={() =>  that.setState({isSearchLocationEnabled : !that.state.isSearchLocationEnabled })}
                  className="mapZoomOut"
                  style={{fontSize:'21px', padding:'9px'}} />,searchIcon);
                centerControlDiv.index =1;
                searchIcon.index =-1 ;
                ReactDOM.render(
                    <LocationDropdown ref={that.storeDropDownRef}
                                      onLocationDropdownSelect = {that.onLocationDropdownSelect}
                    />,searchIcon);

                map.controls[maps.ControlPosition.RIGHT_TOP].push(searchIcon);
                map.controls[maps.ControlPosition.RIGHT_TOP].push(centerControlDiv);
                //map.controls[maps.ControlPosition.TOP_CENTER].push(topCenterDiv);


                this.setState({maps,map,
                  zoomControlOptions: {
                    position: maps.ControlPosition.RIGHT_TOP
                  }});


              }}
            yesIWantToUseGoogleMapApiInternals
            bootstrapURLKeys={{key: this.props.apiKey}}
            // onChildClick={this.onMapPointerClick}
            zoom = {this.state.mapOptions.zoom}
            center = {this.state.mapOptions.center}
            zoomControlOptions = {this.state.zoomControlOptions}
            zoomControl ={true}

        >
          {this.props.isMapClusteringChecked ? clusters.map(item => {
            if (item.numPoints === 1) {
              let animate = false;
              if(this.state.animateStore === item.points[0].store.storeId){
                animate = true;
              }
              return ( this.getIndividualStoreMarkers(item.points[0],item.id,animate)
                  // <Marker
                  //     store = {item.points[0].store}
                  //     shape={item.points[0].shape}
                  //     key={"store" + item.id}
                  //     valueKey = {"store" + item.id}
                  //     lat={item.points[0].lat}
                  //     lng={item.points[0].lng}
                  //     pointerColor={item.points[0].store.pointerColor}
                  //     onMapPointerClick = {this.onMapPointerClick}
                  //     onMapPointerEnter = {this.onChildMouseEnter}
                  //     onMapPointerLeave = {this.onChildMouseLeave}
                  //     animate = {animate}
                  // />
              );
            }

            return (
                this.getMarkers(item.points)

            );
          }) : this.pointsRenderBasedOnBounds()}
          {/*{this.state.isShowMapToolTip ?*/}
          {/*    <MapToolTip*/}
          {/*        toolTipStyle={this.state.toolTipStyle}*/}
          {/*        lat={this.state.toolTipLat}*/}
          {/*        lng = {this.state.toolTipLng}*/}
          {/*        store={this.state.toolTipData}/>*/}
          {/*    : null}*/}
        </GoogleMapReact>

      </div>
    );
  }
}
