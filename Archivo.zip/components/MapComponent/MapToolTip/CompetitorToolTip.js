import React, {Fragment} from 'react';
import {Card, Col, Row,Typography} from "antd";
import './MapToolTip.scss'
import './CompetitorToolTip.scss'

import CompetitorUtil from "../../Utils/CompetitorUtil";

const {Text}= Typography;


const getNumberOfDaysBetweenDates = (date1,date2)=>{
  let differenceInTime = 0;
  let differenceInDays = 0;
  if(date1 && date2){
    let convertedDate1 = new Date(date1);
    convertedDate1.setTime(convertedDate1.getTime()+convertedDate1.getTimezoneOffset()*60*1000);
    let convertedDate2 = new Date(date2);
    convertedDate2.setTime(convertedDate2.getTime()+convertedDate2.getTimezoneOffset()*60*1000);
    let time1 = convertedDate1.getTime();
    let time2 = convertedDate2.getTime();

    if(time1 > time2){
      differenceInTime = time1 - time2;
    }else {
      differenceInTime = time2-time1;
    }
    differenceInDays = differenceInTime / (1000 * 3600 * 24);
  }

  return Math.round(differenceInDays);

};

const getDistanceBetweenTwoPointsInMap = (store) => {
  let currentStoreCoordinates = {lat: store.latitude, lng: store.longitude};
  let scrapeStore = store.sourceScrapeStore;
  let competitorId = store.competitorId;
  let distanceInMiles = "-";
  let competitorData = CompetitorUtil.getCompetitorData(
      CompetitorUtil.getCompetitorName(competitorId)).find(
      competitor => competitor.storeId.toString() === scrapeStore.toString());

  if (competitorData) {
    distanceInMiles = CompetitorUtil.getMilesBetweenTwoPointsInMap(
      currentStoreCoordinates,
        {lat: competitorData.latitudeNumber,
      lng: competitorData.longitudeNumber});
  }

  return distanceInMiles;

};

const  CompetitorToolTip = (props) => {
  let priceInDollars = props.store.scaledPricePennies ? "$" +(props.store.scaledPricePennies/100).toFixed(2):"Unknown";
  let scrapeType = props.store.scrapeType;
  return(
      <Card style={{ ...props.toolTipStyle, ...{ zIndex:1,borderLeft: '0.5em solid ' + props.store.pointerColor } }} className='toolTipCard'>
        <Fragment>
          <Row type='flex'><Col><Text className="comp-bold comp-size-2">{props.store.competitor} # {props.store.storeId}</Text></Col></Row>
          <Row gutter={[0,8]} ><Col><Text className="comp-normal comp-size-1">{CompetitorUtil.getFormattedCamelSpaceString(props.store.storeName)}</Text></Col></Row>
          <Row gutter={[0,8]} ><Col><Text className="comp-normal comp-size-1" >{scrapeType === "assigned" && "Estimated "}Price</Text></Col></Row>
          <Row/>
          <Row  gutter={[0,8]}><Col><Text className="comp-bold comp-size-3" >{priceInDollars}{scrapeType === "assigned" && "*"}</Text></Col></Row>
          
           <Row gutter={[0,8]} ><Col><Text className="comp-light comp-size-1" >{"Scrape Date: "} </Text>
              {
                scrapeType === "actual" ?
                    <Fragment>
                      <Text className="comp-normal comp-size-1">{CompetitorUtil.getDateInStandardFormat(props.store.scrapeDate)}</Text>
                      <Text  className="comp-italics comp-size-1">{" ("+getNumberOfDaysBetweenDates(new Date(), props.store.scrapeDate) +" Days ago)"} </Text>
                    </Fragment>
                    :
                    <Text className="comp-normal comp-size-1" >Store Not Scraped</Text>}</Col></Row>
           {scrapeType === "assigned"  && <Row type='flex'>
             <Col><Text className="comp-bold comp-size-1">*Price From #{props.store.sourceScrapeStore} ({getDistanceBetweenTwoPointsInMap(props.store)} mi Away) </Text></Col></Row>}

        </Fragment>
      </Card>);
};


export default CompetitorToolTip;