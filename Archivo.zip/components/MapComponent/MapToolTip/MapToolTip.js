import React, {Fragment} from 'react';
import { Card, Col, Row, Typography, Tag } from "antd";
import './MapToolTip.scss'
import CompUtil from "../../Utils/CompUtil";
import CompetitorToolTip from "./CompetitorToolTip";
import CompetitorUtil from "../../Utils/CompetitorUtil";
const {Text}= Typography;

const getDateInStandardFormat= (inputDate) =>{
  let convertedDate = new Date(inputDate);
  convertedDate.setTime(convertedDate.getTime()+convertedDate.getTimezoneOffset()*60*1000);
  return (convertedDate.getMonth()+1) + "/" + convertedDate.getDate()+ "/" + convertedDate.getFullYear();
};

const getNumberOfDaysBetweenDates = (date1,date2)=>{
  let differenceInTime = 0;
  let differenceInDays = 0;
  if(date1 && date2){
    let convertedDate1 = new Date(date1);
    convertedDate1.setTime(convertedDate1.getTime()+convertedDate1.getTimezoneOffset()*60*1000);
    let convertedDate2 = new Date(date2);
    convertedDate2.setTime(convertedDate2.getTime()+convertedDate2.getTimezoneOffset()*60*1000);
    let time1 = convertedDate1.getTime();
    let time2 = convertedDate2.getTime();

    if(time1 > time2){
      differenceInTime = time1 - time2;
    }else {
      differenceInTime = time2-time1;
    }
    differenceInDays = differenceInTime / (1000 * 3600 * 24);
  }

  return Math.round(differenceInDays);

};
const  MapToolTip = (props) => {
  let compSalesUpOrDown = CompUtil.findPercentageUpOrDown(props.store.compSales);
  let compUnitsUpOrDown = CompUtil.findPercentageUpOrDown(props.store.compUnits);

      if(props.store.type === "competitor-detail"||props.store.type === "competitor-empty"){
        return <CompetitorToolTip toolTipStyle = {props.toolTipStyle} store = {props.store} />
      }
    else{
      return (
        <Card  style={{...props.toolTipStyle,...{borderLeft: '0.5em solid ' + props.store.pointerColor}}} id="tool-tip-map" className='toolTipCard'>
          {props.store.disaster === true ?
            <Tag style={{position: 'absolute', top: 0, right: 0, margin:0}} color="#ff0000">DISASTER</Tag>: null}
          {props.store.type === "competitor" ||  props.store.type === "dashboard"?
              <Fragment><Text strong> Store# {props.store.storeId}</Text>
            <Row type='flex'><Text>{CompetitorUtil.getFormattedCamelSpaceString(props.store.storeName)}</Text></Row></Fragment>:
              <Fragment>
          <Row >
            <Col><Text strong>THD Store# {props.store.storeId}</Text></Col>
            </Row>
                <Row type='flex'><Text>{props.store.storeName}</Text></Row>

          <Row type='flex'><Text strong style={{fontSize: 'x-large'}}>${Number.parseFloat(props.store.retail).toFixed(2)}</Text></Row>
          <Row type='flex'><Text >{props.store.status}</Text></Row>
          <Row gutter={16}  type='flex'>
            <Col><Text>Comp:{CompUtil.formatCompData(props.store.compSales)}{CompUtil.getArrowUpDownComponent(compSalesUpOrDown)} </Text></Col>
            <Col><Text>Units:{CompUtil.formatCompData(props.store.compUnits)}{CompUtil.getArrowUpDownComponent(compUnitsUpOrDown)} </Text></Col>
          </Row>

          <Row  gutter={16} type='flex'>
            <Col><Text>Zone:<Text strong>{props.store.zoneName}</Text></Text></Col>
            <Col><Text>Market:<Text strong>{props.store.mktName}</Text></Text></Col>
          </Row>
          {!isNaN(props.store.effectiveBeginDate)?
          <Text>Effective: {getDateInStandardFormat(props.store.effectiveBeginDate)} ({getNumberOfDaysBetweenDates(new Date(),props.store.effectiveBeginDate)} days ago )</Text>:null}
  </Fragment>}
              </Card>
      );};
};


export default MapToolTip;