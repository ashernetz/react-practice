import React from 'react';
import "./StaticMap.scss"
// import StaticStreetView from '../StaticStreetView/StaticStreetView';
// import {Card} from 'antd';
import customMapStyle from './StaticMapCustomStyling';
import {convertJSONstyleToStaticUrlStyle} from './staticMapUtil';
// import StreetViewPanorama from '../StreetViewPanorama/StreetViewPanorama';

const StaticMap = (props) => {
    // const [showStreetViewPanorama, toggleShowStreetViewPanorama] = useState(false);
    let imgSrcUrl = "https://maps.googleapis.com/maps/api/staticmap?"
    imgSrcUrl += `size=${props.mapWidth}x${props.mapHeight}`

    if (props.format) {
        imgSrcUrl += `&format=${props.format}`;
    }
    if (props.scale) {
        imgSrcUrl += `&scale=${props.scale}`;
    }
    if (props.zoom) {
        imgSrcUrl += `&zoom=${props.zoom}`
    }
    if (props.markers) {
        props.markers.forEach(marker => {
            imgSrcUrl += "&markers=";
            if (marker.size) {
                imgSrcUrl += `%7Csize:${marker.size}` //mid
            }
            if (marker.scale) {
                imgSrcUrl += `%7Cscale:${marker.scale}`
            }
            if (marker.color) {
                imgSrcUrl += `%7Ccolor:${marker.color}`
            }
            if (marker.label) {
                imgSrcUrl += `%7Clabel:${marker.label}`
            }
            if (marker.address) {
                imgSrcUrl += `%7C${marker.address}`
            } else {
                imgSrcUrl += `%7C${marker.lat},${marker.lng}`
            }
        })
    }
    imgSrcUrl += `&key=${props.apiKey}`
    imgSrcUrl += convertJSONstyleToStaticUrlStyle(customMapStyle);

    return (
        <div id="static-map-wrapper">
            <img 
                id="static-map-img"
                alt=""
                src={imgSrcUrl} 
            />
                {/* <Card  
                    id="static-map-street-view-wrapper" 
                    bodyStyle={{padding: '1px', borderRadius: "10px"}} 
                    hoverable={true}
                    onClick={() => toggleShowStreetViewPanorama(true)}
                >
                    <StaticStreetView 
                        storeAddress={props.storeAddress}
                        storeLatitude={props.storeLatitude}
                        storeLongitude={props.storeLongitude}
                        mapWidth={130}
                        mapHeight={80}
                        apiKey={props.apiKey}
                        fieldOfView={120}
                        radius={1000}
                    />
                </Card>
            {
                showStreetViewPanorama &&
                <StreetViewPanorama 
                    showStreetViewPanorama={showStreetViewPanorama}
                    toggleShowStreetViewPanorama={toggleShowStreetViewPanorama}
                    apiKey={props.apiKey}
                    storeLatitude={props.storeLatitude}
                    storeLongitude={props.storeLongitude}
                />
            } */}
        </div>
    );
};

export default StaticMap;