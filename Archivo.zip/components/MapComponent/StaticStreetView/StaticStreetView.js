import React from 'react';
import "./StaticStreetView.scss"

const StaticStreetView = (props) => {
    let imgSrcUrl = "https://maps.googleapis.com/maps/api/streetview?"
    imgSrcUrl += `size=${props.mapWidth}x${props.mapHeight}`
    imgSrcUrl += `&key=${props.apiKey}`
   
    if(props.storeAddress){
        imgSrcUrl += `&location=${props.storeAddress}`
    }
    else{
        imgSrcUrl += `&location=${props.storeLatitude},${props.storeLongitude}`
    }

    if (props.heading) {
        imgSrcUrl += `&heading=${props.heading}`
    }
    if (props.pitch) {
        imgSrcUrl += `&pitch=${props.pitch}`
    }
    if (props.signature) {
        imgSrcUrl += `&signature=${props.signature}`
    }
    if (props.radius) {
        imgSrcUrl += `&radius=${props.radius}`
    }
    if (props.fieldOfView) {
        imgSrcUrl += `&fov=${props.fieldOfView}`
    }
   

    return (
        <div id="static-street-view-wrapper">
            <img className="static-street-view-img" src={imgSrcUrl} />
        </div>
    );
};

export default StaticStreetView;