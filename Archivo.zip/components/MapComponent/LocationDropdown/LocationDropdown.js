import React, {Component} from 'react';
import { SearchOutlined } from '@ant-design/icons';
import { Select } from "antd";
import {trackEvent} from '../../Utils/mixpanel';

export default class LocationDropdown extends Component {
  state = {
    locationInputSearch: '',
    showSearch: false,
    locationFilterData: [],
    isSearchLocationEnabled: false
  };

  handleClickingSearchIcon = () => {
    trackEvent("CLICKED_MAP_STORE_SEARCH_ICON")
    this.setState({isSearchLocationEnabled: !this.state.isSearchLocationEnabled})
  }

  render() {
    return this.state.isSearchLocationEnabled 
    ?
        <Select
            size="large"
            showSearch = {true}
            style={{width: "250px", marginRight: "12px"}}
            placeholder={'Search Store Locations' }
            optionFilterProp="children"
            onSearch={input => this.setState({locationInputSearch: input})}
            onBlur={() => this.setState({locationInputSearch: "", isSearchLocationEnabled: false})}
            autoFocus={true}
            defaultOpen = {true}
            filterOption = {true}
            mode={"multiple"}
            showArrow={false}
            onSelect={(value, option) => {
              this.setState({isSearchLocationEnabled: false, locationInputSearch: ""});
              this.props.onLocationDropdownSelect(value, option);
            }}
        >
            {

                this.state.locationFilterData.filter(k => k.props.children.toLowerCase().indexOf(this.state.locationInputSearch.toLowerCase()) >= 0)

            }
        </Select>
    : 
        <SearchOutlined
            onClick={this.handleClickingSearchIcon}
            className="mapZoomOut"
            style={{fontSize: '21px',padding: '9px'}} />;
  }
}