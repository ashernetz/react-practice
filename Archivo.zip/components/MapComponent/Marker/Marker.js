import React, {Component} from 'react';
import Icon from '@ant-design/icons';
import './Marker.scss';
import MapToolTip from "../MapToolTip/MapToolTip";
import {Badge} from "antd";

const svgComponent = (shape, pointerColor,colorList,radius,storeCount,animate, isBadge) => {
    let typeComponent;
    switch (shape) {
        case "circle":
            typeComponent = <svg height="10" width="10" ><circle
                cx="5" cy="5" r="4"
                fill={pointerColor}

                style={{
                    cursor: 'pointer',
                    stroke: "#fff",
                    strokeWidth: 2,
                    opacity: 0.9

                }}
            /></svg>
            break;

        case "rectangle" :
            typeComponent = <svg>
                <rect

                    width="5" height="5"
                    fill={pointerColor}
                    style={{
                        cursor: 'pointer',
                        stroke: "#cbcbcb",
                        strokeWidth: 1,
                        opacity: 0.9

                    }}
                />
            </svg>
            break;
        case "bubble":
            typeComponent = <svg
                height={radius} viewBox="0 0 150 150" preserveAspectRatio="none"><circle
                r="50%" cx="50%" cy="50%"
                fill={pointerColor}

                style={{
                    cursor: 'pointer',
                    stroke: "#fff",
                    strokeWidth: 2,
                    opacity: 0.75

                }}
            />
                <text  style = {{font: 'bold 50px sans-serif' ,fill: 'white'}} x="50%" y="50%" textAnchor="middle"  dy=".3em">{storeCount}</text>
            </svg>
            break;
        case "disaster": {
            let customViewBox = false  ? "0 0 1000 1000" : "0 0 512 512";
            typeComponent = <svg
                version="1.1" id="Capa_1" x="0px" y="0px"
                viewBox={customViewBox}

                style={{enableBackground: 'new 512 512 512 512', opacity: 0.9}}
                space="preserve" width={animate?25:25} height={animate?50:50}>
                <g className={animate ? "bounce-custom" : null}>
                    <path d="M507.494,426.066L282.864,53.537c-5.677-9.415-15.87-15.172-26.865-15.172c-10.995,0-21.188,5.756-26.865,15.172 L4.506,426.066c-5.842,9.689-6.015,21.774-0.451,31.625c5.564,9.852,16.001,15.944,27.315,15.944h449.259 c11.314,0,21.751-6.093,27.315-15.944C513.508,447.839,513.336,435.755,507.494,426.066z M256.167,167.227 c12.901,0,23.817,7.278,23.817,20.178c0,39.363-4.631,95.929-4.631,135.292c0,10.255-11.247,14.554-19.186,14.554 c-10.584,0-19.516-4.3-19.516-14.554c0-39.363-4.63-95.929-4.63-135.292C232.021,174.505,242.605,167.227,256.167,167.227z M256.498,411.018c-14.554,0-25.471-11.908-25.471-25.47c0-13.893,10.916-25.47,25.471-25.47c13.562,0,25.14,11.577,25.14,25.47 C281.638,399.11,270.06,411.018,256.498,411.018z"
                          fill={pointerColor}/>
                </g>
            </svg>
        }
            break;
        case "Lowes":
            typeComponent = <svg data-name="Layer 1" viewBox="0 0 200 200" width="25" height="25" >

                <path fill="#0471af" d="M4 4h188v188H4z" />
                <path d="M188 8v180H8V8h180m8-8H0v196h196V0z" fill="#fff" />
                <text
                    transform="translate(61.84 143)"
                    fontSize={128}
                    fontFamily="OpenSans-Bold,Open Sans"
                    fontWeight={700}
                    fill="#fff"
                >
                    {'L'}
                </text>
            </svg>
            break;
        case "Menards":
            typeComponent =   <svg data-name="Layer 1" viewBox="0 0 200 200" width="25" height="25" >
                <path fill="#008938" d="M4 4h188v188H4z" />
                <path d="M188 8v180H8V8h180m8-8H0v196h196V0z" fill="#fff" />
                <text
                    transform="translate(37.66 143)"
                    fontSize={128}
                    fontFamily="OpenSans-Bold,Open Sans"
                    fontWeight={700}
                    fill="#fff"
                >
                    {'M'}
                </text>
            </svg>

            break;
        case "Floor & Decor":
            typeComponent =  <svg data-name="Layer 1" viewBox="0 0 200 200" width="25" height="25" >
                <path d="M4 4h188v188H4z" />
                <path d="M188 8v180H8V8h180m8-8H0v196h196V0z" fill="#fff" />
                <text
                    transform="translate(62.88 148)"
                    fontSize={128}
                    fontFamily="OpenSans-Bold,Open Sans"
                    fontWeight={700}
                    fill="#fff"
                >
                    {'F'}
                </text>
            </svg>
            break;
        case "Sherwin Williams":
            typeComponent =  <svg data-name="Layer 1"viewBox="0 0 200 200" width="25" height="25">
                <path fill="#BE0000" d="M4 4h188v188H4z" />
                <path d="M188 8v180H8V8h180m8-8H0v196h196V0z" fill="#fff" />
                <text
                    transform="translate(62.88 148)"
                    fontSize={128}
                    fontFamily="OpenSans-Bold,Open Sans"
                    fontWeight={700}
                    fill="#fff"
                >
                    {'S'}
                </text>
            </svg>
            break;
        default :
            let customViewBox =false?"0 0 104 104":"0 0 52 52";
            typeComponent = <svg
                version="1.1" id="Capa_1" x="0px" y="0px"
                viewBox={customViewBox}

                style={{enableBackground:'new 0 0 52 52', stroke: "#fff",strokeWidth: 1,opacity: 0.9}}
                space="preserve" width={animate?"25":"25"} height={animate?"50":"30"}>
                {/*<g transform="scale(.96)">*/}
                <g className={animate?"bounce-custom":null}>
                    <path d="M38.853,5.324L38.853,5.324c-7.098-7.098-18.607-7.098-25.706,0h0  C6.751,11.72,6.031,23.763,11.459,31L26,52l14.541-21C45.969,23.763,45.249,11.72,38.853,5.324z M26.177,24c-3.314,0-6-2.686-6-6  s2.686-6,6-6s6,2.686,6,6S29.491,24,26.177,24z" data-original="#1081E0" className="active-path" data-old_color="#1081E0"  fill={pointerColor}/>
                </g>
                {/*</g>*/}
            </svg>
            ;
    }
    if(isBadge){
        typeComponent =(
            <Badge data-testid="competitor badge" dot offset={[-3, 3]}>
                {typeComponent}
            </Badge>
        )}

    return typeComponent;
};

const getMapToolTipStyle = ({x,y}, isFilterDrawerOpen) => {
    let xMax = isFilterDrawerOpen ? 700: 1000;

    let yThreshold = 400;

    let toolTipStyle = x < xMax ? {left:0} : {right:0};
    y > yThreshold ? toolTipStyle.bottom = 0 : toolTipStyle.top = 0;
    toolTipStyle.zIndex = 1;
    return toolTipStyle;
};

export default class Marker extends Component {
    state={
        isClickEnabled :false
    }
    componentDidUpdate = (prevProps, prevState) => {
        if(prevProps.$hover !== this.props.$hover){
            this.setState({isClickEnabled:false});
        }

    }
    render () {
        const { pointerColor, shape, colorList, radius = [],storeCount,animate,store={}} = this.props;
        let props = this.props;
        return (
            <span
                onClick={(e)=>{
                    this.setState({isClickEnabled:true});
                    props.onMapPointerClick(null,{...props});}}
                // onMouseEnter={(e)=>props.onMapPointerEnter(props.valueKey,{...props},e)}
                // onMouseOut = {(e) => props.onMapPointerLeave(props.valueKey,{...props},e)}

            >
      <Icon
          className={!["dashboard","competitor"].includes(store.type) ?'mapCustomMarker':'marker-no-hand'}
          component = {()=>svgComponent(shape,pointerColor,colorList,radius,storeCount,animate, store.type === "competitor-detail")}
      />
                {(!props.noHover && props.$hover === true) && (this.state.isClickEnabled === false && props.valueKey.toString().includes("store")) ?
                    <MapToolTip
                        lat={props.lat}
                        lng = {props.lng}
                        store={store}
                        toolTipStyle= {getMapToolTipStyle(props.$getDimensions(props.$dimensionKey),props.isFilterDrawerOpen)}/>
                    : null}
      </span>
        );
    }

}