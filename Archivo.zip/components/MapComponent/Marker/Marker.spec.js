import React from "react";
import markerResponse from "../__fixtures__/markerResponse.json"
import {render, screen} from '@testing-library/react'
import Marker from "./Marker";

test("CheckCompetitorBadgeRender", () => {
    const {container} = render(<Marker
        isFilterDrawerOpen={false}
        store={markerResponse.store}
        shape={markerResponse.shape}
        key={"store" + markerResponse.id}
        valueKey = {"store" + markerResponse.id}
        lat={markerResponse.lat}
        lng={markerResponse.lng}
        pointerColor={markerResponse.pointerColor}
        animate={false}>
    </Marker>)

    expect(screen.getByText('L')).toBeInTheDocument();
    expect(screen.getByTestId("competitor badge")).toBeInTheDocument();

})