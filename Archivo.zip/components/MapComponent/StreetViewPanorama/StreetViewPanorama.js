import React, {useEffect} from 'react';
import loadGoogleMapsApi from 'load-google-maps-api';
import "./StreetViewPanorama.scss";
import {Modal} from 'antd'

const StreetViewPanorama = (props) => {

    useEffect(() => {
        loadGoogleMapsApi({key: props.apiKey}).then(function (googleMaps) {
            new googleMaps.StreetViewPanorama(
                document.getElementById('street-view-panorama'), {
                  position: {lat: props.storeLatitude, lng: props.storeLongitude},
                  addressControlOptions: {
                    position: googleMaps.ControlPosition.BOTTOM_CENTER
                  }
            });
          }).catch(function (error) {
            console.error(error)
          })
    }, []);
    
    return (
        <Modal
            open
            centered
            onCancel={() => props.toggleShowStreetViewPanorama(false)}
            zIndex={1001}
            footer={null}
        >
            <div id="street-view-panorama-wrapper">
                <div id="street-view-panorama" />
            </div>
        </Modal>
    );
};

export default StreetViewPanorama;