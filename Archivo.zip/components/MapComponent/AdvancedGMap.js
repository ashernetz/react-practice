import React, {Component, Fragment} from 'react';
import SkuContext from "../../context/SkuContext";
import MapContext from "../../context/MapContext";
import MapView from "./MapView/MapView";
import StoreTabModal from "../PricePointDetailLayout/StoreZoneTabModals/StoreTabModal";
import ModifyPriceModal from "../ModifyPriceModal/ModifyPriceModal";
import CompetitorUtil from "../Utils/CompetitorUtil";
import PriceChangeHistoryUtil from '../Utils/PriceChangeHistoryUtil';
import CompetitorStoreModal from "./CompetitorStoreModal/CompetitorStoreModal"
import { Select} from "antd";
import FilterUtil from "../Utils/FilterUtil";

const  {Option} = Select;
export default class AdvancedGMap extends Component {
  static contextType = SkuContext;
  state = {
    isStoreModalOpen: false,
    isCompetitorModalOpen:false,
    forecastChartType: 'salesAmount',
    lastTwelveChartType: 'salesAmount',
    selectedCompetitorData : {}

  };

  changeChartType = e => {
    let value = e.target.value;
    if (value === 'lastTwelveSales') {
      this.setState({lastTwelveChartType: 'salesAmount'});
    }
    else if (value === 'lastTwelveUnits') {
      this.setState({lastTwelveChartType: 'unitSales'});
    }
    else if (value === 'forecastSales') {
      this.setState({forecastChartType: 'salesAmount'});
    }
    else if (value === 'forecastUnits') {
      this.setState({forecastChartType: 'unitSales'});
    }
  }

  clusterControl = (isEnable) => {
    this.context.updateFilterSelection({"isMapClusteringChecked":isEnable});
  };

  formMarkerData = (mapState) => {
    let searchData = [];
    let markerData = [];
    let pricePointDetails = this.context.skuData.pricePointDetails;
    //let pricePointDetails = this.props.validPricePointData;
    this.props.mapFilteredData.filteredPricePoints.forEach(retail => {
      if (mapState.selectedState.retail === retail
          || mapState.selectedState.retail === '') {

        if (mapState.hoverState.retail === retail || mapState.hoverState.retail
            === '') {
          Object.values(pricePointDetails[retail].storeDetails).forEach(
              store => {
                if(this.props.mapFilteredData.filteredStoreList.includes(store.storeId)){
                  if (mapState.hoverState.store === store.storeId
                      || mapState.hoverState.store === '') {
                    if (mapState.hoverState.zone === store.zoneId
                        || mapState.hoverState.zone === '') {
                      let tempStore = {...store};
                      let performanceData = this.context.skuStorePerformanceData.storeLevelPerformance[store.storeId];
                      let {compSales = "-", compUnits = "-"} = performanceData
                          ? performanceData
                          : {};
                      tempStore.compSales = compSales;
                      tempStore.compUnits = compUnits;
                      if (store.latitudeNumber && store.longitudeNumber) {

                        tempStore.pointerColor = pricePointDetails[retail].pointerColor;
                        searchData.push( <Option key={store.storeId} value={store.latitudeNumber + "|" + store.longitudeNumber + "|" + store.storeId} >{store.storeId + "-" + store.storeName}</Option>);

                        markerData.push(
                            {
                              store: tempStore,
                              id: store.storeId,
                              lat: store.latitudeNumber,
                              lng: store.longitudeNumber,
                              pointerColor: pricePointDetails[retail].pointerColor,
                              shape: store.disaster ? 'disaster':'pin-point'
                            });
                      }

                    }
                  }
                }

              });
        }
      }
    });



    if(this.props.isDashboardOpen){
      if(this.context.dashboardData.hasOwnProperty("disasterStoreMap")&&Object.keys(this.context.dashboardData.disasterStoreMap).length>0){
        Object.keys(this.context.dashboardData.disasterStoreMap).forEach(disasterStore => {
          let store = this.context.dashboardData.disasterStoreMap[disasterStore];
          if(store.latitudeNumber && store.longitudeNumber){
            searchData.push( <Option key={store.storeId} value={store.latitudeNumber + "|" + store.longitudeNumber + "|" + store.storeId } >{store.storeId + "-" + store.storeName}</Option>);

            markerData.push(
                {
                  store: {...store,disaster:true,type:"dashboard",pointerColor:"red"},
                  id: store.storeId + "dashboard",
                  lat: store.latitudeNumber,
                  lng: store.longitudeNumber,
                  shape: "disaster",
                  pointerColor : "red"
                });
          }

        });
      }
      if (this.context.filterValues.selectedCompetitors.length > 0) {
        this.context.filterValues.selectedCompetitors.forEach(competitor => {
          CompetitorUtil.getCompetitorData(competitor).forEach(store => {
            let pointerColor = CompetitorUtil.getCompetitorPointerColor(competitor);
            let tempStore = {
              ...store,
              storeId: store.storeId,
              minMaxPriceRange:null,
              type:competitor === "Sherwin Williams"?"competitor":"competitor-empty",
              competitorId : CompetitorUtil.getCompetitorId(competitor),
              latitude: store.latitudeNumber,
              longitude: store.longitudeNumber,
              store: store.storeId,
              name : competitor,
              competitor,
              pointerColor};
            markerData.push(
                {
                  store: tempStore,
                  id: store.storeId + competitor,
                  competitorId : CompetitorUtil.getCompetitorId(competitor),
                  lat: store.latitudeNumber,
                  lng: store.longitudeNumber,
                  shape: competitor,
                  pointerColor
                });
          });
        })
      }
    }else {
      if (this.context.filterValues.selectedCompetitors.length > 0) {
        let competitorDataMap = this.context.competitorData.storeLevelDataMap;
        this.context.filterValues.selectedCompetitors.forEach(competitor => {

          CompetitorUtil.getCompetitorData(competitor).forEach(store => {
            let pointerColor = CompetitorUtil.getCompetitorPointerColor(
                competitor);

            if (FilterUtil.filteredStoresBasedOnOffside(this.context.filterValues.isOffsideRangeChecked,this.props.allowedCompetitorStores,store.storeId)) {

            if (competitorDataMap.hasOwnProperty(competitor) &&
                competitorDataMap[competitor].hasOwnProperty(store.storeId)) {
              let compStore = competitorDataMap[competitor][store.storeId];

              let tempStore = {
                ...compStore,
                storeId: store.storeId,
                minMaxPriceRange: this.context.skuData.minMaxPriceRange,
                type: "competitor-detail",
                competitor,
                pointerColor
              };
              markerData.push(
                  {
                    store: tempStore,
                    id: store.storeId + competitor,
                    lat: store.latitudeNumber,
                    lng: store.longitudeNumber,
                    shape: competitor,
                    pointerColor
                  });
            } else {
              let tempStore = {
                ...store,
                storeId: store.storeId,
                minMaxPriceRange: null,
                type: competitor === "Sherwin Williams" ? "competitor"
                    : "competitor-empty",
                competitorId: CompetitorUtil.getCompetitorId(competitor),
                latitude: store.latitudeNumber,
                longitude: store.longitudeNumber,
                store: store.storeId,
                name: competitor,
                competitor,
                pointerColor
              };
              markerData.push({
                store: tempStore,
                id: store.storeId + competitor,
                lat: store.latitudeNumber,
                lng: store.longitudeNumber,
                shape: competitor,
                pointerColor
              });
            }
          }

          });
        })
      }
    }


    return {markerData,searchData};

  };
  onMapPointerClick = (key, childProps) => {

    if(childProps.store.type === "competitor-detail" || childProps.store.type === "competitor-empty"){
      this.setState({
        isCompetitorModalOpen: true,
        selectedCompetitorData:childProps.store
      });
    }else {
      this.setState({
        isStoreModalOpen: true,
        selectedStoreName: childProps.store.storeName,
        selectedStoreAddress: childProps.store.address,
        selectedStoreLatitude: childProps.store.latitudeNumber,
        selectedStoreLongitude: childProps.store.longitudeNumber,
        selectedStoreStatus: childProps.store.status,
        selectedStorePrice: childProps.store.retailKey,
        selectedStoreId: childProps.store.storeId,
        storeCompSales:childProps.store.compSales,
        storeCompUnits:childProps.store.compUnits,
        pricePointColor:childProps.store.pointerColor
      });
    }
  };

  render() {

    return <Fragment>
      <MapContext.Consumer>
        {mapState => {
          let {markerData, searchData} = this.formMarkerData(mapState);
          return <MapView
              skuNumber={this.context.skuNumber}
              markersData={markerData}
              locationFilterData={searchData}
              onMapPointerClick={this.onMapPointerClick}
              isMapClusteringChecked={this.context.filterValues.isMapClusteringChecked}
              clusterControl={this.clusterControl}
              isFilterDrawerOpen={this.props.isFilterDrawerOpen}
              isDashboardOpen = {this.props.isDashboardOpen}
              apiKey={this.props.apiKey}
              mapDivStyle={{height: 'calc(100vh - 130px)', width: '100%',marginTop:'152px'}}
          />
        }}</MapContext.Consumer>
      {this.state.isStoreModalOpen ?
          <StoreTabModal
              config={this.props.config}
              userId={this.props.userId}
              apiKey={this.props.apiKey}
              isOpen={this.state.isStoreModalOpen}
              storeName={this.state.selectedStoreName}
              storeAddress={this.state.selectedStoreAddress}
              storeStatus={this.state.selectedStoreStatus}
              storeRetail={this.state.selectedStorePrice}
              storeId={this.state.selectedStoreId}
              pricePointColor={"#F96302"}
              selectedUnitComp = {this.state.storeCompUnits}
              storeLatitude={this.state.selectedStoreLatitude}
              storeLongitude={this.state.selectedStoreLongitude}
              selectedComp = {this.state.storeCompSales}
              forecastChartType= {this.state.forecastChartType}
              lastTwelveChartType= {this.state.lastTwelveChartType}
              changeChartType={this.changeChartType}
              onClose={() => this.setState({
                isStoreModalOpen: false, forecastChartType: 'salesAmount',
                lastTwelveChartType: 'salesAmount'
              })}
              onEditPriceClick={() => {
                this.props.verifyAccessToken();
                this.setState(
                  {isStoreModalOpen: false, isModifyPriceModalOpen: true})}}/>    : null}

      {this.state.isModifyPriceModalOpen ? <ModifyPriceModal
              store={this.state.selectedStoreId + "-" + this.state.selectedStoreName}
              storeRetail={this.state.selectedStorePrice}
              storeStatus={this.state.selectedStoreStatus}
              isOpen={this.state.isModifyPriceModalOpen}
              onClose={() => this.setState({isModifyPriceModalOpen: false})}/>
          : null}
      {this.state.isCompetitorModalOpen &&
      <CompetitorStoreModal
              userId={this.props.userId}
              config={this.props.config}
              apiKey={this.props.apiKey}
              isOpen={this.state.isCompetitorModalOpen}
              onClose={() => this.setState({isCompetitorModalOpen: false})}
              competitorData = {this.state.selectedCompetitorData}
        />}

    </Fragment>
  }
}
