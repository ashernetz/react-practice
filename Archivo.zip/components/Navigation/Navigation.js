import React, {useContext} from 'react';
import SkuContext from '../../context/SkuContext';
import {Drawer, Menu, Typography, Tag, Space} from 'antd';
import {HomeOutlined, RadarChartOutlined} from '@ant-design/icons';
import SkuGroupsLogo from '../../images/SkuGroupsLogo.svg';
import "./Navigation.scss";

const {Text} = Typography;

const Navigation = (props) => {
    const context = useContext(SkuContext);
    const handleNavChange = (e) => {
        // trackEvent("CLICKED_NAVIGATION_TAB", {"tab": e.key});
        if(props.headerData.activeTab !== e.key) {
          props.resetDefaultState();
          let url = '/';
          let activeTab = "workspace";
          if (e.key === 'zone') {
            url = '/ZoneControl';
            activeTab = "zone";
            context.updateShowDimmer(true);
          }
          // context.updateShowDimmer(true);
          props.toggleNavMenuOpen();
          props.updateHeaderData({url, activeTab});
        }
    };

    return (
        <Drawer 
            id="navigation-drawer"
            open={props.visible}
            placement='left'
            closable={false}
            width={265}
            onClose={props.toggleNavMenuOpen}
            onBlur={(e) => {
              if (props.visible && !(e.relatedTarget && e.relatedTarget.id
                  === "primary-header-menu-icon")) {
                props.toggleNavMenuOpen()
              }
            }}
        >
            <Menu 
                id="navigation-menu" 
                defaultSelectedKeys={["workspace"]} 
                selectedKeys={props.headerData.activeTab}
                onClick={handleNavChange}
            >
                <Menu.Item
                    key="workspace"
                    className="navigation-menu-item"
                    icon={<HomeOutlined className="navigation-menu-item-icon"/>}
                >Home</Menu.Item>
                {props.headerData.isZoneControlEnabled &&
                    <Menu.Item
                        key="zone"
                        className="navigation-menu-item"
                        icon={<RadarChartOutlined className="navigation-menu-item-icon"/>}
                    >Zone Control</Menu.Item>
                }
                <Menu.Item 
                    key="sku-grouping"
                    disabled
                    className="navigation-menu-item"
                    icon={
                    // <GroupOutlined className="navigation-menu-item-icon navigation-menu-item-icon-disabled"/>
                        <img id="sku-groups-logo" src={SkuGroupsLogo} alt="Sku-Groups" />
                    }
                >
                    <Space>
                        <Text className="custom-text-label">SKU Grouping</Text>
                        <Tag className="navigation-menu-coming-soon-tag" color="#F96203">Coming Soon</Tag>
                    </Space>
                </Menu.Item>
            </Menu>
        </Drawer>
    );
};

export default Navigation;