import React, {Fragment} from 'react';
import {Col, Row, Typography} from 'antd';
import "./CompetitorCard.scss"
import CompUtil from '../../Utils/CompUtil';
const {Text} = Typography;

const CompetitorLocationDetails = (props) => {
    return (
        <Fragment>
          <Row><Col><Text type='secondary'>Location</Text></Col></Row>
          <Row gutter={[0,8]}><Col><Text>{CompUtil.formatLocationFromCompetitorName(props.competitor.storeName)}</Text></Col></Row>
          <Row><Col><Text type='secondary'>Distance</Text></Col></Row>
          <Row><Col> <Text>{Math.round(props.competitor.distanceInMiles)} Miles Away</Text></Col></Row>
        </Fragment>
    );
};

export default CompetitorLocationDetails;