import React, {Fragment} from 'react';
import {Col, Row, Typography} from 'antd';
import "./CompetitorCard.scss"
const {Text} = Typography;

const CompetitorStoreTotals = (props) => {
    return (
        <Fragment>
          <Row><Col><Text type='secondary'>Stores</Text></Col></Row>
          <Row gutter={[0,8]}><Col><Text>{props.competitor.numberOfStoresThisSkuIsIn}/{props.competitor.totalNumberOfStores}</Text></Col></Row>
          <Row><Col><Text type='secondary'>Updated</Text></Col></Row>
          <Row><Col> <Text>{props.competitor.lastUpdated}</Text></Col></Row>
        </Fragment>

        // <div className="flex flex-column">
        //     <div className="flex flex-column">
        //         <Text type={'secondary'}>Stores</Text>
        //         <Text>{props.competitor.numberOfStoresThisSkuIsIn}/{props.competitor.totalNumberOfStores}</Text>
        //     </div>
        //     <div className="flex flex-column">
        //         <Text type={'secondary'}>Updated</Text>
        //         <Text>{props.competitor.lastUpdated}</Text>
        //     </div>
        // </div>
    );
};

export default CompetitorStoreTotals;