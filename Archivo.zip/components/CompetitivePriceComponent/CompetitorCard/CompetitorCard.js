import React from "react";
import { Card, Col, Row, Typography } from "antd";
import "./CompetitorCard.scss";
import CompUtil from "../../Utils/CompUtil";
const { Text, Paragraph, Title } = Typography;

function getCardLogoImage(competitorName, missingSkuInfo) {
  let logoClassName = "competitor-logo";
  if (missingSkuInfo) {
    logoClassName += " competitor-logo-no-data";
  }
  if (competitorName.toLowerCase().includes("lowe")) {
    return (
      <img
        id="lowes-logo"
        className={logoClassName}
        src={require("../../../images/LowesLogo.svg").default}
        alt={competitorName}
      />
    );
  }
  else if (competitorName === "FnD" || competitorName === "Floor & Decor") {
    return (
      <img
        id="floor-and-decor-logo"
        className={logoClassName}
        src={require("../../../images/FloorAndDecorLogo.svg").default}
        alt={competitorName}
      />
    );
  } else if (competitorName === "Menards") {
    return (
      <img
        id="menards-logo"
        className={logoClassName}
        src={require("../../../images/MenardsSquareLogo.png")}
        alt={competitorName}
      />
    );
  } else if (competitorName === "Amazon") {
    return (
      <img
        id="amazon-logo"
        className={logoClassName}
        src={require("../../../images/AmazonLogo.svg").default}
        alt={competitorName}
      />
    );
  } else if (competitorName === "Walmart") {
    return (
      <img
        id="walmart-logo"
        className={logoClassName}
        src={require("../../../images/WalmartLogo.svg").default}
        alt={competitorName}
      />
    );
  }else if (competitorName === "Amazon MKT") {
    return (
        <img
            id="amazon-logo"
            className={logoClassName}
            src={require("../../../images/amz_mkt.svg").default}
            alt={competitorName}
        />
    );
  }
}

function renderCompetitorLocation({ competitorId, storeName }) {
  if (competitorId === 18214 || competitorId === 527 || competitorId === 1) return "Nationwide";
  return CompUtil.formatLocationFromCompetitorName(storeName);
}

function renderCompetitorStoreDistance({ competitorId, distanceInMiles }) {
  if (competitorId === 18214 || competitorId === 527 || competitorId === 1) return "Online";

  const str1 = distanceInMiles < 1 ? "<" : "";
  const str2 = `${Math.ceil(distanceInMiles)} Mile`;
  const str3 = distanceInMiles > 1 ? "s Away" : " Away";
  return str1 + str2 + str3;
}

const CompetitorCard = ({ competitor }) => {
  let missingSkuInfo = !competitor.avgPrice;
  let cardColor = competitor.cardShadeClassName
    ? competitor.cardShadeClassName
    : "";
  let cardClass = "comp-card-style";
  if (missingSkuInfo) {
    cardClass += " comp-card-missing-info";
  } else {
    cardClass += ` comp-card-border${cardColor} comp-card-has-data`;
  }
  let isSamePrice = competitor.priceDifferenceText === "Difference";
  return (
    <Card
      className={cardClass}
      // loading={loading}
      // hoverable={true}
      bodyStyle={{
        padding: "12px 12px 12px 12px",
        height: "100%",
        minHeight: "250px",
      }}
      onClick={
        missingSkuInfo
          ? null
          : () => {
              window.open(competitor.skuUrl, "_blank");
            }
      }
    >
      <Row className="comp-card-header" align="middle">
        <Col span={6}>
          <Row align="middle">
            <Col span={24}>
              {getCardLogoImage(competitor.name, missingSkuInfo)}
            </Col>
          </Row>
        </Col>
        <Col push={1}>
          <Row>
            <Col>
              <Text className="competitor-location-text">
                {renderCompetitorLocation(competitor)}
              </Text>
            </Col>
          </Row>
          <Row className="comp-distance-row">
            <Col>
              <Text className="competitor-distance-text">
                ({renderCompetitorStoreDistance(competitor)})
              </Text>
            </Col>
          </Row>
        </Col>
      </Row>

      {missingSkuInfo ? (
        <Row
          className="missing-sku-info-row"
          gutter={[0, 16]}
          justify="center"
          align="middle"
        >
          <Col flex="auto" className="missing-sku-info-col">
            <Title className="no-data-text" level={4}>
              No Scrape Data
            </Title>
          </Col>
        </Row>
      ) : (
        <Row align="stretch">
          <Col span={24} >
            <Row justify="center" className="competitor-img-row-height">
              <Col span={12} className="competitor-card-container">
                <img
                    className="competitor-card-sku-image"
                    src={competitor.skuImageUrl}
                    alt="sku"
                />
              </Col>
            </Row>
          </Col>

          <Col style={{paddingTop:'5px'}}>
            <Row justify="space-between" align="bottom" gutter={[8, 8]} >
              <Col span={14}>
                <Row >
                  <Col>
                    <Text className="sku-number-text">
                      SKU {competitor.sku}
                    </Text>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Paragraph ellipsis={{ rows: 2 }} className="sku-desc-text">
                      {competitor.skuName}
                    </Paragraph>
                  </Col>
                </Row>
              </Col>

              <Col span={10} className="map-compcard-price">
                <Row>
                  <Col span={24}>
                    <Row justify="end">
                      <Col>
                        <Text className="large-text heavy">
                          ${CompUtil.formatPrice(competitor.avgPrice)}
                        </Text>
                      </Col>
                    </Row>
                    <Row justify="end">
                      {!isSamePrice && (
                        <Col pull={1}>
                          <Text
                            className={
                              "heavy price-diff price-diff" + cardColor
                            }
                          >
                            ${CompUtil.formatPrice(competitor.priceDifference)}
                          </Text>
                        </Col>
                      )}
                      <Col>
                        <Text className={"heavy price-diff" + cardColor}>
                          {isSamePrice
                            ? "Same Price"
                            : competitor.priceDifferenceText}
                        </Text>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
      )}
    </Card>
  );
};

export default CompetitorCard;
