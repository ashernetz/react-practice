import React from "react";
import "./CompetitivePrice.scss";
import CompetitorCard from "./CompetitorCard/CompetitorCard";
import { Col, Row } from "antd";

const CompetitivePrice = (props) => {
  return (
    <Row gutter={[0, 24]} justify={"center"}>
      <Col className="nearbyCompContainer" span={22}>
        <Row type="flex" gutter={[24, 24]}>
          {props.competitorDetails.map((competitor, index) => {
            if (!competitor.avgPrice){
             return null
            }
             return (
              <Col key={index} span={12}>
                <CompetitorCard
                  showLocationDetails={props.showLocationDetails}
                  competitor={competitor}
                  showStoreTotals={props.showStoreTotals}
                />
              </Col>
            );
          })}
        </Row>
      </Col>
    </Row>
  );
};

CompetitivePrice.defaultProps = {
  competitorDetails: [],
  showLocationDetails: false,
  showStoreTotals: false,
};

export default CompetitivePrice;
