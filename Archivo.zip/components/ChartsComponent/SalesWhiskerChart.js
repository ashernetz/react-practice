import {Chart, Tooltip, Axis, Box} from 'viser-react';
import React from 'react';

const DataSet = require('@antv/data-set');

const SalesWhiskerChart = (props) => {

  function getSourceData() {
    const dv = new DataSet.View().source(props.salesMetricsData);
    dv.transform({
      type: 'map',
      callback: (obj) => {
        obj.range = [obj.low, obj.open, obj.mode, obj.close, obj.high];
        return obj;
      },
    });
    return dv.rows;
  }

  let dollar = "$";
  let tooltipOpts = {
    showTitle: false,
    crosshairs: {
      type: 'rect'
    },

    itemTpl: "<li data-index={index} style='color:#f96302; margin:4px;'>"
        + "<span>High：" + dollar + "{high}</span><br/>"
        + "<span>Close：" + dollar + "{close}</span><br/>"
        + "<span>Mode: " + dollar + "{mode}</span><br/>"
        + "<span>Open：" + dollar + "{open}</span><br/>"
        + "<span>Low：" + dollar + "{low}</span><br/>"
        + "</li>"
  };

  let boxStyle = {
    stroke: '#f96302',
    fill: '#f96302'
  };

  let boxTooltip = ['low*open*mode*close*high',
    (low, open, mode, close, high) => {
      return {
        low,
        open,
        mode,
        close,
        high
      };
    }];
  return (
      <div style={{marginLeft:"-5%"}}>
        {props.salesMetricsData.length > 0 ?
            <Chart forceFit height={400} data={getSourceData()} scale={[{
              dataKey: 'range',
              formatter: '$'
            }]}>
              <Tooltip {...tooltipOpts} />
              <Axis/>
              <Box position='type*range' style={boxStyle} tooltip={boxTooltip}/>
            </Chart> : null}
      </div>
  );

};
SalesWhiskerChart.defaultProps = {
  salesMetricsData: []
};

export default SalesWhiskerChart



