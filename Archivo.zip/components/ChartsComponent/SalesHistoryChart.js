import React, {Component} from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import SkuContext from "../../context/SkuContext";

export default class SalesHistoryAreaChart extends Component {

    static contextType = SkuContext;

    render() {
        return(this.context.salesHistoryMap.get(this.props.storeId) ?
            <AreaChart className="salesHistoryGraph" width={700} height={300} data={this.props.dataset}
            margin={{top: 20, right: 30, left: 10, bottom: 10}}>
            <CartesianGrid strokeDasharray="3 3"/>
            <XAxis dataKey="fiscalWeek" height={60}/>
            <YAxis tickFormatter={(k)=>this.props.dataKey === "salesAmount" ? '$'+k : k}/>
            <Tooltip formatter = {(value, name, props) => name === "salesAmount"? '$'+ value :  value}/>
            <Legend />
            <Area type="monotone" dataKey={this.props.dataKey} stroke={this.props.pricePointColor} fill={this.props.pricePointColor}/>
            </AreaChart> : null
        )
    }
}