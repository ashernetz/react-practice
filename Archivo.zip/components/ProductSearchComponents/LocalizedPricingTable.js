import React, {useState} from 'react';
import {Typography, Row, Col, Tooltip, Table} from 'antd';
import "./OnlineComponents.scss";
import CompUtil from "../Utils/CompUtil";
import AdvancedTable from "../GlobalComponents/AdvancedTable/AdvancedTable";
import {UXSpin} from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import SingleAndMultiSkuServices from "../../services/SingleAndMultiSkuServices";
import UXSmallPulse from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";


const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const checkIfAllPriceAreSame=(priceList)=> {
    return priceList.every(k=>k.localizedPrice === priceList[0].localizedPrice);
};

const MultipleOMSPriceTableColumn = [
    {
        title: headerFormatter('OMSID'),
        dataIndex: 'omsId',
        key: 'omsId',
    },
    {
        title: headerFormatter('Price'),
        dataIndex: 'localizedPrice',
        key: 'localizedPrice',
        render: (localizedPrice) =>
            <Text>{localizedPrice ? CompUtil.formatMuMdPrice(localizedPrice,false) : "NA"}</Text>
    },

];

const MultipleOMSPriceToolTip = ({priceList}) => {
    return (
        <Table className="oms-id-table" dataSource={priceList}
               columns={MultipleOMSPriceTableColumn}
               size="small">
        </Table>
    );
}

const LocalizedPriceItem = ({value}) => {
    if(value && value.length > 0){
        if(value.length>1 && !checkIfAllPriceAreSame(value)){
            return (<Tooltip placement="topLeft"
                             color="#ffffff"
                             overlayInnerStyle={{minWidth:'280px'}}
                             overlayClassName="tooltip-overlay-size"
                             title={<MultipleOMSPriceToolTip priceList={value}/>}
            >
                <a>Multiple Prices</a> {/*eslint-disable-line*/}
            </Tooltip>);
        }else {
            return (<Text strong>{value[0].localizedPrice?(CompUtil.formatMuMdPrice(value[0].localizedPrice,false)):"NA" }
            </Text>)
        }
    }else {
        return (<Text strong>NA</Text>);
    }
}

const ItemProperty = (props) => {

    return (
        <>
            <Row gutter={[8, 0]}><Col><Text type="secondary">{props.name}</Text></Col></Row>
            <Row gutter={[8, 0]}>
                {props.value === "-" ?<UXSpin/>:
                    <Col>
                        {props.name === 'Localized Price' ? <LocalizedPriceItem {...props}/>:
                            <Text strong>{props.value?(CompUtil.formatMuMdPrice(props.value,false)):"NA" }
                            </Text>
                        }
                    </Col>
                }
            </Row>
        </>
    );
};

const LocalizedPricingTable = (props) => {

    const [storePriceMap, setStorePriceMap] = useState({});

    const columns = [
        {
            title: headerFormatter('Store #'),
            dataIndex: 'store',
            key: 'store',
            className:'custom-search-icon',
            isCustomFilter: true,
            sorter: (a, b) =>  a.store - b.store,        },
        {
            title: headerFormatter('Store Location'),
            dataIndex: 'storeName',
            key: 'storeName',
            className:'custom-search-icon',
            isCustomFilter: true,
            sorter: (a, b) =>  customStringSorter(a.storeName,b.storeName),
            render: (row) =>
                <Text>
                    {row.storeName+', '+row.stateCode}
                </Text>
        },
        {
            title: headerFormatter('Online Retail'),
            // dataIndex: 'retail',
            key: 'retail',
            // sorter: (a, b) => (a.retail && !isNaN(a.retail)?a.retail:0) - (b.retail && !isNaN(b.retail)?b.retail:0),
            render: (row) =>
                <Text strong>
                    {props.singleSkuHeaderData.effectiveRetail === "-" ? <UXSpin /> :
                        (!props.singleSkuHeaderData.effectiveRetail || props.singleSkuHeaderData.effectiveRetail === "-"? "NA":(CompUtil.formatMuMdPrice(props.singleSkuHeaderData.effectiveRetail,false)))}
                </Text>
        },

    ];

    const priceDetails =[
        {
            name:"Localized Price",
            value:"localizedPriceList"
        },
        {
            name:"Permanent Price",
            value:"permanentPrice"
        },
        {
            name:"Promo Price",
            value:"promotionPrice"
        },
        {
            name:"Promo Type",
            value:"promotionType"
        },
        {
            name:"Clearance Price",
            value:"clearancePrice"
        },
        {
            name:"Invoice Cost",
            value:"invoiceCost"
        }
    ];

    const fetchLocalizedPriceDetails = (record) => {
        if (!storePriceMap.hasOwnProperty(record.store)) {
            setStorePriceMap(k=>({...k,[record.store]:priceDetails.reduce((a,c)=>{a[c.value]="-";return a;},{})}));

            let priceData = {localizedPriceList:null,permanentPrice:null,promotionPrice:null,promotionType:null,clearancePrice:null};
            SingleAndMultiSkuServices.localizedPrice(props.skuNumber, record.store, props.singleSkuHeaderData.omsIdList)
                .then(resp => {
                    if (resp.status === 200) {
                        priceData = {...priceData,...resp.data};
                    }
                })
                .catch(err => console.log(err))
                .finally(() => {
                    setStorePriceMap(k=>({...k,[record.store]:{...k[record.store],...priceData}}));

                });


            let invoiceCost = null;
            SingleAndMultiSkuServices.getInvoiceCostForSkuStoreList([{sku:props.skuNumber, store:record.store}])
                .then(resp => {
                    if (resp.status === 200) {
                        let respObj = resp.data.find(k=>k.sku === props.skuNumber && k.store === record.store);
                        if(respObj && respObj.cost){
                            invoiceCost = respObj.cost/100;
                        }
                    }
                })
                .catch(err => console.log(err))
                .finally(() => {
                    setStorePriceMap(k=>({...k,[record.store]:{...k[record.store],invoiceCost}}));

                });



        }
    };

    const RenderExpandedRow = (props) => {
        return (
            <>
                <Row gutter={[40,0]} className="expandated-table-ant-row">
                    {
                        priceDetails.map(data =>
                            <Col key={data.name}>
                                <ItemProperty
                                    name={data.name}
                                    value={storePriceMap.hasOwnProperty(props.record.store) ? storePriceMap[props.record.store][data.value] : "-"} />
                            </Col>
                        )
                    }
                </Row>

            </>
        );
    };

    return (
        <AdvancedTable
            tableClassName="all-sku-table"
            columns={columns}
            dataSource={props.storeList}
            pagination = {{showSizeChanger:false,
                pageSize: 10}}
            extraTableProps ={{
                getPopupContainer:(triggerNode) => triggerNode.parentNode,
                loading:{spinning:!props.storeList, indicator: <UXSmallPulse /> },
                onExpand: (expanded,record)=> fetchLocalizedPriceDetails(record),
                expandable:
                    {
                        expandedRowRender: (record) =>
                            <RenderExpandedRow record= {record}/>

                    },rowKey:"store"
            }}
        />

    );
};

export default LocalizedPricingTable;
