import React from 'react';
import { Row, Col, Typography, Card } from 'antd';
import "./OnlineComponents.scss";

const { Text } = Typography;

const OnlineGrossMargin = (props) => {

    return (
        <Row>
            <Col span={24}>
                <Card className="grossmargin-card">
                    <Row gutter={[0, 8]} align="middle" justify="center">
                        <Col><Text className="grossmargin-label">Gross Margin</Text></Col>
                    </Row>
                    <Row align="middle" justify="space-around">
                        <Col><Text type="secondary">Total</Text></Col>
                        <Col><Text type="secondary">Per Unit</Text></Col>
                    </Row>
                    <Row align="middle" justify="space-around">
                        <Col><Text className="grossmargin-dollar">$81.32M</Text></Col>
                        <Col><Text className="grossmargin-dollar">$6.16M</Text></Col>
                    </Row>
                    <Row gutter={[0, 8]} align="middle" justify="space-around">
                        <Col><Text className="grossmargin-percentage">32.25%</Text></Col>
                        <Col><Text className="grossmargin-percentage">35.25%</Text></Col>
                    </Row>
                    <Row justify="center">
                        <Col><Text className="view-breakout" strong>View Breakout</Text></Col>
                    </Row>
                </Card>

            </Col>
        </Row>
    );
};

export default OnlineGrossMargin;
