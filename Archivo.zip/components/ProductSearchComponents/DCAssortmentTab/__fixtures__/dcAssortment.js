export const dcAssortment = [
  {
    dcNumber: '5856',
    displayName: '5856 - Atlanta',
    dcLandedCost: 6.47,
    dcOnHand: 183,
    dcOnOrder: 90,
    vendor: '',
    stores: ['1', '2', '3'],
    deliveryType: 'Scheduled Only',
    types: [
      {
        type: 'Total',
        key: 'Total',
        sales: 390,
        units: 1139000,
      },
      {
        type: 'Unscheduled',
        key: 'Unscheduled',
        sales: 104,
        units: 451000,
      },
      {
        type: 'Scheduled',
        key: 'Scheduled',
        sales: 203,
        units: 320000,
      },
      {
        type: 'BOSS',
        key: 'BOSS',
        sales: 82668,
        units: 368000,
      },
    ],
  },
  {
    dcNumber: '5857',
    displayName: '5857 - Tampa',
    dcLandedCost: 6.47,
    dcOnHand: 183,
    dcOnOrder: 90,
    vendor: '',
    stores: ['4', '5'],
    deliveryType: 'Scheduled/Unscheduled',
  },
];
