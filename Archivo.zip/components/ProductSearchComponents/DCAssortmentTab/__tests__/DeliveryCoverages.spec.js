import React from 'react';
import { screen, render } from '@testing-library/react';
import DeliveryCoverages from "../DeliveryCoverages";

describe('DeliveryCoverages component', () => {

  it('renders component title',() => {
    render(<DeliveryCoverages />);
    expect(screen.getByText('Unscheduled Delivery Coverage for Contiguous US')).toBeInTheDocument();
  });

  it('shows 3 days coverages',() => {
    render(<DeliveryCoverages />);
    expect(screen.getByText('1 Day Coverage')).toBeInTheDocument();
    expect(screen.getByText('2 Day Coverage')).toBeInTheDocument();
    expect(screen.getByText('3 Day Coverage')).toBeInTheDocument();
  });


});
