import React from 'react';
import { screen, render, fireEvent } from '@testing-library/react';

import { dcAssortment } from '../__fixtures__/dcAssortment';
import {
  useDCAssortment,
  useLoading,
} from '../../../DCAssortment/DCAssortmentProvider';
import RegionallyAssortedDCTable from '../RegionallyAssortedDCTable';

jest.mock('../../../DCAssortment/DCAssortmentProvider');

describe('RegionallyAssortedDCTable component', () => {
  beforeEach(() => {
    useDCAssortment.mockReturnValue(dcAssortment);
    useLoading.mockReturnValue({});
  });

  it('renders default state', () => {
    render(<RegionallyAssortedDCTable />);

    expect(screen.getByText('Regionally Assorted DCs')).toBeInTheDocument();
    // expect(screen.getByText('DC Landed Cost')).toBeInTheDocument();
    // expect(screen.getByText('Vendor')).toBeInTheDocument();
    // expect(screen.getByText('DC On Hand')).toBeInTheDocument();
    // expect(screen.getByText('DC On Order')).toBeInTheDocument();
    expect(screen.getByText('Stores')).toBeInTheDocument();
    expect(screen.getByText('Delivery Type')).toBeInTheDocument();
  });

  it('renders main table values', () => {
    render(<RegionallyAssortedDCTable />);

    expect(screen.queryByText('5856 - Atlanta')).toBeInTheDocument();
    expect(screen.queryByText('5857 - Tampa')).toBeInTheDocument();

    expect(screen.queryByText('3')).toBeInTheDocument();
    expect(screen.queryByText('2')).toBeInTheDocument();

    expect(screen.queryByText('Scheduled Only')).toBeInTheDocument();
    expect(screen.queryByText('Scheduled/Unscheduled')).toBeInTheDocument();
  });

  // it('renders nested table and checks all columns existence', () => {
  //   render(<RegionallyAssortedDCTable />);
  //
  //   const [firstExpandButton] = screen.getAllByRole('button', {
  //     class: 'ant-table-row-expand-icon',
  //   });
  //   fireEvent.click(firstExpandButton);
  //   expect(screen.getByText('Sales')).toBeInTheDocument();
  //   expect(screen.getByText('Units')).toBeInTheDocument();
  // });
});
