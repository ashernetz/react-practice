import React from 'react';
import {Typography, Row, Col, Space, Progress} from 'antd';
import "./../InStoreSingleSkuTabs/InStoreSingleSkuTabs.scss";

const {Text, Paragraph} = Typography;

const Coverage = ({coverageValue}) => {
  return (
    <Space direction="vertical">
      <Text strong>
        {coverageValue.day} Day Coverage
      </Text>
      <Progress type="circle" size={150} percent={coverageValue.percent} status={!coverageValue.percent ? 'exception' : ''} strokeColor="#d44e00"/>
    </Space>
  );
}

const DeliveryCoverages = () => {
  const coverageData = [
    {
      day:1,
      percent:''
    },
    {
      day:2,
      percent:30
    },
    {
      day:3,
      percent:70
    },
    {
      day:4,
      percent:100
    }
  ];

  return (
    <>
      <Paragraph className="inStore-tab-header-text" style={{marginTop:'20px'}}>
        Unscheduled Delivery Coverage for Contiguous US
      </Paragraph>
      <Row justify="center" align="middle">
        <Col>
          <Space size="large">
            { coverageData.map((value)=> {
              return (<Coverage coverageValue={value}/>);
            })}
          </Space>
        </Col>
      </Row>
      <Paragraph className="coverage-text" >
        Coverages are applicable at SKU level for all regions with unscheduled delivery
      </Paragraph>
    </>
  );
};

export default DeliveryCoverages;
