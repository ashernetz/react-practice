import React, { useMemo } from 'react';
import { Typography, Table, Spin } from 'antd';
import './../InStoreSingleSkuTabs/InStoreSingleSkuTabs.scss';
import AdvancedTable from '../../GlobalComponents/AdvancedTable/AdvancedTable';
import CompUtil from '../../Utils/CompUtil';
import UXSmallPulse from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse';
import { formatNumberToCompact } from '../../Utils/CommonUtil';

import {
  useDCAssortment,
  useLoading,
} from '../../DCAssortment/DCAssortmentProvider';
import { UXSpin } from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';

const { Text, Paragraph } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;
const customStringSorter = (a, b) => {
  return (a || '').localeCompare(b || '');
};

const ExpandedTable = (props) => {
  const expandedTableColumns = [
    {
      title: headerFormatter('Type'),
      dataIndex: 'type',
      key: 'type',
      sorter: (a, b) => customStringSorter(a.type, b.type),
    },
    {
      title: headerFormatter('Sales'),
      dataIndex: 'sales',
      key: 'sales',
      sorter: (a, b) => a.sales - b.sales,
      render: (sales) => <Text>{CompUtil.formatMuMdPrice(sales, true)}</Text>,
    },
    {
      title: headerFormatter('Units'),
      dataIndex: 'units',
      key: 'units',
      sorter: (a, b) => a.units - b.units,
      render: (units) => <Text>{formatNumberToCompact(units)}</Text>,
    },
  ];

  return (
    <Spin indicator={<UXSmallPulse />} spinning={!props.types}>
      <Table
        columns={expandedTableColumns}
        dataSource={props.types}
        pagination={false}
      />
    </Spin>
  );
};

function CellValue({ children, isLoading = false, isPresent = false }) {
  if (isLoading) {
    return <UXSpin />;
  }

  return isPresent ? children : '--';
}

const renderValue = () => <CellValue />;

const getColumns = (loading) => [
  {
    title: headerFormatter('DC'),
    dataIndex: 'displayName',
    key: 'displayName',
    sorter: (a, b) => customStringSorter(a.dcNumber, b.dcNumber),
    render: (value) => value,
  },
  // {
  //   title: headerFormatter('DC Landed Cost'),
  //   dataIndex: 'dcLandedCost',
  //   key: 'dcLandedCost',
  //   render: (value) => (
  //     <CellValue isLoading={loading.isDCSLoading} isPresent={Boolean(value)}>
  //       ${CompUtil.formatPrice(value)}
  //     </CellValue>
  //   ),
  // },
  // {
  //   title: headerFormatter('DC On Hand'),
  //   dataIndex: 'dcOnHand',
  //   key: 'dcOnHand',
  //   render: renderValue,
  // },
  // {
  //   title: headerFormatter('DC On Order'),
  //   dataIndex: 'dcOnOrder',
  //   key: 'dcOnOrder',
  //   render: renderValue,
  // },
  // {
  //   title: headerFormatter('Vendor'),
  //   dataIndex: 'vendor',
  //   key: 'vendor',
  //   render: renderValue,
  // },
  {
    title: headerFormatter('Stores'),
    dataIndex: 'stores',
    key: 'stores',
    sorter: (a, b) => a.stores.length - b.stores.length,
    render: (stores) => (
      <CellValue
        isLoading={loading.isStoresLoading}
        isPresent={Boolean(stores.length)}
      >
        {stores.length}
      </CellValue>
    ),
  },
  {
    title: headerFormatter('Delivery Type'),
    dataIndex: 'deliveryType',
    key: 'deliveryType',
    className: 'custom-search-icon',
    render: (deliveryType) => (
      <CellValue isPresent={Boolean(deliveryType)}>{deliveryType}</CellValue>
    ),
  },
];

const RegionallyAssortedDCTable = () => {
  const loading = useLoading();
  const dcAssortment = useDCAssortment();
  const columns = useMemo(() => getColumns(loading), [loading]);

  return (
    <>
      <Paragraph className="inStore-tab-header-text">
        Regionally Assorted DCs
      </Paragraph>
      <AdvancedTable
        tableClassName="all-sku-table"
        columns={columns}
        dataSource={dcAssortment}
        pagination={false}
        bordered={true}
        extraTableProps={{
          getPopupContainer: (triggerNode) => triggerNode.parentNode,
          loading: {
            spinning: loading.isDCSLoading,
            indicator: <UXSmallPulse />,
          },
          // expandable: {
          //   expandedRowRender: ({ types }) => <ExpandedTable types={types} />,
          //   rowExpandable: ({ types }) => Boolean(types),
          // },
          rowKey: 'dcNumber',
        }}
      />
    </>
  );
};

export default RegionallyAssortedDCTable;
