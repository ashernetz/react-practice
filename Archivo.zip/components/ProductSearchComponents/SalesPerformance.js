import React, { useState, Fragment } from 'react';
import {Row, Col, Typography, Radio, Table, Spin} from 'antd';
import { Chart, Tooltip, Axis,  Line, Legend } from 'viser-react';
import "./OnlineSingleSkuTabs/OnlineSingleSkuTabs.scss";
import CompUtil from "../Utils/CompUtil";
import SvgUtil from "../Utils/SvgUtil";

import { formatNumberToCompact } from "../Utils/CommonUtil";
import UXSmallPulse
    from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";

const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;
const SalesPerformance = (props) => {

    const [selectedType, setSelectedType] = useState("rawSalesAmount");

    function changeChartType(value) {
        setSelectedType(value);
    }

    const salesColumns = [
        {
            title: headerFormatter('Date'),
            dataIndex: 'fiscalWeek',
            sorter: (a, b) => b.fiscalWeek.localeCompare(a.fiscalWeek),
            render: (fiscalWeek, row) => <Text >{fiscalWeek ? fiscalWeek : "-"}</Text>,
        },
        {
            title: headerFormatter('Sales'),
            dataIndex: 'salesAmount',
            align: 'right',
            sorter: (a, b) => (a.rawSalesAmount ? a.rawSalesAmount:0) - (b.rawSalesAmount ? b.rawSalesAmount:0),
            render: (salesAmount, row) => salesAmount ? <Text>{'$' + salesAmount}{CompUtil.getArrowUpDownComponent(row.salesUpOrDown)}</Text> : "-",
        },
        {
            title: headerFormatter('Units'),
            dataIndex: 'unitsSold',
            align: 'right',
            sorter: (a, b) => (a.rawUnitsSold ? a.rawUnitsSold:0) - (b.rawUnitsSold ? b.rawUnitsSold:0),
            render: (unitsSold, row) => unitsSold ? <Text>{unitsSold}{CompUtil.getArrowUpDownComponent(row.unitsUpOrDown)}</Text> : "-",
        }
       
    ];
    const toolTipRender = (title, items) => {

        let toolTip = '<div class="performance-tooltip"><div class="g2-tooltip-title" style="margin-bottom: 4px;">' + title + '</div>';
        items.forEach(item => {
            let formattedValue = (selectedType === "rawSalesAmount" ? "$" : "") + formatNumberToCompact(item.value);
            toolTip = toolTip + '<li data-index={index}><span style="background-color:' + item.color + ';width:4px;height:4px;border-radius:50%;display:inline-block;margin-right:8px;"></span>' + item.name + ' : ' + formattedValue + '</li>'
        });
        toolTip = toolTip + '</div>';
        return toolTip;
    };

    function populateSalesPerformanceData() {
        let graphData = [];
        if (props.salesPerformanceData) {
            props.salesPerformanceData.currentYearPerformance.forEach(data => {
                if((data.rawSalesAmount && selectedType ==="rawSalesAmount") ||(data.rawUnitsSold &&selectedType ==="rawUnitsSold") ){
                    graphData.push({
                        fiscalWeek: data.fiscalWeek,
                        rawSalesAmount: data.rawSalesAmount,    
                        rawUnitsSold:  data.rawUnitsSold,    
                        fiscalYear : data.fiscalYear
                    });
                } 
            });
            props.salesPerformanceData.lastYearPerformance.forEach(data => {
                if((data.rawSalesAmount && selectedType ==="rawSalesAmount") ||(data.rawUnitsSold&&selectedType ==="rawUnitsSold") ){
                    graphData.push({
                        fiscalWeek: data.fiscalWeek,
                        rawSalesAmount: data.rawSalesAmount,    
                        rawUnitsSold:  data.rawUnitsSold,
                        fiscalYear : data.fiscalYear ,                
                    });
                }              
            });

            graphData.sort((a, b) => getFwNum(a.fiscalWeek).localeCompare(getFwNum(b.fiscalWeek), undefined, {numeric: true}));
        }
        return graphData;
    }

    function getFwNum(fwString) {
        return fwString.split("FW")[1]
    }

    const SalesPerformanceNodata = () => {
        return(
            <Fragment>
            <Row justify="center" align="middle" type="flex">
              <Col className="noKVI">
                {SvgUtil.getNoData()}
              </Col>
            </Row>
            <Row justify="center" align="middle" type="flex" style={{paddingTop: "10px" }}>
              <Col>
                <Text className="no-kvi">
                  No Performance Data Available
                </Text>
              </Col>
            </Row>            
          </Fragment>
        )
    }

    return (<Fragment>
        <Row justify="space-between" align="middle" gutter={[0, 24]} style={{padding: "12px 0px"}}>
            <Col span={12}><Text className="online-tab-header-text" >Sales Performance</Text ></Col>
            {Object.keys(props.salesPerformanceData).length > 0 ?
                <Col span={12} className="sales-performanceToggle">
                    <Radio.Group defaultValue="rawSalesAmount" onChange={(e) => changeChartType(e.target.value)} value={selectedType} buttonStyle="solid">
                        <Radio.Button value="rawSalesAmount">Sales</Radio.Button>
                        <Radio.Button value="rawUnitsSold">Units</Radio.Button>
                    </Radio.Group>
                </Col> : null}
        </Row>
        {Object.keys(props.salesPerformanceData).length > 0 ?
            <Row>
                <Col span={24}>
                    <Chart forceFit data={populateSalesPerformanceData()} height={396}>
                        <Tooltip crosshairs="y" htmlContent={toolTipRender} />
                        <Axis dataKey="fiscalWeek" />
                        <Axis dataKey={selectedType} label={{ formatter: val => (selectedType === "rawSalesAmount" ? "$" : "") + formatNumberToCompact(val) }} />
                        <Legend clickable={false} hoverable={false} />
                        <Line
                            position={`fiscalWeek*${selectedType}`}
                            color=
                            {['fiscalYear', (value) => {
                                if (value === props.salesPerformanceData.currentYear) {
                                    return '#fa6302'
                                }
                                else if (value === props.salesPerformanceData.lastYear) {
                                    return '#FFBF94'
                                };
                            }]}
                            shape={['fiscalYear', (value) => {
                                if (value === props.salesPerformanceData.currentYear) {
                                    return 'line'
                                }
                                else if (value === props.salesPerformanceData.lastYear) {
                                    return 'dash'
                                }
                            }]}
                        />
                    </Chart>
                </Col>
            </Row> :
            <Spin indicator = {<UXSmallPulse/>} spinning={!props.salesPerformanceData}>
                <Row className="sales-performance-no-data"><Col span={24}><SalesPerformanceNodata/></Col></Row></Spin>
        }
        <Row gutter={[0, 24]}>
            <Col span={24}>
                <Table
                    columns={salesColumns}
                    rowKey="fiscalWeek"
                    pagination={{pageSize: 10,showSizeChanger:false}}
                    dataSource={props.salesPerformanceData ? props.salesPerformanceData.currentYearPerformance : []} />
            </Col>
        </Row></Fragment>

    );
};
export default SalesPerformance;
