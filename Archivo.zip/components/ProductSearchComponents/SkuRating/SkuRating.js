import React,{Fragment} from "react";
import {Rate,Typography} from "antd";
import "./SkuRating.scss";

const {Text} = Typography;
const findWidth = (inputValue="0")=>{
    return ((inputValue-Number.parseInt(inputValue))*100).toFixed(2)+'%';
};

const SkuRating = (props) =>{
return(<Fragment>
  <Rate
      className="sku-rating-star"
      style={{"--skuRateWidth":findWidth(props.value?props.value:0)}}
      disabled
      allowHalf
      value={props.value}/>
  <Text className="sku-rating-count">({props.count?props.count:0})</Text>
</Fragment>);
};

export default SkuRating;