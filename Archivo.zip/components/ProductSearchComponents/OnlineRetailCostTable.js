import React ,{Fragment}from 'react';
import {Typography, Table, Spin, Tooltip, Row, Col} from 'antd';
import "./OnlineComponents.scss";
import CompUtil from "../Utils/CompUtil";
import UXSmallPulse from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
//<import {trackEvent} from '../Utils/mixpanel';


const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const OnlineRetailCostTable = (props) => {

    const ToolTipTitle = (props) => {
        return(
            <Fragment>
                {/*<Row align="middle"><Col><Text className="tooltip-txt-color">System Id : {props.SystemId ? props.SystemId : "-"}</Text></Col></Row>*/}
                <Row align="middle"><Col><Text className="tooltip-txt-color">Request Id : {props.requestid ? props.requestid : "-"}</Text></Col></Row>
                <Row align="middle"><Col><Text className="tooltip-txt-color">Submitter : {props.submitter ? props.submitter : "-"}</Text></Col></Row>
            </Fragment>
        );
    };

    let homeEvent = "HOUSE EVENT"

    const columns = [
        {
            title: headerFormatter('Date'),
            dataIndex: 'displayDate',
            width: '17%',
            sorter: (a, b) => a.beginDate - b.beginDate,
            render: (beginDate, row) =>
                <Tooltip placement="top"
                         title={<Text style={{color:'#ffffff'}}>{row.tooltipTime}</Text>}>
                <Text className="dashedHover">{row.displayDate}</Text>
                </Tooltip>,
        },
        {
            title: headerFormatter('Event'),
            dataIndex: 'event',
            width: '23%',
            sorter: (a, b) => customStringSorter(a.event,b.event),
            render: (event, row) => <Text >{event ? ((row.event.toLowerCase()).includes(homeEvent.toLowerCase()) ? event+" (not charted)" :  event) : "-"}</Text>,
        },
        {
            title: headerFormatter('Vendor'),
            dataIndex: 'vendorNumber',
            width: '32%',
            sorter: (a, b) => a.vendorNumber - b.vendorNumber,
            render: (vendorNumber, row) =>
                <Fragment>
                    {vendorNumber?
                        <a onClick = {()=>{props.onVendorClick(vendorNumber,row.vendorName)}}>{ row.formattedVendor } </a>:"-"} {/*eslint-disable-line*/}
                </Fragment>,
        },
        {
            title: headerFormatter('Retail'),
            dataIndex: 'retail',
            align:'right',
            sorter: (a, b) => a.retail - b.retail,
            render: (retail, row) => {
                if(retail){
                    let isHouseEvent = row.event.toLowerCase().includes(homeEvent.toLowerCase());
                    return(<Fragment>
                <Tooltip placement="top" title={<ToolTipTitle requestid={row.requestid} submitter={row.submitter}/>}>
                        <Text className={isHouseEvent?"dashedHover":"price-arrow-gap dashedHover"}>{isHouseEvent?CompUtil.formatPrice(retail)+'% off':('$' + CompUtil.formatPrice(retail))}</Text>
                       { CompUtil.getArrowUpDownComponent(isHouseEvent?null:row.arrowIndicator,{className:"black-arrow-indicator"})}
                </Tooltip> </Fragment>);
                }else {return "-"; } }
        },
        {
            title: headerFormatter('Cost'),
            dataIndex: 'cost',
            width: '15%',
            align:'right',
            sorter: (a, b) => a.cost - b.cost,
            render: (cost, row) => cost ? <Fragment>
                <Tooltip placement="top" title={<ToolTipTitle requestid={row.requestid} submitter={row.submitter}/>}>
                    <Text className="price-arrow-gap dashedHover">{ '$' + CompUtil.formatPrice(cost)}</Text>
                </Tooltip> {CompUtil.getArrowUpDownComponent(row.arrowIndicator,{className:"black-arrow-indicator"})}</Fragment>: "-"
        },
    ];


    return (
        <Spin indicator={<UXSmallPulse />} spinning={!props.timelineMap.hasOwnProperty(props.skuNumber)}>
            <Table columns={columns} dataSource={props.timelineMap.hasOwnProperty(props.skuNumber) ? props.timelineMap[props.skuNumber] : []}
                   pagination={props.isPagination?{pageSize: 10,showSizeChanger:false}:false}
            />
        </Spin>

    );
};

export default OnlineRetailCostTable;
