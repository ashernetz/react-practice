import React, {Fragment, useState} from 'react';
import {Typography, Tooltip, Space, Row, Col} from 'antd';
import "./OnlineComponents.scss";
import CompUtil from "../Utils/CompUtil";
import OnlineRetailCostTable from "./OnlineRetailCostTable"
import AdvancedTable from '../GlobalComponents/AdvancedTable/AdvancedTable';
import {trackEvent} from "../Utils/mixpanel";
import {formatNumberToCompact} from "../Utils/CommonUtil";
import TableUtil from "../Utils/TableUtil";
import {UXSpin} from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";

const { Text } = Typography;

const TopSKUTooltip = () =>{
    return (
        <Tooltip arrowPointAtCenter title = {info} placement ='bottom' color="#ffffff"
                 overlayClassName="cpi-tooltip-arrow"
                 overlayInnerStyle={{
                     padding: '20px',
                     width: '250px',
                     height: '210px',
                     marginLeft: '0px',
                 }}
        >
            <i className="material-icons-outlined topskurank-info">
                    info
                  </i>
        </Tooltip>
    )
};

const info = () => {
    return (
        <>
            <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>{ "What is a Top SKU?"}</p>
            <p style={{color: 'black', marginTop: '-5px'}}>Based on annual R12 enterprise (online and in-store) sales dollars, top SKUs are ranked within the top 100,000 across The Home Depot USA. Top SKUs are updated quarterly.</p>
         </>
    )
}


const headerFormatter = (input) => <span>
        <i>{input == 'Top 100K SKU' ? <TopSKUTooltip/> : null}</i>
        <Text strong>{input} </Text>
        </span>;
    

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const omsIdSorter = (a,b) =>{
    let firstValue = (a && a.length>0)?a[0]:0;
    let secondValue = (b && b.length>0)?b[0]:0;

    return firstValue - secondValue;
};

const OnlineMultiSkuTable = (props) => {
    const [paginationObject,setPaginationObject] = useState({currentPage:1,pageSize:20});
    const columns = [
        {
            title: headerFormatter('SKU'),
            dataIndex: 'skuNumber',
            align:'right',
            isCustomFilter: true,
            width: 150,
            fixed: 'left',
            retainColumnRender: true,
            sorter: (a, b) => a.skuNumber - b.skuNumber,
            render: (skuNumber, row) => <a //eslint-disable-line
                style={{ cursor:'pointer'}}
                onClick ={ ()=>{
                    window.open('/s/'+skuNumber);
                    trackEvent("CLICKED_SKU_FROM_ONLINE_MULTI_SKU_PAGE");
                }}>{skuNumber ? skuNumber : "-"}</a>,
        },
        {
            title: headerFormatter('Description'),
            dataIndex: 'skuDescription',
            isCustomFilter: true,
            width: 260,
            fixed: 'left',
            className:'col-sku-desc-search-icon',
            retainColumnRender: true,
            ellipsis: true,
            sorter: (a, b) =>  customStringSorter(a.skuDescription,b.skuDescription),
            render: (skuDescription, row) => <Tooltip placement="topLeft" title={skuDescription}><Text>{skuDescription}</Text></Tooltip>
        },
        {
            title: headerFormatter('OMSID'),
            dataIndex: ['omsIdAndVendorData','omsIdList'],
            align:'right',
            width: 150,
            ellipsis: true,
            isCustomFilter: true,
            retainColumnRender: true,
            sorter: (a, b) => omsIdSorter(a.omsIdAndVendorData.omsIdList,b.omsIdAndVendorData.omsIdList),
            render: (omsIdList, row) => <Tooltip placement="topLeft" title={omsIdList ? (omsIdList.length > 0 ? omsIdList.toString() : "") : "-"}>
                <a>{omsIdList ? (omsIdList.length > 0 ? omsIdList.toString() : "") : "-"}</a> {/*eslint-disable-line*/}
            </Tooltip>
        },
        {
            title: headerFormatter('DCS'),
            dataIndex: 'formattedDCS',
            align:'right',
            width: 120,
            sorter: (a, b) =>  customStringSorter(a.formattedDCS,b.formattedDCS),
            render:(dcs,row) =><> <a onClick = {() => {trackEvent("CLICKED_DCS_FROM_ONLINE_MULTI_SKU_PAGE_TABLE",{"dcs":dcs}); props.getAllSkusforDCSView(dcs)}}>{dcs}</a> {/*eslint-disable-line*/}
            </>
        },
        {
            title: headerFormatter('Eff Retail'),
            dataIndex: 'effectiveRetail',
            align: 'right',
            sorter: (a, b) => (isNaN(a.effectiveRetail) ? 0 : a.effectiveRetail)
                - (isNaN(b.effectiveRetail) ? 0 : b.effectiveRetail),
            render: (effectiveRetail, row) =>
                <Row gutter={[4,0]} justify="end" align="top">
                    <Col>
                        <Text>{effectiveRetail ? '$' + CompUtil.formatPrice(
                            effectiveRetail) : '-'}</Text>
                    </Col>
                    <Col >
                        {(row.retailType === 'PROMOTION' && effectiveRetail && row.permRetail)?
                            <Text delete>{'$'
                            + CompUtil.formatPrice(row.permRetail)}</Text> : ''}
                    </Col>
                </Row>,
        },
        {
            title: headerFormatter('Eff Cost'),
            dataIndex: 'effectiveCost',
            align: 'right',
            sorter: (a, b) => (isNaN(a.effectiveCost) ? 0 : a.effectiveCost)
                - (isNaN(b.effectiveCost) ? 0 : b.effectiveCost),
            render: (effectiveCost, row) =>
                <Space align="end" size="small">
                    <Text>{effectiveCost ? '$' + CompUtil.formatPrice(effectiveCost) : '-'}</Text>
                </Space>,
        },
        {
          title: headerFormatter('Promo Map'),
          dataIndex: 'mapRetail',
          align: 'right',
          sorter: (a, b) => (isNaN(a.mapRetail) ? 0 : a.mapRetail) - (isNaN(b.mapRetail) ? 0 : b.mapRetail),
          render: (mapRetail, row) => <Text>{mapRetail ? '$' + CompUtil.formatPrice(mapRetail) : 'NA'}</Text>
        },
        {
            title: headerFormatter('Top 100K SKU'),
            dataIndex: 'rank',
            isRankCol: true,
            align: 'right',
            width: 180,
            retainColumnRender: true,
            sorter: (a, b, sortDirection) => TableUtil.customRankSorter(a, b, sortDirection),
            render: (rank, row) => <Fragment>
                <Text >{rank ? (rank === "-" ? <UXSpin/> : rank): "NA"}</Text>
            </Fragment>,
        },
        {
            title: headerFormatter('Sales'),
            dataIndex: 'compPercentage',
            align:'right',
            defaultSortOrder: 'descend',
            sorter: (a, b) => (a.rawSales && !isNaN(a.rawSales)?a.rawSales:0) - (b.rawSales && !isNaN(b.rawSales)?b.rawSales:0),
            render: (compPercentage, row) => {
                return(<Space>
                    <Text>{row.rawSales?(row.rawSales === "-"?"N/A":<Text strong>{CompUtil.formatMuMdPrice(row.rawSales,true)}</Text>):""}</Text>
                    <Text>{props.compsAndUnitsFormatter(compPercentage,"end")}</Text>
                </Space>);}
        },
        {
            title: headerFormatter('Units'),
            dataIndex: 'unitsPercentage',
            align:'right',
            sorter: (a, b) => (a.rawUnits && !isNaN(a.rawUnits)?a.rawUnits:0) - (b.rawUnits && !isNaN(b.rawUnits)?b.rawUnits:0),
            render: (unitsPercentage, row) =>
            {
                return(<Space>
                    <Text>{row.rawUnits?(row.rawUnits === "-" ? "N/A": <Text strong>{formatNumberToCompact(row.rawUnits)}</Text>) :""}</Text>
                    <Text>{props.compsAndUnitsFormatter(unitsPercentage,"end")}</Text>
                </Space>);
            }
        },
    ];

    let totalCount =  props.onlineMultiSkuData.length;
    let isRemainder = totalCount%paginationObject.pageSize;
    totalCount = isRemainder?totalCount:totalCount+1;
    return (
        <AdvancedTable
            tableClassName="all-sku-table"
            columns={columns}
            dataSource={props.onlineMultiSkuData}
            pagination = {{onChange:(page,pageSize)=>{
                props.lastKey && Math.ceil(totalCount/pageSize)
                     === page? props.onNewPageRender(k=>setPaginationObject(k=>({...k,currentPage:page})),page):setPaginationObject(k=>({...k,currentPage:page}))
                },
                // total:props.lastKey?totalCount +1:totalCount,
                current:paginationObject.currentPage,
                pageSize:paginationObject.pageSize,
                onShowSizeChange:(current, size)=>setPaginationObject(k=>({...k,currentPage:current,pageSize:size}))}}
            extraTableProps ={{expandable:
            {
                onExpand: (expanded, record) => {props.getOnlineRetailTimelineData(record.skuNumber,record.omsIdAndVendorData);trackEvent("CLICKED_EXPAND_BUTTON_FROM_ONLINE_MULTI_SKU_PAGE",{sku:record.skuNumber});},
                expandedRowRender: (record) => <OnlineRetailCostTable
                skuNumber= {record.skuNumber}
                onVendorClick = {(
                    vendorNumber, vendorName) => {
                    trackEvent("CLICKED_VENDOR_FROM_ONLINE_MULTI_SKU_PAGE_TABLE",{"vendor":vendorNumber});
                    props.getAllSkusforDCSView(
                        record.formattedDCS, vendorNumber, vendorName);
                }}
                timelineMap={props.skuTimelineMap}/>
            },rowKey:"skuNumber", scroll: { y: 400}
            }
            }
        />
    );
};
export default OnlineMultiSkuTable;
