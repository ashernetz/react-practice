import { Select, Typography} from "antd";
import React from "react";

const { Option } = Select;
const { Text } = Typography;
const InStoreMultiSkuPresetSelectOption = (props) => {

    return (
        <Select
            bordered={false}
            className="pricing-dropdown pricing-dropdown-arrow"
            onSelect={(selectedValue) => {props.dropDownValueUpdate(selectedValue);}}
            value={props.initialValue}
            size="large"
            optionFilterProp="children">

            <Option value="overview"><Text strong>Overview of Store SKU's</Text></Option>
            <Option value="price-data"><Text strong>Pricing Data For Store SKU's</Text></Option>
            <Option value="competitive-data"><Text strong>Competitive Data For Store SKU's</Text></Option>
            {/*<Option value="financial-data"><Text strong>Financial Data For Store SKU's</Text></Option>*/}
        </Select>

    );
};

export default InStoreMultiSkuPresetSelectOption;
