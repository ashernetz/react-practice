import React, { Fragment } from 'react';
import { Row, Col ,Space, Typography } from 'antd';
import "./OnlineComponents.scss";
import {UXSpin} from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import CompUtil from '../Utils/CompUtil';
import CPIUtil from '../Utils/CPIUtil';
// import {StarFilled} from '@ant-design/icons';
const { Text } = Typography;

const cpiValueColorFormat = (value) =>{
    return value ==="NA" ? "": (value < 1 ? "cpi-color-positive" : "cpi-color-negative");
};

const CPILabel = ({label,cpi}) => {

    let cpiDaily = "NA";
    let cpiSales = "NA";
    let cpiComps = "NA";
    if(cpi && cpi!=="-"){
        cpiDaily = cpi.cpiDaily? cpi.cpiDaily:"NA";
        cpiComps = cpi.cpiSalesCovDlyPercentage ? CompUtil.formatPrice(cpi.cpiSalesCovDlyPercentage)+"%" : "NA";
        cpiSales = cpi.cpiSalesCovDollarDlyDenom ? CompUtil.formatMuMdPrice(cpi.cpiSalesCovDollarDlyDenom,true) :"NA";
    }
    return(
        <Row gutter={[16,0]} align="middle">
            <Col>
                <Text strong>{label}</Text>
                {/*{cpi ? (cpi.primaryCompetitor === "Y" ? <Badge count={<StarFilled style={{ color: '#f96302',fontSize:'8px' }} />} offset={[7,-6]} /> : "") : "" }*/}
            </Col>
            <Col>
                {cpi ? (cpi === "-" ? <Text>NA</Text> :
                        <Space>
                            <Text strong className={cpiValueColorFormat(cpiDaily )}>{cpiDaily==="NA"?<Text>NA</Text>:CPIUtil.formatCPI(cpiDaily)}</Text>
                            <Row justify="center" align="middle" gutter={[4,0]}>
                                <Col><Text strong>{cpiComps}</Text></Col>
                                <Col><Text>|</Text></Col>
                                <Col><Text strong>{cpiSales}</Text></Col>
                            </Row>
                        </Space>
                ):<UXSpin/>}
            </Col>
        </Row>);
};

const AggregatedCPI = (props) => {

    return(
        <Fragment>
            <Text className="aggr-cpi-text">CPI</Text>
            <Row gutter = {[16,0]} >
                <Col>
                    <Space direction="vertical">
                        <CPILabel label= "Low" cpi={props.aggCPI[3141]}/>
                        <CPILabel label= "F&D" cpi={props.aggCPI[588623]}/>
                        <CPILabel label= "Wal" cpi={props.aggCPI[527]}/>
                    </Space>
                </Col>
                <Col>
                    <Space direction="vertical">
                        <CPILabel label = "Men" cpi={props.aggCPI[6488]}/>
                        <CPILabel label = "Amz" cpi={props.aggCPI[18214]}/>
                    </Space>
                </Col>

            </Row>
        </Fragment>
    )
};
export default AggregatedCPI