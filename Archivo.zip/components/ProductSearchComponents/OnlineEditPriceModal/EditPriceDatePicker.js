import React, {Fragment} from 'react';
import {Row, Col, Typography, DatePicker} from 'antd';
import './OnlineEditPriceModal.scss';
import moment from 'moment-timezone'
const { Text } = Typography;


const EditPriceDatePicker = (props) => {

    const handleChange = (e) => {
        const selectedDate = e.toISOString();
        let today = new Date();
        if(selectedDate > today.toISOString()){
            props.setSelectedDate(moment.utc(selectedDate).tz("America/New_York").set({'hour':0,'minute':0,'second':0,'millisecond':0}).format('YYYY-MM-DDTHH:mm:ss.SS'))
        }
        else{
          props.setSelectedDate(moment.utc(selectedDate).tz("America/New_York").format('YYYY-MM-DDTHH:mm:ss.SS'))
        }
    }

    const disabledDate = (current) => {      
        return current && current < moment().startOf('day');
    }

    return (
        <Fragment>
            <Row align="middle" gutter={[0,8]}>
                <Col>
                    <Text className="edit-price-label">Begin Date</Text>
                </Col>
            </Row>
            <Row align="middle" gutter={[0,8]}>
                <Col>
                  <DatePicker getPopupContainer={trigger => trigger.parentNode}
                              allowClear={false} size="large"
                              style={{width: '444px'}}
                              disabledDate={disabledDate}
                              onChange={(e)=>handleChange(e)}/>
                </Col>
            </Row>
        </Fragment>
    );
};

export default EditPriceDatePicker;