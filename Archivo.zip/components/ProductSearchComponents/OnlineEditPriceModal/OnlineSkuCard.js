import React from 'react';
import { Row, Col, Typography, Space } from 'antd';
import './OnlineEditPriceModal.scss';
import NoSkuImage from "../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import UXImage from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";

const { Text } = Typography;

const OnlineSkuCard = (props) => {
    return (
            <Row align="middle">
                <Col span={6}><UXImage imageUrl={props.skuImage?props.skuImage:NoSkuImage} classNames="online-edit-price-sku-img" /></Col>
                <Col span={18}>
                    <Space direction="vertical" align="start" size={0}>
                        <Text type="secondary" className="online-edit-price-sku">SKU {props.skuNumber}</Text>
                        <Text className="online-edit-price-vendor">{props.vendorName}</Text>
                        <Text className="online-edit-price-sku-des">{props.skuDescription}</Text>
                    </Space>
                </Col>
            </Row>
    );
};
export default OnlineSkuCard;