import React, { Fragment } from 'react';
import { Row, Col, Typography, Space } from 'antd';
import './OnlineEditPriceModal.scss';
import CompUtil from "../../Utils/CompUtil";

const { Text } = Typography;

const ItemProperty = (props) => {
    return (
        <Fragment>
            <Row justify="center" align="middle">
                <Col>
                    <Text className="item-prop-name">{props.name}</Text>
                </Col>
            </Row>
            <Row justify="center" align="middle">
                <Col>
                    <Text strong className="item-prop-value"> {props.value}</Text>
                </Col>
            </Row>
        </Fragment>
    );
};

const EditPriceItemProperty = (props) => {

    return (
            <Row justify="center" align="middle"  gutter={[0, 16]}>
                    <Col span={8} className="item-prop-colCenter">
                        <Space direction="vertical"  size={22}>
                            <ItemProperty name="Price" value={props.headerData.effectiveRetail ? "$"+CompUtil.formatPrice(props.headerData.effectiveRetail) : "NA"}/>
                            <ItemProperty name="Time Period" value={"FW " + props.headerData.fiscalWeek} />
                        </Space>
                    </Col>
                    <Col span={8} className="item-prop-colCenter">
                        <Space direction="vertical" size={22}>
                            <ItemProperty name="Cost" value={props.headerData.effectiveCost ? "$"+CompUtil.formatPrice(props.headerData.effectiveCost) : "NA"}/>
                            <ItemProperty name="Sales" value={props.compsAndUnitsFormatter(props.headerData.totalCompPercentage)} />
                        </Space>
                    </Col>
                    <Col span={8} className="item-prop-colCenter">
                        <Space direction="vertical" size={22}>
                            <ItemProperty name="Vendor" value={props.headerData.vendorName} />
                            <ItemProperty name="Units" value={props.compsAndUnitsFormatter(props.headerData.totalUnitsPercentage)}/>
                        </Space>
                    </Col>
                    {/* value={props.headerData.vendorName} */}
            </Row>
    );
};

export default EditPriceItemProperty;