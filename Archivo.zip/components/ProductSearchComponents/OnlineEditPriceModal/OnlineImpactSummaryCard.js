import React, { Fragment } from 'react';
import { Row, Col, Typography, Space, Input } from 'antd';
import './OnlineEditPriceModal.scss';

const { Text } = Typography;

const ImpactSummaryCard = (props) => {

    return (
        <Row align="middle" justify="center" className="impact-summary-card">
            <Col>
                <Space direction="vertical" align="center" size={0}>
                    <Text className="impact-summary-imu">{props.imu}</Text>
                    <Space align="center">
                        <Text className="impact-summary-imuPer">{props.imuPercentage}</Text>
                        <Text className="impact-summary-imuRange">{props.imuRange}</Text>
                    </Space>
                </Space>
            </Col>
        </Row>
    );
};


const OnlineImpactSummaryCard = (props) => {

    const currentPrice = props.headerData.effectiveRetail ? props.headerData.effectiveRetail : "";
    const currentCost = props.headerData.effectiveCost ? props.headerData.effectiveCost : "";
    const newPrice = props.newPrice ? props.newPrice : "";
    const newCost = props.newCost ? props.newCost : "";
    let currentIMU = "";
    let newIMU = "";
    const disableCost = props.headerData.vendorNumber !== 0 ? false: true;

    const calculateCurrentIMU = (currentPrice, currentCost) => {
        if (currentCost === "" || isNaN(currentCost) || isNaN(currentPrice) || currentPrice === "") {
            return "NA"
        }
        else {
            currentIMU = ((currentPrice - currentCost) / currentPrice) * 100;
            let currentIMUPercentage = currentIMU.toFixed(2) + " %";
            return currentIMUPercentage;
        }
    }

    const calculateNewIMU = (newPrice, newCost) => {
        newPrice = newPrice === "" ? currentPrice : newPrice
        newCost = newCost === "" ? currentCost : newCost
        if (isNaN(newPrice) || isNaN(newCost) || newPrice === "" || newCost === "") {
            return "NA"
        } else {
            newIMU = ((newPrice - newCost) / newPrice) * 100;
            let newIMUPercentage = newIMU.toFixed(2) + " %";
            return newIMUPercentage;
        }
    }

    const calculateImuDifference = () => {
        if (currentIMU === "" || newIMU === "" || isNaN(currentIMU)|| isNaN(newIMU)) {
            return "-";
        }
        else {
            let imuDifference = ((currentIMU - newIMU)).toFixed(2) + " %";
            return imuDifference;
        }
    }

    return (
        <Fragment>
            <Row gutter={[24, 16]}>
                <Col span={12}>
                    <Space direction="vertical" size={6}>
                        <Text className="edit-price-label">New Price</Text>
                        <Input value={props.newPrice} size="large" prefix="$" onChange={(e) => { let price = e.target.value; const re = /^[0-9]*\.?[0-9]*$/; if(price === '' || re.test(price)){props.setNewPrice(price) }}} />

                    </Space>
                </Col>
                <Col span={12}>
                    <Space direction="vertical" size={6}>
                        <Text className="edit-price-label">New Cost</Text>
                        <Input disabled = {disableCost} value={props.newCost} size="large" prefix="$" onChange={(e) => { let cost = e.target.value;const re = /^[0-9]*\.?[0-9]*$/; if(cost === '' || re.test(cost)){ props.setNewCost(cost) }}} />
                    </Space>
                </Col>
            </Row>
            <Row gutter={[0, 16]}>
                <Col span={24}>
                    <Space direction="vertical">
                        <Text className="online-impact-summary">Impact Summary</Text>
                        <Space direction="horizontal" align="center" size={37}>
                            <ImpactSummaryCard imu="Current IMU" imuPercentage={calculateCurrentIMU(currentPrice, currentCost)} />
                            <ImpactSummaryCard imu="New IMU" imuPercentage={calculateNewIMU(newPrice, newCost)} imuRange={"(" + calculateImuDifference() + ")"} />
                        </Space>
                    </Space>
                </Col>
            </Row>
        </Fragment>

    );
};
export default OnlineImpactSummaryCard;