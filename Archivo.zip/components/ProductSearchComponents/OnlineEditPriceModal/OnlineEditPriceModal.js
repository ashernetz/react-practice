import React,{useState,useContext} from 'react';
import { Typography, Modal, Input, Space } from 'antd';
import './OnlineEditPriceModal.scss';
import OnlineSkuCard from "./OnlineSkuCard";
import EditPriceItemProperty from "./EditPriceItemProperty";
import OnlineImpactSummaryCard from "./OnlineImpactSummaryCard";
import EditPriceDatePicker from "./EditPriceDatePicker";
import PriceDataServices from "../../../services/PriceDataServices";
import AlertUtil from "../../Utils/AlertUtil";
import SkuContext from "../../../context/SkuContext";
import {trackEvent} from '../../Utils/mixpanel';

const { Text } = Typography;
const { TextArea } = Input;

const OnlineEditPriceModal = (props) => {
    const context = useContext(SkuContext);
    const [newPrice,setNewPrice] = useState("");
    const[newCost,setNewCost]= useState("");
    const[beginDate,setSelectedDate] = useState("");
    const [comments, setComments] = useState("");

    const disableCheck = () =>{
        let allowPriceCheck = newPrice !=="" || newCost!=="" ? true:false;
        let beginDateCheck = beginDate!=="" ? true: false;
        return allowPriceCheck && beginDateCheck ? true : false;
    }

    const onPreviewChangesClick = () => {

        let pacManOnlineUrl = props.config.onlineRequestUrl;
        let vendorNumber  = props.headerData.vendorNumber===0?"":props.headerData.vendorNumber;
        context.updateShowDimmer(true);

        trackEvent("CLICKED_SEND_TO_PACMAN_BUTTON_ONLINE", {
            'SKU': props.headerData.skuTitle,
            'STORE_ID': 8119,
            'PRICE': newPrice,
            'COST' : newCost,
            'VENDOR' : vendorNumber,
            'BEGIN_DATE': beginDate
        });

        PriceDataServices.performOnlinePreviewChanges(
            props.headerData.skuTitle,
            props.userId,
            newPrice,
            newCost,
            beginDate,
            comments,
            vendorNumber        
        ).then((response) => {
            if (response.status === 200) {
                window.open(pacManOnlineUrl+response.data.RequestId);
                props.onClose();
                context.updateShowDimmer(false);
            }
        }).catch(e => {
            let alertMessage = AlertUtil.getErrorMessage("executing price change");
            context.updateShowDimmer(false);
            AlertUtil.showAlert("error","Error",alertMessage)
        });
    };


    return (
        <Modal
            title="Edit Online Price"
            open={props.isOpen}
            onCancel={props.onClose}
            destroyOnClose={true}
            className="online-edit-price-modal"
            bodyStyle={{ padding: "15px 25px" }}
            okButtonProps={{ size: 'large', disabled:disableCheck()?false:true}}
            cancelButtonProps={{size: 'large'}}
            okText="Send to PaCMan"
            cancelText="Cancel"
            onOk={onPreviewChangesClick}
        >
                <Space direction="vertical" size={6}>
                    <OnlineSkuCard skuImage={props.editPriceSkuImg}
                        skuNumber={props.headerData.skuTitle ? props.headerData.skuTitle : "-"}
                        vendorName={props.headerData.vendorName ? props.headerData.vendorName.toUpperCase() : "-"}
                        skuDescription={props.headerData.skuDescription ? props.headerData.skuDescription : "-"} />
                    <EditPriceItemProperty headerData={props.headerData}
                        compsAndUnitsFormatter={props.compsAndUnitsFormatter} />
                    <OnlineImpactSummaryCard headerData={props.headerData} 
                                             newPrice ={newPrice} 
                                             setNewPrice ={setNewPrice}
                                             newCost = {newCost} 
                                             setNewCost = {setNewCost} />
                    <EditPriceDatePicker setSelectedDate = {setSelectedDate}/>
                    <Space direction="vertical" size={6}>
                        <Text className="edit-price-label">Comments</Text>
                        <TextArea className="edit-price-textarea" placeholder="Write any additional information here" value = {comments} onChange = {(e)=> setComments(e.target.value)}/>
                    </Space>
                </Space>
        </Modal>
    );
};
export default OnlineEditPriceModal;