import React, {Fragment, useState} from 'react';
import {
    Typography,
    Tooltip,
    Alert,
    Space,Row, Col
} from 'antd';
import "./OnlineComponents.scss";
import CompUtil from "../Utils/CompUtil";
import {formatNumberToCompact} from "../Utils/CommonUtil";
import { trackEvent } from "../Utils/mixpanel";
import AdvancedTable from '../GlobalComponents/AdvancedTable/AdvancedTable';
import {UXSpin} from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import CPIUtil from '../Utils/CPIUtil';
import {StarFilled, InfoCircleOutlined} from '@ant-design/icons';
import AnchorSku from '../../images/AnchorSku.svg';
import CompetitorUtil from '../Utils/CompetitorUtil';
import MultipleVendorDetectedModal
    from "../Pages/SkuPages/MultipleVendorDetectedModal/MultipleVendorDetectedModal";
import TableUtil from "../Utils/TableUtil";

const { Text } = Typography;

const TopSKUTooltip = () =>{
    return (
        <Tooltip arrowPointAtCenter title = {info} placement ='bottom' color="#ffffff"
                 overlayClassName="cpi-tooltip-arrow"
                 overlayInnerStyle={{
                     padding: '20px',
                     width: '250px',
                     height: '210px',
                     marginLeft: '0px',
                 }}
        >
            <i className="material-icons-outlined topskurank-info">
                    info
                  </i>
        </Tooltip>
    )
};

const info = () => {
    return (
        <>
            <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>{ "What is a Top SKU?"}</p>
            <p style={{color: 'black', marginTop: '-5px'}}>Based on annual R12 enterprise (online and in-store) sales dollars, top SKUs are ranked within the top 100,000 across The Home Depot USA. Top SKUs are updated quarterly.</p>
         </>
    )
}


const headerFormatter = (input) => <span>
        <i>{input == 'Top 100K SKU' ? <TopSKUTooltip/> : null}</i>
        <Text strong>{input} </Text>
        </span>;
    

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};


const omsIdSorter = (a,b) =>{
    let firstValue = (a && a.length>0)?a[0]:0;
    let secondValue = (b && b.length>0)?b[0]:0;

    return firstValue - secondValue;
};


// const PopUpContent = (props) => {
//     let popUpContentData = props.cpiData;
//     return (
//             <Row align="middle" className="cpi-row-spacing">
//                 <Col span={24}>
//                     <Row align="middle" gutter={[0, 8]}>
//                         <Col span={24}> <Text strong className="cpi-tooltip-heading">CPI</Text> </Col>
//                     </Row>
//                     <Divider className="cpi-divider"/>
//                     <Row align="middle">
//                         <Col>
//                     { CPIUtil.displayCPIOrder.map((competitorId)=> {
//                         let rowData = popUpContentData[competitorId];
//                         return (
//                             <Row key={competitorId} align="middle" className="cpi-tooltip-row-spacing">
//
//                                 <Col span={5}>
//                                     <Row align="middle" gutter={[6, 0]}>
//                                         <Col  span={5}>
//                                             {rowData.primaryCompetitor === "Y" ?
//                                             <StarFilled style={{ color: '#f96302',fontSize:'8px',lineHeight:'22px' }}/>
//                                                 : ""}
//                                         </Col>
//                                         <Col span={19}>
//                                             <Text className="cpi-competitor-text">{CPIUtil.competitorCPIName[competitorId]}</Text>
//                                         </Col>
//                                     </Row>
//                                 </Col>
//
//                                 <Col span={19}>
//                                     {rowData !== '-' ? <>
//                                         <Row justify="start" align="middle" gutter={[8, 0]}>
//                                             <Col>
//                                                 <Text strong className={cpiValueColorFormat(rowData.cpiDaily)}>
//                                                     {rowData.cpiDaily ? CPIUtil.formatCPI(rowData.cpiDaily): <Text>NA</Text>}
//                                                 </Text>
//                                             </Col>
//                                             <Col>
//                                                 <Text strong>
//                                                     {rowData.cpiSalesCovDlyPercentage ? CompUtil.formatPrice(rowData.cpiSalesCovDlyPercentage)+ '%': 'NA'}
//                                                 </Text>
//                                             </Col>
//                                             <Col>
//                                                 <Text strong>{'|'}</Text>
//                                             </Col>
//                                             <Col>
//                                                 <Text strong>
//                                                     {rowData.cpiSalesCovDollarDlyDenom ? CompUtil.formatMuMdPrice(rowData.cpiSalesCovDollarDlyDenom,true): 'NA'}
//                                                 </Text>
//                                             </Col>
//                                         </Row>
//                                     </> : <Text>NA</Text>}
//                                 </Col>
//                             </Row>
//                             );}
//                     )}</Col></Row>
//                 </Col>
//             </Row>
//     );
// }
const cpiValueColorFormat = (value) =>{
        return value < 1 ? "cpi-color-positive" : "cpi-color-negative";
};


const InStoreMultiSkuTable = (props) => {
    const [paginationObject,setPaginationObject] = useState({currentPage:1,pageSize:20});
    const [vendorList, setVendorList] = useState(null);


    function buildCompetitorTableColumns(title,competitorId,cpiData) {
        return {
            title: headerFormatter(title),
            dataIndex:['cpiData',competitorId],
            width: 240,
            sorter: (a,b) => {
                let cpi_a = a.cpiData[competitorId] && a.cpiData[competitorId].cpiDaily ? a.cpiData[competitorId].cpiDaily : 0;
                let cpi_b = b.cpiData[competitorId] && b.cpiData[competitorId].cpiDaily? b.cpiData[competitorId].cpiDaily : 0;
                return cpi_a - cpi_b;
            },
            align: "right",
            render: (cpiData) =>{
                if(cpiData){
                    if(Object.keys(cpiData).length > 0){
                        return(<CompetitiveData cpiData={cpiData}/>)
                    }else{return "NA"}
                }else{return <UXSpin/>;}
            },
        };
    }

    function multiSkuTableColumns(){
        return[
            {
                title: headerFormatter('SKU'),
                dataIndex: 'skuNumber',
                align: 'right',
                width: 180,
                fixed: 'left',
                isCustomFilter: true,
                retainColumnRender: true,
                sorter: (a, b) => a.skuNumber - b.skuNumber,
                render: (skuNumber, row) => <Fragment>
                    {row.isAnchorSku ? <img src={AnchorSku} alt="Anchor SKU" className="sku-table-anchor"/> : ""}
                    <a //eslint-disable-line
                        style={{ cursor: 'pointer' }}
                        onClick={() => {
                            window.open('/s/' + skuNumber);
                            trackEvent("CLICKED_SKU_FROM_IN_STORE_MULTI_SKU_PAGE");
                        }}>{skuNumber ? skuNumber : "-"}</a>
                </Fragment>,
            },
            {
                title: headerFormatter('Description'),
                dataIndex: 'skuDescription',
                isCustomFilter: true,
                ellipsis: true,
                width: 200,
                fixed: 'left',
                className:'col-sku-desc-search-icon',
                retainColumnRender: true,
                sorter: (a, b) =>  customStringSorter(a.skuDescription,b.skuDescription),
                render: (skuDescription, row) => <Tooltip placement="topLeft" title={skuDescription}><Text>{skuDescription}</Text></Tooltip>
            },
            {
                title: headerFormatter('OMSID'),
                dataIndex: ['omsIdList'],
                align: 'right',
                width: 200,
                ellipsis: true,
                isCustomFilter: true,
                retainColumnRender: true,
                sorter: (a, b) => omsIdSorter(a.omsIdList,b.omsIdList),
                render: (omsIdList, row) => <Tooltip placement="topLeft" title={ omsIdList?(omsIdList.length > 0 ? omsIdList.toString() : ""): "-" }>
                    <a>{omsIdList ? (omsIdList.length > 0 ? omsIdList.toString() : "") : "-"}</a>{/*eslint-disable-line*/}
                </Tooltip>
            },
            {
                title: headerFormatter('DCS'),
                dataIndex: 'formattedDCS',
                align:'right',
                width:180,
                sorter: (a, b) =>  customStringSorter(a.formattedDCS,b.formattedDCS),
                render:(dcs,row) => <Fragment>
                    <a onClick = {() => {props.getAllSkusforDCSView(dcs)}}>{dcs}</a> {/*eslint-disable-line*/}
                </Fragment>
            },
            {
                title: headerFormatter('Vendor'),
                dataIndex: 'vendors',
                align:'left',
                width:180,
                ellipsis: true,
                render:(vendors,row) =>{
                    if(vendors === null)
                        return <UXSpin/>;
                    else{
                        if(vendors && vendors.length > 0){
                            if(vendors.length > 1)
                                return (<><a onClick={()=>{setVendorList(vendors);}}>{vendors.length} Vendors</a>{/*eslint-disable-line*/}</>);
                            else
                                return (<Tooltip placement="topLeft" title={"#"+vendors[0].vendorNumber+"-"+vendors[0].vendorName}>
                                    <a onClick={()=>{props.getAllSkusforDCSView("",vendors[0].vendorNumber,vendors[0].vendorName);}}>{vendors[0].vendorName}</a>{/*eslint-disable-line*/}
                                </Tooltip>);
                        }else
                            return "NA";
                    }
                }
            },
            {
                title: headerFormatter('Top 100K SKU'),
                dataIndex: 'rank',
                isRankCol: true,
                align: 'right',
                width: 180,
                retainColumnRender: true,
                sorter: (a, b, sortDirection) => TableUtil.customRankSorter(a, b, sortDirection),
                render: (rank, row) => <Fragment>
                    <Text >{rank ? (rank === "-" ? <UXSpin/> : rank): "NA"}</Text>
                </Fragment>,
            },
            {
                title: headerFormatter('Sales'),
                dataIndex: 'compPercentage',
                align: 'right',
                width: 180,
                defaultSortOrder: 'descend',
                sorter: (a, b) => (a.rawSales && !isNaN(a.rawSales)?a.rawSales:0) - (b.rawSales && !isNaN(b.rawSales)?b.rawSales:0),
                render: (compPercentage, row) => <Space>
                    <Text>{row.rawSales?(row.rawSales === "-"?"N/A": <Text strong>{CompUtil.formatMuMdPrice(row.rawSales,true)}</Text>):""}</Text>
                    <Text>{props.compsAndUnitsFormatter(compPercentage, "end")}</Text>
                </Space>
            },
            {
                title: headerFormatter('Units'),
                dataIndex: 'unitsPercentage',
                align: 'right',
                width: 180,
                sorter: (a, b) => (a.rawUnits && !isNaN(a.rawUnits)?a.rawUnits:0) - (b.rawUnits && !isNaN(b.rawUnits)?b.rawUnits:0),
                render: (unitsPercentage, row) => <Space>
                    <Text>{row.rawUnits?(row.rawUnits === "-" ? "N/A": <Text strong>{formatNumberToCompact(row.rawUnits)}</Text>) :""}</Text>
                    <Text>{props.compsAndUnitsFormatter(unitsPercentage, "end")}</Text>
                </Space>
            },
            // {
            //     title: headerFormatter('Primary CPI'),
            //     dataIndex: ['primaryCpiValue'],
            //     align: 'right',
            //     width: 200,
            //     sorter: (a, b) => {
            //         let primaryComp_a = a.primaryCpiValue && a.primaryCpiValue.cpiDaily ? a.primaryCpiValue.cpiDaily:0;
            //         let primaryComp_b = b.primaryCpiValue && b.primaryCpiValue.cpiDaily ? b.primaryCpiValue.cpiDaily:0;
            //         return (primaryComp_a - primaryComp_b );
            //     },
            //     render: (primaryCpiValue,record) => {
            //         if(primaryCpiValue){
            //             if(Object.keys(primaryCpiValue).length > 0){
            //                 let competitorData = record.cpiData[primaryCpiValue.id];
            //                 return(
            //                     // <Tooltip
            //                     // color="#ffffff"
            //                     // placement="topRight"
            //                     // overlayInnerStyle={{minWidth:'280px'}}
            //                     // onVisibleChange={(value) =>{if(value){trackEvent("SHOW_CPI_TOOLTIP_FROM_IN_STORE_MULTI_SKU_PAGE")}}}
            //                     // title={<PopUpContent cpiData={record.cpiData} />}
            //                     // overlayClassName="tooltip-overlay-size">
            //                     <Space size="small">
            //                         <>
            //                             <Text strong>{CPIUtil.competitorCPIName[primaryCpiValue.id]}</Text>
            //                             <Text strong className={cpiValueColorFormat(primaryCpiValue.cpiDaily)}>{CPIUtil.formatCPI(primaryCpiValue.cpiDaily)}</Text>
            //                             <Text>{competitorData.cpiSalesCovDlyPercentage?
            //                                 competitorData.cpiSalesCovDlyPercentage+'%':'NA'}
            //                             </Text>
            //                             <Text>{'|'}</Text>
            //                             <Text>{competitorData.cpiSalesCovDollarDlyDenom?
            //                                 CompUtil.formatMuMdPrice(competitorData.cpiSalesCovDollarDlyDenom,true):'NA'}
            //                             </Text>
            //                         </>
            //
            //
            //
            //                     </Space>
            //                 );
            //             }else{return "NA"}
            //         }else {
            //             return <UXSpin/>;
            //         }
            //     }
            // },
            {
                title: headerFormatter('Retail min/max'),
                dataIndex: 'minRetail',
                align: 'right',
                width: 160,
                render: (minRetail, row) =>
                    <Fragment>
                        {(minRetail || row.maxRetail) === "-" ? <UXSpin/> :<>
                            <Text>{!minRetail || minRetail === "-"? "NA":(CompUtil.formatMuMdPrice(minRetail,true))}</Text>
                            {row.maxRetail ? "/" : ""}
                            <Text>{!row.maxRetail || row.maxRetail === "-"? "":(CompUtil.formatMuMdPrice(row.maxRetail,true))}</Text>
                        </>}
                    </Fragment>
            },
            {
                title: headerFormatter('Mode Retail'),
                dataIndex: 'mostCommonRetail',
                align: 'right',
                width:160,
                sorter: (a, b) => ((isFinite(a.mostCommonRetail))?a.mostCommonRetail:0) - ((isFinite(b.mostCommonRetail))?b.mostCommonRetail:0),
                render: (mostCommonRetail, row) =>
                    <Text>
                        {mostCommonRetail === "-" ? <UXSpin /> : (!mostCommonRetail || mostCommonRetail === "-"? "NA":(CompUtil.formatMuMdPrice(mostCommonRetail,false)))}
                        <Text>{row.assortedStore?(" ("+row.assortedStore+")"):""}</Text>
                    </Text>,
            },
            // {
            //     title: headerFormatter('Min/Max Cost'),
            //     dataIndex: 'minCost',
            //     align: 'right',
            //     width:160,
            //     allowColumnList:["financial-data"],
            //     render: (minCost, row) =>
            //         <Fragment>
            //             {(minCost || row.maxCost) === "-" ? <UXSpin/> :<>
            //                 <Text>{!minCost || minCost === "-"? "NA":(CompUtil.formatMuMdPrice(minCost,true))}</Text>
            //                 {" / "}
            //                 <Text>{!row.maxCost || row.maxCost === "-"? "NA":(CompUtil.formatMuMdPrice(row.maxCost,true))}</Text>
            //             </>}
            //         </Fragment>
            // },
            // {
            //     title: headerFormatter('Mode Cost'),
            //     dataIndex: 'modeCost',
            //     align: 'right',
            //     width:160,
            //     allowColumnList:["financial-data"],
            //     sorter: (a, b) => a.modeCost - b.modeCost,
            //     render: (modeCost, row) =>
            //         <Text>
            //             {modeCost === "-" ? <UXSpin /> : (!modeCost || modeCost === "-"? "NA":(CompUtil.formatMuMdPrice(modeCost,true)))}
            //         </Text>,
            // },
            // {
            //     title: headerFormatter('IMU'),
            //     dataIndex: 'modeCost',
            //     align: 'right',
            //     allowColumnList:["financial-data"],
            //     sorter: (a, b) => a.modeCost - b.modeCost,
            //     render: (modeCost, row) =>
            //         <Text>
            //             {modeCost === "-" ? <UXSpin /> : (!modeCost || modeCost === "-"? "NA":('$' + CompUtil.formatPrice(modeCost)))}
            //         </Text>,
            // },
            // {
            //     title: headerFormatter('Gross margin'),
            //     dataIndex: 'modeCost',
            //     align: 'right',
            //     allowColumnList:["financial-data"],
            //     sorter: (a, b) => a.modeCost - b.modeCost,
            //     render: (modeCost, row) =>
            //         <Text>
            //             {modeCost === "-" ? <UXSpin /> : (!modeCost || modeCost === "-"? "NA":('$' + CompUtil.formatPrice(modeCost)))}
            //         </Text>,
            // },
            {
                title: headerFormatter('AUR'),
                dataIndex: 'aur',
                align: 'right',
                width: 160,
                sorter: (a, b) => ((a.aur && isFinite(a.aur))?a.aur:0) - ((b.aur && isFinite(b.aur))?b.aur:0),
                render: (aur, row) => <Text>{aur === "-" ? <UXSpin /> : (!aur || aur === "-"? "NA":('$'+ CompUtil.formatPrice(aur)))}</Text>
            },
            // {
            //     title: headerFormatter('Mode Common'),
            //     dataIndex: 'minCost',
            //     align: 'right',
            //     allowColumnList:["financial-data"],
            //     sorter: (a, b) => a.minCost - b.minCost,
            //     render: (minCost, row) =>
            //         <Text>
            //             {minCost === "-" ? <UXSpin /> : (!minCost || minCost === "-"? "NA":('$' + CompUtil.formatPrice(minCost)))}
            //         </Text>,
            // },

            buildCompetitorTableColumns('Low CPI',CompetitorUtil.getCompetitorId('Lowes'),'cpiData'),
            buildCompetitorTableColumns('Amz CPI',CompetitorUtil.getCompetitorId('Amazon'),'cpiData'),
            buildCompetitorTableColumns('Men CPI',CompetitorUtil.getCompetitorId('Menards'),'cpiData'),
            buildCompetitorTableColumns('F&D CPI',CompetitorUtil.getCompetitorId('Floor & Decor'),'cpiData'),
            buildCompetitorTableColumns('Wal CPI',CompetitorUtil.getCompetitorId('Walmart'),'cpiData'),
            buildCompetitorTableColumns('Amz Mkt CPI',CompetitorUtil.getCompetitorId('Amazon MKT'),'cpiData')


        ]
    }

    const CompetitiveData = (props) => {
        return (
            <Row align="end" gutter={[4,0]}>
                {props.cpiData.cpiDaily ? <>
                <Col>
                    <Text> {props.cpiData && props.cpiData.primaryCompetitor === 'Y' ?
                        <StarFilled style={{color: '#f96302', fontSize: '8px', lineHeight: '22px',}}/> : ''}</Text>
                </Col>
                <Col>
                    <Text className={cpiValueColorFormat(props.cpiData.cpiDaily)}>{props.cpiData.cpiDaily
                        ? CPIUtil.formatCPI(props.cpiData.cpiDaily) : ""}</Text>
                </Col>
                <Col>
                    <Text>{props.cpiData.cpiSalesCovDlyPercentage
                        ? CompUtil.formatPrice(props.cpiData.cpiSalesCovDlyPercentage) + '%' : ''}</Text>
                </Col>
                <Col>
                    <Text>{props.cpiData.cpiDaily ? '|' : ''}</Text>
                </Col>
                <Col>
                    <Text>{props.cpiData.cpiSalesCovDollarDlyDenom
                        ? CompUtil.formatMuMdPrice(props.cpiData.cpiSalesCovDollarDlyDenom, true) : ''}</Text>
                </Col>
                </>: "NA"}
            </Row>
        );
    };

    let totalCount =  props.inStoreSkuRowData.length;
    let isRemainder = totalCount%paginationObject.pageSize;
    totalCount = isRemainder?totalCount:totalCount+1;

    let title = props.messageType && props.messageType !== "-"?() => <Alert showIcon
                            message={"PaCMan worksheet download is unavailable for SKU lists with > 5 "+(props.messageType === "dcs"?"DCS's":"Vendors")}
                            type="warning"/>: ()=>{};
    return (<>
            <AdvancedTable
                tableClassName="all-sku-table multi-sku-table-title"
                columns={multiSkuTableColumns()}
                dataSource={props.inStoreSkuRowData}
                pagination = {{onChange:(page,pageSize)=>{
                        props.lastKey && Math.ceil(totalCount/pageSize)
                        === page? props.onNewPageRender(k=>setPaginationObject(k=>({...k,currentPage:page})),page):setPaginationObject(k=>({...k,currentPage:page}))
                    },
                    // total:props.lastKey?totalCount +1:totalCount,
                    current:paginationObject.currentPage,
                    pageSize:paginationObject.pageSize,
                    onShowSizeChange:(current, size)=>setPaginationObject(k=>({...k,currentPage:current,pageSize:size}))}}
                extraTableProps = {{rowKey: "skuNumber",scroll: { y: 400},title}}

            />

            {(vendorList !== null) ?
                <MultipleVendorDetectedModal
                    isOpen={(vendorList !== null)}
                    onClose={() => setVendorList(null)}
                    onVendorCardClick = {(vendorNumber,vendorName)=>{props.getAllSkusforDCSView("",vendorNumber,vendorName);}}
                    multiVendorList={vendorList}
                /> : null
            }
    </>


    );
};

export default InStoreMultiSkuTable;
