import React, {Fragment, useContext} from "react";
import {Dropdown, Menu, Space} from 'antd';
import {DownloadOutlined} from '@ant-design/icons';
import {trackEvent} from '../../Utils/mixpanel';
import SingleAndMultiSkuServices from '../../../services/SingleAndMultiSkuServices';
import {appendTimeToFileName, excelDownload} from '../../Utils/ExcelUtil';
import SkuContext from '../../../context/SkuContext';
import DCSUtil from '../../Utils/DCSUtil';
import "./ProductDownload.scss";
// import AlertUtil from '../../Utils/AlertUtil';
import {UXSpin} from '../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin';


const ProductDownload = (props) =>{

  const context = useContext(SkuContext);

  let type = props.isOnline?"ONLINE":"IN_STORE";
  let fileType = props.isOnline?"ONLINE":"CORE";

  const onNormalDownload = () => {

    context.updateShowDimmer(true);
    trackEvent("CLICKED_"+type+"_MULTI_SKU_PAGE_DOWNLOAD_BUTTON");

    SingleAndMultiSkuServices.downloadMultiSkuExcel(props.excelData(),"MULTI_SKU_"+fileType)
    .then(resp => {
      excelDownload(appendTimeToFileName("MULTI_SKU_"+fileType) + ".xlsx", resp.data);
    })
    .catch(err => console.log(err))
    .finally(()=> context.updateShowDimmer(false));

  };

  const onWorksheetDownload = () => {
    props.verifyAccessToken();
    context.updateShowDimmer(true);

    let multiSearchInput = props.multiSearchData.input?props.multiSearchData.input:{};
    let inputData = {
      "categoryCode": 1,
      "skuStatusList": [ 100, 200, 300, 400, 500, 600 ],
      "userId": props.userId

    };
    if(multiSearchInput.searchType === "VNDR" && !props.isFilterApplied){
      trackEvent("CLICK_INSTORE_PACMAN_WORKSHEET_BUTTON",{type:"VENDOR",sheetType:"RCCW"});
      let hierarchyList = [];
        [...props.distinctDCSSet].forEach(k=> {
          let dcsArray = k.split("-").map(k => Number.parseInt(k.trim()));
          let subDepartment = DCSUtil.getSubDept(context.subDeptDataMap,dcsArray[0],dcsArray[1]);
          hierarchyList.push({...inputData,
            hierarchyInputList: [
              {
                subDepartment,
                departmentNumber: dcsArray[0],
                classNumber: dcsArray[1],
                subClass: dcsArray[2]
              }],
            subDepartment,
            'skuSearchType': 'HIERARCHY',
            'onlyRetail': false,
            "vendors": props.multiVendorList === "-" ? {[multiSearchInput.vendorNumber]:multiSearchInput.vendorName}: props.multiVendorList.reduce((total,current) => ({...total,[current.vendorNumber]:current.vendorName}),{}),
          })
        });
        Promise.all(hierarchyList.map(k=>SingleAndMultiSkuServices.downloadSkuInquiryReport(k)
        .catch(err => {
          console.log(err); return false;
        }))).then(res=>{
          // if(res.some(k=>k === false)){
          //   AlertUtil.showAlert("error","Error",AlertUtil.getErrorMessage("downloading PaCMan Worksheet"))
          // }else {
            window.open(props.config.skuInquiryReportUrl+'/reportHistory', "_blank");
          // }
        }).finally(()=>context.updateShowDimmer(false))


    }else {
      if(multiSearchInput.searchType === "DCS" && !props.isFilterApplied){
        trackEvent("CLICK_INSTORE_PACMAN_WORKSHEET_BUTTON",{type:"DCS",sheetType:"RCW"});
        let subDepartment = DCSUtil.getSubDept(context.subDeptDataMap,multiSearchInput.department,multiSearchInput.classNumber);
        inputData = {...inputData, hierarchyInputList:[{
            subDepartment,
            "departmentNumber": multiSearchInput.department,
            "classNumber": multiSearchInput.classNumber,
            "subClass": multiSearchInput.subClassNumber
          }],
          subDepartment,
          "skuSearchType": "HIERARCHY",
          "onlyRetail": true


        }
      }
      else {
        trackEvent("CLICK_INSTORE_PACMAN_WORKSHEET_BUTTON",{type:"SKU",sheetType:"RCW"});
        let skuNumberList = props.skuObjectList.map(k=>k.skuNumber);
        inputData = {...inputData,...{
            skuNumberList,
            "skuSearchType": "SKU",
            // "vendors": props.multiVendorList.reduce((total,current) => ({...total,[current.vendorNumber]:current.vendorName}),{}),
            "onlyRetail": true

          }
        }
      }

      SingleAndMultiSkuServices.downloadSkuInquiryReport(inputData)
      .then(resp => {
        window.open(props.config.skuInquiryReportUrl+'/reportHistory', "_blank");
      })
      .catch(err => console.log(err))
      .finally(()=> context.updateShowDimmer(false));
    }

  };


  let isNormalDownloadOnly = props.isOnline || !props.isPacManUser || !!props.inStoreDcsVendorAlertType;
  let isUndetermined = props.inStoreDcsVendorAlertType === "-";
  const clickedValue = ({key}) =>{
    key === "normal" ? onNormalDownload() :onWorksheetDownload();
  }
  const menu =() => (

      <Menu onClick={clickedValue} >
            <Menu.Item className="spread-sheet-download" key="normal"> Spreadsheet</Menu.Item>
            {!isNormalDownloadOnly && <Menu.Item className="pacman-work-sheet-download" key="pacman" >PaCMan Worksheet </Menu.Item>}
      </Menu>
      );

  return(<Fragment>
    <Space size="middle">
       {isUndetermined ? <UXSpin/> :
            < Dropdown.Button
        overlay={menu()}
        disabled={props.disabled}
        type="text"
        ghost='true'
        block
        icon={<DownloadOutlined style={{fontSize: '20px', color: '#253238'}} />}
        /> }

    </Space>
  </Fragment>);
};

export default ProductDownload;
