import React, { Fragment } from 'react';
import { Row, Col, Typography } from 'antd';
import { formatNumberToCompact } from "../Utils/CommonUtil";
import CompUtil from "../Utils/CompUtil";
import {UXSpin} from "../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";

const { Text } = Typography;

const OnlineItemProperties = (props) => {
  const compUnitsPropertyValue = (currentYearValue, percentage, prefix) => {
    return (
        <Fragment>
          {currentYearValue && !isNaN(currentYearValue) &&
          <Col>
            <Text strong>{prefix}{formatNumberToCompact(currentYearValue)}</Text>
          </Col>}
          <Col>
            <Text strong>{props.compsAndUnitsFormatter(percentage)}</Text>
          </Col>
        </Fragment>);
  };
    const ItemProperty = (props) => {
        return (
            <Fragment>
                <Row gutter={[8, 0]}><Col><Text type="secondary">{props.name}</Text></Col></Row>
                <Row gutter={[8, 0]}>
                  {props.value}
                </Row>
            </Fragment>
        );
    };

    return (
        <Row gutter={[24,0]}>
            <Col>
                <Row gutter={[0,24]} style={{"marginBottom": "24px"}} >
                    <Col>
                        <ItemProperty name="Sales" value={compUnitsPropertyValue(props.totalThisYearSales, props.totalCompPercentage, "$")} />
                    </Col>
                </Row>
                {props.isSingleSku && !props.isOnline &&
                    <Row gutter={[0,24]} style={{"marginBottom": "24px"}} >
                        <Col>
                            <ItemProperty name="Stores Assorted" value={<Col><Text strong>{props.assortedStores?props.assortedStores:"-"}</Text></Col>} />
                        </Col>
                    </Row>
                }
            </Col>
            <Col>
              <Row gutter={[0,24]} style={{"marginBottom": "24px"}} >
                <Col>
                  <ItemProperty name="Units" value={compUnitsPropertyValue(props.totalThisYearUnits, props.totalUnitsPercentage, "")} />
                </Col>
              </Row>
                {props.isSingleSku && !props.isOnline &&
                    <Row gutter={[0,24]} style={{"marginBottom": "24px"}} >
                        <Col>
                            <Row gutter={[40,0]}>
                            <Col>
                              <ItemProperty
                                  name="Active Stores"
                                  value={<Col><Text strong>{props.activeStores ? props.activeStores : "-" }</Text></Col>} />
                            </Col>
                              <Col>
                                <ItemProperty
                                    name="Daily ISS%"
                                    value={(props.dailyISSData ? <Col><Text strong>{props.dailyISSData !== "-" ? `${CompUtil.formatPrice(props.dailyISSData)}%` : "-"}</Text></Col> : <UXSpin />)} />
                              </Col>
                            </Row>
                        </Col>
                  </Row>
                }
                {/*{props.isOnline && !props.isSingleSku && <Col>*/}
                    {/*    <ItemProperty name="On Hand" value={<Col><Text>{props.onHandQuantity}</Text></Col>} />*/}
                    {/*</Col>}*/}
            </Col>
        </Row>


    );
};

export default OnlineItemProperties;
