import React from 'react';
import {Typography} from 'antd';
import "./OnlineComponents.scss";
import AdvancedTable from "../GlobalComponents/AdvancedTable/AdvancedTable";
import MarkdownPromotionData from "./MarkdownPromotionData";


const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;

const customStringSorter=(a,b)=> {
    return (a ? a : "").localeCompare(b ? b : "");
};

const MarkdownPromotionTable = (props) => {

    const columns = [
        {
            title: headerFormatter('Name'),
            dataIndex: 'name',
            key: 'name',
            sorter: (a, b) =>  customStringSorter(a.name,b.name),
        },
        {
            title: headerFormatter('Type'),
            dataIndex: 'type',
            key: 'type',
            sorter: (a, b) =>  customStringSorter(a.type,b.type),
        },
        {
            title: headerFormatter('Start Date'),
            dataIndex: 'startDate',
            key: 'startDate',
            sorter: (a, b) =>  customStringSorter(a.startDate,b.startDate),

        },
        {
            title: headerFormatter('End Date'),
            dataIndex: 'endDate',
            key: 'endDate',
            sorter: (a, b) =>  customStringSorter(a.endDate,b.endDate),

        },
        {
            title: headerFormatter('Source'),
            dataIndex: 'source',
            key: 'source',
            sorter: (a, b) =>  customStringSorter(a.source,b.source),

        },
        {
            title: headerFormatter('Promo ID'),
            dataIndex: 'promoId',
            key: 'promoId',
            sorter: (a, b) => customStringSorter(a.promoId,b.promoId),

        },

    ];
    const data = MarkdownPromotionData;

    return (
        <AdvancedTable
            tableClassName="all-sku-table"
            columns={columns}
            dataSource={data}
            pagination = {{showSizeChanger:false,
                pageSize: 10}}
        />

    );
};

export default MarkdownPromotionTable;
