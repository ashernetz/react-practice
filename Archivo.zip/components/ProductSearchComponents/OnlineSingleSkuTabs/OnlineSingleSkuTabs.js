import React, {Fragment} from 'react';
import { Row, Col, Typography, Tabs } from 'antd';
import { Chart, Tooltip, Axis, Line, Legend,Point } from 'viser-react';
import "./OnlineSingleSkuTabs.scss";
import OnlineRetailCostTable from "../OnlineRetailCostTable";
import SalesPerformance from "../SalesPerformance"
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import CompUtil from "../../Utils/CompUtil";
import {trackEvent} from "../../Utils/mixpanel";
import DataConnectionIssue
    from "../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue";
import LocalizedPricingTable from "../LocalizedPricingTable";
//import MarkdownPromotionTable from "../MarkdownPromotionTable";

const { TabPane } = Tabs;
const { Text } = Typography;


const customDateFormatter = (inputMillis) => {
    let output = "";
    if (inputMillis) {
        let inputDate = new Date(inputMillis);
        output = inputDate.toString() === "Invalid Date" ? "" : inputDate.getMonth() + 1 + "/" + inputDate.getDate() + "/" + inputDate.getFullYear();
    }
    return output;
};



const label ={
    formatter : function formatter(val){
        return '$'+val;
    }}

const OnlineSingleSkuTabs = (props) => {


    function populateRetailCostGraphData() {
        let graphData = [];
        if (props.skuTimelineMap[props.skuNumber]) {
            let timelineData = [...props.skuTimelineMap[props.skuNumber]];
            timelineData.sort((a, b) => a.beginDate - b.beginDate);

            let latestRetailData = timelineData.filter(row => (row.displayDate.includes('No End') && row.retail)).pop();
            let latestCostData = timelineData.filter(row => (row.displayDate.includes('No End') && row.cost)).pop();

            let today = new Date();
            let homeEvent = "HOUSE EVENT";
            timelineData.forEach((data,index) => {
                let beginDate = new Date(data.beginDate);
                let runningDate = customDateFormatter(
                    data.beginDate ? data.beginDate : "");
                let runningEndDate = customDateFormatter(
                    data.endDate ? data.endDate : "");
                let dayAfterEndDate = new Date(data.endDate);
                dayAfterEndDate = dayAfterEndDate.setDate(dayAfterEndDate.getDate()+1);

                let runningDayAfterEndDate=customDateFormatter(
                    dayAfterEndDate ? dayAfterEndDate : "").toString();

                let dayBeforeStartDate = new Date(data.beginDate);
                dayBeforeStartDate = dayBeforeStartDate.setDate(dayBeforeStartDate.getDate()-1);

                let eventValue = (data.event.toLowerCase()).includes(homeEvent.toLowerCase());
                let previousRetailData = graphData.filter(row =>(row.type === 'Retail')).pop();

                if(data.retail || data.cost){
                    if(eventValue && previousRetailData && previousRetailData.value){
                        graphData.push({
                            type: "Retail",
                            date: customDateFormatter(
                                dayBeforeStartDate ? dayBeforeStartDate : ""),
                            value: previousRetailData.value,
                        });
                    }
                    let isPreviousDate = false;
                    let lastGraphData = graphData.filter(row => (data.retail ? row.type === 'Retail' :
                        row.type === 'Cost')).pop();
                    if(lastGraphData && beginDate.getTime() < new Date(lastGraphData.date).getTime())
                        isPreviousDate = true;

                    if(!isPreviousDate){
                        graphData.push({
                            type: data.retail ? "Retail" : "Cost",
                            date: runningDate,
                            value: data.retail ? (eventValue ? null : data.retail): data.cost,
                        });
                    }

                    if(!data.displayDate.includes('No End')) {
                        let sameBeginDateDataExist = timelineData.filter(each => (( data.retail ? each.retail : each.cost ) && (customDateFormatter(
                            each.beginDate ? each.beginDate : "") === runningEndDate || customDateFormatter(
                            each.beginDate ? each.beginDate : "") === runningDayAfterEndDate))).pop();
                        if(!sameBeginDateDataExist){
                            let dayAfterEndDateData = timelineData.filter(each => (( data.retail ? each.retail : each.cost ) &&
                                ( eventValue ? !each.event.toLowerCase().includes(homeEvent.toLowerCase()) : true) &&
                                (each.beginDate.getTime() <= new Date(dayAfterEndDate).getTime() &&
                                    each.endDate.getTime() >= new Date(dayAfterEndDate).getTime()))).pop();

                            if(dayAfterEndDateData && new Date(dayAfterEndDate).getTime() < today.getTime()){
                                graphData.push({
                                    type: data.retail ? "Retail" : "Cost",
                                    date: runningDayAfterEndDate,
                                    value: data.retail ? dayAfterEndDateData.retail : dayAfterEndDateData.cost,
                                });
                            }
                        }
                    }
                }

            });
            let lastHouseEvent = timelineData.filter(each => (each.retail &&
                each.event.toLowerCase().includes(homeEvent.toLowerCase()) &&
                (each.beginDate.getTime() <= today.getTime() && each.endDate.getTime() >= today.getTime()))).pop();

            let lastData = timelineData.pop();
            let lastGraphData = (graphData) ? graphData[graphData.length -1] : null;
            let lastEndDate = lastData?new Date(lastData.beginDate):null;

            if(latestRetailData && !lastHouseEvent && lastEndDate){
                graphData.push({
                    type: "Retail",
                    date: (lastEndDate.getTime() < today.getTime()) ? customDateFormatter(today) : lastGraphData.date,
                    value: latestRetailData.retail,
                });
            }

            if(latestCostData) {
                graphData.push({
                    type: "Cost",
                    date: (lastEndDate.getTime() < today.getTime()) ? customDateFormatter(today) : lastGraphData.date,
                    value: latestCostData.cost,
                });
            }
        }
        return graphData;
    }

    const toolTipRender = (title, items) => {

        let toolTip = '<div class="retail-cost-tooltip"><div class="g2-tooltip-title" style="margin-bottom: 4px;">' + title + '</div>';
        items.forEach(item => {
            let formattedValue = "$" + CompUtil.formatPrice(Number.parseFloat(item.value));
            toolTip = toolTip + '<li data-index={index}><span style="background-color:' + item.color + ';width:4px;height:4px;border-radius:50%;display:inline-block;margin-right:8px;"></span>' + item.name + ' : ' + formattedValue + '</li>'
        });
        toolTip = toolTip + '</div>';
        return toolTip;
    };

    const trackMixPanel=(tabKey)=>{
        let tabObject = {"1":"RETAIL_AND_COST_TAB","2":"SALES_PERFORMANCE_TAB"};
        trackEvent("CLICK_"+tabObject[tabKey]+"_ONLINE",{tabName:tabKey===1?"Retail & Cost":"Sales Performance"})

    };
    return (
        <Row>
            <Col span={24}>
                <Tabs
                    className="SSTabs"
                    size="large"
                    defaultActiveKey="1"
                    tabBarGutter={[16, 8]}
                    onTabClick={(key)=>trackMixPanel(key)}
                    onChange={(key)=>(key === '3' && props.storeList !== null && !props.storeList.length) ? props.onLocalizedTabClick(props.skuNumber) : null}>
                    <TabPane tab="Cost & Retail" key="1">
                        <Row gutter={[0, 24]}>
                            <Col span={24}>
                                <Text className="online-tab-header-text" >History</Text>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={24}>
                                {props.skuTimelineMap[props.skuNumber]?
                                    <Chart forceFit height={400} data={populateRetailCostGraphData()}
                                           scale={[{
                                               dataKey: 'date',
                                               tickCount: 10,
                                               nice:true
                                           }]}>
                                        <Tooltip htmlContent={toolTipRender} />
                                        <Axis dataKey="value" label={label}/>
                                        <Axis dataKey="date"/>
                                        <Legend useHtml={true}
                                                itemTpl= {`<li data-color="{originColor}" data-value="{originValue}" style="cursor: pointer;font-size: 14px;"><i style="width:10px;height:10px;border-radius:0% ;display:inline-block;margin-right:10px;background-color: {color};"></i><span class="g2-legend-text">{value}</span></li>`}/>
                                        <Line position="date*value" shape="hv"  color={['type', (value) => {
                                            if(value === "Retail") {
                                                return '#FA6304'
                                            }
                                            else if (value === "Cost") {
                                                return '#8400FF'
                                            }
                                        }]}/>
                                        <Point
                                            position="date*value"
                                            shape="circle"
                                            size={3}
                                            color={['type', (value) => (value === "Retail"?'#FA6304':'#8400FF')]}
                                        />
                                    </Chart>:<div style={{height:'400px'}}><UXSmallPulse/></div>}
                            </Col>
                        </Row>
                        <Row gutter={[0, 24]}>
                            <Col span={24}>
                                <OnlineRetailCostTable
                                    skuNumber= {props.skuNumber}
                                    timelineMap={props.skuTimelineMap}
                                    isPagination ={true}
                                    onVendorClick={(vendorNumber,vendorName)=>{props.onVendorClick(vendorNumber,vendorName);
                                        trackEvent("CLICKED_VENDOR_FROM_ONLINE_HISTORY_TABLE",{"vendor":vendorNumber})}}/>
                            </Col>
                        </Row>
                    </TabPane>

                    <TabPane tab="Sales Performance" key="2">
                        {props.salesPerformanceData.is5xx ?
                            <Fragment>
                                <Row><Col><Text className="online-tab-header-text" >Sales Performance</Text ></Col></Row>
                                <Row justify="center"><Col><DataConnectionIssue/></Col></Row>
                            </Fragment>:
                            <SalesPerformance salesPerformanceData={props.salesPerformanceData.data}/>}
                    </TabPane>
                    <TabPane tab="Localized Pricing" key="3">
                        <LocalizedPricingTable
                            singleSkuHeaderData = {props.singleSkuHeaderData}
                            storeList = {props.storeList}
                            skuNumber= {props.skuNumber}
                        />
                    </TabPane>
                    {/*<TabPane tab="Markdowns & Promotions" key="4">*/}
                    {/*    <Row gutter={[0,16]}>*/}
                    {/*        <Col span={24}>*/}
                    {/*            <Text className="inStore-tab-header-text">Markdowns & Promotions</Text>*/}
                    {/*        </Col>*/}
                    {/*    </Row>*/}
                    {/*    <Row gutter={[0,16]}>*/}
                    {/*        <Col span={24}>*/}
                    {/*            <MarkdownPromotionTable />*/}
                    {/*        </Col>*/}
                    {/*    </Row>*/}
                    {/*</TabPane>*/}
                </Tabs>
            </Col>
        </Row>
    );
};
export default OnlineSingleSkuTabs;
