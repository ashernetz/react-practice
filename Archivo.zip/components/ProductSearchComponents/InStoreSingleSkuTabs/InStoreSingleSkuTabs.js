import React, {Fragment, useContext} from 'react';
import { Row, Col, Typography, Table, Spin } from 'antd';
import "./InStoreSingleSkuTabs.scss";
import { Tabs } from 'antd';
import InStoreCompetitorTab from "../InStoreSingleSkuTabs/InStoreCompetitorTab/InStoreCompetitorTab"
import SalesPerformance from "../SalesPerformance"
import {trackEvent} from "../../Utils/mixpanel";
import DataConnectionIssue from "../../Pages/DashboardPage/DataConnectionIssue/DataConnectionIssue";
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import RegionallyAssortedDCTable from "../DCAssortmentTab/RegionallyAssortedDCTable";
//import DeliveryCoverages from "../DCAssortmentTab/DeliveryCoverages";

const { TabPane } = Tabs;
const { Text } = Typography;

const headerFormatter = (input) => <Text strong>{input}</Text>;


const InStoreSingleSkuTabs = (props) => {

    const zoneColumns = [
        {
            title: headerFormatter('Zone'),
            dataIndex: 'zoneName',
            sorter: (a, b) => a.zoneName.localeCompare(b.zoneName),
            render: (zoneName, row) => <Text >{zoneName ? zoneName : "-"}</Text>,
        },
        {
            title: headerFormatter('Stores'),
            dataIndex: 'storeCount',
            align: 'right',
            sorter: (a, b) => a.storeCount - b.storeCount,
            render: (storeCount, row) => <Text >{storeCount ? storeCount : "-"}</Text>,
        },
        {
            title: headerFormatter('Comp'),
            dataIndex: 'zoneCompPercentage',
            align: 'right',
            sorter: (a, b) => 
            {
                return (isNaN(a.zoneCompPercentage)?0:a.zoneCompPercentage) - (isNaN(b.zoneCompPercentage)?0:b.zoneCompPercentage);
            },
            render: (zoneCompPercentage, row) =>  zoneCompPercentage?props.compsAndUnitsFormatter(zoneCompPercentage,"end"):"-",
        },
        {
            title: headerFormatter('Units'),
            dataIndex: 'zoneUnitsPercentage',
            align: 'right',
            sorter: (a, b) =>
            {
                return (isNaN(a.zoneUnitsPercentage)?0:a.zoneUnitsPercentage) - (isNaN(b.zoneUnitsPercentage)?0:b.zoneUnitsPercentage);
            },
            render: (zoneUnitsPercentage, row) => zoneUnitsPercentage?props.compsAndUnitsFormatter(zoneUnitsPercentage,"end"):"-",
        },
    ] ;

    const trackMixPanel=(tabKey)=>{
        let tabObject = {"1":"PERFORMANCE_TAB","2":"COMPETITIVE_TAB"};
        //,"3":"DISCOUNTS_TAB"
        trackEvent("CLICK_"+tabObject[tabKey]+"_IN_STORE",{tabName:tabKey==="1"?"Performance": (tabKey ==="2"?"Competitive":"")})
    };

    return (        
        <Row>
            <Col span={24}>
                <Tabs
                    className="SSTabs"
                    size="large"
                    defaultActiveKey="1"
                    tabBarGutter={[32, 8]}
                    onTabClick={(key)=>trackMixPanel(key)}>
                    <TabPane tab="Performance" key="1">
                        {props.salesPerformanceData.is5xx ?
                            <Fragment>
                                <Row><Col><Text className="inStore-tab-header-text" >Sales Performance</Text ></Col></Row>
                                <Row className="in-store-dc-issue-svg" justify="center"><Col><DataConnectionIssue/></Col></Row>
                            </Fragment>:
                       <SalesPerformance salesPerformanceData={props.salesPerformanceData.data}/> }
                        <Row gutter={[0, 24]} style={{padding: "12px 0px"}}>
                            <Col span={24}><Text className="inStore-tab-header-text" >Zone Performance</Text ></Col>
                        </Row>
                        {props.zoneRowsPerformanceData.is5xx ?
                            <Row className="in-store-dc-issue-svg" justify="center"><Col><DataConnectionIssue/></Col></Row> :
                        <Row gutter={[0, 24]} style={{padding: "12px 0px"}}>
                            <Col span={24}>
                            <Spin indicator={<UXSmallPulse />} spinning={!props.zoneRowsPerformanceData.data}>
                                <Table
                                    rowKey="zoneId"
                                    columns={zoneColumns}
                                    dataSource={props.zoneRowsPerformanceData.data?props.zoneRowsPerformanceData.data.zonePerformanceData:[]}
                                    pagination={{pageSize: 10,showSizeChanger:false}}
                                />
                            </Spin>
                            </Col>
                        </Row>}
                    </TabPane>

                    <TabPane tab="Competitive" key="2">
                        {/*<Row>*/}
                        {/*    <Col>*/}
                        {/*        <Text className="inStore-tab-header-text">Competitive Pricing</Text>*/}
                        {/*    </Col>*/}
                        {/*</Row>*/}
                        {/*<Row gutter={[0, 24]}>*/}
                        {/*    <Col>*/}
                        {/*        <Text>A Comparison of </Text>*/}
                        {/*        <Text style={{textDecoration: "underline"}}>Most Common Price</Text>*/}
                        {/*        <Text> across competitors</Text>*/}
                        {/*    </Col>*/}
                        {/*</Row>*/}
                        <InStoreCompetitorTab singleSkuCPIData={props.singleSkuCPIData}/>
                    </TabPane>

                    <TabPane tab="DC Assortment" key="3">
                        <RegionallyAssortedDCTable />
                        {/*<DeliveryCoverages />*/}
                    </TabPane>

                    {/*<TabPane tab="Markdowns & Promotions" key="3">*/}
                    {/*    <Row gutter={[0,16]}>*/}
                    {/*        <Col span={24}>*/}
                    {/*            <Text className="inStore-tab-header-text">Markdowns & Promotions</Text>*/}
                    {/*        </Col>*/}
                    {/*    </Row>*/}
                    {/*    <Row gutter={[0,16]}>*/}
                    {/*        <Col span={24}>*/}
                    {/*            <MarkdownPromotionTable />*/}
                    {/*        </Col>*/}
                    {/*    </Row>*/}
                    {/*</TabPane>*/}

                    {/*<TabPane tab="Discounts" key="3">*/}
                    {/*    <Row gutter={[0, 24]}>*/}
                    {/*        <Col>*/}
                    {/*            <Text className="inStore-tab-header-text">Price Distribution</Text>*/}
                    {/*        </Col>*/}
                    {/*    </Row>                   */}
                    {/*   { props.salesMetricsData && props.salesMetricsData.length>0 ?*/}
                    {/*   <Row style={{marginLeft:"5%"}}>*/}
                    {/*       <Col span={24}><SalesWhiskerChart salesMetricsData={props.salesMetricsData}/></Col>*/}
                    {/*   </Row>:<Fragment>*/}
                    {/*   <Row justify="center" align="middle" type="flex">*/}
                    {/*     <Col className="noKVI">*/}
                    {/*       {SvgUtil.getNoData()}*/}
                    {/*     </Col>*/}
                    {/*   </Row>*/}
                    {/*   <Row justify="center" align="middle" type="flex" style={{paddingTop: "10px" }}>*/}
                    {/*     <Col>*/}
                    {/*       <Text className="no-kvi">*/}
                    {/*         No Price Distribution Data Available*/}
                    {/*       </Text>*/}
                    {/*     </Col>*/}
                    {/*   </Row>            */}
                    {/* </Fragment>}*/}
                    {/*</TabPane>*/}

                    {/* <TabPane tab="Line Structure" key="4">
                        <Row gutter={[0, 32]}>
                            <Col>
                                <Text className="inStore-tab-header-text">Line Structure</Text>
                            </Col>
                        </Row>

                    </TabPane> */}
                </Tabs>
            </Col>
        </Row>

    );
}
export default InStoreSingleSkuTabs;
