import React, { Fragment, useContext, useEffect, useState } from "react";
import {Row, Col, Typography, Spin, Badge, Space} from 'antd';
import "./InStoreCompetitorTab.scss";
import CompetitorUtil from "../../../Utils/CompetitorUtil";
import SkuContext from "../../../../context/SkuContext";
import CompUtil from "../../../Utils/CompUtil";
import SvgUtil from "../../../Utils/SvgUtil";
import UXSmallPulse from "../../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import NoSkuImage from "../../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import PriceDataServices from '../../../../services/PriceDataServices';
import PriceHistoryChart from '../../../GlobalComponents/PriceHistoryChart/PriceHistoryChart';
import moment from 'moment';
import CompetitorComparisonModal
  from '../../../CompetitorComparisonModal/CompetitorComparisonModal';
import {trackEvent} from "../../../Utils/mixpanel";

const { Text } = Typography;

// const cpiValueColorFormat = (value) =>{
//   return value ?(value < 1 ? "competitive-cpi-color-green" : "competitive-cpi-color-red"):"";
// };

const InStoreCompetitorTab = (props) => {
  const context = useContext(SkuContext);
  const [competitorData, setCompetitorData] = useState("");
  const [competitorPriceHistory, setCompetitorPriceHistory] = useState([]);
  const [loadingCompPriceHistory, toggleLoadingCompPriceHistory] = useState();
  const [noPriceHistory, setNoPriceHistory] = useState(true);
  const [comparisonModalData,setComparisonModalData] = useState();

  useEffect(() => {
    formCompetitorDetailData();
  }, [context.competitorData, context.skuData.mostCommonRetails, props.singleSkuCPIData]);

  function fetchCompetitorPriceHistory(numberOfMonths) {
    toggleLoadingCompPriceHistory(true);
    let compId, startDate, endDate;
    if (numberOfMonths) {
      startDate = moment().subtract(numberOfMonths, "months").format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    }
    PriceDataServices.getCompetitorSkuLevelPriceHistory(context.skuNumber, compId, startDate, endDate).then(response => {
      if(response.data && response.data.length > 0){
        response.data.forEach(row =>{
          row['priceHistory'] = row['priceHistory'].filter((history) => (CompetitorUtil.isCompetitorAllowed(history.competitorId)));
          if(row['priceHistory'].filter((history) => (history.scaledPricePennies)).length > 0)
            setNoPriceHistory(false);
        })
      }
      setCompetitorPriceHistory(response.data);
    }).catch(e => {
      console.log(e);
    }).finally(() => {
      toggleLoadingCompPriceHistory(false);
    })
  }

  function formCompetitorDetailData() {
    if (context.competitorData.isLoaded === false) {
      setCompetitorData([]);
    }
    if (
      context.competitorData.aggregatedDataMap &&
      context.skuData.mostCommonRetails &&
      context.competitorData.isLoaded === true
    ) {
      let thdSkuPrice = Number.parseFloat(context.skuData.mostCommonRetails[0]);
      let resultantData = [];
      Object.values(context.competitorData.aggregatedDataMap).forEach(
        (competitor) => {
          competitor.inStoreCompetitorTabDetails.forEach((eachSku) => {
            resultantData.push({
              skuNumber: eachSku.skuNumber,
              skuDescription: eachSku.skuDescription,
              skuImageUrl: eachSku.skuImageUrl
                ? eachSku.skuImageUrl
                : NoSkuImage,
              id: competitor.competitorId,
              name: competitor.competitorName,
              avgPrice: eachSku.mostCommonRetail,
              ...CompetitorUtil.competitorPriceDifferenceData(
                eachSku.mostCommonRetail,
                thdSkuPrice
              ),
              //cardShadeClassName: (props.singleSkuCPIData && props.singleSkuCPIData[competitor.competitorId] !== "-") ?CPIUtil.findCPIColor(props.singleSkuCPIData[competitor.competitorId].cpiDaily):"",
              cpiData:props.singleSkuCPIData? props.singleSkuCPIData[competitor.competitorId]: null
            });
          });
        }
      );

      const sortedCompetitors = CompetitorUtil.sortCompetitors(resultantData);

      setCompetitorData(sortedCompetitors);
    }
  }

  const mixPanel =  ( inputData ) => {
    trackEvent("CLICKED_COMPETITIVE_PRICE_TO_OPEN_COMPARISION_MODAL", {
      'THD_SKU':context.skuData.sku,
      'THD_PRICE': context.skuData.mostCommonRetails,
      'COMPETITIVE_ID': inputData.id,
      'COMPTITIVE_NAME': inputData.name,
      'COMPETITIVE_SKU': inputData.skuNumber,
      'COMPETITIVE_PRICING': inputData.avgPrice,
      'PRICE_DIFFERENCE': CompUtil.formatPrice(inputData.priceDifference),
      ACTION: origin,
    });
  }
  const CompetitiveCardComponent = ({ inputData }) => {
    return (
      <Row align={"middle"} justify="space-between" gutter={[0, 0]} onClick={()=>{setComparisonModalData(inputData);mixPanel(inputData)}}>
        <Col span={3} >{CompetitorUtil.getCompetitorLogoSvg(inputData.id)}</Col>
        <Col span={3} style={{ textAlign: "center" }}>
          <img
            className="competitive-sku-image"
            src={inputData.skuImageUrl}
            alt="sku"
          />
        </Col>
        <Col span={12} >
          <Row >
            {/*<Col><Text className="competitive-vendor-name">DEWALT</Text></Col>*/}
            <Col>
              <Text className="competitive-sku-number">
                SKU {inputData.skuNumber}
              </Text>
            </Col>
          </Row>
          <Row>
            <Col>
              <Text strong className="competitive-description">
                {inputData.skuDescription}
              </Text>
            </Col>
          </Row>
        </Col>
        <Col span={6}><div></div></Col>
        {/*<Col span={6}>*/}
        {/*  <Row>*/}
        {/*    <Col>*/}
        {/*      /!*<Row justify="flex-end">*!/*/}
        {/*      /!*  <Col>*!/*/}
        {/*      /!*    <Text className="competitive-pricing">*!/*/}
        {/*      /!*      ${CompUtil.formatPrice(inputData.avgPrice)}*!/*/}
        {/*      /!*    </Text>*!/*/}
        {/*      /!*  </Col>*!/*/}
        {/*      /!*</Row>*!/*/}
        {/*      <Row >*/}
        {/*        <Col offset={2} span={22}>*/}
        {/*          <Text className="cpi-text-heading">CPI</Text>*/}
        {/*        </Col>*/}
        {/*      </Row>*/}
        {/*      {inputData.cpiData ? ( inputData.cpiData === "-" ? <Text className="cpi-sales-coverage">NA</Text> :<>*/}
        {/*      <Row align="middle" justify="start" >*/}
        {/*        <Col span={2}>*/}
        {/*          {inputData.cpiData && inputData.cpiData !=="-" && inputData.cpiData.primaryCompetitor === "Y"?*/}
        {/*              <Badge count={<StarFilled style={{ color: '#f96302',fontSize:'12px',paddingBottom:'2px' }} />}  />:""}*/}
        {/*        </Col>*/}
        {/*        <Col span={22}>*/}
        {/*          <Text className={cpiValueColorFormat(inputData.cpiData.cpiDaily)}>*/}
        {/*            {(inputData.cpiData.cpiDaily)?CPIUtil.formatCPI(inputData.cpiData.cpiDaily):<Text className="cpi-dailiy-not-avai">NA</Text>}*/}
        {/*          </Text>*/}
        {/*        </Col>*/}
        {/*      </Row >*/}
        {/*        <Row align="middle" >*/}
        {/*          <Col offset={2} span={22}>*/}
        {/*            <Space>*/}
        {/*              <Text className="cpi-sales-coverage">*/}
        {/*                {(inputData.cpiData.cpiSalesCovDlyPercentage)?CompUtil.formatPrice(inputData.cpiData.cpiSalesCovDlyPercentage)+'%':"NA"}*/}
        {/*              </Text>*/}
        {/*              <Text className="cpi-sales-divider">{"|"}</Text>*/}
        {/*              <Text className="cpi-sales-coverage">*/}
        {/*                {(inputData.cpiData.cpiSalesCovDollarDlyDenom) ?*/}
        {/*                    CompUtil.formatMuMdPrice(inputData.cpiData.cpiSalesCovDollarDlyDenom,true):"NA"}*/}
        {/*              </Text>*/}
        {/*            </Space>*/}

        {/*          </Col>*/}
        {/*        </Row>*/}
        {/*      </>):<UXSpin/>}*/}

        {/*      /!*<Row justify="flex-end">*!/*/}
        {/*      /!*  <Col>*!/*/}
        {/*      /!*    <Text*!/*/}
        {/*      /!*      className={*!/*/}
        {/*      /!*        "competitive-price competitive-color" +*!/*/}
        {/*      /!*        inputData.cardShadeClassName*!/*/}
        {/*      /!*      }*!/*/}
        {/*      /!*    >*!/*/}
        {/*      /!*      {inputData.priceDifferenceText === "Difference"*!/*/}
        {/*      /!*        ? "Same Price"*!/*/}
        {/*      /!*        : "$ " +*!/*/}
        {/*      /!*          CompUtil.formatPrice(inputData.priceDifference) +*!/*/}
        {/*      /!*          " " +*!/*/}
        {/*      /!*          inputData.priceDifferenceText}*!/*/}
        {/*      /!*    </Text>*!/*/}
        {/*      /!*  </Col>*!/*/}
        {/*      /!*</Row>*!/*/}
        {/*    </Col>*/}
        {/*  </Row>*/}
        {/*</Col>*/}
      </Row>
    );
  };

  const compareDateFormat = (input)=>{
    let dataArray = input.split("/");
    return dataArray[2]+dataArray[0]+dataArray[1];
  }

  let thdHistoryMap = context.skuPriceChangeHistoryMap.thdHistoryMap;
  let thdPriceHistory = (thdHistoryMap && Object.keys(thdHistoryMap).sort((a,b)=>compareDateFormat(a)-compareDateFormat(b)).map(k => ({changeDate: k, retail: thdHistoryMap[k]}))) || [];
  let startDate = moment().subtract(3, "months").format("MM/DD/YYYY");

  if(context.skuData.mostCommonRetails && thdPriceHistory.length == 0 && Object.keys(context.skuPriceChangeHistoryMap.storeHistoryMap).length){
    thdPriceHistory.push({changeDate:startDate,retail:Number.parseFloat(context.skuData.mostCommonRetails[0])});
  }

  return (
    <Fragment><Row>
      <Col span={24}>
        <Row>
          <Col span={24}>
            {
              competitorData && competitorData.length > 0 ? (
                <Fragment>
                  {competitorData.map((data,key) => (
                    <Row
                      key={key+data.id}
                      className="competitive-ant-row"
                    >
                      <Col span={24}>
                        <CompetitiveCardComponent inputData={data} />
                      </Col>
                    </Row>
                  ))}
                </Fragment>
              ) : (
                <Fragment>
                  <Spin indicator={<UXSmallPulse />} spinning={!competitorData}>
                    <Row justify="center" align="middle" type="flex">
                      <Col className="noKVI">{SvgUtil.getNoData()}</Col>
                    </Row>
                    <Row
                      justify="center"
                      align="middle"
                      type="flex"
                      style={{ paddingTop: "10px" }}
                    >
                      <Col>
                        <Text className="no-kvi">No Competitor Data Available</Text>
                      </Col>
                    </Row>
                  </Spin>
                </Fragment>
              )
            }
          </Col>
        </Row>
        <Row>
          <Col span={24} style={{height: "400px"}}>
            <PriceHistoryChart
              competitorPriceHistory={competitorPriceHistory}
              thdStorePriceHistory={thdPriceHistory}
              fetchCompetitorPriceHistory={fetchCompetitorPriceHistory}
              headerTitle={"Competitive History"}
              isLoading={(loadingCompPriceHistory || !thdHistoryMap) ? "Y":"N"}
              isNoData={((loadingCompPriceHistory === false && noPriceHistory) && !thdPriceHistory.length) ? "Y":"N" }
            />
          </Col>
        </Row>
      </Col>
    </Row>
      {comparisonModalData && <CompetitorComparisonModal
        isOffside={false}
        onClose={()=>setComparisonModalData(null)}
        offsideComparisonData={{
          skuImage: context.skuImageUrl,
          skuDesc: context.skuData.skuDescription,
          SKU_NBR: context.skuData.sku,
          competitorId: comparisonModalData.id,
          competitorPrice:comparisonModalData.avgPrice,
          THD_PRICE: Number.parseFloat(context.skuData.mostCommonRetails[0]),
        }}
        loadedCompetitorApiData = {{ skuImage: comparisonModalData.skuImageUrl,
          skuDesc: comparisonModalData.skuDescription,
          skuNumber: comparisonModalData.skuNumber}}
        loadedCompetitorZoneData={context.competitorZonePriceData[comparisonModalData.id]}
        loadedThdZoneStoreData={{
          storeRetailObject: context.skuData.storeRetailMap,
          zoneDetails: context.skuData.zoneDetails,
        }}/>}
    </Fragment>
  )
  
  
};
export default InStoreCompetitorTab;
