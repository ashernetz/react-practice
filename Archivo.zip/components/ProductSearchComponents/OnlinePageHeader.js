import React from 'react';
import {PageHeader, Row, Col } from 'antd';
import "./OnlineComponents.scss";
import HeaderCrumbs from "../GlobalComponents/HeaderCrumbs/HeaderCrumbs";
//const {Text}=Typography;

const OnlinePageHeader = (props) => {

    return (
        <PageHeader ghost={false} className="online-page-header-msp">
          <Row align="middle" justify="space-between">
            <Col>
              <HeaderCrumbs headerData={props.headerData} backArrowClick={props.backArrowClick}/>
            </Col>
            <Col>
              <Row gutter={[0,32]}  align="middle" style={{margin:'0px'}}>
                <Col>
                  {props.downloadOption}
                </Col>
                <Col style={{paddingLeft:'20px'}}>
                  {props.multiSkuFilter}
                </Col>
              </Row>
            </Col>
          </Row>
        </PageHeader>
    );
};

export default OnlinePageHeader;
