import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import logo from './MPulseLogo.png';
import { UXDimmer } from "../GlobalComponents/GlobalReactComponents/UXComponents/UXDimmer";
import SkuContext from "../../context/SkuContext";
import { UserOutlined } from '@ant-design/icons';
import { Layout, Button, Dropdown, Menu, Col, Row, Modal} from 'antd';
import './MainHeader.scss';
import ProfileLoader from "../ProfileLoader/ProfileLoader"
import DCSUtil from "../Utils/DCSUtil";
import FavoritesMenu from "./Favorites/FavoriteMenu";
import SearchBox from "./SearchBox/SearchBox";
import {trackEvent} from '../Utils/mixpanel';
import AppCenter from "./AppCenter/AppCenter";
import NotificationComponent from "./NotificationComponent/NotificationComponent";
import SvgUtil from '../Utils/SvgUtil';

const { Header } = Layout;
const { confirm } = Modal;

export default class MainHeader extends Component {

  static contextType = SkuContext;

  constructor(props) {
    super(props);
    this.name = "Mpulse";
  }

  componentDidMount() {
    this.props.zoneStateDefaultCopy({"updateShowDimmer":this.context.updateShowDimmer})
  }

  handleTabChange = (e) => {
    trackEvent("CLICKED_MAIN_HEADER_TAB", {"tab": e.key});
    if(this.props.headerData.activeTab !== e.key) {

      this.props.resetDefaultState();
      let url = '/';
      let activeTab = "workspace";
      if (e.key === 'zone') {
        url = '/ZoneControl';
        activeTab = "zone";
        this.context.updateShowDimmer(true);
      }
      //this.context.updateShowDimmer(true);
      this.props.updateHeaderData({url, activeTab});
    }
  };

  showConfirm = () => {
    confirm({
      title: 'Remove from your favorites?',
      content: 'Removing this from your favorites list will not allow you to access it as a favorite again until its manually added back.',
      width: 376,
      height: 473,
      onOk() { },
      onCancel() { },
      okText: 'Yes',
      cancelText: 'No'
    });
  }

  render() {
    let userName = this.context.profileData.firstName ? this.context.profileData.firstName.charAt(0).toUpperCase() + this.context.profileData.firstName.toLowerCase().slice(1)
        + ' ' + this.context.profileData.lastName.charAt(0).toUpperCase() + this.context.profileData.lastName.toLowerCase().slice(1) : '';
    let initials = this.context.profileData.firstName ? this.context.profileData.firstName.substring(0, 1) + this.context.profileData.lastName.substring(0, 1) : '';
    let subClassName = DCSUtil.getHierarchyName(this.context.dcsDataMap, this.context.profileData.subClassDetails);
    let title = this.context.profileData.title + " - " + subClassName;
    let menu = (
        <Menu>
          <Menu.Item className="profileDDUserArea" onClick={() => {this.props.toggleHeaderDropdownDimmer(false);this.props.updateHeaderData({ isEditProfileOpen: true });}}>
            <Row id="user-item-row"><Col span={6}>
              <div className="user-badge">{initials ? initials : ''}</div>
            </Col>
            <Col span={18}>
              <div className="menuItemCol">
                <span className="profileDDName">{userName ? userName : 'Name Placeholder'}</span>
                <span className="profileDDTitle">{title}</span><br />
                {/* <Text>Role Placeholder</Text> */}
              </div>
            </Col></Row>
          </Menu.Item>
          <Menu.Divider />
          <Menu.Item onClick={() => {this.props.toggleHeaderDropdownDimmer(false);this.props.updateHeaderData({ isEditProfileOpen: true });}}>
            <i style={{ float: "left" }} className="material-icons">person</i><span className="profileItem">View Profile</span>
          </Menu.Item>
          <Menu.Item  onClick={() => {
            trackEvent("MPULSE_CHANGELOG");
            this.props.toggleHeaderDropdownDimmer(false);
            window.open("https://team.homedepot.com/:b:/s/Merch_Solutions_Product/Ea6Js7mQ1LRLgqrzf35oOpYBV-FtizCnP1i6ZsYy8OF_aQ");
          }}>
            <span style={{ float: "left" }}>{SvgUtil.getAddChangeLogSvg()}</span>
            <span className="profileItem">Changelog</span>
          </Menu.Item>
          {/* <Menu.Item>
                    <i style={{float:"left"}} className="material-icons">live_help</i><a className="profileItem">Support</a>
                </Menu.Item>
                <Menu.Item>
                    <i style={{float:"left"}} className="material-icons">assignment</i><a className="profileItem">Changelog</a>
                </Menu.Item>  */}
          <Menu.Item onClick={()=>{this.props.toggleHeaderDropdownDimmer(false);this.props.logout();}}>
            <i style={{ float: "left" }} className="material-icons">power_settings_new</i><span className="profileItem">Logout</span>
          </Menu.Item>
        </Menu>
    );

    return (
        <Fragment>
          {
            this.props.loginState === 'NOT_ALLOW' ? null :
              <Layout>
                <ProfileLoader
                    updateHeaderData={this.props.updateHeaderData}
                    user={this.props.userProfile}
                    isEditProfileOpen={this.props.headerData.isEditProfileOpen}
                    // loadDcsDetails = {this.props.loadDcsDetails}
                />
                <Header className="mainHead">
                  <Row justify="space-between" align="middle">
                    <Col span={9}>
                      <Row align="middle">
                        {/* <Col id="menu-icon-col-wrapper">
                          <MenuOutlined 
                            id="primary-header-menu-icon"
                            onClick={this.props.toggleNavMenuOpen}
                          />
                        </Col> */}
                        <Col>
                          <a href="/"><img src={logo} alt="MPulse" className="logo" /></a>
                        </Col>
                      </Row>
                    </Col>
                    <Col span={6}>
                      {this.props.isHideFeature ? "" :
                          <SearchBox
                              singleItemInquiry={this.props.singleItemInquiry}
                              multiItemInquiry={this.props.multiItemInquiry}
                              diverseMultiSearch={this.props.diverseMultiSearch}
                          />
                      }
                    </Col>
                    {!this.props.empty && (
                      <Col span={9} id="header-menu-icons">
                        <Row justify="end" align="middle">
                          {this.props.isHideFeature ? "" :
                              <>
                          <Col className="rightMenuItems">
                            <FavoritesMenu
                                userId={this.props.userProfile.userId}
                                skuSearch = {(sku)=>this.props.singleItemInquiry(sku, "OPENED_FAVORITES_LIST")}
                                toggleHeaderDropdownDimmer={this.props.toggleHeaderDropdownDimmer}
                            />
                          </Col>
                          <Col className="rightMenuItems">
                            <NotificationComponent userProfile={this.props.userProfile} />
                          </Col>
                          <Col className="rightMenuItems">
                            <AppCenter  toggleHeaderDropdownDimmer={this.props.toggleHeaderDropdownDimmer}/>
                          </Col>
                        </>}
                          <Col>
                            <Dropdown
                                onOpenChange={(flag)=>this.props.toggleHeaderDropdownDimmer(flag)}
                              overlay={menu}
                              trigger={['click']}
                              getPopupContainer={trigger => trigger.parentNode}
                            >
                              <Button id="user-menu-icon" type="primary" shape="circle" icon={<UserOutlined />} size='large' />
                            </Dropdown>
                          </Col>
                        </Row>
                      </Col>
                      )
                    }
                </Row>
              </Header>
            </Layout>
        }
        <UXDimmer showDimmer={this.context.showDimmer} />
      </Fragment>
    );
  }
}

MainHeader.propTypes = {
  logout: PropTypes.func,
  empty: PropTypes.bool.isRequired,
  userProfile: PropTypes.object
};
