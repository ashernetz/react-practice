import React from 'react';
import { AlertNotificationBell, ConfigProvider } from 'merchexp_alert_ui';

const NotificationComponent = (props) => {
  const { ldap, accessToken } = props.userProfile;

  if (!ldap) {
    return null;
  }

  return (
    <ConfigProvider ldap={ldap.toUpperCase()} pingfedToken={accessToken}>
      <AlertNotificationBell fillColor="#ffffff" />
    </ConfigProvider>
  );
};
export default NotificationComponent;
