import React  from "react";
import {Col, Row,Typography} from "antd";
import MarkUpOpportunity from "../../../images/MarkUpOpportunity.svg";
import MarkDownOpportunity from "../../../images/MarkDownOpportunity.svg";
import NoSkuImage from "../../SkuDetailComponent/SkuCard/no-sku-image.jpg";
import "./NotificationSKUCard.scss"

const {Text} = Typography;

const getDateDifferenceInWords = (inputDate) => {

  const MILLISECONDS_PER_DAY = 1000 * 60 * 60 * 24;
  let dateInWordsObject = {0: "Today", 1: "Yesterday"};
  let currentDateInMillis = new Date().setHours(0, 0, 0, 0);
  let inputDateInMillis = new Date(inputDate).setHours(0, 0, 0, 0);
  let dayDifference = Math.ceil(
      (currentDateInMillis - inputDateInMillis) / MILLISECONDS_PER_DAY);
  return dateInWordsObject[dayDifference] || dayDifference + " days ago";

};

const NotificationSKUCard = (props)=>{

 

  let markUpMarkDown = {
    svgSrc: props.skuDetails.MUMD_IND==="MU"?MarkUpOpportunity:MarkDownOpportunity,
    value:props.skuDetails.MUMD_IND==="MU"?"Markup":"Markdown",
    textColor:props.skuDetails.MUMD_IND==="MU"?"green":"red"


  };

  return (
      <Row key={props.skuDetails.SKU_NBR}>

        <Col span={6}  style={{ textAlign: "center" }} >
          <img
              className="notification-sku-image"
              src={props.skuDetails.SKU_IMAGE_URL?props.skuDetails.SKU_IMAGE_URL:NoSkuImage}
              alt="sku"
          />
        </Col>
        <Col span={17} offset={1}>
          <Row justify="space-between">
            <Col><Text type="secondary" className="notification-card-vendor-name">{props.skuDetails.SKU_VENDOR}</Text></Col>
            <Col><Text type="secondary" className="notification-card-sku-number">SKU:{props.skuDetails.SKU_NBR}</Text></Col>
          </Row>
          <Row>
            <Col  span={23} className="notificationOVF"><Text strong className="notification-card-sku-desc">{props.skuDetails.SKU_DESCRIPTION}</Text></Col>
          </Row>
          <Row gutter={[8,0]}>
            <Col><img className="markup-markdown-image-size" alt="high-low" src={markUpMarkDown.svgSrc} /></Col>
            <Col><Text className={"notification-mumd-"+markUpMarkDown.textColor}>{markUpMarkDown.value}</Text></Col>
            <Col><Text className="notification-card-opportunity">Opportunity</Text></Col>
          </Row>
          <Row>
            <Col span={24}>
              <Text type="secondary" className="notification-card-day-status">{getDateDifferenceInWords(props.skuDetails.PREDICTION_DATE)}</Text>
            </Col>
          </Row>

        </Col>

      </Row>

  );
};

export default NotificationSKUCard;