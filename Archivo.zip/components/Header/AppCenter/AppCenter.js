import React,{useState} from "react";
import {Menu, Col, Row, Divider, Typography, Dropdown, Card } from 'antd';
import './AppCenter.scss';
import Delivery from "../../../images/Delivery.svg";
import MPulseAppCenter from "../../../images/MPulseAppCenter.svg";
import PacMan from "../../../images/PacMan.svg";
import Home from "../../../images/PacManHome.svg";
import Inquiry from "../../../images/InquiryLogo.svg";
import Online from "../../../images/Online.svg";
import MyMatch from "../../../images/MyMatch.svg";
import Apps from "../../../images/Apps.svg";
import ClearanceIcon from "../../../images/ClearanceIcon.png";
import PriceEngine from "../../../images/PELogo.svg"
import {trackEvent} from "../../Utils/mixpanel";
import Reports from "../../../images/Reports_Icon.svg"

const { Text } = Typography;

const AppCenter = (props) => {
  const [isVisible, setIsVisible] = useState(false);

  const  EachAppSection = (appCompProps) => {
      return (<Col span={12}>
      <Card bordered={false} className="app-link-card" onClick={()=>{setIsVisible(false);props.toggleHeaderDropdownDimmer(false);mixPanel(appCompProps)}}>
        <a target="_blank" rel="noopener noreferrer"  href={appCompProps.appUrl}>
          <Row justify = "center"><Col><img className={appCompProps.imgClassName?appCompProps.imgClassName:"image-size"} alt="app-link" src={appCompProps.appImage} /></Col></Row>
          <Row justify = "center"><Col className="app-name-text" ><Text>{appCompProps.appName} </Text></Col></Row>

        </a>      </Card>
      </Col>);

  };

  const mixPanel = (appCompProps) => {
      trackEvent("CLICKED_APP_FROM_APP_CENTER_MENU", {
          'CLICKED_APP_NAME':appCompProps.appName,
          'CLICKED_APP_URL': appCompProps.appUrl,
          ACTION: origin,
      });
  };

  const AppCenterOverlay = () => {
    return (
        <Menu selectable={false} className="apps-menu">
          <Menu.Item className="apps-menu-item">
            {/* <Row type="flex" justify="space-around" align="middle" gutter={[0,24]}>
                <Col>
                  <Input className="appmenu-input-size" placeholder="Find an App" allowClear />
                </Col>
              </Row> */}
            <Row align="middle">
              <Col span={24}>
                <Divider orientation="left">Strategy</Divider>
              </Col>
            </Row>
            <Row justify="space-around" align="middle" gutter={[8, 0]}>
              <EachAppSection appImage={MPulseAppCenter}
                              appUrl="https://mpulse.apps.homedepot.com/"
                              appName="MPulse"/>
              <EachAppSection appImage={Inquiry}
                              appUrl="https://online-ui.apps.homedepot.com/newInquiry"
                              appName="Inquiry"/>
            </Row>

            <Row justify="space-around" align="middle" gutter={[8, 0]}>
              <EachAppSection appImage={MyMatch}
                              appUrl="https://mymatch.blacklocus.com"
                              appName="myMatch"/>
              <EachAppSection appImage={ClearanceIcon}
                              appUrl="https://console.cloud.google.com/storage/browser/hd-pricing-prod-clearance-pricing/content-grid-data/Forecast"
                              appName="Clearance"
                              imgClassName="clearance-image-size"/>
            </Row>
            <Row justify="start" align="middle" gutter={[8, 0]}>
              <EachAppSection appImage={PriceEngine}
                              appUrl="https://de-assistor-ui.apps.homedepot.com/request"
                              appName="PriceEngine"
                              imgClassName="price-engine-image-size"/>
              <EachAppSection appImage={Reports} appUrl="/reports"
                              appName="Reports"
                              imgClassName="reports-image-size"/>
            </Row>
            <Row align="middle">
              <Col span={24}>
                <Divider orientation="left">Execution</Divider>
              </Col>
            </Row>
            <Row justify="space-around" align="middle" gutter={[8, 0]}>
              <EachAppSection appImage={Online}
                              appUrl="https://online-ui.apps.homedepot.com/"
                              appName="Online"/>
              <EachAppSection appImage={PacMan}
                              appUrl="https://pacman.apps.homedepot.com"
                              appName="Core"/>
            </Row>
            <Row justify="space-around" align="middle" gutter={[8, 8]}>
              <EachAppSection appImage={Home}
                              appUrl="http://homeservicesuigreen.apps.homedepot.com/login"
                              appName="Home Service"/>
              <EachAppSection appImage={Delivery}
                              appUrl="https://deliverypricingui.apps.homedepot.com/"
                              appName="Delivery"/>
            </Row>
          </Menu.Item>
        </Menu>
    )};
    return(<Dropdown
            onOpenChange={(flag)=>{setIsVisible(flag);props.toggleHeaderDropdownDimmer(flag)}}
            overlay={<AppCenterOverlay/>}
            open ={isVisible}
            trigger={['click']}
            getPopupContainer={trigger => trigger.parentNode}>
          <img
              className="appCenterMenu"
              id="apps-center-icon"
              height={30}
              src={Apps}
              alt={"app-center"}
          />
        </Dropdown>

      );

  
};

export default AppCenter;
