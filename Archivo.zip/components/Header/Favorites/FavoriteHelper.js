import  { Component } from 'react';
import PriceDataServices from "../../../services/PriceDataServices";
import {message} from "antd";
import AlertUtil from "../../Utils/AlertUtil";

export default class FavoriteHelper extends Component {
  static addOrRemoveFavoriteSku (isRemoveFlag,userId,skuNumber,skuContext,onSuccess) {
    PriceDataServices.addOrRemoveFavoriteSku(skuNumber,
        isRemoveFlag,userId).then(res => {
            let favSkuData = res.data;
            if(skuNumber === skuContext.skuNumber){
              skuContext.updateStateFields({isFavorite: !skuContext.isFavorite});
            }

            //let profileData =  { ...skuContext.profileData};
            let favSkuMap = { ...skuContext.favSkuMap};

            if(!isRemoveFlag){

              let {compUnits="",compSales=""}= skuContext.skuStorePerformanceData.skuCompData && skuContext.skuStorePerformanceData.skuCompData;
              favSkuMap[skuContext.skuNumber] =  {
                "skuNumber": skuContext.skuNumber,
                "skuDesc": skuContext.skuDescription,
                "favSkuTimestamp": favSkuData[skuContext.skuNumber].favSkuTimestamp,
                "vendorName": skuContext.skuVendors,
                "skuImage": skuContext.skuImageUrl,
                "netUnitsComp": compUnits,
                "netSalesComp": compSales
              };
             // profileData["favSkuMap"]=favSkuMap;
              skuContext.updateStateFields({favSkuMap,isFavNotificationOn:true});
              message.success('Added to Favorites');

            }else {
              delete (favSkuMap[skuNumber]);
              //profileData["favSkuMap"]=favSkuMap; 
              skuContext.updateStateFields({favSkuMap});
              message.success('Removed from Favorites');
            }


        onSuccess(true);
        }).catch(resp=>{
      if(resp.response.status === 422){
        AlertUtil.showAlert("error","Error", resp.response.data);
      }else {
          console.log(resp);
          AlertUtil.showAlert("error","Error", "Error Occurred on adding or Removing Favorites");}
      onSuccess(false);
    });
  }
  static DEL_FAV_TITLE = "Remove from your favorites?";
  static DEL_FAV_MSG =  "Removing this from your favorites list will not allow you to access it as a favorite again until its manually added back.";

}