import React, { Component } from 'react';
import { DeleteOutlined, HeartFilled } from '@ant-design/icons';
import { Dropdown, Menu, Col, Row, Typography, Button, Badge } from 'antd';
import './Favorite.scss'
import SkuInfoCard from "../../DashboardDrawer/SkuInfoCard";
import MenuItem from "antd/lib/menu/MenuItem";
import AlertUtil from "../../Utils/AlertUtil";
import SkuContext from "../../../context/SkuContext";
import FavoriteHelper from "./FavoriteHelper";
import {Redirect} from "react-router-dom";
import PriceDataServices from "../../../services/PriceDataServices";
import {trackEvent} from '../../Utils/mixpanel'
import SvgUtil from "../../Utils/SvgUtil";

const { Text } = Typography;

export default class FavoritesMenu extends Component {

  static contextType = SkuContext;

  state = {
    cardOpen: false,
    isDeleteAlertOpen: false,
    skuCompMap: {},
    isCompLoaded: false
  };

  componentDidUpdate(prevProps, prevState){
    let skuCompMap={};
    let skuNumbers = this.context.favSkuMap ? Object.keys(this.context.favSkuMap):[];

    if(prevState.cardOpen === false && this.state.cardOpen === true && skuNumbers.length>0) {
      PriceDataServices.fetchPerformanceDataForSkus(skuNumbers,this.props.userId).then(response => {
        if(response.status === 200){
          skuCompMap = response.data;
          let favSkuMap = {...this.context.favSkuMap};
          if (skuNumbers.length > 0) {
            skuNumbers.forEach(sku => {
              let isPresent = skuCompMap.hasOwnProperty(sku);
              favSkuMap[sku].netUnitsComp = isPresent ? skuCompMap[sku].netUnitsComp : 0;
              favSkuMap[sku].netSalesComp = isPresent ? skuCompMap[sku].netSalesComp : 0;
              favSkuMap[sku].rawSales = isPresent ? skuCompMap[sku].rawSales : 0;
              favSkuMap[sku].rawUnits = isPresent ? skuCompMap[sku].rawUnits : 0;
            });
          }
          this.context.updateStateFields({favSkuMap,skuCompMap});
          this.setState({skuCompMap,isCompLoaded: true})
        }
      }).catch(resp => {
        this.setState({isCompLoaded: true});
        console.log(resp);
      });
    }
  }

  skuListDetails =() => {
    let skuNumbers = this.context.favSkuMap ? Object.values(this.context.favSkuMap) : [];
    skuNumbers = skuNumbers.sort((a, b) => {
      return Date.parse(b.favSkuTimestamp) - Date.parse(a.favSkuTimestamp);
    });
    let allowedFavoriteCount = this.context.profileData.allowedFavSkuCount ? this.context.profileData.allowedFavSkuCount : '';
    return (
      <Menu className='fav-menu'>
        <MenuItem  key='header' className="fav-header"> <Text className="fav-header-text">Favorites ({skuNumbers.length})</Text>
        </MenuItem>
      <MenuItem className='fav-menu-item fav-sku-menu-item' key='sku-menu'>
        {
          skuNumbers.map( sku =>
            <Row
                key={sku.skuNumber}
                className="fav-border fav-ant-row"
                justify="space-between"
                align="middle"
                type="flex"
            >
              <Col span={20} onClick={ () => {
                  this.props.skuSearch(sku.skuNumber);
                  this.setState({cardOpen:false,skuCompMap:{},isCompLoaded: false});
                  this.props.toggleHeaderDropdownDimmer(false);
                }}
              >
                <SkuInfoCard
                    isCompLoaded={this.state.isCompLoaded}
                    skuNumber={sku.skuNumber}
                    skuDescription={sku.skuDesc}
                    skuVendors={sku.vendorName}
                    skuImageUrl={sku.skuImage? sku.skuImage : "no-sku-image"}
                    skuCompSales={this.state.isCompLoaded === true? (this.state.skuCompMap[sku.skuNumber] ? this.state.skuCompMap[sku.skuNumber].netSalesComp: "-") : "no-comp-data"}
                    skuCompUnits={this.state.isCompLoaded === true?  (this.state.skuCompMap[sku.skuNumber] ? this.state.skuCompMap[sku.skuNumber].netUnitsComp: "-") : "no-comp-data"}
                />
              </Col>
              <Col span={4} style={{padding: '0px 12px'}}>
                <Button
                  onClick={() => {this.handleClickingDeleteIcon(sku)}}
                  shape="circle" icon={<DeleteOutlined />} size="large"
                />
              </Col>
            </Row>
        )}
      </MenuItem>
      {
          skuNumbers.length === 0 &&
          <MenuItem className='no-fav-menu-item' >
            <Row align='middle' justify='center' ><Col>{SvgUtil.getNoFavSkuData()}</Col></Row>
            <Row align='middle' justify='center'><Col><Text
                className='no-fav-sku'> No Favorites Added </Text></Col></Row>
          </MenuItem>
        }
        {
          skuNumbers.length > 0 &&
          <MenuItem className='fav-menu-item' key='fav-count'>
            <Row className="menuFooter" align='middle' justify="center" type='flex'>
              <Col><Text
                  type="secondary">{skuNumbers.length} / {allowedFavoriteCount} Favorites
                Used</Text></Col>
            </Row>
          </MenuItem>
        }
      </Menu>
    );
  }

  handleClickingDeleteIcon = (sku) => {
    trackEvent("CLICKED_DELETE_FAVORITE_TRASH_ICON", {'sku': sku.skuNumber})
    this.setState({isDeleteAlertOpen:true});
    AlertUtil.showAlert(
      "confirm",
      (<div>{FavoriteHelper.DEL_FAV_TITLE}</div>),
      FavoriteHelper.DEL_FAV_MSG,
      ()=>this.handleDeleteAlert(true, sku.skuNumber),
      ()=>this.handleDeleteAlert(false)
    )
  }

  handleDeleteAlert = (onConfirm,skuNumber)=> {
    if (onConfirm) {
      FavoriteHelper.addOrRemoveFavoriteSku(true,this.props.userId,skuNumber,this.context,()=>{});
      this.setState({cardOpen:false,skuCompMap:{},isCompLoaded: false});
      this.props.toggleHeaderDropdownDimmer(false);
      trackEvent("FAVORITE_REMOVED", {'ORIGIN': "FAVORITES_LIST", 'sku': skuNumber})
    }
    this.setState({isDeleteAlertOpen : false});
  }

  handleDropdownCloseOpen = (flag) => {
    let cardOpen = this.state.isDeleteAlertOpen ? true : flag;
    trackEvent("CLICKED_FAVORITES_LIST_TOGGLE_ICON");
    this.props.toggleHeaderDropdownDimmer(cardOpen);
    if(cardOpen) {
      this.setState({cardOpen});
      this.context.updateStateFields({isFavNotificationOn:false});
    } else {
      this.setState({cardOpen, skuCompMap:{}, isCompLoaded: false});
    }
  };

  render() {
    let skuNumbers = this.context.favSkuMap ? Object.keys(this.context.favSkuMap) : [];
    if (this.state.sku) {
      return <Redirect path from="*" to={'/'+this.state.sku}/>
    }
    return (
      <Dropdown
        getPopupContainer={trigger => trigger.parentNode}
        onOpenChange={(flag)=>{this.handleDropdownCloseOpen(flag);}}
        overlayClassName = "fav-dropdown"
        overlay={this.skuListDetails()}
        trigger={["click"]}
        open={this.state.cardOpen}
      >
        <Badge
            count={this.context.isFavNotificationOn?skuNumbers.length:0}
            offset={[-22, 8]}
            className='badgeDotSize'>
          <HeartFilled
            style={{ cursor:'pointer', fontSize: '25px', color: '#FFFFFF'}} />
        </Badge>
      </Dropdown>
    );
  }
}
// 