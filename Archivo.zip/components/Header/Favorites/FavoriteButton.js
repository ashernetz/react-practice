import React, {Component, Fragment} from 'react';
import SkuContext from "../../../context/SkuContext";
import FavoriteHelper from "./FavoriteHelper";
import AlertUtil from "../../Utils/AlertUtil";
import {trackEvent} from '../../Utils/mixpanel';
import {Button} from 'antd';
import './Favorite.scss';

export default class FavoriteButton extends Component {
  static contextType = SkuContext;

  state = {isLoading: false};
  
  // componentDidMount(){
  //   let skuCompMap = {};
  //   let skuList = this.context.skuNumber ? [this.context.skuNumber]:[];
  //   if(skuList.length>0) {
  //     PriceDataServices.fetchPerformanceDataForSkus(skuList,this.context.userId).then(response => {
  //       if(response.status === 200){
  //         skuCompMap = response.data;
  //         this.context.updateStateFields({skuCompMap});
  //       }
  //     }).catch(resp => {
  //       console.log(resp);
  //     });
  //   }
  //
  // }

  onFavoriteIconClick = () => {
    let isRemove = this.context.isFavorite;
    trackEvent("CLICKED_SKU_CARD_FAVORITE_ICON")
    if (isRemove) {
      AlertUtil.showAlert("confirm",<div>{FavoriteHelper.DEL_FAV_TITLE}</div>,
          FavoriteHelper.DEL_FAV_MSG,
          ()=>
              this.addOrRemoveFavoriteSku(isRemove),
          ()=>{});
    } else {
      this.addOrRemoveFavoriteSku(isRemove);
    }
  };

  addOrRemoveFavoriteSku=(isRemove)=>{
    trackEvent(`${isRemove ? "FAVORITE_REMOVED" : "FAVORITE_ADDED"}`, {'ORIGIN': "SKU_CARD_FAVORITE_ICON", 'sku': this.context.skuNumber})
    if(!isRemove){this.setState({isLoading: true});}
    FavoriteHelper.addOrRemoveFavoriteSku(isRemove,this.context.userId,this.context.skuNumber,this.context, () => {setTimeout(()=> this.setState({isLoading: false}), 2000);})
  };

  render() {
    let isFav = this.context.isFavorite;
    return (
      <Fragment>
        {this.props.isInStoreFav ?
          <Button className="inStore-fav-btn" size="large" type="text" shape="circle" onClick={this.onFavoriteIconClick}
            icon={<span className={this.state.isLoading ? "is_animating" : isFav ? "filled-heart" : "un-filled-heart"}
              style={{ transform: "translate(-49%, -49%)",position:"absolute", width: 75, height: 70 }}></span>} />
          : <div className={this.state.isLoading ? "is_animating" : isFav ? "filled-heart" : "heart"}
            style={{ marginLeft: '-15px', width: 50, height: 50 }} onClick={this.onFavoriteIconClick}>
          </div>}
      </Fragment>
    );
  }

}


