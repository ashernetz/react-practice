import {
  base64str_changedSkus,
  base64str_noskus,
  base64str_noZonemultiplierid,
  pricingSkuGroup,
} from './__fixtures__/pricingSkuGroup';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import React from 'react';
import SearchModal from './SearchModal';
import SkuGroupUtil from '../../Utils/SkuGroupUtil';

const getProps = (props = {}) => ({
  closeModal: jest.fn(),
  onSkuSearch: jest.fn(),
  ...props,
});

const renderComponent = (props = {}) => {
  return render(<SearchModal {...getProps()} {...props} />);
};

const selectChangeReviewPrices = () => {
  const pricesSelect = screen.getByLabelText('Change/Review Prices');
  fireEvent.click(pricesSelect, { target: { value: 'review' } });
};

const pasteShareCode = (shareCode) => {
  const shareCodeInput = screen.getByPlaceholderText(
    'Have a Share Code? Paste it here.'
  );
  fireEvent.paste(shareCodeInput, {
    clipboardData: { getData: () => shareCode },
  });
};

const clickGoButton = () => {
  const goButton = screen.getByTestId('go-button');
  fireEvent.click(goButton);
};
describe('SearchModal', () => {
  describe('Share Code functionality', () => {
    it('should render share code input', async () => {
      renderComponent();
      selectChangeReviewPrices();

      await waitFor(() => {
        expect(
          screen.getByPlaceholderText('Have a Share Code? Paste it here.')
        ).toBeInTheDocument();
      });
    });

    it('renders the error message if no skus', async () => {
      renderComponent();
      selectChangeReviewPrices();
      pasteShareCode(base64str_noskus);
      clickGoButton();

      await waitFor(() => {
        expect(
          screen.getByText('Share code is no longer valid.')
        ).toBeInTheDocument();
      });
    });

    it('renders the error message if no zoneGroupMultiplierId', async () => {
      renderComponent();
      selectChangeReviewPrices();
      pasteShareCode(base64str_noZonemultiplierid);
      clickGoButton();

      await waitFor(() => {
        expect(
          screen.getByText('Share code is no longer valid.')
        ).toBeInTheDocument();
      });
    });

    it('renders the error message if share code has invalid characters', async () => {
      renderComponent();
      selectChangeReviewPrices();

      const invalidShareCodeString =
        JSON.stringify(pricingSkuGroup) + '_invalid';
      const shareCodeInput = screen.getByPlaceholderText(
        'Have a Share Code? Paste it here.'
      );
      fireEvent.paste(shareCodeInput, {
        clipboardData: { getData: () => invalidShareCodeString },
      });

      clickGoButton();

      await waitFor(() => {
        expect(
          screen.getByText('Share code is not valid.')
        ).toBeInTheDocument();
      });
    });

    it('renders the error message if sku group is modified', async () => {
      const getSkuGroupsMock = jest.fn().mockResolvedValue({
        [pricingSkuGroup.skuGroupId]: pricingSkuGroup.skus,
      });

      jest
        .spyOn(SkuGroupUtil, 'getSkuGroups')
        .mockImplementation(getSkuGroupsMock);

      renderComponent();
      selectChangeReviewPrices();
      pasteShareCode(base64str_changedSkus);
      clickGoButton();
      await waitFor(() => {
        expect(
          screen.getByText(
            'Share code is no longer valid. The Sku Group has changed since this code was generated.'
          )
        ).toBeInTheDocument();
      });

      getSkuGroupsMock.mockRestore();
    });
  });
});
