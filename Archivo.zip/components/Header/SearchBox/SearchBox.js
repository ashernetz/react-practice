import React, { useState, useContext } from 'react';
import { Col, Input, Row } from 'antd';
import './SearchBox.scss';
import {convertSearchTextToItemList} from "../../Utils/CommonUtil";
import { SearchOutlined } from "@ant-design/icons";
import SkuContext from '../../../context/SkuContext';
import { trackEvent } from '../../Utils/mixpanel';
import SearchModal from './SearchModal';

const SearchBox = (props) => {

	const context = useContext(SkuContext);
	const [isModalOpen, setIsModalOpen] = useState(false);

	const onSkuSearch = (selectedSearch, searchText) => {
		if (searchText) {
			setIsModalOpen(false);
			if (selectedSearch === "product" || selectedSearch === "map") {

				let { skuNumberList, omsIdList } = convertSearchTextToItemList(searchText);
				if ((skuNumberList.length === 1 && omsIdList.length === 0) || (skuNumberList.length === 0 && omsIdList.length === 1)) {
					props.singleItemInquiry(
						skuNumberList.length === 1 ? skuNumberList[0] : omsIdList[0],
						"ENTERED_SINGLE_ITEM_IN_SEARCH_BAR",
						selectedSearch === "map"
					);
				} else {
					props.multiItemInquiry(skuNumberList, omsIdList, "ENTERED_MULTIPLE_ITEM_IN_SEARCH_BAR");
				}

			} else {
				let data = {
					searchType: "VNDR",
					vendorNumber: searchText,
				};
				trackEvent("ENTERED_VENDOR_NUMBER_IN_SEARCH_BAR", { vendor: searchText });
				props.diverseMultiSearch(data, "ENTERED_VENDOR_NUMBER_IN_SEARCH_BAR", context.updateShowDimmer);

			}
		}
	};


	const showModal = () => {
		setIsModalOpen(true);
	};

	const closeModal = () => {
		setIsModalOpen(false);
	};

	return (
		<>
			<Row>
				<Col id="header-search-box" span={24}>
					<Input.Group compact >
						<Input
							style={{ backgroundColor: "#ffffff" }}
							size="large"
							placeholder={"Search"}
							suffix={<SearchOutlined style={{ color: "#f96302", fontSize: "26px" }}
							/>}
							onClick={() => showModal()}
							data-testid="search-input-box"
							readOnly
						/>
					</Input.Group>
				</Col>
			</Row>
			
			{isModalOpen && <SearchModal
				closeModal={closeModal}
				onSkuSearch={onSkuSearch}
			/>}
		</>
	);
};

export default SearchBox;



