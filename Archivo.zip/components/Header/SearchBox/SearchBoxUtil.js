import SingleAndMultiSkuServices from "../../../services/SingleAndMultiSkuServices";
import _ from 'lodash';
import DCSUtil from "../../Utils/DCSUtil";

export default class SearchBoxUtil {


   static fetchValidatedSkus = (skuSearchList, setSkuValidationObject) => {
      setSkuValidationObject({data: {valid: [], invalid: []}, isLoading: true})
      SingleAndMultiSkuServices.fetchValidSkus(skuSearchList).then(response => {
          let responseData = response.data;
          let invalidSkusList = _.difference(skuSearchList, responseData);
          setSkuValidationObject({data:{valid: responseData, invalid: invalidSkusList}, isLoading: false});
      })
      .catch(err => {
         setSkuValidationObject({data: {valid: [], invalid: []}, isLoading: false});
         console.log(err);
     })
   }

    static fetchSkusDcs = (skuSearchList, setSkusByTraitGroupDcs, setPacmanTraitGroups) => {
        setPacmanTraitGroups({data: [], isLoading: true});
        let groupSKUsByDept;
        SingleAndMultiSkuServices.fetchSkusDcs(skuSearchList).then(response => {
            const dcs = response.data.filter(sku => sku.dcs).map(sku => sku.dcs);
            const dcsSet = new Set([...dcs])
            groupSKUsByDept = _.groupBy(response.data, function (b) { return b.dcs })
            return [...dcsSet]
        }).then(dcsSet => {
            SingleAndMultiSkuServices.fetchValidZones(dcsSet).then(dcsResponse => {
                let skusByDepartment = {};
                dcsResponse.data.forEach(({traitGroup,subclasses}) => {
                    let pacmanDcs = `${traitGroup.subDepartment}-${traitGroup.classNumber}-${traitGroup.subClassNumber}`;
                    traitGroup.dcs = pacmanDcs;
                    skusByDepartment[pacmanDcs] = subclasses.map(eachSubClass => groupSKUsByDept[eachSubClass]).flat()
                });
                setSkusByTraitGroupDcs(skusByDepartment);
                setPacmanTraitGroups({data: dcsResponse.data.map(item => item.traitGroup), isLoading: false});
            })
        }).catch(() => {
            setPacmanTraitGroups({data: [], isLoading: false});
        })

    }


    static buildZoneMultiplierGroupRequest = (dcsString) => {
        let dcsObject = DCSUtil.getFormattedDCSObject(dcsString)
        let nameAndDescription = {
            name: "auto-generated group",
            description: ""
        }
        return {...dcsObject, ...nameAndDescription}
    }

    static buildZoneGroupRequest = (pacmanZoneSet) => {
        if(pacmanZoneSet.length > 10) {
            return [{
                name: "Pacman Zones",
                description: "",
                weight: 1,
                zones: pacmanZoneSet.map(obj => obj.zoneId)
            }]
        } else {
            let requestArr = [];
            pacmanZoneSet.forEach(zone => {
                requestArr.push(
                    {
                        name: zone.zoneName,
                        description: "",
                        weight: 1,
                        zones: [zone.zoneId]
                    }
                )
            })
            return requestArr
        }

    }

    static zoneGroupAutoCreation = (dcsString, pacmanZoneSet, setIsZoneGroupAutoCreationLoading) => {
        setIsZoneGroupAutoCreationLoading(true)
        let request = this.buildZoneMultiplierGroupRequest(dcsString)

        // Create Zone Multiplier Group.
        SingleAndMultiSkuServices.createZoneMultiplierGroup(request).then(response => {
            let responseData = response.data;
            return responseData.id
        }).then(zoneMultGroupId => {
            let zoneGroupRequest = this.buildZoneGroupRequest(pacmanZoneSet)
            return Promise.all(zoneGroupRequest.map(zoneGroupObj => {
                // Create each Zone Group.
                return SingleAndMultiSkuServices.createZoneGroupForMultiplierGroup(zoneMultGroupId, zoneGroupObj).then(response => {
                    let responseData = response.data;
                    return responseData.id;
                })
            })).then(zoneGrpId => {
                // Set the anchor Zone Group.
                return SingleAndMultiSkuServices.setZoneGroupAnchorForMultiplierGroup(zoneMultGroupId, zoneGrpId[0]);
            })
        }).finally(() => {
            setIsZoneGroupAutoCreationLoading(false);
        });
    }


}


