import React, {useEffect, useRef, useState} from 'react';
import _ from 'lodash';
import {Input, Row, Modal, Button, Radio, Space, Popover, Alert, Col, Spin, Collapse, Typography} from 'antd';
import { RightCircleFilled, InfoCircleOutlined, CaretRightOutlined, CloseCircleFilled } from "@ant-design/icons";
import { useHistory } from "react-router-dom";
import './SearchModal.scss';
import { convertSkuSearchTextToList } from "../../Utils/CommonUtil";
import SearchBoxUtil from "./SearchBoxUtil";
import UXSmallPulse from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSmallPulse";
import ZoneGroupSelectionModal from "../../ZonegroupSelectionModal/ZoneGroupSelectionModal";
import SingleAndMultiSkuServices from "../../../services/SingleAndMultiSkuServices";
import SkuGroupUtil from "../../Utils/SkuGroupUtil";
import { decryptSharedCode } from '../../Helper/ShareCode';
const { Text } = Typography;
const { TextArea } = Input;
const { Panel } = Collapse;
const SEARCH_TYPES = {
   "product": {
      type: "product",
      label: "Search by Products",
      placeholder: "Enter one or multiple SKUs or OMS IDs. You can copy and paste a list of items from an outside source.",
      allowedRegex: /^[0-9, \n]*$/
   },
   "vendor": {
      type: "vendor",
      label: "Search by Vendor",
      placeholder: "Enter one Vendor ID. You can copy and paste an ID from an outside source.",
      allowedRegex: /^[0-9]*$/
   },
   "review": {
      type: "review",
      label: "Change/Review Prices",
      placeholder: "Enter Up to 200 SKUs. You can even copy and paste a list of items from an outside source. ",
      allowedRegex: /^[0-9, \n]*$/
   },
   "map": {
      type: "product",
      label: "Search by Product",
      placeholder: "Enter one SKU or OMSID to view on the MPulse Price Map. You can even copy and paste a SKU or OMSID number from an outside source.",
      allowedRegex: /^[0-9]*$/
   }
};

const SearchModal = ({ closeModal, onSkuSearch }) => {
   const history = useHistory();

   const skuInputRef = useRef(null);
   const [searchText, setSearchText] = useState('');
   const [selectedSearch, setSelectedSearch] = useState("product");

   const [isOverSkuThreshold, setIsOverSkuThreshold] = useState(false);
   const [skuValidationObject, setSkuValidationObject] = useState({ data: {valid: [], invalid: []}, isLoading: false });

   const [skusByTraitGroupDcs, setSkusByTraitGroupDcs] = useState({});
   const [pacmanTraitGroups, setPacmanTraitGroups] = useState({data: [], isLoading: false});

   const [isZoneGroupSelectionModalOpen, setIsZoneGroupSelectionModalOpen] = useState(false);
   const [zoneMultiplierGroups, setZoneMultiplierGroups] = useState({data: [], isLoading: false});
   const [isZoneGroupAutoCreationLoading, setIsZoneGroupAutoCreationLoading] = useState(false)

   const [radioButtons, setRadioButtons] = useState({
      product: '',
      vendor: '',
      review: '',
      map: ''
   });

   const [shareCode, setShareCode] = useState('');
   const [shareCodeError, setShareCodeError] = useState('');
   const [isShareCodeValidating, setIsShareCodeValidating] = useState(false);

   useEffect(() => {
      skuInputRef.current.focus();
   }, []);

   useEffect(() => {
      handleValidations();
   }, [skuValidationObject, pacmanTraitGroups]);

   useEffect(() => {
      handleValidations(true);
   }, [isZoneGroupAutoCreationLoading]);

   const isInvalidSkus = () => {
      return skuValidationObject.data.invalid.length > 0;
   }

   const isSingleTraitGroup = () => {
      return pacmanTraitGroups.data.length === 1;
   }

   const areValidationRequestsLoading = () => {
      return skuValidationObject.isLoading || pacmanTraitGroups.isLoading || isZoneGroupAutoCreationLoading || zoneMultiplierGroups.isLoading;
   }

   const validationDataExists = () => {
      return skuValidationObject.data.valid.length > 0 && pacmanTraitGroups.data.length > 0;
   }

   /**
    * Ensures that the user-entered skus pass all validations, optionally ignoring invalid skus.
    * @param ignoreInvalidSkus True, if we should ignore invalid skus.
    * @returns {boolean} True, if the input skus are valid for the Edit Price Page.
    */
   const isValidEppSkus = (ignoreInvalidSkus) => {
      return !isOverSkuThreshold && isSingleTraitGroup() && (!isInvalidSkus() || ignoreInvalidSkus);
   }

   const handleValidations = (ignoreInvalidSkus = false) => {
      if (selectedSearch !== "review" || areValidationRequestsLoading() || !validationDataExists()) {
         return; // Ensure review prices is selected, and all validation http calls are done.
      }

      if (isValidEppSkus(ignoreInvalidSkus)) {
         handleZoneSelection(skuValidationObject.data.valid, pacmanTraitGroups.data[0]);
      }
   }

   const onEditPriceValidate = (skuList) => {
      const isOverThreshold = skuList.length > 200;
      setIsOverSkuThreshold(isOverThreshold);

      if (isOverThreshold) {
         return;
      }

      if (!validationDataExists()) {
         SearchBoxUtil.fetchValidatedSkus(skuList, setSkuValidationObject);
         SearchBoxUtil.fetchSkusDcs(skuList, setSkusByTraitGroupDcs, setPacmanTraitGroups);
      }
   }

   const onEditPriceSearch = () => {
      handleValidations(true);

      const skuList = convertSkuSearchTextToList(searchText)["skuNumberList"];
      onEditPriceValidate(skuList);
   }

   const zoneGroupAutoCreation = (pacmanTraitGroup) => {
      SearchBoxUtil.zoneGroupAutoCreation(pacmanTraitGroup.dcs, pacmanTraitGroup.zones, setIsZoneGroupAutoCreationLoading)
   }

   const handleSearchText = (value) => {
      setSearchText(value);
      setRadioButtons((prevState) => {
         return {
            ...prevState,
            [selectedSearch]: value
         }
      })
      if (selectedSearch === "review") {
         invalidateChecks();
      }
   }

   const handleRadioChange = (event) => {
      setSearchText("");
      setSelectedSearch(event.target.value);
   }

   const invalidateChecks = () => {
      setIsOverSkuThreshold(false)
      setSkuValidationObject({data: {valid: [], invalid: []}, isLoading: false})
      setPacmanTraitGroups({data: [], isLoading: false})
      setSkusByTraitGroupDcs({})
   }

   const handleGo = () => {
      if (selectedSearch === "review") {
         if(shareCode.length) {
            onShareCodeGo();
         } else {
            return onEditPriceSearch();
         }
      } else {
         return onSkuSearch(selectedSearch, searchText);
      }
   }

   const handleZoneModalCancel = () => {
      setIsZoneGroupSelectionModalOpen(false);
   };

   const handleZoneSelection = (skus, pacmanTraitGroup) => {
      setZoneMultiplierGroups({data: [], isLoading: true});
      SingleAndMultiSkuServices.fetchZoneMultiplierGroupBySubclasses([pacmanTraitGroup.dcs])
          .then(response => {
             const zoneGroups = response.data;
             setZoneMultiplierGroups({data: zoneGroups, isLoading: false});
             if(zoneGroups && zoneGroups.length === 1) {
                goToEditPricePage(skus, zoneGroups[0].id);
             } else if(zoneGroups && zoneGroups.length >= 2) {
                setIsZoneGroupSelectionModalOpen(true);
             } else {
                zoneGroupAutoCreation(pacmanTraitGroup)
             }
          })
          .catch(error => {
             setZoneMultiplierGroups({data: [], isLoading: false});
          });
   }

   const handleSelectedZoneMultiplierGroup = (zoneMultiplierGroupId) => {
      setIsZoneGroupSelectionModalOpen(false);
      let searchSKUs = skuValidationObject.data.valid || []
      goToEditPricePage(searchSKUs, zoneMultiplierGroupId);
   }

   const goToEditPricePage = (skus, zoneMultiplierGroupId) => {
      closeModal();
      invalidateChecks();
      history.push({
         pathname: "/EditPrices",
         state: {
            skus,
            zoneMultiplierGroupId,
            skuGroupName: "Custom Group"
         }
      });
   }

   const getCollapsibleDcsAlerts = (key) => {
      const [dept, cls, subCls] = key.replace(/0/g, '').split('-');
      return `D${dept}${cls ? '.C' + cls : ''}${subCls ? '.S' + subCls : ''} Pacman Zone`
   }
   const getDepartmentInfo = () => {
      return (
         <Collapse bordered={false}
            className="site-collapse-custom-collapse"
            expandIcon={({ isActive }) => <CaretRightOutlined rotate={isActive ? 90 : 0} />}
         >
            {Object.keys(skusByTraitGroupDcs).map((key) => {
               return (
                  <Panel header={getCollapsibleDcsAlerts(key)} key={key} className="site-collapse-custom-panel">
                     {skusByTraitGroupDcs[key].map(eachDept => eachDept.sku).toString()}
                  </Panel>
               )
            })}
         </Collapse>
      )
   }

   const onShareCodeGo = () => {
      //result from decoding function
      let shareCodeData =  {};
      try {
         shareCodeData = decryptSharedCode(shareCode);
      } catch(e) {
         setShareCodeError('Share code is not valid.');
         return;
      }

      const {skus, zoneGroupMultiplierId, ...rest } = shareCodeData;

      setIsShareCodeValidating(true);
      validateShareCode(shareCodeData).then(({ isValid, errorMessage }) => {
         setIsShareCodeValidating(false);
         if(isValid) {
            closeModal();
            history.push({
               pathname: '/EditPrices',
               state: {
                  skus,
                  zoneMultiplierGroupId: zoneGroupMultiplierId,
                  ...rest
               },
            });
         } else {
            setShareCodeError(errorMessage);
         }
      })
   }

   const validateShareCode = async (shareCodeData) => {
      const { skuGroupId, skus, zoneGroupMultiplierId } = shareCodeData;
      const requiredFieldsArePresent = zoneGroupMultiplierId && skus && skus.length > 0;

      if(!requiredFieldsArePresent) {
         return {
            isValid: false,
            errorMessage: 'Share code is no longer valid.'
         };
      }

      if(skuGroupId) {
         const skuGroups = await SkuGroupUtil.getSkuGroups();
         const isSkuGroup = skuGroups.hasOwnProperty(skuGroupId);
         const isUnmodified = _.isEqual(_.sortBy(skus), _.sortBy(skuGroups[skuGroupId]));
         const isSkuGroupValid= isSkuGroup && isUnmodified;

         if (!isSkuGroupValid) {
            return {
               isValid: false,
               errorMessage: 'Share code is no longer valid. The Sku Group has changed since this code was generated.'
            };
         }

         return { isValid: true, errorMessage: '' };
      } else {
         return { isValid: true, errorMessage: '' };
      }
   }

   const handleShareCodePaste = (e) => {
      e.preventDefault();
      const clipboardData = e.clipboardData;
      const pastedData = clipboardData.getData('Text');

      if(pastedData.length) {
         setShareCode(pastedData);
      }
   }

   const handleClear = () => {
      setShareCode('');
      handleSearchText('');
      setShareCodeError('');
   }

   return (
       <div>
      <Modal
         open
         title="Find what you're looking for..."
         onCancel={closeModal}
         className="search_modal"
         footer={[
            <Button key="back" type="primary" size="large" ghost onClick={handleClear}>
               Clear
            </Button>,
            <Button key="submit"
               type="primary"
               size="large"
               onClick={handleGo}
               data-testid="go-button"
               disabled={selectedSearch === "review" &&
                  (areValidationRequestsLoading() ||
                      (validationDataExists() && !isValidEppSkus(true)))}
            >
               {selectedSearch !== "review" || (selectedSearch === "review" && !isInvalidSkus()) ? "Go" : "Proceed"} <RightCircleFilled />
            </Button>
         ]}
      >
         <Spin indicator={<UXSmallPulse />} spinning={(areValidationRequestsLoading() && !shareCode.length) || isShareCodeValidating} >
            <Space size="large" className='search_modal_content'
               direction="vertical">
               {isOverSkuThreshold && !shareCode.length &&
                  <Row>
                     <Col span={22}>
                        <Alert message="List exceeds 200 SKU limit"
                           type="error"
                           banner={true}
                        />
                     </Col>
                  </Row>
               }
               {!isOverSkuThreshold && isInvalidSkus() && !shareCode.length &&
                  <Row>
                     <Col span={22}>
                         <Alert message={skuValidationObject.data.invalid.length + " invalid SKUs in list. Modify the list of SKUs or click Proceed to remove the following: " + skuValidationObject.data.invalid.join(', ')}
                                type="warning"
                           banner={true}
                        />
                     </Col>
                  </Row>
               }
               {!isOverSkuThreshold && !isSingleTraitGroup() && Object.keys(skusByTraitGroupDcs).length > 0 && !shareCode.length &&
                  <Row>
                     <Col span={22} className="sku-description-container">
                        <Alert
                           description={<Space direction="vertical" size="small" style={{ fontSize: '16px' }}>
                              <div>
                                 <strong>SKUs belong to multiple Pacman zone Structures</strong>
                              </div>
                              <p>Inputs must belong to only one pacman zone structure before proceeding. {getDepartmentInfo()}
                              </p>
                           </Space>
                           }
                           type="error"
                           showIcon
                           icon={<CloseCircleFilled />}
                           banner={true}
                        />
                     </Col>
                  </Row>
               }
               <Row type="flex">
                  <Col span={9}>
                     <Space size="large">
                           <Radio.Group defaultValue={'product'} onChange={handleRadioChange}>
                              <Space direction="vertical" className='radio-col-small-space'>
                                 <Radio value={'product'}>Search SKUs</Radio>
                                 <Radio value={'vendor'}>Search Vendor ID</Radio>
                                 <Row justify="space-between">
                                    <Radio value={'review'}>Change/Review Prices</Radio>
                                    <Popover content={<div className='change-price-popover-content'>
                                       Change permanent retail prices for in store SKUs using the same zones, and automatically generate a Pacman ready RCW.
                                    </div>} trigger='click' placement='bottom'>
                                       <Button type="link" data-testid='change-price-info' shape='circle' size={'large'}
                                             icon={<InfoCircleOutlined />} />
                                    </Popover>
                                 </Row>
                                 <Radio value={'map'}>Go to Map</Radio>
                              </Space>
                           </Radio.Group>
                     </Space>
                  </Col>
                  <Col span={15}>
                     <TextArea rows={selectedSearch !== "review" ? 6 : 4}
                               value={radioButtons[selectedSearch]}
                               ref={skuInputRef}
                               data-testid="search-modal-textarea"
                               onChange={(e) => {
                                  let searchText = e.target.value;
                                  if (SEARCH_TYPES[selectedSearch].allowedRegex.test(searchText)) {
                                     handleSearchText(searchText);
                                  }
                               }}
                               placeholder={SEARCH_TYPES[selectedSearch]["placeholder"]}
                               disabled={selectedSearch === "review" && !!shareCode.length}
                     />
                     {selectedSearch === "review" && (
                       <TextArea
                         value={shareCode}
                         rows={2}
                         className="share-code-input"
                         disabled={!!shareCode.length || !!searchText.length}
                         onPaste={handleShareCodePaste}
                         placeholder="Have a Share Code? Paste it here."
                       />
                     )}
                  </Col>
               </Row>
               {shareCodeError.length > 0 && <Alert
                      type="error"
                      showIcon
                      closable
                      message={<Text>{shareCodeError}</Text>}
                    />}

            </Space>
         </Spin>
      </Modal>
   {!isOverSkuThreshold && isSingleTraitGroup() && isZoneGroupSelectionModalOpen && !shareCode.length && <ZoneGroupSelectionModal
       zoneMultiplierGroups={zoneMultiplierGroups.data}
       handleCancel={handleZoneModalCancel}
       handleSelectedZoneMultiplierGroup={handleSelectedZoneMultiplierGroup}
   />}
   </div>
)}


export default SearchModal




