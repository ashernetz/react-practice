import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react';
import { act } from 'react-dom/test-utils';
import '@testing-library/jest-dom';
import { MemoryRouter } from 'react-router-dom';
import axios from "axios";
import { when } from "jest-when";

import SearchBox from './SearchBox';

jest.mock('axios');

const mockHistoryPush = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useHistory: () => ({
        push: mockHistoryPush,
    })
}));

beforeEach(() => {
    render(
        <MemoryRouter>
            <SearchBox
                singleItemInquiry={() => { }}
                multiItemInquiry={() => { }}
                diverseMultiSearch={() => { }}
            />

        </MemoryRouter>
    )

})
describe('SearchBox', () => {

    test('render Search Modal radio buttons', async () => {
        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));

        })
        expect(screen.getByText('Search SKUs')).toBeInTheDocument();
        expect(screen.getByText('Search Vendor ID')).toBeInTheDocument();
        expect(screen.getByText('Change/Review Prices')).toBeInTheDocument();

    })

    test('show popover content on button click', async () => {
        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByTestId("change-price-info"));
        })

        expect(screen.getByText('Change permanent retail prices for in store SKUs using the same zones, and automatically generate a Pacman ready RCW.')).toBeInTheDocument();
    })

    test('show error message on List exceeds 200 SKU limit', async () => {
        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Change/Review Prices"));
            fireEvent.change(screen.getByTestId('search-modal-textarea'), {
                target: {
                    value:
                        "723288,\n723369,\n723372,\n784574,\n784575,\n784576,\n817597,\n817651,\n817678,\n817686,\n817694,\n817708,\n817724,\n817783,\n817791,\n817805,\n817813,\n817821,\n860662,\n860743,\n860751,\n860786,\n860816,\n860948,\n860956,\n998885,\n1006032747,\n737135,\n1000018829,\n1000018831,\n1000018833,\n1000018839,\n1000018840,\n1000018849,\n1000018851,\n1000018853,\n1000018855,\n1000018857,\n1000031685,\n1000031686,\n1000031689,\n1000031691,\n1000031692,\n1000031693,\n1000031694,\n1000031695,\n1000031696,\n1000031697,\n1000031993,\n1000032000,\n10000320,723288,\n723369,\n723372,\n784574,\n784575,\n784576,\n817597,\n817651,\n817678,\n817686,\n817694,\n817708,\n817724,\n817783,\n817791,\n817805,\n817813,\n817821,\n860662,\n860743,\n860751,\n860786,\n860816,\n860948,\n860956,\n998885,\n1006032747,\n737135,\n1000018829,\n1000018831,\n1000018833,\n1000018839,\n1000018840,\n1000018849,\n1000018851,\n1000018853,\n1000018855,\n1000018857,\n1000031685,\n1000031686,\n1000031689,\n1000031691,\n1000031692,\n1000031693,\n1000031694,\n1000031695,\n1000031696,\n1000031697,\n1000031993,\n1000032000,\n10000320,723288,\n723369,\n723372,\n784574,\n784575,\n784576,\n817597,\n817651,\n817678,\n817686,\n817694,\n817708,\n817724,\n817783,\n817791,\n817805,\n817813,\n817821,\n860662,\n860743,\n860751,\n860786,\n860816,\n860948,\n860956,\n998885,\n1006032747,\n737135,\n1000018829,\n1000018831,\n1000018833,\n1000018839,\n1000018840,\n1000018849,\n1000018851,\n1000018853,\n1000018855,\n1000018857,\n1000031685,\n1000031686,\n1000031689,\n1000031691,\n1000031692,\n1000031693,\n1000031694,\n1000031695,\n1000031696,\n1000031697,\n1000031993,\n1000032000,\n10000320,723288,\n723369,\n723372,\n784574,\n784575,\n784576,\n817597,\n817651,\n817678,\n817686,\n817694,\n817708,\n817724,\n817783,\n817791,\n817805,\n817813,\n817821,\n860662,\n860743,\n860751,\n860786,\n860816,\n860948,\n860956,\n998885,\n1006032747,\n737135,\n1000018829,\n1000018831,\n1000018833,\n1000018839,\n1000018840,\n1000018849,\n1000018851,\n1000018853,\n1000018855,\n1000018857,\n1000031685,\n1000031686,\n1000031689,\n1000031691,\n1000031692,\n1000031693,\n1000031694,\n1000031695,\n1000031696,\n1000031697,\n1000031993,\n1000032000,\n10000320,723288,\n723369,\n723372,\n784574,\n784575,\n784576,\n817597,\n817651,\n817678,\n817686,\n817694,\n817708,\n817724,\n817783,\n817791,\n817805,\n817813,\n817821,\n860662,\n860743,\n860751,\n860786,\n860816,\n860948,\n860956,\n998885,\n1006032747,\n737135,\n1000018829,\n1000018831,\n1000018833,\n1000018839,\n1000018840,\n1000018849,\n1000018851,\n1000018853,\n1000018855,\n1000018857,\n1000031685,\n1000031686,\n1000031689,\n1000031691,\n1000031692,\n1000031693,\n1000031694,\n1000031695,\n1000031696,\n1000031697,\n1000031993,\n1000032000,\n10000320"
                }
            });
        })
        await act(async () => {
            fireEvent.click(screen.getByText("Go"));
        })
        expect(screen.getByText('List exceeds 200 SKU limit')).toBeInTheDocument();

    })

    test('SKUs belong to multiple Pacman zone Structures', async () => {
        const skuValidationResponse = { data: [1006032747, 301329] };
        const dcsResponse = {
            data: [
                { "sku": 301329, "dcs": "026P-001-006" },
                { "sku": 1006032747, "dcs": "029B-026-002" }
            ]
        };
        const zoneDefinitionResponse = {
            data: [
                {
                    "subclasses": [
                        "029B-026-002"
                    ],
                    "traitGroup": {
                        "subDepartment": "029B",
                        "classNumber": 0,
                        "subClassNumber": 0,
                    }
                },
                {
                    "subclasses": [
                        "026P-001-006"
                    ],
                    "traitGroup": {
                        "subDepartment": "026P",
                        "classNumber": 0,
                        "subClassNumber": 0,

                    }
                }
            ]
        }

        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Change/Review Prices"));
            fireEvent.change(screen.getByTestId('search-modal-textarea'), {
                target: {
                    value:
                        "301329,1006032747"
                }
            });
        })
        await act(async () => {

            when(axios.post).calledWith(`/api/dataConnect/skuValidation`, expect.anything())
                .mockResolvedValue(skuValidationResponse);
            when(axios.post).calledWith(`/api/dataConnect/sku/dcs`, expect.anything())
                .mockResolvedValue(dcsResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-definition`, expect.anything())
                .mockResolvedValue(zoneDefinitionResponse);
            await fireEvent.click(screen.getByText("Go"));
            expect(screen.getByText("Go").closest('button')).toBeDisabled();
        })
        expect(screen.getByText('SKUs belong to multiple Pacman zone Structures')).toBeInTheDocument();
        expect(screen.getByText('D29B Pacman Zone')).toBeInTheDocument();
        expect(screen.getByText('D26P Pacman Zone')).toBeInTheDocument();
    })

    test('Invalid SKU in the list', async () => {
        const skuValidationResponse = { data: [301329] };
        const dcsResponse = {
            data: [
                { "sku": 301329, "dcs": "026P-001-006" },
            ]
        };
        const zoneDefinitionResponse = {
            data: [
                {
                    "subclasses": [
                        "026P-001-006"
                    ],
                    "traitGroup": {
                        "subDepartment": "026P",
                        "classNumber": 0,
                        "subClassNumber": 0,

                    }
                }
            ]
        }

        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Change/Review Prices"));
            fireEvent.change(screen.getByTestId('search-modal-textarea'), {
                target: {
                    value:
                        "301329,1234"
                }
            });
        })
        await act(async () => {

            when(axios.post).calledWith(`/api/dataConnect/skuValidation`, expect.anything())
                .mockResolvedValue(skuValidationResponse);
            when(axios.post).calledWith(`/api/dataConnect/sku/dcs`, expect.anything())
                .mockResolvedValue(dcsResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-definition`, expect.anything())
                .mockResolvedValue(zoneDefinitionResponse);
           await fireEvent.click(screen.getByText("Go"));
            expect(screen.getByText("Go").closest('button')).toBeDisabled();
        })
        
        expect(screen.getByText('1 invalid SKUs in list. Modify the list of SKUs or click Proceed to remove the following: 1234')).toBeInTheDocument();

    })

    test('Navigate to EditPrice page when all skus are valid', async () => {
        const skuValidationResponse = { data: [1000092702, 1000384113] };
        const dcsResponse = {
            data: [
                {
                    "sku": 1000384113,
                    "dcs": "026P-001-018"
                },
                {
                    "sku": 1000092702,
                    "dcs": "026P-001-020"
                }
            ]
        };
        const zoneDefinitionResponse = {
            data: [
                {
                    "subclasses": [
                        "026P-001-018",
                        "026P-001-020"
                    ],
                    "traitGroup": {
                        "subDepartment": "026P",
                        "classNumber": 0,
                        "subClassNumber": 0,

                    }
                }
            ]
        }
        const subClassResponse = {
            data: [
                {
                    "id": "7c0b7834-03c8-4783-b557-f4ed987ff7d5",
                    "subclass": "026P-000-000",
                    "name": "Black Pipe",
                    "description": "",
                    "anchorGroupId": "0c28fd74-6214-4dd6-b0ea-1318a16789f7"
                },
                {
                    "id": "fbbcedaa-3669-4176-9f99-fecf3fe0a0ba",
                    "subclass": "026P-000-000",
                    "name": "Copper Pipe",
                    "description": "",
                    "anchorGroupId": "a6fdc1b2-4cbf-4103-866d-051c19208531"
                },
                {
                    "id": "bbfbc902-92a8-41d3-a35d-b7873dd778eb",
                    "subclass": "026P-000-000",
                    "name": "PVC Only Pipe",
                    "description": "",
                    "anchorGroupId": "b378116f-4851-4ab4-a81d-fd20a528103f"
                },
                {
                    "id": "dbb74fd3-e299-4de0-b53e-2a5a0e7cfccc",
                    "subclass": "026P-000-000",
                    "name": "DWV Only Pipe",
                    "description": "",
                    "anchorGroupId": "1fcacfc4-1ee1-4ebd-bbb2-f3f788f833ba"
                },
                {
                    "id": "3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
                    "subclass": "026P-000-000",
                    "name": "Galvanized Pipe",
                    "description": "",
                    "anchorGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
                }
            ]
        }

        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Change/Review Prices"));
            fireEvent.change(screen.getByTestId('search-modal-textarea'), {
                target: {
                    value:
                        "1000092702,1000384113"
                }
            });
        })
        await act(async () => {

            when(axios.post).calledWith(`/api/dataConnect/skuValidation`, expect.anything())
                .mockResolvedValue(skuValidationResponse);
            when(axios.post).calledWith(`/api/dataConnect/sku/dcs`, expect.anything())
                .mockResolvedValue(dcsResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-definition`, expect.anything())
                .mockResolvedValue(zoneDefinitionResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-multiplier/subclass`, expect.anything())
                .mockResolvedValue(subClassResponse);
            await fireEvent.click(screen.getByText("Go"));
            expect(screen.getByText("Go").closest('button')).toBeDisabled();
        })


        expect(screen.getByText(`Select the standard “Pacman Zones” option, or if you setup custom zone multiplier groups in MPulse, you may select from the list.`)).toBeInTheDocument();
        expect(screen.getByText('Black Pipe')).toBeInTheDocument();
        expect(screen.getByText('Copper Pipe')).toBeInTheDocument();
        expect(screen.getByText('PVC Only Pipe')).toBeInTheDocument();
        expect(screen.getByText('DWV Only Pipe')).toBeInTheDocument();
        expect(screen.getByText('Galvanized Pipe')).toBeInTheDocument();
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Copper Pipe"));

        })
        await act(async () => {

            fireEvent.click(screen.getByText("Ok"));
        })
         expect(mockHistoryPush).toBeCalledTimes(1)

        expect(mockHistoryPush).toBeCalledWith({
            "pathname": "/EditPrices", 
            "state": {
                "skuGroupName": "Custom Group",
                "skus": [1000092702,1000384113],
             "zoneMultiplierGroupId": "fbbcedaa-3669-4176-9f99-fecf3fe0a0ba"}})

    })

    test('Navigate to EditPrice page when all skus are valid but  many commas,and  newlines in between', async () => {
        const skuValidationResponse = { data: [1000092702, 1000384113] };
        const dcsResponse = {
            data: [
                {
                    "sku": 1000384113,
                    "dcs": "026P-001-018"
                },
                {
                    "sku": 1000092702,
                    "dcs": "026P-001-020"
                }
            ]
        };
        const zoneDefinitionResponse = {
            data: [
                {
                    "subclasses": [
                        "026P-001-018",
                        "026P-001-020"
                    ],
                    "traitGroup": {
                        "subDepartment": "026P",
                        "classNumber": 0,
                        "subClassNumber": 0,

                    }
                }
            ]
        }
        const subClassResponse = {
            data: [
                {
                    "id": "7c0b7834-03c8-4783-b557-f4ed987ff7d5",
                    "subclass": "026P-000-000",
                    "name": "Black Pipe",
                    "description": "",
                    "anchorGroupId": "0c28fd74-6214-4dd6-b0ea-1318a16789f7"
                },
                {
                    "id": "fbbcedaa-3669-4176-9f99-fecf3fe0a0ba",
                    "subclass": "026P-000-000",
                    "name": "Copper Pipe",
                    "description": "",
                    "anchorGroupId": "a6fdc1b2-4cbf-4103-866d-051c19208531"
                },
                {
                    "id": "bbfbc902-92a8-41d3-a35d-b7873dd778eb",
                    "subclass": "026P-000-000",
                    "name": "PVC Only Pipe",
                    "description": "",
                    "anchorGroupId": "b378116f-4851-4ab4-a81d-fd20a528103f"
                },
                {
                    "id": "dbb74fd3-e299-4de0-b53e-2a5a0e7cfccc",
                    "subclass": "026P-000-000",
                    "name": "DWV Only Pipe",
                    "description": "",
                    "anchorGroupId": "1fcacfc4-1ee1-4ebd-bbb2-f3f788f833ba"
                },
                {
                    "id": "3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
                    "subclass": "026P-000-000",
                    "name": "Galvanized Pipe",
                    "description": "",
                    "anchorGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
                }
            ]
        }

        await act(async () => {
            fireEvent.click(screen.getByTestId("search-input-box"));
        })
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Change/Review Prices"));
            fireEvent.change(screen.getByTestId('search-modal-textarea'), {
                target: {
                    value:
                        "1000092702,\n,\n\n,,\n,,,,,,,,,\n\n\n\n\n\n\n\n\n\n\n\n\n,,,,,,,,,,,,,,,,,,,,,,,,,\n1000384113"
                }
            });
        })
        await act(async () => {

            when(axios.post).calledWith(`/api/dataConnect/skuValidation`, expect.anything())
                .mockResolvedValue(skuValidationResponse);
            when(axios.post).calledWith(`/api/dataConnect/sku/dcs`, expect.anything())
                .mockResolvedValue(dcsResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-definition`, expect.anything())
                .mockResolvedValue(zoneDefinitionResponse);
            when(axios.post).calledWith(`/api/dataConnect/zone-multiplier/subclass`, expect.anything())
                .mockResolvedValue(subClassResponse);
            await fireEvent.click(screen.getByText("Go"));
            expect(screen.getByText("Go").closest('button')).toBeDisabled();
        })


        expect(screen.getByText(`Select the standard “Pacman Zones” option, or if you setup custom zone multiplier groups in MPulse, you may select from the list.`)).toBeInTheDocument();
        expect(screen.getByText('Black Pipe')).toBeInTheDocument();
        expect(screen.getByText('Copper Pipe')).toBeInTheDocument();
        expect(screen.getByText('PVC Only Pipe')).toBeInTheDocument();
        expect(screen.getByText('DWV Only Pipe')).toBeInTheDocument();
        expect(screen.getByText('Galvanized Pipe')).toBeInTheDocument();
        await act(async () => {
            fireEvent.click(screen.getByLabelText("Copper Pipe"));

        })
        await act(async () => {

            fireEvent.click(screen.getByText("Ok"));
        })
        // todo: what is the reason for checking call times? If you run only this single spec, the invocation times will be equal to 1
         // expect(mockHistoryPush).toBeCalledTimes(2)

        expect(mockHistoryPush).toBeCalledWith({
            "pathname": "/EditPrices", 
            "state": {
                "skuGroupName": "Custom Group",
                "skus": [1000092702,1000384113],
             "zoneMultiplierGroupId": "fbbcedaa-3669-4176-9f99-fecf3fe0a0ba"}})

    })

});
