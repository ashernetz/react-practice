import React, {Component} from 'react';
import {
  Drawer,
  Row,
  Col,
  Typography,
  Switch,
  Divider
} from 'antd';
import {Layout, Checkbox, Select} from 'antd';
import {isMobile} from 'react-device-detect';
import SkuContext from "../../context/SkuContext";
import './FilterComponent.scss'
import FilterUtil from "../Utils/FilterUtil";
import Radio from "antd/lib/radio";
import {trackEvent} from '../Utils/mixpanel'
import OffsideFilter from "./OffsideFilter/OffsideFilter";

const {Text} = Typography;
const {Content} = Layout;
const plainOptions = ['Lowes', 'Floor & Decor', 'Menards', 'Sherwin Williams'];
const {Option} = Select;


export default class FilterComponent extends Component {
static contextType = SkuContext;

   onSkuStatusChange =(selectedSkuStatusList) => {
    this.context.updateFilterSelection({selectedSkuStatusList});
  };

  onFilterValuesChange = (type,value)=> {
    trackEvent("MPULSE_MAP_FILTER_CHANGE", {'FILTER_TYPE': type, 'FILTER_VALUE': value});
    this.context.updateFilterSelection({[type]:value});
  };

  onPerformanceFilterChange = () => {
    this.context.updateFilterSelection({
      isPerformanceFilterChecked: !this.context.filterValues.isPerformanceFilterChecked,
      selectedCompSales: 0,
      selectedCompUnits: 0
    });
  };

  render() {

    let filterValues = this.context.filterValues;
    return (
        <Drawer
            //title= "mapFilters"
            className='mapFilters'
            placement='right'
            closable={false}
            open={this.props.visible}
            style={{marginTop: "151px", zIndex: 'auto', padding:'4px'}}
            //afterVisibleChange = {(val ue) => !value ? this.context.updateFilterSelection({...this.state}): null}
            width={isMobile ? 280 : 380}
            mask={false}
        >
          {/* filter / right drawer content starts here */}
          <Row className='map-filter-heading' type="flex" justify="space-between" align="middle">
            <Col><Text id="map-filter-title" strong>Map Filters</Text></Col>
            <Col>
              <Text strong>{this.props.acrossStoreCount}</Text>
              <Text type="secondary" >{" Stores"}</Text>
            </Col></Row>
          <Divider className="dividerNoGap" />

          < Content>

            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>SKU Status</Text>
            </Col>
            </Row>
            <Row>
              <Col span={24}>
                <Select
                    mode="multiple"
                    placeholder="Select Status"
                    className='filterInput'
                    size='large'
                    onChange={this.onSkuStatusChange}
                    value={filterValues.selectedSkuStatusList}
                >
                  {this.props.distinctSkuStatusList.map(item => (
                      <Option key={item.value} value={item.status}>
                        {item.value}
                      </Option>

                  ))}
                </Select>
              </Col>
            </Row>
            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>Competitor Locations</Text>
            </Col>
            </Row>
            <Row style={{marginBottom: 18}}><Col span={24}>
              <Checkbox.Group value={filterValues.selectedCompetitors}options={plainOptions}
                              onChange={(value)=>{
                                this.context.updateFilterSelection({"selectedCompetitors":value,isOffsideRangeChecked:false});
                                }}/>
            </Col>
            </Row>
            <OffsideFilter/>
            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>SKU Availability</Text>
            </Col>
            </Row>
            <Row><Col span={24}>
              <Select size='large' value= {filterValues.selectedSkuAvailability} className='filterInput'
                      onChange={(value)=>this.onFilterValuesChange("selectedSkuAvailability",value)}>
                {FilterUtil.getSkuAvailabilityDropdownData().map(skuAvailabilityLabel =>
                    (<Option key={skuAvailabilityLabel} value={skuAvailabilityLabel} >{skuAvailabilityLabel}</Option>))
                }
              </Select>
            </Col>
            </Row>
            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>Market</Text>
            </Col>
            </Row>
            <Row>
              <Col span={24}>
                <Select
                    mode="multiple"
                    placeholder="Select Market"
                    className='filterInput'
                    size='large'
                    onChange={(value)=>this.onFilterValuesChange("selectedMarkets",value)}
                    filterOption={(input, option) =>
                        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    value={filterValues.selectedMarkets}
                >
                  {
                    Object.keys(this.context.skuData.marketMap).map(key => (
                        <Option key={key} value={key}>
                          {this.context.skuData.marketMap[key]}
                        </Option>

                    ))}
                </Select>
              </Col>
            </Row>
            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>Zones</Text>
            </Col>
            </Row>
            <Row>
              <Col span={24}>
                <Select
                    mode="multiple"
                    placeholder="Select Zones"
                    className='filterInput'
                    size='large'
                    onChange={(value)=>this.onFilterValuesChange("selectedZones",value)}
                    filterOption={(input, option) =>
                        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    value={filterValues.selectedZones}
                >
                  {
                    Object.keys(this.context.skuData.availableZoneMap).map(key =>
                       <Option key={key} value={key}>
                        {this.context.skuData.availableZoneMap[key]}
                      </Option>
                    )}
                </Select>
              </Col>
            </Row>
            <Row className='inputLabel'><Col span={24}>
              <Text level={4}>Disaster Stores</Text>
            </Col>
            </Row>
            <Row><Col span={24}>
              <Select size='large' value= {filterValues.selectedDisasterValue} className='filterInput'
                      onChange={(value)=>this.onFilterValuesChange("selectedDisasterValue",value)}>
                {FilterUtil.getDisasterDropdownData().map(disasterLabel =>
                    (<Option key={disasterLabel} value={disasterLabel} >{disasterLabel}</Option>))
                }
              </Select>
            </Col>
            </Row>
            <Row className='inputLabel'>
              <Col span={10}>Map Clustering</Col>
            <Col span={6} offset={8} className="filter-switch">
              <Switch  checked={filterValues.isMapClusteringChecked} onChange={(e)=> {this.onFilterValuesChange("isMapClusteringChecked",!filterValues.isMapClusteringChecked)}} />
            </Col>
            </Row>
            <Row className='inputLabel'>
              <Col span={13}>Performance Filters</Col>
              <Col span={6} offset={5} className="filter-switch">
                <Switch checked={filterValues.isPerformanceFilterChecked}
                        onChange={this.onPerformanceFilterChange} />
              </Col>
            </Row>
            {filterValues.isPerformanceFilterChecked && 
            <Row className='inputLabel'>
              <Col span={24}>
            <Row gutter={[0,24]} style={{marginBottom: "24px"}}>
              <Col span={23} offset={1}>Comp Performance</Col>
            </Row>
            <Row gutter={[0,24]} style={{marginBottom: "24px"}}>
              <Col span={22} offset={2}>
                <Radio.Group  onChange={(e)=> {this.onFilterValuesChange("selectedCompSales",e.target.value)}}
                    value={filterValues.selectedCompSales}>
                  <Radio.Button
                  disabled={!filterValues.isPerformanceFilterChecked}
                  value={1}>Positive</Radio.Button>
                  <Radio.Button
                      disabled={!filterValues.isPerformanceFilterChecked}
                      value={-1}>Negative</Radio.Button>
                  <Radio.Button  value={0}>Both</Radio.Button>
                </Radio.Group></Col>
            </Row>
            <Row gutter={[0,24]} style={{marginBottom: "24px"}}>
              <Col span={23} offset={1}>Unit Performance</Col>
            </Row>
            <Row gutter={[0,24]} style={{marginBottom: "24px"}}>
              <Col span={22} offset={2}>
                <Radio.Group onChange={(e)=> {this.onFilterValuesChange("selectedCompUnits",e.target.value)}}
                            value={filterValues.selectedCompUnits}>
                  <Radio.Button
                      disabled={!filterValues.isPerformanceFilterChecked}
                      value={1}>Positive</Radio.Button>
                  <Radio.Button
                      disabled={!filterValues.isPerformanceFilterChecked}
                      value={-1}>Negative</Radio.Button>
                  <Radio.Button  value={0}>Both</Radio.Button>
                </Radio.Group></Col>
            </Row>
              </Col>
            </Row>
            }
          </Content>
        </Drawer>
    );
  }

}
