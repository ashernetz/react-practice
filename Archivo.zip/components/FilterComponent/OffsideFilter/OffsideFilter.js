import React, {Fragment, useContext, useState} from 'react';
import {
  Col,
  Input,
  Popover,
  Row,
  Switch,
  Typography,
  Badge,
  Tooltip,
  Space
} from "antd";
import {getHistoslideData} from "../../Utils/CompetitorOffsideUtil";
import SkuContext from "../../../context/SkuContext";
import '../FilterComponent.scss';
import {trackEvent} from "../../Utils/mixpanel";
import { OffsideRangeSlider } from './OffsideRangeSlider'

const {Text} = Typography;


const OffsideFilter = () => {

const skuContext = useContext(SkuContext);
  const [graphInitialData,setGraphInitialData] = useState("");
  const [showOffsideAlert,setShowOffsideAlert] = useState(false);
  const [minMaxValue,setMinMaxValue] = useState([-25,25]);

  // const onChangeMinMax=(minMax)=> {
  //   let minMaxFinalValue ;
  //   if(minMax[1] === 25){
  //     minMaxFinalValue= [-5,5];
  //   }else{
  //     minMaxFinalValue= [minMax[0]-5,minMax[1]+5];
  //   }
  //   let{data} = getHistoslideData(skuContext.filterValues.offsideMap[selectedCompetitors.toString()],minMaxFinalValue);
  //   if(data.length>0){setGraphInitialData(data)}
  //   setMinMaxValue(minMaxFinalValue);
  //   skuContext.updateFilterSelection({"minMaxDefaultOffsideRange":minMaxFinalValue,"minMaxSelectedOffsideRange":minMaxFinalValue});
  //
  // };

  const inputBoxValueFormatter = (count) => {

    let value;
    if(skuContext.filterValues.minMaxSelectedOffsideRange){
      value = skuContext.filterValues.minMaxSelectedOffsideRange[count];
    }else {
      value = skuContext.filterValues.minMaxDefaultOffsideRange[count];
    }
    if(value === skuContext.filterValues.minMaxDefaultOffsideRange[count]){
      value=value+" +";
    }

    return value;
  };
  const getRheostatValues = (minMaxSelectedOffsideRange) => {

    let output = [];
    if(minMaxSelectedOffsideRange) {
      output.push(isNaN(minMaxSelectedOffsideRange[0])
          ? skuContext.filterValues.minMaxDefaultOffsideRange[0]
          : Number.parseFloat(minMaxSelectedOffsideRange[0]));
      output.push(isNaN(minMaxSelectedOffsideRange[1])
          ? skuContext.filterValues.minMaxDefaultOffsideRange[1]
          : Number.parseFloat(minMaxSelectedOffsideRange[1]));
      return output;
    }else return [skuContext.filterValues.minMaxDefaultOffsideRange[0],skuContext.filterValues.minMaxDefaultOffsideRange[1]];

  };

  function handleChange(values) {
    const nextFilterSelection = values.map((value) => (
      parseFloat(Number(value).toFixed(2))
    ))

    skuContext.updateFilterSelection({
      minMaxSelectedOffsideRange: nextFilterSelection,
    })
  }

  let selectedCompetitors = skuContext.filterValues.selectedCompetitors;
  let offsidePresent = skuContext.filterValues.offsideMap[selectedCompetitors.toString()]? skuContext.filterValues.offsideMap[selectedCompetitors.toString()].size >0 ? true : false: false;
  if(selectedCompetitors.length === 1 && selectedCompetitors.toString() !== "Sherwin Williams"){
  return ( <Fragment>

    <Row className='inputLabel filterInput'>
      <Col span={16}>
        <Space>
          <Text>Competitor Offside Range</Text>
        <Badge
            offset={[-3,-5]}
            count={
              <div>
                <Tooltip title={"Enables a 50mi range from selected competitor's price difference"} placement="top">
                  <i className="material-icons-outlined subclassInfoIcon">
                    info
                  </i>
                </Tooltip>
              </div>
            }
        ></Badge>
        </Space></Col>
      <Col span={6} offset={2} className="filter-switch">
        <Popover
            placement="top"
            trigger="hover"
            content={<Text type="secondary">No competitor prices available to complete offside analysis</Text>}
            overlayStyle={{width:"180px"}}
            open={offsidePresent? false: showOffsideAlert}
            onOpenChange={()=>setShowOffsideAlert(!showOffsideAlert)}
        >
          <Switch  disabled={!offsidePresent} checked={skuContext.filterValues.isOffsideRangeChecked} onChange={(e) => {
            trackEvent("COMPETITOR_OFFSIDE_EVENT");

            if(!skuContext.filterValues.isOffsideRangeChecked){
              let minMaxFinalValue=[-25,25];
              setMinMaxValue(minMaxFinalValue);
              let{data} = getHistoslideData(skuContext.filterValues.offsideMap[selectedCompetitors.toString()],minMaxFinalValue);
              if(data.length>0){setGraphInitialData(data)}
              skuContext.updateFilterSelection({isOffsideRangeChecked: !skuContext.filterValues.isOffsideRangeChecked,minMaxSelectedOffsideRange:minMaxFinalValue,minMaxDefaultOffsideRange:minMaxFinalValue});

            }else {
              skuContext.updateFilterSelection({isOffsideRangeChecked: !skuContext.filterValues.isOffsideRangeChecked});
            }
          }}/>
        </Popover>

      </Col>
    </Row>

    {skuContext.filterValues.isOffsideRangeChecked && <Fragment>
      {/*<RadioButton onClick={()=>onChangeMinMax(minMaxValue)}>{minMaxValue[0] + " to " + minMaxValue[1]} </RadioButton>*/}
      <Row justify='center' type="flex">
        <Col>
          {graphInitialData && (
            <OffsideRangeSlider
              data={graphInitialData}
              selection={getRheostatValues(skuContext.filterValues.minMaxSelectedOffsideRange)}
              onChange={handleChange}
            />
          )}
        </Col>
      </Row>
      <Row className='filterInput' type="flex" justify="space-between">
        <Col>{minMaxValue[0] +"%"} </Col><Col>0%</Col><Col>{minMaxValue[1]+"%+"} </Col></Row>

          <Row className='filterInput' type="flex" align="middle"
                                         justify="space-around">
      <Col span={11}><Input onChange={k => {
        let minMaxSelectedOffsideRange = [...skuContext.filterValues.minMaxSelectedOffsideRange];
        minMaxSelectedOffsideRange[0] =k.target.value;
        skuContext.updateFilterSelection(
            {minMaxSelectedOffsideRange})
      } }
                            placeholder="Min"
                            value={inputBoxValueFormatter(0)}
                            suffix="%"/></Col>
      <Col span={2}><Row type="flex"  justify="center"><Col><Text>--</Text></Col></Row></Col>
      <Col span={11} ><Input onChange={(k) => {
        let minMaxSelectedOffsideRange = [...skuContext.filterValues.minMaxSelectedOffsideRange];
        minMaxSelectedOffsideRange[1] = k.target.value;

        skuContext.updateFilterSelection(
            {minMaxSelectedOffsideRange})
      }} placeholder="Max"
                             value={inputBoxValueFormatter(1)}
                             suffix="%"/></Col>
    </Row>
   </Fragment>}

  </Fragment>)}else return null;
};

export default OffsideFilter;