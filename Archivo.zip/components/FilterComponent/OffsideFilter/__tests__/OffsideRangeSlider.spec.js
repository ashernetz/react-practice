import React from 'react';
import { screen, render, fireEvent, waitFor } from '@testing-library/react';

import { OffsideRangeSlider } from '../OffsideRangeSlider';

jest.mock('recharts', () => ({
  ...jest.requireActual('recharts'),
  ResponsiveContainer: MockResponsiveContainer,
}));

function MockResponsiveContainer({ children }) {
  return React.Children.map(children, (child) =>
    React.cloneElement(child, { width: 300, height: 175 })
  );
}

const getProps = (props = {}) => ({
  data: [
    { x0: 10, x: 15, y: 42 },
    { x0: 20, x: 25, y: 62 },
  ],
  selection: [10, 25],
  onChange: jest.fn(),
  onAnimationEnd: jest.fn(),
  ...props,
});

describe('OffsideRangeSlider component', () => {
  it('renders default state', async () => {
    const props = getProps();
    const { container } = render(<OffsideRangeSlider {...props} />);

    await waitFor(() => {
      expect(props.onAnimationEnd).toHaveBeenCalled();
    });

    expect(screen.queryByText('42')).toBeInTheDocument();
    expect(screen.queryAllByText('62').length).toEqual(2);
    expect(container.querySelector('.ant-slider')).toBeInTheDocument();
    expect(container.querySelector('.recharts-wrapper')).toBeInTheDocument();
  });

  it('handles change event if bar is clicked', async () => {
    const props = getProps();
    const { container } = render(<OffsideRangeSlider {...props} />);

    await waitFor(() => {
      expect(props.onAnimationEnd).toHaveBeenCalled();
    });

    fireEvent.click(container.querySelector('.recharts-rectangle'));

    expect(props.onChange).toHaveBeenCalledWith([10, 15]);
  });
});
