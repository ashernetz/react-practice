import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  LabelList,
  ResponsiveContainer,
} from 'recharts';
import { Slider } from 'antd';
import styled from 'styled-components';

const Container = styled.div`
  width: 300px;
`;

const Colors = {
  SELECTED: '#fa6304',
  UNSELECTED: '#797979',
};

function getCellColor(entry, selection) {
  const [left, right] = selection;
  const { x0, x } = entry;

  return x0 >= left && x <= right ? Colors.SELECTED : Colors.UNSELECTED;
}

function getMinMaxRange(data) {
  const first = data[0];
  const last = data[data.length - 1];

  return [first.x0, last.x];
}

function getXAxisValue({ x0, x }) {
  return Math.round((x0 + x) / 2);
}

export function OffsideRangeSlider({
  data,
  selection,
  onChange,
  onAnimationEnd,
}) {
  const [min, max] = useMemo(() => getMinMaxRange(data), [data]);

  function handleBarClick({ payload }) {
    const { x0, x } = payload;

    onChange([x0, x]);
  }

  return (
    <Container>
      <ResponsiveContainer height={175} >
        <BarChart data={data} margin={{ left: 6, right: 6, top:18 }}>
          <XAxis
            hide
            type="number"
            domain={[-25, 25]}
            dataKey={getXAxisValue}
          />
          <Bar
            onAnimationEnd={onAnimationEnd}
            radius={2}
            minPointSize={3}
            barSize={12}
            dataKey="y"
            onClick={handleBarClick}
          >
            <LabelList dataKey="y" position="top" />
            {data.map((entry, index) => (
              <Cell
                fontSize={10}
                key={index}
                cursor="pointer"
                fill={getCellColor(entry, selection)}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <Slider range min={min} max={max} value={selection} onChange={onChange} />
    </Container>
  );
}
