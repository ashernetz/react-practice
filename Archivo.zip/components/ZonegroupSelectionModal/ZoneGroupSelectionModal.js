import React, { useState } from "react";
import {
    Row,
    Modal,
    Space,
    Radio,
    Alert,
    Typography
} from "antd";
import "./ZoneGroupSelectionModal.scss";

const {Text} = Typography;

const ZoneGroupSelectionModal = ({ zoneMultiplierGroups, handleCancel, handleSelectedZoneMultiplierGroup }) => {
    //alphabetical order
    let sortedZoneMultiplierGroups = zoneMultiplierGroups.sort(function(a, b) {
        let textA = a.name.toUpperCase();
        let textB = b.name.toUpperCase();
        return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
    });

    //sort pacman zones to index 0
    let enhancedSort = sortedZoneMultiplierGroups.sort(function(a,b) {
        let textA = a.name.toUpperCase();
        let textB = b.name.toUpperCase();
        return (textB === "PACMAN ZONES") - (textA === "PACMAN ZONES");
    })

    const [selectedZoneMultiplierGroup, setSelectedZoneMultiplierGroup] = useState(enhancedSort[0].id);

    return (
        <Modal
            open
            className="zoneGroup-modal"
            onCancel={handleCancel}
            title="Select an option to proceed."
            okButtonProps={{ disabled: false }}
            okText="Ok"
            cancelText="Cancel"
            onOk={() => {
                handleSelectedZoneMultiplierGroup(selectedZoneMultiplierGroup);
            }}
        >
            <Alert message={<Text>Select the standard “Pacman Zones” option, or if you setup custom zone multiplier groups in MPulse, you may select from the list.</Text>}
                   type="info"
                   showIcon />

            <Radio.Group value={selectedZoneMultiplierGroup}>
                {
                    enhancedSort.map((zoneMultiplierGroup) => (
                        <Row key={zoneMultiplierGroup.id} data-testid={"radio-buttons-row"}>
                            <Space size="small" direction="vertical">
                                <Radio
                                    onClick={() => {
                                        setSelectedZoneMultiplierGroup(zoneMultiplierGroup.id);
                                    }}
                                    value={zoneMultiplierGroup.id}
                                    key={zoneMultiplierGroup.id}>
                                    {zoneMultiplierGroup.name}
                                </Radio>
                            </Space>
                        </Row>
                    ))
                }
            </Radio.Group>
        </Modal>
    );
}

export default ZoneGroupSelectionModal;

