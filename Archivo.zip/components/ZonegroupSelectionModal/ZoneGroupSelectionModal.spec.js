import React from 'react'
import {render, screen, within} from '@testing-library/react'
import '@testing-library/jest-dom'
import ZoneGroupSelectionModal from "./ZoneGroupSelectionModal";


let mockZoneMultiplierGroups = [
    {
        "id": "3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
        "subclass": "026P-000-000",
        "name": "Banana",
        "description": "",
        "anchorGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
    },
    {
        "id": "9e1feb9f-176a-49e1-9524-92514a1d6ad3",
        "subclass": "026P-000-000",
        "name": "Apple",
        "description": "",
        "anchorGroupId": "796d3c89-dd70-4956-bb6c-e04129feb482"
    },
    {
        "id": "7c0b7834-03c8-4783-b557-f4ed987ff7d5",
        "subclass": "026P-000-000",
        "name": "Pacman Zones",
        "description": "",
        "anchorGroupId": "0c28fd74-6214-4dd6-b0ea-1318a16789f7"
    }
]
describe('Zone Group Selection Modal', () => {
    test('render zone group selection modal', () => {
        render(<ZoneGroupSelectionModal zoneMultiplierGroups={mockZoneMultiplierGroups} handleCancel={jest.fn()} handleSelectedZoneMultiplierGroup={jest.fn()}/>)
        let rows = screen.getAllByTestId('radio-buttons-row');
        expect(within(rows[0]).queryByText('Pacman Zones').toBeInTheDocument);
        expect(within(rows[1]).queryByText('Apple').toBeInTheDocument);
        expect(within(rows[2]).queryByText('Banana').toBeInTheDocument);
    })
})