import React, { Component, Fragment } from "react";
import { RightOutlined } from '@ant-design/icons';
import { Row, Col, Typography, Badge, Divider, Button } from "antd";
import "./PricePoints.scss";
import AddNewModalComponent from "../../AddNewModalComponent/AddNewModalComponent.js";
import SkuContext from "../../../context/SkuContext";
import MapContext from "../../../context/MapContext";

import CompUtil from "../../Utils/CompUtil";
import { UXSpin } from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import SvgUtil from "../../Utils/SvgUtil";
import {formatNumberToCompact} from "../../Utils/CommonUtil";

const { Text,Paragraph } = Typography;

export default class PricePoints extends Component {
  static contextType = SkuContext;
  onSelectedRowClick = (row, mapState) => {
    mapState.updateSelectedState({ retail: row.retail });
    this.context.updateStateFields({ selectedPricePoint: row.retail });
    this.props.onPricePointRowClick(row);
  };

  onPricePointMouseOver = (mapState, retail) => {
    mapState.updateHoverState({ retail });
  };
  onPricePointMouseLeave = mapState => {
    mapState.updateHoverState({ retail: "" });
  };
  render() {
    return (
      <MapContext.Consumer>
        {mapState => (
          <div>
            <AddNewModalComponent
              acrossStoreCount={this.props.acrossStoreCount}
              pricePointCount={this.props.pricePointCount}
              activeStoresCount={this.context.skuData.totalStoreCount}
              userId={this.props.userId}
            />
            <Divider className="dividerNoGap" />
            {this.props.rows && this.props.rows.length > 0 ? this.props.rows.map((row, index) => {
              return (
                <div key={index} className="drawer-height">
                  <Row
                    className="antrow-cursor"
                    type={"flex"}
                    onMouseOver={() =>
                      this.onPricePointMouseOver(mapState, row.retail)
                    }
                    onMouseLeave={() => this.onPricePointMouseLeave(mapState)}
                    key={index}
                    onClick={e => this.onSelectedRowClick(row, mapState)}
                  >
                    <Col className="dotContainer" span={2}>
                      <Badge color={row.color} />
                    </Col>
                    <Col span={6}>
                      <Text className="ppPrice">
                        ${row.retail.split("-")[0]}{" "}
                      </Text>
                      <br />
                      <Text type="secondary" className="ppLabels">
                        {row.storeCount}/{this.context.skuData.totalStoreCount}{" "}
                        Stores
                      </Text>
                    </Col>

                      <Col span={8}>
                        {this.context.isPerformanceDataLoaded === true ? (
                            <Fragment>
                              <Row align = "middle" justify="start" gutter={[8,0]}>
                              <Col><Text className="ppLabels">Sales</Text></Col>
                              <Col >
                                <Row type="flex" align = "middle" gutter={[4,0]}>
                                  <Col>
                                    <Text style={{marginRight:"4px"}} strong>{row.rawSales?CompUtil.formatMuMdPrice(row.rawSales,true):"N/A"}</Text>
                                    <Text className={CompUtil.findCompDataUpOrDown(row.compSales)}>
                                  {CompUtil.formatCompData(row.compSales)}{" "}</Text>
                                  </Col>
                                  <Col>{CompUtil.isCompDataAvailable(row.compSales) ? CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(row.compSales),{ className:"ppIcon"}) : <Text/>}</Col>
                                </Row>
                              </Col>
                            </Row>
                              <Row align ="middle" justify="start" gutter={[8,0]}>
                                <Col> <Text className="ppLabels">Units</Text></Col>
                                <Col>
                                  <Row type="flex" align = "middle" gutter={[4,0]}>
                                    <Col>
                                      <Text style={{marginRight:"4px"}} strong>{row.rawUnits?formatNumberToCompact(row.rawUnits):"N/A"}</Text>
                                      <Text className={CompUtil.findCompDataUpOrDown(row.compUnits)}>
                                        {CompUtil.formatCompData(row.compUnits)}{" "}</Text>
                                    </Col>
                                    <Col>{CompUtil.isCompDataAvailable(row.compUnits) ? CompUtil.getArrowUpDownComponent(CompUtil.findPercentageUpOrDown(row.compUnits),{ className:"ppIcon"}) : <Text/>}</Col>
                                  </Row>
                                </Col>
                              </Row></Fragment>
                        ) : (
                                <UXSpin />
                            )}

                      </Col>

                    {/*    <Col span={6}>   <Text strong className={CompUtil.findCompDataUpOrDown(row.compSales)}>{CompUtil.formatCompData(row.compSales)} <Icon type={CompUtil.findPercentageUpOrDown(row.compSales)} /></Text>*/}
                    {/*      <Text strong className={CompUtil.findCompDataUpOrDown(row.compUnits)}>{CompUtil.formatCompData(row.compUnits)} <Icon type={CompUtil.findPercentageUpOrDown(row.compUnits)} /> </Text>*/}
                    {/*</Col> */}
                    <Col span={5}>
                      {row.endsOn ? (
                        <Text className="ppLabels" type="primary">
                          {row.endsOn}{" "}
                        </Text>
                      ) : null}
                      <br />
                      {row.disasterCount > 0 ? (
                        <Text type="primary" className="ppLabels">
                          {row.disasterCount} Disasters
                        </Text>
                      ) : null}
                    </Col>
                    <Col span={2}>
                      <RightOutlined style={{ marginTop: "14px", float: "right" }} />
                    </Col>
                  </Row>
                </div>
              );
            }) : this.props.rows && <Fragment>
              <Row justify="center" align="middle" type="flex">
                <Col className="noKVI">
                  {SvgUtil.getNoData()}
                </Col>
              </Row>
              <Row justify="center" align="middle" type="flex" style={{paddingTop: "10px" }}>
                <Col>
                  <Text className="no-kvi">
                    Applied Filters have removed all Price
                  </Text>
                </Col>
              </Row>
              <Row justify="center" align="middle" type="flex">
                <Col>
                  <Text className="no-kvi">
                    Points for this SKU
                  </Text>
                </Col>
              </Row>
              <Paragraph/>
              <Row justify="center" align="middle" type="flex">
              <Button className="modal-submit-button buttonGroup" key="submit" type="primary" size="large"
                     onClick={()=>this.context.updateFilterSelection(this.props.defaultMapFilterValues)}>
                Clear Filters
              </Button>
              </Row></Fragment>}
          </div>
        )}
      </MapContext.Consumer>
    );
  }
}
