import React, { Component } from 'react';
import { Divider, Drawer, Layout, Alert} from 'antd';
import './SkuDetailComponent.scss';
import SkuCard from './SkuCard/SkuCard';
import PricePoints from './PricePoints/PricePoints';
import {isMobile} from "react-device-detect";
import SkuContext from "../../context/SkuContext";
import FilterUtil from "../Utils/FilterUtil";
import VendorDisplayText from '../Pages/SkuPages/VendorDisplayText';
import {dcsFormatter} from '../Utils/CommonUtil';

const { Content } = Layout;
export default class SkuDetailComponent extends Component {
    static  contextType = SkuContext;
    render() {
        let pricePointRowDetails = this.props.pricePointRowDetails;
        let allowedRows = Object.keys(pricePointRowDetails.rows).length > 0?Object.values(pricePointRowDetails.rows).filter(k=>k.isAllowed):"";
        return (
            <Drawer
                placement='left'
                closable={false}
                keyboard={true}
                open={this.props.isOpen}
                style={{zIndex:'auto',marginTop:'144px',}}
                width={isMobile ? 560 : 540}
                className='sku-detail-drawer'
                mask={false}
            >
                <Content>
                    {FilterUtil.checkIfFilterIsApplied(this.props.defaultMapFilterValues, this.context.filterValues, ["selectedCompetitors", "isMapClusteringChecked"]) &&
                        <Alert className="filter-alert" showIcon message="Filters are applied to the results below" type="warning" closeText="Clear Filters" banner  onClose={()=>this.context.updateFilterSelection(this.props.defaultMapFilterValues)} />
                    }
                    <SkuCard
                        showFavIcon ={true}
                        skuVendors = {<VendorDisplayText multiVendorList={this.props.multiVendorList}
                                                         dcsTitle = {dcsFormatter(this.context.skuData.departmentNumber,
                                                                    this.context.skuData.classNumber, this.context.skuData.subClassNumber)}
                                                         getAllSkusforDCSView={this.props.getAllSkusforDCSView}
                                                         selectedType={"inStore"}
                                                         isSmall={true}
                                                         trackEventTitle={"INSTORE_SKU_VIEW_PAGE"}/>}
                        //  skuStorePerformanceData={this.context.skuStorePerformanceData}
                        isPerformanceDataLoaded={this.props.isPerformanceDataLoaded}
                        getAllSkusforDCSView={this.props.getAllSkusforDCSView}
                    />
                    <Divider className="dividerNoGap" />
                    <PricePoints 
                        onPricePointRowClick={this.props.onPricePointRowClick}
                        acrossStoreCount={pricePointRowDetails.acrossStoreCount}
                        defaultMapFilterValues={this.props.defaultMapFilterValues}
                        pricePointCount={pricePointRowDetails.pricePointCount}
                        rows={allowedRows}
                        userId={this.props.userId}
                    />
                 </Content>
            </Drawer>
        );
    }
}