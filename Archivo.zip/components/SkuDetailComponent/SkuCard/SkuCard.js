import React, { Component,Fragment } from "react";
import {Row, Col, Typography, Space, Tooltip} from 'antd';
import "./SkuCard.scss";
import SkuContext from "../../../context/SkuContext";
import CompUtil from "../../Utils/CompUtil";
import NoSkuImage from "./no-sku-image.jpg";
import UXImage from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXImage";
import { UXSpin } from "../../GlobalComponents/GlobalReactComponents/UXComponents/UXSpin";
import FavoriteButton from "../../Header/Favorites/FavoriteButton";
import {dcsFormatter, formatNumberToCompact} from '../../Utils/CommonUtil';
import {trackEvent} from '../../Utils/mixpanel';

const { Text } = Typography;
export default class SkuCard extends Component {
  static contextType = SkuContext;

  LastRow = (props) => {
    return (<Fragment>
      <Row type="flex" justify="start" align="middle">
        <Col>{props.objectHeading}</Col>
      </Row>
      <Row type="flex" justify="start" align="middle">
        <Col>{props.objectValue}</Col>
      </Row>
    </Fragment>);
  };


  render() {
    let skuNumber = this.props.skuNumber
        ? this.props.skuNumber
        : this.context.skuNumber;
    let skuRank = this.props.skuRank
        ? this.props.skuRank 
        : this.context.skuRank;
    let skuDescription = this.props.skuDescription
        ? this.props.skuDescription
        : this.context.skuDescription;
    let skuVendors = this.props.skuVendors
        ? this.props.skuVendors
        : this.context.skuVendors;
    let skuImageUrl = this.props.skuImageUrl
        ? this.props.skuImageUrl
        : this.context.skuImageUrl;
    // let skuCompSales = this.props.skuCompSales
    //     ? this.props.skuCompSales
    //     : this.context.skuCompSales;
    // let skuCompUnits = this.props.skuCompUnits
    //     ? this.props.skuCompUnits
    //     : this.context.skuCompUnits;
    let skuCompSalesUnit = this.props.inStorePerfData
        ? this.props.inStorePerfData
        : this.context.inStorePerfData;


    let dailyISS = this.props.dailyISS
        ? this.props.dailyISS
        : this.context.dailyISS;

    //let compSalesUpOrDown = CompUtil.findPercentageUpOrDown(skuCompSales);
    //let compUnitsUpOrDown = CompUtil.findPercentageUpOrDown(skuCompUnits);
    //let compSales = CompUtil.formatCompData(skuCompSales);
    //let compUnits = CompUtil.formatCompData(skuCompUnits);
    //let skuDetailSpan = this.props.isBackArrow ? [2, 4, 17, 1]: [0, 6, 17] ;
    let skuDetailSpan = this.props.showFavIcon ? [0,6, 17, 1]:[0, 6, 17];
    let lastRowSpan = this.props.showFavIcon ? [4,8,7,5]:[8,8,8];
    let dcsTitle = dcsFormatter(this.context.skuData.departmentNumber,
        this.context.skuData.classNumber, this.context.skuData.subClassNumber);

    const compsAndUnitsFormatter = ( prefix, currentYearValue, currentYearPer) => {
      let compOrUnitValue = CompUtil.findPercentageUpOrDown(currentYearPer);
      let compOrUnitAmt = formatNumberToCompact(currentYearValue);
      return (
              <Row justify="start" align="middle" gutter={[8, 0]}>
                {currentYearValue && !isNaN(currentYearValue) &&
                <Col>
                  {compOrUnitAmt ?
                  <Text className="skucard-property">
                    {prefix}{compOrUnitAmt}
                  </Text>: "N/A"}
                </Col>}
                {!currentYearPer && currentYearPer !== "" ? <UXSpin/> :
                <Col>
                  {compOrUnitValue ?
                  <Text className={compOrUnitValue && 'comp-units-' + compOrUnitValue}>
                    {CompUtil.formatPrice(CompUtil.formatCompData(currentYearPer))}{" "}
                    {CompUtil.getArrowUpDownComponent(compOrUnitValue)}
                  </Text>: "N/A"}
                </Col>}
              </Row>
      );
    };

    const TopSKUTooltip = () =>{
      return (
          <Tooltip arrowPointAtCenter title = {info} placement ='right' color="#ffffff"
                   overlayClassName="cpi-tooltip-arrow"
                   overlayInnerStyle={{
                       padding: '20px',
                       width: '250px',
                       height: '240px',
                       marginLeft: '0px',
                   }}
          >
             <div className="top-skus">
                    <span className="trophy-icon" >
                        { skuRank <= 20000 ? 
                         <img
                            className="top20K-trophy"
                            src={require("../../../images/top20KTrophyIcon.svg").default}
                        />
                        :
                        <img
                            className="top100K-trophy"
                            src={require("../../../images/top100KTrophyIcon.svg").default}
                        />
                        }
                    </span>
              </div>
          </Tooltip>
      )
  };

  const info = () => {
      return (
          <>
              <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>{skuRank <= 20000 ? "Top 20K SKU" : "Top 100K SKU"}</p>
              <p style={{color: 'black', textAlign: 'left' , fontWeight: 'bold'}}>Rank: { skuRank}</p>
              <p style={{color: 'black', marginTop: '-5px'}}>Based on annual R12 enterprise (online and in-store) sales, this SKU is within the top {skuRank < 20000 ? "20,000" : "100,000"} across The Home Depot USA. Top SKUs are updated quarterly.</p>
           </>
      )
  }

    return (
        <div>
          <Row className="skuCardRow" type="flex" align="middle">
            {/* { this.props.isBackArrow ?
            (
              <MapContext.Consumer>
                {mapState => (
                  <Col span={2}>
                    <Icon
                      style={{ fontSize: "20px", color: "black" }}
                      className="backArrow"
                      type="arrow-left"
                      onClick={e => {
                        mapState.resetState();
                        this.context.resetState();
                        this.props.toggleDashboardView();
                      }}
                    />
                  </Col>SkuDeta
                )}
              </MapContext.Consumer>
            )
            : null
          } */}
            <Col
                span={skuDetailSpan[1]}
                style={{ textAlign: "center" }}
                className="productImageCont"
            >
              {skuImageUrl === "no-sku-image" ?
                  (<UXImage imageUrl={NoSkuImage} classNames="productImage" />)
                  :
                  (<UXImage imageUrl={skuImageUrl} classNames="productImage" />)
              }
            </Col>
            <Col span={17}>
              <Row style={{ paddingLeft: "12px" }}>
                {this.props.showFavIcon ?
                    <a type="link" style={{color:"#286fad"}} onClick={()=> {this.props.getAllSkusforDCSView(dcsTitle);trackEvent("CLICKED_DCS_FROM_INSTORE_SKU_VIEW_PAGE",{"dcs":dcsTitle})}} >{dcsTitle}</a> : <Text type="secondary">{`${dcsTitle}`}</Text>} {/*eslint-disable-line*/}
                <Text style={{ paddingLeft: "12px" }} type="secondary">{`SKU ${skuNumber}`}</Text>
                <Row style={{ paddingLeft: "5px" }}>
                <Col className="topSkuIcon">
                  <Text>{skuRank ? <TopSKUTooltip/> : null}</Text>
                </Col>
              </Row>
                </Row>
              <Row style={{ paddingLeft: "12px" }}>
                <Col  span={this.props.retail ? 18 : 23}>
                  {React.isValidElement(skuVendors)?skuVendors:
                  <Text className="sku-card-skuVendorName">
                    {skuVendors?skuVendors.toUpperCase():skuVendors}
                  </Text>
                }</Col>
                { this.props.retail ?
                    (
                        <Col span={6}>
                          <Text className="productPrice">${this.props.retail}</Text>
                        </Col>
                    )
                    : null
                }
              </Row>
              <Row style={{ paddingLeft: "12px" }}>
                <Col className="textShortener" >
                  <Text className="sku-card-skuProductName">{skuDescription}</Text>
                </Col>
              </Row>
            
              {/* <Row span={24} style={{ padding:"15px"}} type="flex">
                            <Col><Text strong>{this.context.skuFiscalWeek}</Text><Text type="secondary">Fiscal Week</Text></Col>
                            <Col><Text strong>{this.context.skuCompSales}</Text><Text type="secondary">Comp Sales</Text></Col>
                            <Col><Text strong>{this.context.skuCompUnits}</Text><Text type="secondary">Comp Units</Text></Col>
                        </Row> */}
              {this.props.isZoneModalOpen && !this.props.isSalesModal ? (
                  <Row type="flex" gutter={20} className="storeModalDetailsCont">
                    <Col>
                      <Text type="secondary">Department &nbsp; </Text>{" "}
                      <Text className="storeModalDM">
                        {" "}
                        {this.context.skuData.departmentNumber}
                      </Text>
                    </Col>
                    <Col span={2} />
                    <Col>
                      <Text type="secondary">Class &nbsp; </Text>{" "}
                      <Text className="storeModalDM">
                        {this.context.skuData.classNumber}
                      </Text>
                    </Col>
                    <Col span={2} />
                    <Col>
                      <Text type="secondary">Subclass &nbsp; </Text>{" "}
                      <Text className="storeModalDM">
                        {" "}
                        {this.context.skuData.subClassNumber}
                      </Text>
                    </Col>
                  </Row>
              ) : null}
            </Col>
            {this.props.showFavIcon &&(
                <Col span={skuDetailSpan[3]}>
                  <FavoriteButton />
                </Col>
            )}
          </Row>
          {!this.props.isZoneModalOpen ? (
              <Row
                  span={24}
                  style={{ textAlign: "center" }}
                  className="regContainer"
                  type="flex"
                  justify="space-around"
              >

                <Col>
                  <this.LastRow
                      objectValue={<Text className="skucard-property">{dailyISS !== "-" ? `${dailyISS}%` : dailyISS}</Text>}
                      objectHeading={<Text className="skuCardLabels" type="secondary">ISS%</Text>}
                  />
                </Col>

                <Col>
                  <this.LastRow
                      objectValue={this.context.isPerformanceDataLoaded === true
                          ? (
                              <Space>
                                  {compsAndUnitsFormatter('$',skuCompSalesUnit.totalThisYearSales,skuCompSalesUnit.totalCompPercentage)}
                              </Space>
                          ) : (
                              <UXSpin />
                          )}
                      objectHeading={ <Text className="skuCardLabels" type="secondary">
                        Sales
                      </Text>}
                  />
                </Col>

                <Col>
                  <this.LastRow
                      objectValue= {this.context.isPerformanceDataLoaded === true ? (
                          <Space>
                            {compsAndUnitsFormatter(null,skuCompSalesUnit.totalThisYearUnits,skuCompSalesUnit.totalUnitsPercentage)}
                          </Space>
                      ) : (
                          <UXSpin />
                      )}
                      objectHeading={<Text className="skuCardLabels" type="secondary">
                        Units
                      </Text>}
                  />
                </Col>

                {(this.props.showFavIcon && this.context.skuData.mostCommonRetails) && <Col span={lastRowSpan[3]}>
                  <this.LastRow
                      objectValue={ <Text className="skucard-property">
                        ${CompUtil.formatPrice(Number.parseFloat(this.context.skuData.mostCommonRetails[0]))}
                      </Text>}
                      objectHeading={ <Text className="skuCardLabels" type="secondary">
                        Most Common
                      </Text>}
                  />
                </Col>}
              </Row>
          ) : null}

          {/*<Row >*/}
          {/*    <Col span={8}>*/}
          {/*        <Text strong>{this.props.skuStorePerformanceData.fiscalWeek ? this.props.skuStorePerformanceData.fiscalWeek: null}</Text><br />*/}
          {/*        <Text type="secondary">Last Week</Text>*/}
          {/*    </Col>*/}
          {/*    <Col span={8}>*/}
          {/*        <Text strong><CompFormatter value={this.props.skuStorePerformanceData.skuCompData?this.props.skuStorePerformanceData.skuCompData["compUnits"]:null}  isPerformanceDataLoaded = {this.props.isPerformanceDataLoaded}/></Text><br />*/}
          {/*        <Text type="secondary">Sales $ Comp</Text>*/}
          {/*    </Col>*/}
          {/*    <Col span={8}>*/}
          {/*        <Text strong><CompFormatter value={this.props.skuStorePerformanceData.skuCompData?this.props.skuStorePerformanceData.skuCompData["compSales"]:null} isPerformanceDataLoaded = {this.props.isPerformanceDataLoaded} /></Text><br />*/}
          {/*        <Text type="secondary">Unit Comp</Text>*/}
          {/*    </Col>*/}

          {/*</Row>*/}
        </div>
    );
  }
}

// const CompFormatter = (props) => {
//     if(props.isPerformanceDataLoaded){
//       return <span style={{fontWeight:600,fontSize:'14px'}}>{isNaN(props.value)?"-":props.value +"%"}<i className={findPercentageUpOrDown(props.value)}/></span>

//     }
//     else {
//       return null;
//     }
//    };

//   const findPercentageUpOrDown = (value) => {
//     let className = "";
//     if (!isNaN(value)) {
//       className = value > 0 ? "icon_arrow-up" : "icon_arrow-down";
//     }
//     return className;
//   };
