import React, { Component } from 'react';
import {Col, Row, Button, PageHeader} from "antd";
import PropTypes from 'prop-types';
import './SearchBarLayout.scss';
import SkuContext from "../../context/SkuContext";
import FilterUtil from "../Utils/FilterUtil";
import { trackEvent } from '../Utils/mixpanel'
import HeaderCrumbs from "../GlobalComponents/HeaderCrumbs/HeaderCrumbs";


export default class SearchBarLayout extends Component {

  static contextType = SkuContext;

  handleClickingMapFiltersButton = (e) => {
    trackEvent("CLICKED_MAP_FILTERS_BUTTON");
    this.props.toggleFilterView(e)
  }

  render() {
    return (
        <PageHeader className="subHeader sku-info-page-header" ghost={false}>
        <Row align="middle" >
          <Col span={12}>
            <HeaderCrumbs headerData={this.props.headerData} backArrowClick={this.props.backToSkuDetails}/>
          </Col>
          <Col span={12}> <Row justify="end" align="middle">
            <Col>
              {FilterUtil.checkIfFilterIsApplied(this.props.defaultMapFilterValues, this.context.filterValues, []) ?
                <Button className="buttonGroup clearFilters" size="large" type="link" key="back"
                        onClick={() => this.context.updateFilterSelection(this.props.defaultMapFilterValues)} >Clear Filters</Button> : null}
            </Col>
            <Col>
              <Button onClick={e => this.handleClickingMapFiltersButton(e)} ghost='true' type='primary' size='large'>
                <i className="material-icons icon-padding">{this.props.isFilterOpen ? "close" : "tune"}</i>
                Map Filters
              </Button>
            </Col>
          </Row>
          </Col>
        </Row>
        </PageHeader>
    );
  }
}

SearchBarLayout.propTypes = {
  toggleFilterView: PropTypes.func.isRequired,
  isFilterOpen: PropTypes.bool.isRequired,
};
