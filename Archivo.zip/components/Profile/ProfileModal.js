import React, {Component} from 'react';
import { Row, Col, Typography, Modal, Input, Select} from 'antd';
import SkuContext from "../../context/SkuContext";
import "./ProfileModal.scss";
import ProfileUtil from "../Utils/ProfileUtil";
import MapContext from "../../context/MapContext";
import DCSUtil from "../Utils/DCSUtil";


const {Text} = Typography;
const { Option } = Select;

export default class ProfileModal extends Component {
  static contextType = SkuContext;
  dcs = this.context.profileData.subClassDetails;
  state = {
    title:this.context.profileData.title,
    deptNumber : Number.parseInt(this.dcs.split("-")[0]),
    classNumber : Number.parseInt(this.dcs.split("-")[1]),
    subclassNumber: Number.parseInt(this.dcs.split("-")[2])
  };

  updateProfile=()=>{
    this.context.updateShowDimmer(true);
    this.props.resetDashboardView();
    this.props.onClose();
    this.props.updateUserProfileData(this.state.title,DCSUtil.getHyphenatedDCS(this.state.deptNumber,this.state.classNumber,this.state.subclassNumber),this.props.userProfile);
    //this.props.updateUserProfileAndReadDashboardData(this.state.title,DCSUtil.getHyphenatedDCS(this.state.deptNumber,this.state.classNumber,this.state.subclassNumber),this.props.userProfile);

  };

  isSaveButtonEnabled = () => {
    if(this.state.classNumber === 0 ){
      return true;
    }else if((DCSUtil.getHyphenatedDCS(this.state.deptNumber,
      this.state.classNumber,
      this.state.subclassNumber) === this.dcs) && this.state.title === this.context.profileData.title) {
        return true;
      }else{
        return false;
      }
  };

  render() {
    let title = this.state.title;
    let name = ProfileUtil.getFirstName(this.props.userProfile) + ' ' + ProfileUtil.getLastName(this.props.userProfile);
    let initials= this.context.profileData.firstName ? this.context.profileData.firstName.substring(0,1) + this.context.profileData.lastName.substring(0,1) : '';
    return (
        <MapContext.Consumer>
          {mapState => (
        <Modal
            className="profileModal"
            title = "Profile"
            open={this.props.isOpen}
            onCancel={this.props.onClose}
            destroyOnClose={true}
            okButtonProps={{ size: 'large',disabled:this.isSaveButtonEnabled()}}
            cancelButtonProps={{size: 'large' }}
            okText="Save Changes"
            cancelText="Cancel"
            onOk={()=>{mapState.resetState();this.updateProfile();}}

        >
          <Row type="flex" justify="center" align="middle" gutter={[0,8]} style={{marginBottom: "8px"}}> <Col><div className="badge">{initials ? initials : ''}</div></Col></Row>
          <Row type="flex" justify="center" align="middle" gutter={[0,2]} style={{marginBottom: "2px"}}> <Col><Text className="profileName">{name}</Text></Col></Row>
          <Row type="flex" justify="center" align="middle" gutter={[0,2]} style={{marginBottom: "2px"}}> <Col><Text type="secondary">LDAP {this.props.userProfile.userId}</Text></Col></Row>
          <div className="profileInfoArea">
          <Row type="flex" justify="start" align="middle" gutter={[0, 8]} style={{marginBottom: "8px"}}>
            <Col><Text style={{ fontSize: '16px' }}>Position</Text></Col></Row>
          <Row type="flex" justify="start" align="middle" gutter={[0, 16]} style={{marginBottom: "16px"}}><Col span={24}><Select
              size="large"
              defaultValue={title}
              style={{ width: "100%" }}
              onChange={(value) => this.setState({ title: value })}>
            {ProfileUtil.userPositionList.map(titleLabel =>
                (<Option key={titleLabel} value={titleLabel} >{titleLabel}</Option>))}
          </Select>
          </Col>
          </Row>

          <Row type="flex" justify="start" align="middle" gutter={[0, 8]} style={{marginBottom: "8px"}}>
            <Col ><Text style={{ fontSize: '16px' }}>Email</Text></Col></Row>
          <Row type="flex" justify="start" align="middle" gutter={[0, 22]} style={{marginBottom: "22px"}}><Col span={24}><Input size="large" disabled={true} placeholder={this.props.userProfile.email} style={{ width: "100%" }}></Input></Col></Row>


          <Row align="middle" type="flex" gutter={[30, 20]} style={{marginBottom: "20px"}}>
            <Col className="modalHeaderTextCont">
              <Text type="storeName">My Product Hierarchy</Text>
            </Col>
          </Row>
          {/* <Row align="left" style={{ marginBottom: "18px", marginTop: "18px" }} type="flex" gutter={[40, 0]}>
            <Col span={24}>
              <Row type="flex">
                <Col className="modalHeaderTextCont">
                   <Text type="storeName">My Product Hierarchy</Text>
                </Col>
              </Row>
            </Col>
          </Row> */}


            <Row type="flex" justify="space-between" align="middle" gutter={[16, 20]} style={{marginBottom: "20px"}}>
              <Col span={12}>
                <Row gutter={[0, 8]} style={{marginBottom: "8px"}}>
                  <Col><Text style={{ fontSize: '16px' }}>Department</Text></Col></Row>
                <Row>
                  <Col span={24}><Select
                  size="large"
                      showSearch
                      placeholder={"Select Department"}
                      style={{ width: "100%" }}
                      optionFilterProp="children"
                      value={this.state.deptNumber === 0?[]: this.state.deptNumber}
                      onChange={(value) => this.setState({ deptNumber: value, subclassNumber:0,classNumber:0 })}
                      filterOption={(input, option) =>
                          option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                      }
                  >
                    {DCSUtil.getDeptDropdownData(this.context.dcsDataMap)}
                  </Select>
                  </Col>
                </Row>
              </Col>
              <Col span={12}>
                <Row gutter={[0,8]} style={{marginBottom: "8px"}}>
                  <Col><Text style={{ fontSize: '16px' }}>Class</Text></Col></Row>
                <Row>
                  <Col span={24}><Select
                      size="large"
                      showSearch
                      disabled={this.state.deptNumber === 0}
                      placeholder={"Select Class"}
                      style={{ width: "100%" }}
                      optionFilterProp="children"
                      value = {this.state.classNumber === 0? []:this.state.classNumber}
                      onChange={(value) => this.setState({ classNumber: value,subclassNumber:0 })}
                      filterOption={(input, option) =>
                          option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                      }
                  >
                    {DCSUtil.getClassDropdownData(this.context.dcsDataMap,this.state.deptNumber)}
                  </Select>
                  </Col>
                </Row>
              </Col>
            </Row>
            <Row gutter={[0,8]} style={{marginBottom: "8px"}}>
              <Col><Text style={{ fontSize: '16px' }}>Sub Class</Text></Col></Row>
            <Row type="flex" justify="start" align="middle" gutter={[0, 8]} style={{marginBottom: "8px"}}><Col span={24}>
              <Select
                size="large"
                showSearch
                disabled={this.state.classNumber === 0}
                placeholder={"Select Subclass"}
                style={{ width: "100%" }}
                optionFilterProp="children"
                value = {this.state.subclassNumber === 0? []: this.state.subclassNumber}
                onChange={(value) => this.setState({ subclassNumber: value })}
                filterOption={(input, option) =>
                    option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
            >{
              DCSUtil.getSubClassDropdownData(this.context.dcsDataMap,this.state.deptNumber,this.state.classNumber)
            }
            </Select>
            </Col>
            </Row>
          </div>
        </Modal>)}
        </MapContext.Consumer>
    );
  }
}
