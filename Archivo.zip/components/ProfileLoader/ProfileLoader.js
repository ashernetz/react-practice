import React, {Component,Fragment} from 'react';
import SkuContext from "../../context/SkuContext";
import UserProfileModal from '../DashboardDrawer/UserProfileModal/UserProfileModal';
import ProfileModal from '../Profile/ProfileModal';
import PriceDataServices from "../../services/PriceDataServices";
import AlertUtil from "../Utils/AlertUtil";

const defaultState =  {
    isUserProfileModalOpen:false,
};

export default class ProfileLoader extends Component {
    static contextType = SkuContext;
     state =  defaultState;

    componentDidMount () {
        this.context.updateShowDimmer(true);
        PriceDataServices.getSubDepartments().then(subDepartmentDetails => {
          let subDeptDataMap = {};
          subDepartmentDetails.data.productStructureResponse.resultSet[0].merchandiseSubDepartment.forEach(subDeptData=>{
            let deptClassMap = new Map();
           let subDepartment = subDeptData.merchandiseClassCategoryId.toString().trim();
            let subDepartmentName = subDeptData.shortMerchandiseClassCategoryDescription.toString().trim();
            let longDescription = subDeptData.merchandiseClassCategoryDescription.toString().trim();
            if(subDeptData.hasOwnProperty("merchandiseDepartment")) {
              subDeptData.merchandiseDepartment.forEach(deptClassData => {
                let departmentNumber = Number.parseInt(
                    deptClassData.merchandiseDepartmentNumber);
                let classNumber = Number.parseInt(
                    deptClassData.merchandiseClassNumber);
                if (!deptClassMap.has(departmentNumber)) {
                  deptClassMap.set(departmentNumber, []);
                }
                deptClassMap.get(departmentNumber).push(classNumber);
              });
            }
            subDeptDataMap[subDepartment] = {
              name: subDepartment.replace(/^0+/, "")+"-"+subDepartmentName,
              deptClassMap,
              description:subDepartmentName,
              longDescription
            }

          });
          PriceDataServices.getSubclassDetails().then(subClassDetails => {
            let dcsDataMap = new Map();

            subClassDetails.data.productStructureResponse.resultSet[0].merchandiseSubordinateClass.forEach(subclassObj => {

              let departmentNumber = Number.parseInt(subclassObj.merchandiseDepartmentNumber) ;
              let classNumber = Number.parseInt(subclassObj.merchandiseClassNumber);
              let subClassNumber = Number.parseInt(subclassObj.merchandiseSubordinateClassNumber);
              let dcs =  departmentNumber + " | " + classNumber  + " | " +
                  subClassNumber + " - " +
                  subclassObj.merchandiseSubordinateClassDescription;
              if(!dcsDataMap.has(departmentNumber)) {
                dcsDataMap.set(departmentNumber,new Map(
                    [
                      ["name", departmentNumber + "-" + subclassObj.shortDepartmentName],
                      ["classes", new Map()],
                      ["description", subclassObj.shortDepartmentName.toString().trim()],
                      ["longDescription", subclassObj.departmentName.toString().trim()]
                    ]));
              }
              let classesObject = dcsDataMap.get(departmentNumber).get("classes");
              // console.log(subclassObj)
              if(!classesObject.has(classNumber)) {
                classesObject.set(classNumber, new Map([
                    ["name",departmentNumber + " | " + classNumber + "-" + subclassObj.shortMerchandiseClassDescription],
                    ["subclasses", new Map()],
                    ["description", subclassObj.shortMerchandiseClassDescription.toString().trim()],
                    ["longDescription", subclassObj.merchandiseClassDescription.toString().trim()]
                ]));
              }
              // console.log(classesObject)

              let subClassesObject = classesObject.get(classNumber).get("subclasses");
              subClassesObject.set(subClassNumber, new Map([
                  ["name",dcs],
                  ["description",subclassObj.merchandiseSubordinateClassDescription.toString().trim()],
                  ["longDescription",subclassObj.merchandiseSubordinateClassDescription.toString().trim()]
              ]));


            });
            this.context.updateStateFields({dcsDataMap,subDeptDataMap});
            this.readUserProfile();

          }).catch(e => {
              let alertMessage = AlertUtil.getErrorMessage("fetching subclass details");
              this.context.updateShowDimmer(false);
              console.log("Error in calling Sub Class service "+ e)
              AlertUtil.showAlert("error", "Error", alertMessage);
          });
        }).catch(e => {
          this.context.updateShowDimmer(false);
          console.log("Error in calling Sub Department service "+ e)});
    }

    updateSelectedDCSKey=(dcsKey) => {
     this.props.updateHeaderData({dcsKey});
    }

    updateProfileData=(response,dcsKey)=>{
      this.context.updateProfileData({
        ...response.data,
        subClassDetails:dcsKey
      });
      //this.props.loadDcsDetails(dcsKey);

    }

  readUserProfile = () => {
        let favSkuMap = {};
        let skuCompMap = {};
      PriceDataServices.readUserProfileDetails(this.props.user.userId).then( response => {
          if(response.status === 200){
            let dcsKey = response.data.departmentNumber + '-' + response.data.classNumber + '-' +response.data.subClassNumber;
            this.updateProfileData(response, dcsKey);
            this.context.updateStateFields({selectedDCS:dcsKey});
            this.context.updateShowDimmer(false);

            this.setState({isUserProfileModalOpen:false});

            PriceDataServices.readFavSkusDetails(this.props.user.userId).then(favSkuResponse => {
            if(favSkuResponse.status === 200) {
              favSkuMap = favSkuResponse.data;
              let skuNumbers = favSkuMap ? Object.keys(favSkuMap) : [];
              if (skuNumbers.length > 0) {
              PriceDataServices.fetchPerformanceDataForSkus(skuNumbers,this.props.user.userId).then(
                  response => {
                    if (response.status === 200) {
                      skuCompMap = response.data;
                      if (skuNumbers.length > 0) {
                        skuNumbers.forEach(sku => {
                            let isPresent = skuCompMap.hasOwnProperty(sku);
                          favSkuMap[sku].netUnitsComp = isPresent ? skuCompMap[sku].netUnitsComp : 0;
                          favSkuMap[sku].netSalesComp = isPresent ? skuCompMap[sku].netSalesComp : 0;
                          favSkuMap[sku].rawSales = isPresent ? skuCompMap[sku].rawSales : 0;
                          favSkuMap[sku].rawUnits = isPresent ? skuCompMap[sku].rawUnits : 0;
                        });
                      }
                      this.context.updateStateFields({favSkuMap,skuCompMap});
                    }
                  }).catch(resp => {
                this.context.updateStateFields({favSkuMap});
                console.log(resp);
              })
            }}
            }).catch(k => {
            console.log(k);
            });
          }else {
            this.context.updateShowDimmer(false);
          }
        }).catch(k => {
            this.context.updateShowDimmer(false);
            let alertMessage = AlertUtil.getErrorMessage(
                "fetching user profile data");
            if (k.response.status === 422 && k.response.data.includes(
                "No user profile exists for the given userId")) {
              this.setState({isUserProfileModalOpen: true});
            } else {
              console.log(k);
              AlertUtil.showAlert("error", "Error", alertMessage);
                  }
      });
      };

      updateUserProfileData= (title,dcs,userProfile)=> {
        if(window.location.pathname === "/ZoneControl"){
          this.context.updateShowDimmer(false);
        }else{
          this.context.updateShowDimmer(true);
        }
        PriceDataServices.updateUserProfileData(title,dcs,userProfile).then( response => {
          if(response.status === 200){
            let dcsKey = response.data.departmentNumber + '-' + response.data.classNumber + '-' +response.data.subClassNumber;
            this.context.updateStateFields({selectedDCS:dcsKey});
            this.context.updateProfileData({
              ...response.data,
              subClassDetails: dcsKey
            });
            //this.props.loadDcsDetails(dcsKey);
            this.context.updateShowDimmer(false);

          }else {
            this.context.updateShowDimmer(false);
          }
        }).catch(k => {
          let alertMessage = AlertUtil.getErrorMessage("updating user profile");
          this.context.updateShowDimmer(false);
          console.log(k.response.data);
          AlertUtil.showAlert("error", "Error",alertMessage);
    
        });
      };

  render() {
   
    return (
        <Fragment>

        {this.state.isUserProfileModalOpen ? <UserProfileModal
            readUserProfile={this.readUserProfile}
            user={this.props.user}
            isOpen={this.state.isUserProfileModalOpen}
            onClose={()=> this.setState({isUserProfileModalOpen:false})}
            onOpen={()=> this.setState({isUserProfileModalOpen:true})}/> : null}

        {this.props.isEditProfileOpen ? <ProfileModal
            userProfile={this.props.user}
            resetDashboardView={()=> this.setState(defaultState)}
            updateUserProfileData = {this.updateUserProfileData}
            isOpen={this.props.isEditProfileOpen}
            onClose={()=> 
            this.props.updateHeaderData({isEditProfileOpen:false})
            } />: null} 
      </Fragment>
    );
  }
}