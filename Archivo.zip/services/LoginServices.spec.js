import LoginServices from './LoginServices';
import axios from 'axios';

jest.mock('axios');

describe('LoginServices', () => {

    it('Should loginUser', () => {
        const storeNum = '57';
        const usedName = 'asdfas';
        const response = {
        "THDLogin":{"Authentication":"asdfas"}
        }
        axios.mockResolvedValue(response);
        LoginServices.loginUser(storeNum,usedName,"").then(data => expect(data).toEqual(response));
    });

    it('Should getUserProfileFromToken', () => {
        const response = {"firstName":"aaa","lastName":"asdf","userId":"asdfas","email":"asdfas@homedepot.com","statusCode":0,"roles":{"560":["1","2","3","4"],"561":["1","3","4"]},"accesses":{"isSubmitEnabled":true,"isZoneControlEnabled":true,"dashboard":{"isRead":false,"roleValues":[]}}};
        
        axios.mockResolvedValue(response);
        LoginServices.getUserProfileFromToken().then(data => expect(data).toEqual(response));
    });


    
});