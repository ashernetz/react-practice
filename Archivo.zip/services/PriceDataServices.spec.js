import PriceDataServies from './PriceDataServices';
import axios from 'axios';

jest.mock('axios');

describe('PriceDataServices', () => {
    it('should fetch sku details', () => {
        const skuNum = 439318;
        const skuResponse = [{
            "sku": 439318,
            "totalStoreCount": 2003,
            "skuDescription": "22\" ROUND GABLE VENT-WHITE",
            "pacManSKU": true,
            "skuStoreStatus": {
                "100": "Active",
                "400": "Inactive",
                "500": "Clearance"
            },
            "zoneDetails": {
                "590": {
                    "zoneId": "590",
                    "zoneName": "Mattoon",
                    "storeCount": 1,
                    "storeList": [
                        "1967"
                    ]
                }
            },
            "pricePointDetails": {
                "0.01": {
                    "storeDetails": {
                        "111": {
                        "storeId": 111,
                        "storeName": "Merchants Walk",
                        "address": "4101 ROSWELL RD, MARIETTA, GA 30062",
                        "mktId": 1,
                        "mktName": "1-ATLANTA",
                        "zoneId": "337",
                        "zoneName": "St Thomas,vi",
                        "latitudeNumber": 33.98022,
                        "longitudeNumber": -84.432829,
                        "retail": 0.01,
                        "status": "Clearance",
                        "newLowerPrice": false,
                        "clearance": false,
                        "promotion": false,
                        "instantRebate": false,
                        "skuStoreStatus": 500,
                        "effectiveBeginDate": "2015-08-15",
                        "disaster": false,
                        "bulkRetail": {}
                        }
                    }
                }
            },
            "departmentNumber": 22,
            "classNumber": 3,
            "subClassNumber": 2,
            "storeTempSKU": true,
            "zoneTempSKU": true
        }];
        const resp = skuResponse;
        axios.get.mockResolvedValue(resp);
        
        // or you could use the following depending on your use case:
        // axios.get.mockImplementation(() => Promise.resolve(resp))
        
        PriceDataServies.fetchSkuDetails(skuNum).then(data => expect(data).toEqual(skuResponse));
    });
    it('should fetch getSkuStorePerformance', () => {
        const skuNum = 439318;
        const skuResponse = [{
            "skuNumber": 439318,
            "storeSet": [
                3904
            ],
            "currentYearPerformanceMap": {
                "139": {
                "netRetailSales": 333.71999999999997,
                "netUnitSales": 6
                }
            },
            "lastYearPerformanceMap": {
                "139": {
                "netRetailSales": 0,
                "netUnitSales": 0
                }
            },
            "fiscalWeek": "FW52",
            "skuCompData": {
                "compUnits": 71.43,
                "compSales": 78.4
            }
        }];
        const resp = skuResponse;
        axios.get.mockResolvedValue(resp);

        PriceDataServies.getSkuStorePerformanceData(skuNum).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should fetchPendingPriceChange for PacManSku' , () => {
        const isPacManSku = true;
        const skuNum = 439318;
        const skuResponse = [{
            "skuNumber": 439318,
            "storeDetails": [
            {
                "storeNumber": 8527,
                "currentRetail": 0,
                "previousRetail": 0,
                "pendingRetailAmount": 2.45,
                "pendingRetailBgnTimestamp": "02/08/2020 00:00:00",
                "pendingRetailEndTimestamp": "02/11/2020 23:59:59"
            }]
        }];
        const resp = skuResponse;
        axios.get.mockResolvedValue(resp);
    
        PriceDataServies.getPendingPriceChangeDetails(skuNum, isPacManSku).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should fetch dwSkuPendingPriceChange for non PacManSku', () => {
        const isPacManSku = false;
        const skuNum = 439318;
        const skuResponse = [{
            "skuNumber": 439318,
            "storeDetails": [
            {
                "storeNumber": 8527,
                "currentRetail": 0,
                "previousRetail": 0,
                "pendingRetailAmount": 2.45,
                "pendingRetailBgnTimestamp": "02/08/2020 00:00:00",
                "pendingRetailEndTimestamp": "02/11/2020 23:59:59"
            }]
        }];
        const resp = skuResponse;
        axios.get.mockResolvedValue(resp);
    
        PriceDataServies.getPendingPriceChangeDetails(skuNum, isPacManSku).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should fetchSkuImageSource', () => {
        const skuNum = 439318;
        const url = 'https://images.homedepot-static.com/productImages/e9009c40-9ff3-49d6-a123-6a96d02ae899/svn/ply-gem-gable-vents-%26-louvers-rdgvh04h-64_100.jpg';
        axios.get.mockResolvedValue(url);

        PriceDataServies.fetchSkuImageSource(skuNum).then(data => expect(data).toEqual(url));
    });
    it('Should getVendors', () => {
        const skuNum = 439318;
        const response = [
            'Prime Source'
        ]
        axios.get.mockResolvedValue(response);
        PriceDataServies.getVendors(skuNum).then(data => expect(data).toEqual(response));
    });
    it('Should getThdSkuPriceChangeHistory', () => {
        const skuNum = 439318;
        const skuResponse = {
            "sku": 439318,
            "storePriceChangeMap": {
                "105": [
                    {
                      "changeDate": "12/19/2019",
                      "eventType": "Price Change",
                      "retail": 0.01,
                      "priceChange": "Same"
                    },
                    {
                      "changeDate": "03/14/2019",
                      "eventType": "Price Change",
                      "retail": 0.01,
                      "priceChange": null
                    }
                  ]
            }
        }
        axios.get.mockResolvedValue(skuResponse);
        PriceDataServies.getThdSkuPriceChangeHistory(skuNum).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should getSalesMetrics', () => {
        const skuNum = 439318;
        const skuResponse = {
            "salesMetricBoxPlotList": [
                {
                    "type": "SHELF",
                    "low": 47.87,
                    "high": 55.62,
                    "open": 47.87,
                    "close": 55.62,
                    "mode": 55.62
                }
            ],
            "storeKVIPricePointData": {
                "6155": {
                    "SHELF": 55.62
                },
                "6167": {
                    "SHELF": 55.62
                }
            }
        }
        axios.get.mockResolvedValue(skuResponse);
        PriceDataServies.getSalesMetrics(skuNum).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should getPlanogramInfo' , () => {
        const skuNum = 439318;
        const store = 101;
        const url = '';

        axios.get.mockResolvedValue(url);
        PriceDataServies.getPlanogramInfo(skuNum, store).then(data => expect(data).toEqual(url));

    });
    it('Should getSalesHistory', () => {
        const skuNum = 100088;
        const store = 204;
        const skuResponse = {
            "skuNumber": 100088,
            "store": 204,
            "salesHistoryLastTwelveWeeks": [
                {
                    "fiscalWeek": "FW52",
                    "date": "02/03/2020",
                    "salesAmount": 10.79,
                    "unitSales": 1.0
                },
                {
                    "fiscalWeek": "FW51",
                    "date": "01/27/2020",
                    "salesAmount": 21.58,
                    "unitSales": 2.0
                }
            ],
            "salesHistoryForecast": [
                {
                    "fiscalWeek": "FW12",
                    "date": "04/28/2019",
                    "salesAmount": 21.58,
                    "unitSales": 2.0
                },
                {
                    "fiscalWeek": "FW11",
                    "date": "04/21/2019",
                    "salesAmount": 10.79,
                    "unitSales": 1.0
                }
            ]
        };
        axios.get.mockResolvedValue(skuResponse);
        PriceDataServies.getSalesHistory(skuNum, store).then(data => expect(data).toEqual(skuResponse));
    });
    it('Should executeTempRetailChanges', () => {
        const skuNumber = 100088;
        const retailAmount = 0.02;
        const storeNumber = 245;
        const userId = 'MC62YE';
        const tempRetailBeginDate = "2020-02-07";
        const tempRetailEndDate = "2020-02-08";

        const response= {"RequestId":"14881197"};
        axios.post.mockResolvedValue(response);
        PriceDataServies.executeTempRetailChanges(skuNumber, retailAmount, storeNumber, userId, tempRetailBeginDate, tempRetailEndDate).then(data => expect(data).toEqual(response));
    });
    it('Should getAisleBay', () => {
        const skuNum = 100088;
        const store = 204;
        const response = {"aisleBay":{"searchReport":{"storeId":"204","recordCount":"1"},"storeSkus":{"storeSku":{"storeSkuId":"100088","aisleBayInfo":{"aisle":"35","bay":"002"}}}}};
        axios.get.mockResolvedValue(response);
        PriceDataServies.getAisleBay(skuNum, store).then(data => expect(data).toEqual(response));
    });
    it('Should getOnHandQuantity', () => {
        const skuNum = 100088;
        const store = 204;
        const response = {"204":10020003};
        axios.post.mockResolvedValue(response);
        PriceDataServies.getOHQuantityDetails(skuNum, store).then(data => expect(data).toEqual(response));
    });
    it('Should getUnitsOnHandDetails', () => {
        const skuNum = 100088;
        const store = 204;
        const response = {"204":10};
        axios.post.mockResolvedValue(response);
        PriceDataServies.getUnitsOnHandDetails(skuNum, store).then(data => expect(data).toEqual(response));
    });
    it('Should getSkuVelocity', () => {
        const skuNum = 100088;
        const store = 204;
        const response = 'C';
        axios.get.mockResolvedValue(response);
        PriceDataServies.getSkuVelocity(skuNum, store).then(data => expect(data).toEqual(response));

    });
    it('Should readUserProfileDetails', () => {
        const userId = 'MC62YE';
        const response = {
            "userId": "MC62YE",
            "firstName": "MICHELLE",
            "lastName": "BRADFORD",
            "departmentNumber": 21,
            "classNumber": 1,
            "subClassNumber": 5,
            "title": "Merchant",
            "editFlag": false
        };
        axios.get.mockResolvedValue(response);
        PriceDataServies.readUserProfileDetails(userId).then(data => expect(data).toEqual(response));
    });

    it('Should readPerformersDCSDEtails', () => {
        const dep = 21;
        const classNum = 1;
        const subClass = 5;
        const response = {
            "subClassNumber": 5,
            "departmentNumber": 21,
            "classNumber": 1,
            "fiscalWeek": "FW52",
            "topPerformersSalesMap": {
                "454559": {
                    "skuImage": "https://images.homedepot-static.com/productImages/c554d425-b002-4451-a0e0-f079bfd926d1/svn/hardwood-plywood-454559-64_100.jpg",
                    "vendorName": "Green Forest Products, L",
                    "skuDescription": "3/4\" 4'X8' SANDE PLYWOOD",
                    "netSalesComp": 17.63,
                    "netUnitsComp": 18.22,
                    "skuNumber": 454559
                }
            },
            "bottomPerformersSalesMap": {
                "165921": {
                  "skuImage": "https://images.homedepot-static.com/productImages/8af532d2-a10e-4cf0-b5b7-e95328eebf9e/svn/pbb203750304300-64_100.jpg",
                  "vendorName": "Multiple Vendors",
                  "skuDescription": "3/4\" 4'X8' BIRCH PLYWOOD",
                  "netSalesComp": 14.87,
                  "netUnitsComp": 14.83,
                  "skuNumber": 165921
                }
            },
            "disasterStoreMap": {
                "105": {
                  "storeId": 105,
                  "storeName": "Duluth",
                  "latitudeNumber": 33.947795,
                  "longitudeNumber": -84.131869
                }
            }
        };
            
        axios.get.mockResolvedValue(response);
        PriceDataServies.readPerformersDCSDetails(dep, classNum, subClass).then(data => expect(data).toEqual(response));

    });

    it('Should createUserProfileData', () => {
        const user = {
            userId: 'MC62YE',
            firstName: 'Mechelle',
            lastName: 'Bradford',
        };
        const dcsData = '21-1-2';
        const title = 'Analyst';
        const response = {"userId":"MC62YE","firstName":"MICHELLE","lastName":"BRADFORD","departmentNumber":21,"classNumber":1,"subClassNumber":2,"title":"Merchant Planner","editFlag":false};
        axios.post.mockResolvedValue(response);
        PriceDataServies.createUserProfileData(title, dcsData, user).then(data => expect(data).toEqual(response));

    });
    it('Should updateUserProfileData', () => {
        const user = {
            userId: 'MC62YE',
            firstName: 'Mechelle',
            lastName: 'Bradford',
        };
        const dcsData = '21-1-2';
        const title = 'Analyst';
        const response = {"userId":"MC62YE","firstName":"MICHELLE","lastName":"BRADFORD","departmentNumber":21,"classNumber":1,"subClassNumber":2,"title":"Merchant Planner","editFlag":false};
        axios.post.mockResolvedValue(response);
        PriceDataServies.updateUserProfileData(title, dcsData, user).then(data => expect(data).toEqual(response));
    });
    it('Should getCompetitorPrices', () => {
        let skuNumber = 12345;
        let mockUrl = "mock-url";
        let response = { "competitors": { "3141": [ { "competitorId": 3141, "latitude": 35.38, "locationId": 3, "longitude": -96.93, "name": "Lowe's", "rawPricePennies": 1348, "scaledPricePennies": 1348, "scalingFactor": 1.0, "scrapeDate": "2020-03-06T03:15:08Z", "scrapeType": "assigned", "sku": "5434" }, { "competitorId": 3141, "latitude": 38.95, "locationId": 4, "longitude": -92.29, "name": "Lowe's", "rawPricePennies": 1348, "scaledPricePennies": 1348, "scalingFactor": 1.0, "scrapeDate": "2020-03-05T17:33:27Z", "scrapeType": "actual", "sku": "5434" } ] } };
        axios.get.mockResolvedValue(response);
        PriceDataServies.getCompetitorPrices(skuNumber,mockUrl).then(data => expect(data).toEqual(response));
    });
    it('Should getNearestCompetitorData', () => {
        let skuNumber = 12345;
        let mockUrl = "mock-url";
        let response = {"competitors":{"3141":[{"competitorId":3141,"distanceInMiles":3.24301742889156,"latitude":39.64,"locationId":200,"longitude":-86.12,"name":"Lowe's","rawPricePennies":2105,"scaledPricePennies":2105,"scalingFactor":1.0,"scrapeDate":"2020-03-24T07:17:20Z","scrapeType":"actual","sku":"12227","skuImageUrl":"https://mobileimages.lowes.com/product/converted/081999/081999104504.jpg?size=xl","skuName":"Plytanium 15/32 CAT PS1-09 Square Structural Plywood Pine, Application as 4 x 8","skuUrl":"https://www.lowes.com/pd/Plytanium-15-32-CAT-PS1-09-Pine-Sanded-Plywood-Application-as-4-x-8/3010108","store":442,"storeName":"LOWE'S OF S. INDIANAPOLIS, IN","zipCode":"46227"}],"6488":[{"competitorId":6488,"distanceInMiles":0.385713953351538,"latitude":39.61,"locationId":2181,"longitude":-86.16,"name":"Menards","rawPricePennies":1999,"scaledPricePennies":1999,"scalingFactor":1.0,"scrapeDate":"2020-03-20T19:04:12Z","scrapeType":"actual","sku":"1251023","skuImageUrl":"https://hw.menardc.com/main/items/media/GEORG008/ProductSmall/1251007.jpg","skuName":"4 x 8 BCX Sanded Plywood","skuUrl":"https://www.menards.com/main/building-materials/panel-products/sanded-plywood/4-x-8-bcx-sanded-plywood/1251023/p-1444431327058.htm","store":3169,"storeName":"GREENWOOD","zipCode":"46142"}],"588623":[{"competitorId":588623,"distanceInMiles":21.3628939719569,"latitude":39.9,"locationId":12437,"longitude":-86.07,"name":"FnD","store":203,"storeName":"F&D OF INDIANAPOLIS, IN","zipCode":"46250"}]}}
        axios.get.mockResolvedValue(response);
        PriceDataServies.getCompetitorPrices(skuNumber,mockUrl).then(data => expect(data).toEqual(response));
    });
    it('Should getCompetitorNearestTHDStore', () => {
        let competitorStore = 1858;
        let competitorId = 3141;
        let mockUrl = "mock-url";
        let response = {"competitorId":3141,"competitorStore":1858,"distanceInMiles":2.23547618714117,"thdStore":2676}
        axios.get.mockResolvedValue(response);
        PriceDataServies.getCompetitorNearestTHDStore(competitorStore,competitorId,mockUrl).then(data => expect(data).toEqual(response));
    })
    it('Should getCompetitorPrices', () => {
        let skuNumber = 185812;
        let response = {"competitors":{"3141":[{"cacheerId":"354c4f48-6036-403a-8c75-6b7ab63e8b84","competitorId":3141,"latitude":35.3824,"locationId":3,"longitude":-96.9274,"name":"Lowe's","rawPricePennies":564,"scaledPricePennies":564,"scalingFactor":1.0,"scrapeDate":"2020-06-20T19:34:10Z","scrapeType":"assigned","sku":"6550","skuImageUrl":"http://mobileimages.lowes.com/product/converted/085622/085622001420.jpg?size=pdhi","skuName":"Georgia-Pacific J-channel White 0.625-in x 150-in Vinyl Siding Trim","skuUrl":"https://www.lowes.com/pd/0-625-in-x-150-in-White-J-Channel-Vinyl-Siding-Trim/3037104","sourceScrapeStore":2574,"sourceScrapeStoreName":"LOWE'S OF MIDWEST CITY, OK","store":5,"storeName":"LOWE'S OF SHAWNEE, OK","zipCode":"74804"}]}}
        axios.get.mockResolvedValue(response);
        PriceDataServies.getCompetitorPrices(skuNumber).then(data => expect(data).toEqual(response));
    });
    it('Should addOrRemoveFavoriteSku', () => {
        let skuNumber = 185812;
        let isRemoveSku = true;
        let userId = "asdf4rt";
        let response = {"534172": {
                "skuNumber": 534172,
                "favSkuTimestamp": "06/01/2020 16:39:43",
                "removeFavSku": false
            },}
        axios.get.mockResolvedValue(response);
        PriceDataServies.addOrRemoveFavoriteSku(skuNumber, isRemoveSku, userId).then(data => expect(data).toEqual(response));
    });
    it('Should getContacts', () => {
        let storeNumber = 57;
        let response = {
            "regionalVicePresident": " Richard Goodrich",
            "districtManager": "Uchenna D Opene",
            "storeManager": "Norma L Kinkead",
            "phoneNumber": "770-452-8858"
        }
        axios.get.mockResolvedValue(response);
        PriceDataServies.getContacts(storeNumber).then(data => expect(data).toEqual(response));
    });

    it('Should getThdSkuStorePriceHistory', () => {
        let skuNum = 12345, store = 123, startDate ='2020-09-10' , endDate = '2020-11-22';
        let response = [{"historyDate":"2020-11-22","priceHistory":[{"competitorId":18214,"scaledPricePennies":931,"scalingFactor":1.0}]},{"historyDate":"2020-11-18","priceHistory":[{"competitorId":527,"scaledPricePennies":937,"scalingFactor":1.0}]},{"historyDate":"2020-11-17","priceHistory":[{"competitorId":527,"scaledPricePennies":1064,"scalingFactor":1.0}]},{"historyDate":"2020-11-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-15","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-14","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-05","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-04","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-11-03","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-11-01","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-10-28","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-27","priceHistory":[{"competitorId":18214,"scaledPricePennies":1054,"scalingFactor":1.0}]},{"historyDate":"2020-10-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-13","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-10-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-10-06","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-25","priceHistory":[{"competitorId":18214,"scaledPricePennies":1039,"scalingFactor":1.0}]},{"historyDate":"2020-09-16","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]},{"historyDate":"2020-09-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-11","priceHistory":[{"competitorId":18214,"scaledPricePennies":1066,"scalingFactor":1.0}]},{"historyDate":"2020-09-10","priceHistory":[{"competitorId":18214,"scaledPricePennies":1082,"scalingFactor":1.0}]},{"historyDate":"2020-09-08","priceHistory":[{"competitorId":18214,"scaledPricePennies":1019,"scalingFactor":1.0}]}]
        axios.get.mockResolvedValue(response);
        PriceDataServies.getThdSkuStorePriceHistory(skuNum,store,startDate,endDate).then(data => expect(data).toEqual(response));
    })
});
it('Should getCompetitorSkuLevelPriceHistory', () => {
    let skuNum = 675108 , competitorId = 18214, startDate ='2020-11-09' , endDate = '2020-12-14';
    let response = [{"historyDate":"2020-12-14","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-12-12","priceHistory":[{"competitorId":3141,"scaledPricePennies":1798,"scalingFactor":1.0}]},{"historyDate":"2020-12-10","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-12-09","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-12-08","priceHistory":[{"competitorId":527,"scaledPricePennies":1200,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-12-07","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-12-06","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0}]},{"historyDate":"2020-12-05","priceHistory":[{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-12-04","priceHistory":[{"competitorId":527,"scaledPricePennies":1200,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-12-02","priceHistory":[{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-12-01","priceHistory":[{"competitorId":18214,"scaledPricePennies":1752,"scalingFactor":1.209}]},{"historyDate":"2020-11-30","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0}]},{"historyDate":"2020-11-29","priceHistory":[{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-11-28","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-27","priceHistory":[{"competitorId":18214,"scaledPricePennies":1752,"scalingFactor":1.209}]},{"historyDate":"2020-11-26","priceHistory":[{"competitorId":527,"scaledPricePennies":1200,"scalingFactor":1.0}]},{"historyDate":"2020-11-24","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-11-23","priceHistory":[{"competitorId":527,"scaledPricePennies":1200,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-21","priceHistory":[{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-11-20","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-18","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0}]},{"historyDate":"2020-11-17","priceHistory":[{"competitorId":527,"scaledPricePennies":1200,"scalingFactor":1.0},{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]},{"historyDate":"2020-11-16","priceHistory":[{"competitorId":527,"scaledPricePennies":1524,"scalingFactor":1.0}]},{"historyDate":"2020-11-13","priceHistory":[{"competitorId":527,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-12","priceHistory":[{"competitorId":18214,"scaledPricePennies":null,"scalingFactor":null}]},{"historyDate":"2020-11-09","priceHistory":[{"competitorId":18214,"scaledPricePennies":2175,"scalingFactor":1.209}]}]
    axios.get.mockResolvedValue(response);
    PriceDataServies.getCompetitorSkuLevelPriceHistory(skuNum,competitorId,startDate,endDate).then(data => expect(data).toEqual(response));
});
