import axios from 'axios';

export default class DiscountsService {

    static getDiscounts = (userId, formattedClassName, formattedSubClassName, sellingChannel) => {
        const body = {
            userId,
            formattedClassName,
            formattedSubClassName
        };

        return axios.post('/api/dataConnect/getDiscounts', {body,sellingChannel});
    };

    static getPromoDetails = (userId, formattedClassName, formattedSubClassName, reasonCode) => {
        const body = {
            userId,
            formattedClassName,
            formattedSubClassName,
            reasonCode,
        };

        return axios.post('/api/dataConnect/getPromoDetails', body);
      };

    static getTotalSalesByFiscalWeek = (userId, formattedClassName, formattedSubClassName, sellingChannel) => {
        const body = {
            userId,
            formattedClassName,
            formattedSubClassName,
        };

        return axios.post('/api/dataConnect/getTotalSalesByFiscalWeek', {body,sellingChannel});
    };

    static getReasonCodeDollarsByFiscalWeek = (userId, formattedClassName, formattedSubClassName, sellingChannel) => {
        const body = {
            userId,
            formattedClassName,
            formattedSubClassName,
        };
        return axios.post('/api/dataConnect/getReasonCodeDollarsByFiscalWeek', {body, sellingChannel});
    };
}
