import ZoneServices from './ZoneServices';
import axios from 'axios';

jest.mock('axios');

describe('ZoneServices', () => {
    it('Should readZoneByDCS', () => {
        const depNum = 21;
        const classNum = 1;
        const subclassNum = 5;
        const response ={
                "returnCode": 0,
                "message": null,
                "response": {
                    "taxonomyId": 2391,
                    "categoryCode": 1,
                    "traitGroupId": 2738,
                    "skuGroupId": 1400,
                    "traits": [],
                    "subDepartment": "0021",
                    "classNumber": 1,
                    "subClassNumber": 2,
                    "zoneDefinitionLevel": "SCLS",
                    "userId": null,
                    "create": null,
                    "missingStores": [163],
                    "subClassHierarchyList": null,
                    "skuNumberList": null
                },
                "error": null
            
        }
        axios.post.mockResolvedValue(response);
        ZoneServices.readZoneByDCS(depNum, classNum, subclassNum,[],1).then(data => expect(data).toEqual(response));

    });
    
});