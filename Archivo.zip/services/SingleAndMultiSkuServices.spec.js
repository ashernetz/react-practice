import SingleAndMultiSkuServices from './SingleAndMultiSkuServices';
import axios from 'axios';

jest.mock('axios');

describe('OnlineServices', () => {

    it('Should onlineSearch', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 106057];
        const response = {
            minimumRetail: 15.5,
            maximumRetail: 200.76,
            onlineSkuDetailList: [{
                skuNumber: 123567,
                storeNumber: 8119,
                onhandQuantity: 34,
                omsIdList: [{
                    omsId: 2323456,
                    vendorNumber: 3457,
                    vendorName: "uuery skdjfhsd sre"
                }
                ],
                effectiveRetail: 34.45,
                effectiveCost: 56.78,
                effectiveBeginDate: "12-12-2020",
                effectiveEndDate: "10-10-9999",
                currentYearPerformance: {
                    netSalesComp: 123.86,
                    netUnitsComp: 675,
                },
                lastYearPerformance: {
                    netSalesComp: 567.86,
                    netUnitsComp: 345
                }
            }
            ],
            currentYearPerformance: {
                netSalesComp: 123.86,
                netUnitsComp: 675
            },
            lastYearPerformance: {
                netSalesComp: 567.86,
                netUnitsComp: 345
            },
            totalOnHandQuantity: 34546
        }
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.onlineSearch(skuList).then(data => expect(data).toEqual(response));
    });

    it('Should fetchOnHandQuantity', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 106057];
        const response = {138154:4,138319:5}

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchOnHandQuantity(skuList).then(data => expect(data).toEqual(response));
    });

    it('Should fetchSkuRank', () => {
        const sku = 1002352618;
        const response = 39102;

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchSkuRank(sku).then(data => expect(data).toEqual(response));
    });

    it('Should fetchRetailTimeline', () => {
        const skuNumber = 880439;
        const response = {"SKU":880439,"EFFECTIVEBEGINDATE":"2021-01-04T08:00:00","EFFECTIVERETAIL":1349,"PROMOTIONTYPE":null}
        
        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchRetailTimeline(skuNumber).then(data => expect(data).toEqual(response));

    });

    it('Should fetchCostTimeline', () => {
        const skuNumber = 1002466451;
        const response = {"SKU_NBR":1002466451,"MVNDR_NBR":60005580,"SRC_EFF_BGN_DT":"2017-04-12","CURR_COST_AMT":39.5}
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCostTimeline(skuNumber).then(data => expect(data).toEqual(response));

    });

    it('Should fetchMultiSKUPerformance', () => {
        const skuList = [1000951424,1000062200,1000986758,1000120181,1000894443];
        const userId = 'MC62YE';
        const response = {
            "skuCompMap": {
                "1000062200": {
                    "skuNumber": 1000062200,
                    "compPercentage": -68.15,
                    "unitsPercentage": -66.36
                }
            },
            "totalCompPercentage": -68.15,
            "totalUnitsPercentage": -66.36,
            "fiscalWeek": "FW29",
            "totalThisYearSales": 60.66,
            "totalThisYearUnits": 72.00
        }
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchMultiSKUPerformance(skuList,userId).then(data => expect(data).toEqual(response));

    });

    it('Should downloadMultiSkuExcel', () => {
        const excelType = true
        const response = {}
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.downloadMultiSkuExcel(excelType).then(data => expect(data).toEqual(response));

    });

    it('Should determineSellingChannel', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 106057];
        const omsIdList =[1000672161,100630747,1000061495,1000598164,1000398660,1000476618]
        const response = {
            "onlineSkus": {
              "1000062200": {
                "skuNumber": 1000062200,
                "omsId": [
                  "306372393",
                  "100374870",
                  "305680543"
                ],
                "skuDescription": "MTS12 12\" 16GA MEDIUM TWIST STRAP",
                "department": 22,
                "classNumber": 14,
                "subClass": 9,
                "imgSourcePath": "https://images.homedepot-static.com/productImages/6816af8a-13bd-4b26-827c-f7d2fdb7a41d/svn/simpson-strong-tie-metal-straps-mts12-64_145.jpg"
              },
              "1000951424": {
                "skuNumber": 1000951424,
                "omsId": [
                  "202503211"
                ],
                "skuDescription": "PARADIGM COLLECTION 1-1/4 IN. BLUE C",
                "department": 25,
                "classNumber": 4,
                "subClass": 60,
                "imgSourcePath": "https://images.homedepot-static.com/productImages/10ef2966-94c5-4642-8453-0edf6bd2dc99/svn/atlas-homewares-cabinet-knobs-mg20-b-64_145.jpg"
              }
            },
            "coreSkus": {},
            "onlineDcs": "MULTIPLE DCS"
          }
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.determineSellingChannel(skuList,omsIdList).then(data => expect(data).toEqual(response));

    });

    it('Should fetchInStoreRetailMode', () => {
        const skuList = [1000951424,1000062200,1000986758,1000120181,1000894443];
        const response = {"maxRetail":0.95,"minRetail":0.87,"skuRetailList":[{"skuNumber":159686,"mostCommonRetail":0.88}]}
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchInStoreRetailMode(skuList).then(data => expect(data).toEqual(response));

    });

    it('Should fetchSkuSalesPerformance', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 106057];
        const userId = 'MC62YE';
        const onlineOnly = true;
        const response = {
            "currentYearPerformance": [
              {
                "fiscalWeek": "FW28",
                "fiscalYear": "2020",
                "salesAmount": "168.24",
                "unitsSold": "8.0",
                "rawSalesAmount": 168.24,
                "rawUnitsSold": 8.00
              }, 
              {
                "fiscalWeek": "FW22",
                "fiscalYear": "2020",
                "salesAmount": "264.98",
                "unitsSold": "14.0",
                "rawSalesAmount": 264.98,
                "rawUnitsSold": 14.00
              }
            
            ]}
        
        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchSkuSalesPerformance(skuList,userId).then(data => expect(data).toEqual(response));

    });

    it('Should fetchSkuZonePerformanceData', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 106057];
        const userId = 'MC62YE';
        const response = {
            "zonePerformanceData": [
              {
                "zoneId": "231408",
                "zoneName": "Albuquerque",
                "storePerformanceData": [
                  {
                    "storeNumber": "3504",
                    "storeName": null,
                    "compPercentage": null,
                    "unitsPercentage": null,
                    "latitudeNumber": null,
                    "longitudeNumber": null
                  },               
                  {
                    "storeNumber": "3517",
                    "storeName": null,
                    "compPercentage": null,
                    "unitsPercentage": null,
                    "latitudeNumber": null,
                    "longitudeNumber": null
                  }
                ],
                "zoneCompPercentage": 105.58,
                "zoneUnitsPercentage": 100.00
              }
              ]
            }
        
        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchSkuZonePerformanceData(skuList,userId).then(data => expect(data).toEqual(response));

    });

    it('Should fetchDailyISS', () => {
        const skuNumber = 122863;
        const response = {
            "skuNumber": 122863,
            "istsPercentage": 96.76
        }
        
        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchDailyISS(skuNumber).then(data => expect(data).toEqual(response));

    });

    it('Should fetchVendorNames', () => {
        const skuList = [102859, 102636, 102780, 102859, 242715, 311220];
        const isOnline = true;
        const response = {"1003817655":["Master_consign"]}
        
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchVendorNames(skuList,isOnline).then(data => expect(data).toEqual(response));

    });

    it('Should fetchProductRating', () => {
        const omsId = 1000061495;
        const response = {"omsId":203302207,"totalReviewCount":2,"averageOverallRating":5}
        
        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProductRating(omsId).then(data => expect(data).toEqual(response));

    });

    it('Should fetchMultipleVendor', ()=> {
      const skuNumber =177480;
      const onlineOnly = true;
      const response =
          [{
            "vendorName": "S/O AMERICAN WOOD MOULDI",
            "vendorNumber": 60081767,
            "vendorType": "DTC"
          }]

      axios.get.mockResolvedValue(response);
      SingleAndMultiSkuServices.fetchMultipleVendor(skuNumber,onlineOnly).then(data => expect(data).toEqual(response));

  });

    it('Should fetchMultiSearchPerformance', ()=> {
      const skuObject = [159686,177480];
      const response = {"skuCompMap":{},"totalCompPercentage":null,"totalUnitsPercentage":null,"fiscalWeek":"FW7","totalThisYearSales":null,"totalThisYearUnits":null}

      axios.post.mockResolvedValue(response);
      SingleAndMultiSkuServices.fetchMultiSearchPerformance(skuObject).then(data => expect(data).toEqual(response));

    });

  it('Should fetchMinMaxRetail', ()=> {
    const skuObject = [159686,177480,161640,302084];
    const response = {"maxRetail":135,"minRetail":3.97}

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchMinMaxRetail(skuObject).then(data => expect(data).toEqual(response));

  });

  it('Should fetchMultiSearchVendorList', ()=> {
    const skuObject = [159686,177480,161640,302084];
    const response = [{"vendorName":"MAPEI CORPORATION","vendorNumber":29760,"vendorType":"DTC"}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchMultiSearchVendorList(skuObject).then(data => expect(data).toEqual(response));

  });

  it('Should downloadSkuInquiryReport', ()=> {
    const skuObject = [159686,177480,161640,302084];
    const response = [{"vendorName":"MAPEI CORPORATION","vendorNumber":29760,"vendorType":"DTC"}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.downloadSkuInquiryReport(skuObject).then(data => expect(data).toEqual(response));

  });

  it('Should fetchCPIResponse', ()=> {
    const skuList = [786446,122863];
    const response = [{"786446":[{"cpiWeekly":1.1156462585,"skuNumber":786446,"primaryCompetitor":"Y","competitorName":"FnD","competitorId":588623}]}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchCPIResponse(skuList).then(data => expect(data).toEqual(response));

  });

  it('Should fetchAggregatedCPI', ()=> {
    const skuList = [786446,122863];
    const response = [{"cpiWeekly":1.0319477807,"skuNumber":null,"primaryCompetitor":null,"competitorName":"Lowe's","competitorId":3141},{"cpiWeekly":1.0405511597,"skuNumber":null,"primaryCompetitor":null,"competitorName":"Menards","competitorId":6488},{"cpiWeekly":1.0903714754,"skuNumber":null,"primaryCompetitor":null,"competitorName":"FnD","competitorId":588623}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchAggregatedCPI(skuList).then(data => expect(data).toEqual(response));

  });

  it('Should fetchSubClassLevelCPI', ()=> {
    const skuList = [123848];
    const response = [{"023-014-005-TOOLS":[{"competitorId":3141,"primaryCompetitor":"N","competitorName":"Lowe's","cpiWeekly":1.0137574181,"formattedClassName":null,"formattedSubClassName":"023-014-005-TOOLS"}]}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchSubClassLevelCPI(skuList).then(data => expect(data).toEqual(response));

  });

  it('Should fetchAverageUnitRetail', ()=> {
    const skuList = [786446,122863,768651];
    const userId = 'MC62YE';
    const response = [{"768651":84.2256746032,"786446":1.95,"122863":12.5186624411}]

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchAverageUnitRetail(skuList,userId).then(data => expect(data).toEqual(response));

  });


  it('Should fetchZoneMultiplierGroups', ()=> {
    const zoneMultiplierGroupId = "";
    const response =  { id: "3fa85f64-5717-4562-b3fc-2c963f66afa6", name: "myMultiplierGroup",
        description: "This is a group of zones with multipliers.", anchorGroupId: "12312312-5717-4562-b3fc-2c963f66afa6",
        zoneGroups: [ { "id": "12312312-5717-4562-b3fc-2c963f66afa6", "name": "Core", "weight": 1.768 },
            { "id": "98798798-5717-4562-b3fc-2c963f66afa6", "name": "Menards", "weight": 2.234 },
            { "id": "768795-5717-4562-b3fc-2c963f66afa6", "name": "Lowes", "weight": 9.86 } ] };

    axios.get.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchZoneMultiplierGroups(zoneMultiplierGroupId).then(data => expect(data).toEqual(response));

  });

  it('Should generate RCW', ()=> {
    const userId = 'MC62YE';
    const payload = [
        {
            "email":"Michelle_Cox_Bradford@homedepot.com",
            "subDepartment":"026P",
            "subClassNumber":6,
            "classNumber":1,
            "recommendations":[
                {"sku":191396,"zone":{"traitId":28283,"userDefZoneId":"57","zoneName":"MYRTLE BEACH"},"currentPrice":null,"recommendedPrice":1693,"reason":"User entered custom price"},
                {"sku":191396,"zone":{"traitId":28400,"userDefZoneId":"503","zoneName":"HOLLAND TUNNEL"}}
            ],
        }];
    const response = "success";

    axios.post.mockResolvedValue(response);
    SingleAndMultiSkuServices.generateRcw(userId,payload).then(data => expect(data).toEqual(response));

  });

    it('Should fetchCurrentIMULineStructure', ()=> {
        const skuZonePrice = [ {"sku": 741810, "traitId": 24770}];
        const response = [{
            "imu": 33.333
        }]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCurrentLineStructureIMU(skuZonePrice).then(data => expect(data).toEqual(response));
    });

    it('Should fetchProjectedIMULineStructure', ()=> {
        const skuZonePrice = [ {"sku": 741810, "traitId": 24770, "price": 243530}];
        const response = [{
            "imu": 33.333
        }]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProjectedLineStructureIMU(skuZonePrice).then(data => expect(data).toEqual(response));
    });

    // it('Should fetchMaxCost', ()=> {
    //     const userId = 'MC62YE';
    //     const skuList = [161640,159686,166065,311220];
    //     const response = {"311220": 5291.2139535839,"166065": 49867.9186963928,"159686": 59637.5726743105,"161640": 634103.2207969145}
    //
    //     axios.post.mockResolvedValue(response);
    //     SingleAndMultiSkuServices.fetchMaxCost(userId,skuList).then(data => expect(data).toEqual(response));
    //
    // });
    //
    // it('Should fetchMinCost', ()=> {
    //     const userId = 'MC62YE';
    //     const skuList = [161640,159686,166065,311220];
    //     const response = {"311220": -267.7115391591,"166065": -909.3899420056,"159686": -19.434960025,"161640": 7.1056543031}
    //
    //     axios.post.mockResolvedValue(response);
    //     SingleAndMultiSkuServices.fetchMinCost(userId,skuList).then(data => expect(data).toEqual(response));
    //
    // });
    //
    // it('Should fetchModeCost', ()=> {
    //     const userId = 'MC62YE';
    //     const onlineOnly = false;
    //     const skuList = [161640,159686,166065,311220];
    //     const response = {"311220": -267.7115391591,"166065": -909.3899420056,"159686": -19.434960025,"161640": 7.1056543031}
    //
    //     axios.post.mockResolvedValue(response);
    //     SingleAndMultiSkuServices.fetchModeCost(skuList,userId,onlineOnly).then(data => expect(data).toEqual(response));
    //
    // });

    it('Should vendorsBySkus', ()=> {
        const skuList = [311293,402470,411396,411485,531053,555313,555318,721525,736996,737003,872261,872288,872296,872318];
        const response = {"402470":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"737003":[{"vendorName":"LINCOLN ELECTRIC        ","vendorNumber":22331,"vendorType":"DTC"},{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"411396":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"872296":[{"vendorName":"LINCOLN ELECTRIC        ","vendorNumber":22331,"vendorType":"DTC"},{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"872261":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"872288":[{"vendorName":"LINCOLN ELECTRIC        ","vendorNumber":22331,"vendorType":"DTC"},{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"736996":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"872318":[{"vendorName":"LINCOLN ELECTRIC        ","vendorNumber":22331,"vendorType":"DTC"},{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"311293":[{"vendorName":"LINCOLN ELECTRIC        ","vendorNumber":22331,"vendorType":"DTC"}],"555313":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"411485":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"555318":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}],"721525":[{"vendorName":"OATEY SUPPLY CHAIN SERV","vendorNumber":541508,"vendorType":"DTC"}]};
      
        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.vendorsBySkus(skuList,false).then(data => expect(data).toEqual(response));

    });

    it('Should localizedPrice', ()=> {
        const skuNumber = 173041;
        const storeNumber = 105;
        const omsIdList = ["304679976","203224992","204852355","206491571"]
        const response = {"localizedPriceList":[{"omsId":304679976,"localizedPrice":6.44},{"omsId":203224992,"localizedPrice":6.44},{"omsId":204852355,"localizedPrice":6.44},{"omsId":206491571,"localizedPrice":6.44}],"permanentPrice":13.98};

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.localizedPrice(skuNumber,storeNumber,omsIdList).then(data => expect(data).toEqual(response));

    });

    it('Should localizedRetailStores', ()=> {
        const skuNumber = 100230;
        const response = {"skuNumber":100230,"storeDetail":[{"store":3801,"storeName":"W TOLEDO","stateCode":"OH"},{"store":3807,"storeName":"WESTGATE","stateCode":"OH"},{"store":3808,"storeName":"NILES, OH","stateCode":"OH"},{"store":3809,"storeName":"CUYAHOGA FALLS","stateCode":"OH"},{"store":3810,"storeName":"CANTON, OH","stateCode":"OH"},{"store":3815,"storeName":"MENTOR","stateCode":"OH"},{"store":3817,"storeName":"STRONGSVILLE","stateCode":"OH"},{"store":3818,"storeName":"CLEVELAND HEIGHTS","stateCode":"OH"},{"store":3820,"storeName":"WEST CLEVELAND","stateCode":"OH"},{"store":3824,"storeName":"MACEDONIA","stateCode":"OH"},{"store":3827,"storeName":"ELYRIA","stateCode":"OH"},{"store":3830,"storeName":"S AKRON","stateCode":"OH"},{"store":3835,"storeName":"AVON,OH","stateCode":"OH"},{"store":3838,"storeName":"ASHTABULA","stateCode":"OH"},{"store":3841,"storeName":"FAIRLAWN","stateCode":"OH"},{"store":3842,"storeName":"HIGHLAND HEIGHTS","stateCode":"OH"},{"store":3846,"storeName":"ONTARIO","stateCode":"OH"},{"store":3847,"storeName":"ROCKY RIVER","stateCode":"OH"},{"store":3848,"storeName":"NE TOLEDO","stateCode":"OH"},{"store":3852,"storeName":"EUCLID","stateCode":"OH"},{"store":3858,"storeName":"ROSSFORD","stateCode":"OH"},{"store":3859,"storeName":"STREETSBORO","stateCode":"OH"},{"store":3860,"storeName":"MASSILLON","stateCode":"OH"},{"store":3866,"storeName":"SANDUSKY","stateCode":"OH"},{"store":3875,"storeName":"BRUNSWICK,OH","stateCode":"OH"},{"store":3882,"storeName":"WADSWORTH","stateCode":"OH"},{"store":3886,"storeName":"AUSTINTOWN, OH","stateCode":"OH"},{"store":3888,"storeName":"ASHLAND,OH","stateCode":"OH"},{"store":6857,"storeName":"STEELYARD","stateCode":"OH"},{"store":6930,"storeName":"LORAIN","stateCode":"OH"}]};

        axios.get.mockResolvedValue(response);
        SingleAndMultiSkuServices.localizedRetailStores(skuNumber).then(data => expect(data).toEqual(response));
    });

    it('Should costBySkus', ()=> {
        const skuList = [311293,402470,411396];
        const response = [{sku: 311293, cost: 1000}, {sku: 402470, cost: 1500}, {sku: 411396, cost: 2000}];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.currentCostBySku(skuList).then(data => expect(data).toEqual(response));
    });

    it('Should permRetailAndStoreOccurrenceBySkus', ()=> {
        const skuList = [332259, 854892, 637758]
        const response = {data:[{"sku": 854892, "retail": 897, "occurrences": 1710}, 
        {"sku": 332259, "retail": 897, "occurrences": 1566},
         {"sku": 637758, "retail": 1797, "occurrences": 1750}]};

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.permRetailBySku(skuList).then(data => expect(data).toEqual(response));
    });

    it('Should permRetailAndStoreOccurrenceBySkuZoneGroup',()=> {
        const zoneGroupId = "323e5e5b-f350-4cc9-b91f-64e07e055482"
        const skuList = [332259, 854892, 637758]
        const skuZoneGroupList = {"skus": skuList, "zoneMultiplierGroupId": zoneGroupId}
        const response = [{"sku": 854892, "retail": 897, "occurrences": 1710, "zoneGroupId": zoneGroupId}, {"sku": 332259, "retail": 897, "occurrences": 1566, "zoneGroupId": zoneGroupId}, {"sku": 637758, "retail": 1797, "occurrences": 1750, "zoneGroupId": zoneGroupId}];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.permRetailBySkuZoneGroup(skuZoneGroupList).then(data => expect(data).toEqual(response));
    });

    it('Should getInvoiceCostForSkuStore', ()=> {
        const response = [{sku: 311293,store:123, cost: 1000}];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.getInvoiceCostForSkuStoreList(311293,123).then(data => expect(data).toEqual(response));

    });

    it('Should getSkuLevelIMU', ()=> {
        const skuZoneList = [{sku:652512,traitId: 28283}];
        const response = [{imu: -25.234427717151032,sku:652512}];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchSkuLevelImu(skuZoneList).then(data => expect(data).toEqual(response));
    });

    it('Should getProjectedSkuLevelIMU', ()=> {
        const skuZonePriceList = [{sku:652512,traitId: 28283, costOverride: 6000, price:2000}];
        const response = [{imu: -25.234427717151032,sku:652512}];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProjectedSkuLevelImu(skuZonePriceList).then(data => expect(data).toEqual(response));
    });

    it('Should getZoneLevelImu', ()=> {
        const zoneGroupObject = {
            zoneMultiplierGroupId: "7c0b7834-03c8-4783-b557-f4ed987ff7d5",
            skuZones: [
                {
                    sku: 311790,
                    traitId: 24741
                },
                {
                    sku: 741810,
                    traitId: 24770
                }
            ]
        }
        const response = [
            {
                imu: 39.671875,
                sku: 741810,
                zoneGroupId: "0c28fd74-6214-4dd6-b0ea-1318a16789f7"
            },
            {
                imu: "NaN",
                sku: 311790,
                zoneGroupId: "ecb1516f-a6e9-4630-819e-232f30810e7b"
            }];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchZoneGroupIMU(zoneGroupObject).then(data => expect(data).toEqual(response));
    });

    it('Should getProjectedZoneLevelImu', ()=> {
        const zoneGroupObject = {
            zoneMultiplierGroupId: "7c0b7834-03c8-4783-b557-f4ed987ff7d5",
            skuZonePriceCostList: [
                {
                    sku: 311790,
                    traitId: 24741,
                    price: 15,
                    costOverride: 0
                },
                {
                    sku: 741810,
                    traitId: 24770,
                    price: 15,
                    costOverride: 0
                }
            ]
        }
        const response = [
            {
                imu: 39.671875,
                sku: 741810,
                zoneGroupId: "0c28fd74-6214-4dd6-b0ea-1318a16789f7"
            },
            {
                imu: "NaN",
                sku: 311790,
                zoneGroupId: "ecb1516f-a6e9-4630-819e-232f30810e7b"
            }];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProjectedZoneGroupIMU(zoneGroupObject).then(data => expect(data).toEqual(response));
    });
    it('Should getCPIData', ()=> {
        const skuZoneList = [
            {
                "sku": 301329,
                "traitId": 24664
            },
            {
                "sku": 301329,
                "traitId": 24665
            } ];
        const response = [
            {
                "competitorId": 3141,
                "competitorName": "Lowe's",
                "cpi": 1.0064535901
            },
            {
                "competitorId": 6488,
                "competitorName": "Menards",
                "cpi": 0.9966360082
            }
        ]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCurrentCpi(skuZoneList).then(data => expect(data).toEqual(response));
    });

    it('Should getMyPriceCPIData', ()=> {
        const skuZoneList = [
            {
                "sku": 301329,
                "traitId": 24664
            },
            {
                "sku": 301329,
                "traitId": 24665
            } ];
        const response = [
            {
                "competitorId": 3141,
                "competitorName": "Lowe's",
                "cpi": 1.0064535901
            },
            {
                "competitorId": 6488,
                "competitorName": "Menards",
                "cpi": 0.9966360082
            }
        ]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCurrentMyPriceCPI(skuZoneList).then(data => expect(data).toEqual(response));
    });

    it('Should getProjectedCPIData', ()=> {
        const skuZonePriceList = [
            {
                "sku": 301329,
                "traitId": 24664,
                "price": 15
            },
            {
                "sku": 301329,
                "traitId": 24665,
                "price": 15
            } ];
        const response = [
            {
                "competitorId": 3141,
                "competitorName": "Lowe's",
                "cpi": 1.0064535901
            },
            {
                "competitorId": 6488,
                "competitorName": "Menards",
                "cpi": 0.9966360082
            }
        ]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProjectedCpi(skuZonePriceList).then(data => expect(data).toEqual(response));
    });

  it('Should fetchRegionallyAssortedSkuData', ()=> {
    const skuNumber = [180254]
    const response = {
      "regionallyAssorted": "Yes",
      "regionsAssorted": 7,
      "locationType": "RGN"
    }

    axios.get.mockResolvedValue(response);
    SingleAndMultiSkuServices.fetchRegionallyAssortedSkuData(skuNumber).then(data => expect(data).toEqual(response));
  });

    it('Should getCompetitorData', ()=> {
        const competitorData = {
            "zoneMultiplierGroupId": "3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
            "skus": [301329,689930,652520]
        }
        const response = [
            {
                "sku": 689930,
                "competitorId": 3141,
                "occurrences": 3,
                "scaledPricePennies": 8898,
                "rawPricePennies": 8898,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 652520,
                "competitorId": 3141,
                "occurrences": 52,
                "scaledPricePennies": 838,
                "rawPricePennies": 838,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 301329,
                "competitorId": 3141,
                "occurrences": 248,
                "scaledPricePennies": 3393,
                "rawPricePennies": 3393,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 652520,
                "competitorId": 3141,
                "occurrences": 8,
                "scaledPricePennies": 818,
                "rawPricePennies": 818,
                "scalingFactor": 1.0,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45"
            },
            {
                "sku": 301329,
                "competitorId": 3141,
                "occurrences": 18,
                "scaledPricePennies": 2672,
                "rawPricePennies": 2672,
                "scalingFactor": 1.0,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45"
            },
            {
                "sku": 689930,
                "competitorId": 3141,
                "occurrences": 2,
                "scaledPricePennies": 8898,
                "rawPricePennies": 8898,
                "scalingFactor": 1.0,
                "zoneGroupId": "01cb2e21-33ac-4934-9bfe-bc1df9aefe99"
            },
            {
                "sku": 652520,
                "competitorId": 3141,
                "occurrences": 57,
                "scaledPricePennies": 838,
                "rawPricePennies": 838,
                "scalingFactor": 1.0,
                "zoneGroupId": "01cb2e21-33ac-4934-9bfe-bc1df9aefe99"
            },
            {
                "sku": 301329,
                "competitorId": 3141,
                "occurrences": 92,
                "scaledPricePennies": 3047,
                "rawPricePennies": 3047,
                "scalingFactor": 1.0,
                "zoneGroupId": "01cb2e21-33ac-4934-9bfe-bc1df9aefe99"
            },
            {
                "sku": 689930,
                "competitorId": 6488,
                "occurrences": 10,
                "scaledPricePennies": 6265,
                "rawPricePennies": 6265,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 652520,
                "competitorId": 6488,
                "occurrences": 4,
                "scaledPricePennies": 549,
                "rawPricePennies": 549,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 301329,
                "competitorId": 6488,
                "occurrences": 16,
                "scaledPricePennies": 2582,
                "rawPricePennies": 2582,
                "scalingFactor": 1.0,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 689930,
                "competitorId": 6488,
                "occurrences": 211,
                "scaledPricePennies": 6265,
                "rawPricePennies": 6265,
                "scalingFactor": 1.0,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45"
            },
            {
                "sku": 652520,
                "competitorId": 6488,
                "occurrences": 153,
                "scaledPricePennies": 549,
                "rawPricePennies": 549,
                "scalingFactor": 1.0,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45"
            },
            {
                "sku": 301329,
                "competitorId": 6488,
                "occurrences": 348,
                "scaledPricePennies": 2582,
                "rawPricePennies": 2582,
                "scalingFactor": 1.0,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45"
            }
        ]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCompetitorPriceCPI(competitorData).then(data => expect(data).toEqual(response));
    })

    it('Should getZoneGroupCurrentCpi', ()=> {
        const request ={
            "skus": [
                301329,
                191396
            ],
            "zoneMultiplierGroupId": "3bf84d52-d3ee-4875-8a1b-c69d695dd7df"
        }
        const response = [
            {
                "sku": 301329,
                "competitorId": 6488,
                "cpi": 1.3116334229,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            },
            {
                "sku": 191396,
                "competitorId": 6488,
                "cpi": 1.3116334229,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c"
            }
        ];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCurrentZoneGroupCpi(request).then(data => expect(data).toEqual(response));

    });

    it('Should fetchNewRetailStatus', ()=> {
        const request =[163585,
            105985,
            182273]
        const response = {data:[{
            "sku": 182273,
            "retail": 411,
            "occurrences": 52,
            "strategy": "ACTIVE"
        },
        {
            "sku": 105985,
            "retail": 27200,
            "occurrences": 1499,
            "strategy": "INACTIVE"
        },
        {
            "sku": 105985,
            "retail": 27200,
            "occurrences": 353,
            "strategy": "ACTIVE"
        },
        {
            "sku": 163585,
            "retail": 342,
            "occurrences": 1,
            "strategy": "INACTIVE"
        }
    ]}

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchModeRetailStatus(request).then(data => expect(data).toEqual(response));

    });

    it('Should fetchModeZoneGroupRetailStatus', ()=> {
        const request = {
            skus: [163585, 105985, 182273],
            zoneMultiplierGroupId: "a2e0c246-a180-4536-ba00-ea97e5fb1690"
        }
        const response = {data:[{
            "sku": 182273,
            "retail": 411,
            "zoneGroupId": "54c9ffc7-e0e0-4dc3-a2f5-cf24336adc48",
            "occurrences": 52,
            "strategy": "ACTIVE"
        },
        {
            "sku": 105985,
            "retail": 27200,
            "zoneGroupId": "54c9ffc7-e0e0-4dc3-a2f5-cf24336adc48",
            "occurrences": 1499,
            "strategy": "INACTIVE"
        },
        {
            "sku": 105985,
            "retail": 27200,
            "zoneGroupId": "54c9ffc7-e0e0-4dc3-a2f5-cf24336adc48",
            "occurrences": 353,
            "strategy": "ACTIVE"
        },
        {
            "sku": 163585,
            "retail": 342,
            "zoneGroupId": "54c9ffc7-e0e0-4dc3-a2f5-cf24336adc48",
            "occurrences": 1,
            "strategy": "INACTIVE"
        }
    ]}

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchZoneGroupModeRetailStatus(request).then(data => expect(data).toEqual(response));

    });


    it('Should getCurrentMyPriceZoneGroupCpi', ()=> {
        const skuZoneGroupObj = {
            zoneMultiplierGroupId:"3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
            skuZones: [{
                sku:652512,
                traitId: 28283,
            }]};
        const response = [
            {
                "sku": 301329,
                "competitorId": 3141,
                "zoneGroupId": "4f205b79-45fa-4b36-ab2a-d7c4509afb6c",
                "cpi": 0.8708932238193019
            }
        ];

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchCurrentMyPriceZoneGroupCpi(skuZoneGroupObj).then(data => expect(data).toEqual(response));
    });

    it('Should getProjectedZoneGroupCpi', ()=> {
        const skuZoneGroupPriceObj = {
            zoneMultiplierGroupId:"3bf84d52-d3ee-4875-8a1b-c69d695dd7df",
            skuZones: [{
                sku:652512,
                traitId: 28283,
                price: 2642
            }]};
        const response = [
            {
                "sku": 652512,
                "competitorId": 3141,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45",
                "cpi": 0.8904617458712504
            },
            {
                "sku": 301329,
                "competitorId": 6488,
                "zoneGroupId": "10b724c2-661b-4a50-846d-cd58d01c8a45",
                "cpi": 1.0232378001549187
            }
        ]

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.fetchProjectedSkuLevelImu(skuZoneGroupPriceObj).then(data => expect(data).toEqual(response));
    });

    it('Should uploadSkuToSkuExcel', () => {
        const file = new File([''], 'test.xlsx', {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        const response = '';

        axios.post.mockResolvedValue(response);
        SingleAndMultiSkuServices.uploadSkuToSkuExcel(file).then(data => expect(data).toEqual(response));
    });
});
