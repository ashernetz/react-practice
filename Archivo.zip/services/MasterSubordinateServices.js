import axios from 'axios';
export default class MasterSubordinateServices{

static fetchSkusDetails = async (skuList) => {
    return await axios.post(`/api/dataConnect/sku-description-details`, skuList);
  }

  static fetchByoMarkets = async (skuList) => {
    return await axios.post(`/api/dataConnect/byo-markets`, skuList);
  }
  static fetchAssortmentMarkets = async (skuList) => {
    return await axios.post(`/api/dataConnect/sku-market-status`, skuList);
  }

  static fetchMasterSubordinateRelationship = async (skuList) => {
    return await axios.post(`/api/sku-relationship/master-subordinate-relationship`, skuList)
  }

  static updateMasterSubordinateRelationship = async (masterSubResponse,isSaving) => {
    return await axios.post(`/api/sku-relationship/update-master-subordinate-relationship?isSaving=${isSaving}`, masterSubResponse
    )
  }
  static fetchSeasonClearenceDates = async (skuList) =>  {
  return await axios.post(`/api/dataConnect/sku-market-date`, skuList);
}
}