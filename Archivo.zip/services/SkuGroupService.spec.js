import SkuGroupService from './SkuGroupService';
import axios from 'axios';

jest.mock('axios');

describe('SkuGroupService', () => {
    describe('getSkuGroups()', () => {
        it("gets sku groups", () => {
            let skuGroups = [
                {
                    "skuGroupId": "abc",
                    "skuGroupName": "myGroup1",
                    "skuGroupDescription": "wow much descriptive",
                    "createdUserId": "JRP0BPV",
                    "createdTimestamp": "06-04-2020 12:00:00",
                    "lastUpdatedUserId": "JRP0BPV",
                    "lastUpdatedTimestamp": "06-04-2020 12:00:00",
                    "skuNumbers": [123456, 789100]
                },
                {
                    "skuGroupId": "def",
                    "skuGroupName": "myGroup2",
                    "skuGroupDescription": "wow indeed",
                    "createdUserId": "JRP0BPV",
                    "createdTimestamp": "06-04-2020 12:00:00",
                    "lastUpdatedUserId": "JRP0BPV",
                    "lastUpdatedTimestamp": "06-04-2020 12:00:00",
                    "skuNumbers": [123456, 654321]
                }
            ]
        })
    })

    describe('getSkuGroupPerformance()', () => {
        it("gets sku group performance", () => {
            let performance = {
                "skuCompMap": {
                    "159686": {
                        "skuNumber": 159686,
                        "compPercentage": 110.88,
                        "unitsPercentage": 121.6
                    },
                    "439318": {
                        "skuNumber": 439318,
                        "compPercentage": 45.74,
                        "unitsPercentage": 80
                    }
                },
                "totalCompPercentage": 109.65,
                "totalUnitsPercentage": 121.59,
                "fiscalWeek": "FW10",
                "totalThisYearSales": 92866.97,
                "totalThisYearUnits": 101861
            }
        })
    })
    
});