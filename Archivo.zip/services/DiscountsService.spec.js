import DiscountsService from "./DiscountsService";
import mockReasonCodeResponse from "./__fixtures__/mockReasonCodeResponse.json"
import mockTotalSalesResponse from "./__fixtures__/mockTotalSalesResponse.json"
import discountResponse from "./__fixtures__/discountResponse.json"
import axios from 'axios';

jest.mock('axios');

const getDiscountInput = {
    "subDepartmentDescription":"PLUMBING",
    "subDepartmentNumber":"026P",
    "departmentNumber":26,
    "classDescription":"PIPE AND FITTINGS",
    "classNumber":1,
    "subClassDescription":"",
    "subClassNumber":0,
}


describe('DiscountsService', () => {
        // mock input data
        const userId = "MC62YE";
        let formattedClassName = "026-001-PIPE AND FITTINGS";
        let formattedSubClassName  = "026-001-002-PVC PIPE";
        let departmentNumber = 26;
        let classNumber = 1;
        let subClassNumber = 0;

        test("getDiscounts for success", async () => {
            expect(departmentNumber).toEqual(getDiscountInput.departmentNumber);
            expect(classNumber).toEqual(getDiscountInput.classNumber);
            expect(subClassNumber).toEqual(getDiscountInput.subClassNumber);
            axios.post.mockResolvedValue(discountResponse);

            await expect(
                DiscountsService.getDiscounts(
                    userId,
                    formattedClassName,
                    formattedSubClassName
                )
            ).resolves.toEqual(discountResponse);
        })

        test("mockTotalSales for success", async () => {
            axios.post.mockResolvedValue(mockTotalSalesResponse);
            await expect(
                DiscountsService.getTotalSalesByFiscalWeek(
                    userId,
                    formattedClassName,
                    formattedSubClassName
                )
            ).resolves.toEqual(mockTotalSalesResponse);
        })

    test("mockReasonCodes for success", async () => {
        axios.post.mockResolvedValue(mockReasonCodeResponse);
        await expect(
            DiscountsService.getReasonCodeDollarsByFiscalWeek(
                userId,
                formattedClassName,
                formattedSubClassName
            )
        ).resolves.toEqual(mockReasonCodeResponse);
    })
})