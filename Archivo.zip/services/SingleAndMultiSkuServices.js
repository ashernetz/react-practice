import axios from 'axios';

export default class SingleAndMultiSkuServices {
  static onlineSearch = async (skuList,vendor) => {
    let url ="/api/multi-sku/onlineSearch";
    url = url + (vendor?"?vendor="+ vendor:"");
    return await axios.post(url, skuList);
  };

  static fetchSkuRank = async (sku) => {
    return await axios.post("/api/multi-sku/skuRank", sku);
  }

  static fetchMultiSKUPerformance = async (skuList,userId,onlineOnly,merchandisingVendor) => {
    let params = "userId=" + userId +"&onlineOnly="+onlineOnly;
    params = params + (merchandisingVendor?("&merchandisingVendor="+merchandisingVendor):"");
    return await axios.post(
        "/api/dataConnect/multi-sku-performance?"+params, skuList);
  };

  static fetchOnHandQuantity = async (skuList) => {
    return await axios.post("/api/multi-sku/getCheckAvailabilityBySkusAndStore",
        skuList);
  };

  static fetchRetailTimeline = async (skuNumber) => {
    return await axios.get(`/api/multi-sku/getRetailTimeline?skuNumber=${skuNumber}`);
  };

  static fetchCostTimeline = async (skuNumber,vendorNumber) => {
    let vendors=[];
    vendors.push(vendorNumber);
    return await axios.post("/api/multi-sku/getCostTimelineUrl?skuNumber="+skuNumber,vendors);
  };

  static downloadMultiSkuExcel = async (requestBody,excelType) => {
    return await axios.post(`/api/multi-sku/excel/multi-sku?excelType=${excelType}`,
        requestBody, {responseType: 'blob'});
  };

  static determineSellingChannel = async (skuList,omsIdList) => {
    return await axios.post("/api/multi-sku/selling-channel", {skuList,omsIdList});
  };

  static fetchInStoreRetailMode = async(skuList)=>{
    return await axios.post("/api/multi-sku/in-store/retail-mode", skuList);

  };

  static fetchSkuSalesPerformance = async (skuNumber,userId,onlineOnly) => {
    return await axios.get(`/api/dataConnect/salesPerformanceDetails?skuNumber=${skuNumber}&userId=${userId}&onlineOnly=${onlineOnly}`);
  };

  static fetchSkuZonePerformanceData = async (skuNumber,userId) => {
    return await axios.get(`/api/dataConnect/skuZonePerformanceDetails?skuNumber=${skuNumber}&userId=${userId}`);
  };

  static fetchDailyISS = async (skuNumber) => {
    return await axios.get(`/api/multi-sku/dailyISS?skuNumber=${skuNumber}`);
  };

  static fetchRegionallyAssortedSkuData = async (skuNumber) => {
    return await axios.get(`/api/multi-sku/regionally-assorted?skuNumber=${skuNumber}`);
  };

  static fetchVendorNames = async (skuList,isOnline) => {
    return await axios.post(`/api/multi-sku/vendor-name?isOnline=${isOnline}`, skuList);
  };

  static fetchProductRating = async (omsId) => {
    return await axios.get(`/api/multi-sku/productRating?omsId=${omsId}`);
  };

  static fetchMultipleVendor = async (skuNumber,onlineOnly) => {
    return await axios.get(`/api/multi-sku/multipleVendor?skuNumber=${skuNumber}&onlineOnly=${onlineOnly}`);
  };

  static fetchMultiSearchPerformance = async (dataObject) => {
    // reference
    // let initialValue = {
    //   "classNumber": "",
    //   "departmentNumber": "",
    //   "merchandisingVendor":0,
    //   "onlineOnly": false,
    //   "skuNumbers": [
    //   ],
    //   "subClassDescription": "",
    //   "subClassNumber": "",
    //   "userId": ""
    // }
    return await axios.post(
        "/api/dataConnect/multi-search-performance", dataObject);
  };

  static fetchMinMaxRetail = async (dataObject) => {
    return await axios.post(
        "/api/multi-sku/multiSearchPriceRange", dataObject);
  };

  static fetchMultiSearchVendorList = async (dataObject) => {
    return await axios.post(
        "/api/multi-sku/multiSearchVendor", dataObject);
  };

  static downloadSkuInquiryReport = async (dataObject) => {
    return await axios.post(
        "/api/multi-sku/sku-inquiry/download", dataObject);
  };

  static fetchCPIResponse = async (skuList,userId) => {
    return await axios.post(`/api/dataConnect/cpi-skus`,{skuList,userId});
  };

  static fetchAggregatedCPI = async (skuList,userId) =>{
    return await axios.post(`/api/dataConnect/cpi-aggregate-skus`,{skuList,userId});
  }

  static fetchSubClassLevelCPI = async (dataObject) => {
    return await axios.post(`/api/dataConnect/cpi-subclass`,dataObject)
  }

  static fetchClassLevelCPI = async (dataObject) => {
    return await axios.post(`/api/dataConnect/cpi-class`,dataObject)
  }

  static fetchSubClassByClassLevelCPI = async (dataObject) => {
    return await axios.post(`/api/dataConnect/cpi-subclass-by-class`,dataObject)
  }

  static fetchAverageUnitRetail = async (skuList,userId) => {
    return await axios.post(`/api/dataConnect/average-unit-retail`,{skuList,userId});
  }

  static generateRcw = async (userId,dataObject) => {
    return await axios.post(`/api/multi-sku/rcw-generation?userId=`+userId,dataObject)
  }

  static fetchMarkUpMarkDown = async (skuZonePriceList, isDisaster) => {
    return await axios.post(`/api/dataConnect/markUpMarkDown?filterDisaster=${isDisaster}`, skuZonePriceList)
  }

  static fetchZoneMultiplierGroups = async (zoneMultiplierGroupId) => {
    return await axios.get(`/api/multi-sku/zoneMultiplierGroups?zoneMultiplierGroupId=${zoneMultiplierGroupId}`);
  }

  static fetchCurrentLineStructureIMU = async (skuZoneList) => {
    return await axios.post(`/api/dataConnect/imuCurrentLineStructure`, skuZoneList)
  }

  static fetchProjectedLineStructureIMU = async (skuZonePriceList, isDisaster) => {
    return axios.post(`/api/dataConnect/imuProjectedLineStructure?filterDisaster=${isDisaster}`, skuZonePriceList);
  }



  // static fetchMaxCost = async (skuList,userId) => {
  //   return await axios.post(`/api/dataConnect/max-cost`,{skuList,userId});
  // }
  // static fetchMinCost = async (skuList,userId) => {
  //   return await axios.post(`/api/dataConnect/min-cost`,{skuList,userId});
  // }
  // static fetchModeCost = async (skuList,userId,onlineOnly) => {
  //   return await axios.post(`/api/dataConnect/mode-cost`,{skuList,userId,onlineOnly});
  // }

  static vendorsBySkus = async (skuList,onlineOnly) => {
    return await axios.post(`/api/multi-sku/vendorsBySkus`,{skuList,onlineOnly});
  }

  static localizedPrice = async (skuNumber,storeNumber,omsIdList) => {
    return await axios.post(`/api/multi-sku/localizedPrice`,{skuNumber,storeNumber,omsIdList});
  }

  static localizedRetailStores = async (skuNumber) => {
    return await axios.get(`/api/multi-sku/localized-retail-stores?skuNumber=${skuNumber}`);
  }

  static getInvoiceCostForSkuStoreList = async (skuStoreList) => {
    return await axios.post(`/api/dataConnect/invoice-cost-sku-store`,skuStoreList);
  }

  static currentCostBySku = async (skuList) => {
    return await axios.post(`/api/multi-sku/currentCost`,{skuList})
  }

  static permRetailBySku = async (skuList) => {
    return await axios.post('/api/dataconnect/permanentRetailBySku', {skuList})
  }

  static permRetailBySkuZoneGroup = async (skuZoneGroupList) => {
    return await axios.post('/api/dataconnect/permanentRetailBySkuZoneGroup', {skuZoneGroupList})
  }

  static fetchSkuLevelImu = async (skuZoneList) => {
    return await axios.post(`/api/dataConnect/sku-level-imu`, skuZoneList)
  }

  static fetchProjectedSkuLevelImu = async (skuZonePriceList) => {
    return await axios.post(`/api/dataConnect/projected-sku-level-imu`, skuZonePriceList)
  }

  static fetchZoneGroupIMU = async (zoneGroupObject) => {
    return await axios.post('/api/dataconnect/imu-sku-zoneGroup', zoneGroupObject)
  }

  static fetchProjectedZoneGroupIMU = async (zoneGroupObject) => {
    return await axios.post('/api/dataconnect/projected-imu-sku-zoneGroup', zoneGroupObject)
  }
  static fetchCurrentCpi = async (skuList) => {
    return await axios.post('/api/dataconnect/current-cpi-dataConnect',skuList)
  }

  static fetchCurrentMyPriceCPI = async (skuList) => {
    return await axios.post('/api/dataconnect/current-cpi-myPrice',skuList)
  }

  static fetchProjectedCpi = async (skuZonePriceList,isDisaster) => {
    return await axios.post(`/api/dataconnect/projected-cpi?filterDisaster=${isDisaster}`,skuZonePriceList)
  }

  static fetchCompetitorPriceCPI = async (zoneGroupObject) => {
    return await axios.post('/api/dataconnect/retail/competitor/sku/zone-group-competitor-price',zoneGroupObject)
  }

  static fetchCurrentZoneGroupCpi = async (skuZoneGroupObj) => {
    return await axios.post('/api/dataconnect/zone-level-current-cpi',skuZoneGroupObj)
  }

  static updateGroupMultipliers = async (skuZoneGroupObj) => {
    return await axios.post('/api/dataconnect/editZoneMultiplierRules',skuZoneGroupObj)
  }

  static fetchModeRetailStatus = async (skuList) => {
    return await axios.post(`/api/dataConnect/modeRetailStatus`, skuList)
  }

  static fetchZoneGroupModeRetailStatus = async (skuZoneGroupObj) => {
    return await axios.post(`/api/dataConnect/zoneGroupModeRetailStatus`, skuZoneGroupObj)
  }

  static fetchSkuToSkuRules = async (skuList) => {
    return await axios.post(`/api/sku-relationship/getLineStructure`, skuList)
  }

  static fetchSkuToSkuRuleEdit = async (id, ruleObject) => {
    return await axios.post(`/api/sku-relationship/editSkuToSkuRules?id=${id}`, ruleObject);
  };

  static fetchCurrentMyPriceZoneGroupCpi = async (skuZoneGroupObj) => {
    return await axios.post('/api/dataconnect/myPrice-zone-group-current-cpi',skuZoneGroupObj)
  }

  static fetchProjectedZoneGroupCpi = async (skuZoneGroupPriceObj) => {
    return await axios.post('/api/dataconnect/zone-group-projected-cpi',skuZoneGroupPriceObj)
  }

  static fetchSkusDcsAndDescriptions = async (skuList) => {
    return axios.post(`/api/dataConnect/sku/dcs-description`, skuList);
  }

  static fetchAnchorSkus = async (skuList) => {
    return axios.post(`/api/sku-relationship/sku/anchors`, skuList);
  }

  static fetchValidSkus = async (skuList) => {
    return axios.post(`/api/dataConnect/skuValidation`, skuList);
  }

  static fetchZoneMultiplierGroupBySubclasses = async (subclasses) => {
    return await axios.post(`/api/dataConnect/zone-multiplier/subclass`, subclasses)
  }

  static fetchValidZones = async (skuList) => {
    return axios.post(`/api/dataConnect/zone-definition`, skuList);
  }

  static fetchSkusDcs = async (skuList) => {
    return axios.post(`/api/dataConnect/sku/dcs`, skuList);
  }

  static createZoneMultiplierGroup = async (zoneMultiplierGroupObj) => {
    return axios.post(`/api/dataConnect/createZoneMultiplierGroup`, zoneMultiplierGroupObj);
  }

  static createZoneGroupForMultiplierGroup = async (id, zoneGroupObj) => {
    return axios.post(`/api/dataConnect/createZoneGroupForMultiplierGroup?id=${id}`, zoneGroupObj);
  }

  static setZoneGroupAnchorForMultiplierGroup = async (zoneMultiplierGroupId, zoneGroupId) => {
    return axios.post(`/api/dataConnect/setZoneGroupAnchor?id=${zoneMultiplierGroupId}`, zoneGroupId);
  }

  static getZoneGroupRecommendation = async (recommendReq) => {
    return await axios.post(`/api/recommendation/zone-group-recommendations`, recommendReq)
  }

  static fetchPriceEndingRulesBySku = async (skus) => {
    return await axios.post(
        '/api/price-ending-rules/custom-rules/sku', skus);
  };

  static updatePriceEndingRules = async (endingRules) => {
      return await axios.put(
          '/api/price-ending-rules/custom-rules/sku', endingRules);
  };

  static uploadSkuToSkuExcel = async (file, lineStructureId) => {
    let url = '/api/sku-relationship/uploadLineStructure';
    if (lineStructureId) {
      url += `/${lineStructureId}`;
    }

    return await axios.post(url, file, {
      responseType: 'text',
      validateStatus: function(status) {
        return status >= 200 && status < 300 || status === 400;
      }
    });
  };

  static downloadSkuToSkuExcel = async (lineStructureId) => {
    let url = '/api/sku-relationship/downloadLineStructure';
    if (lineStructureId) {
      url += `/${lineStructureId}`;
    }
    return await axios.post(url, null,
      {
        responseType: 'blob',
      });
  };

  static fetchVendorDetails = async (vendorObj) => {
    return await axios.post('/api/dataConnect/vendor/vendorData', vendorObj)
  }

  static fetchVendorCosts = async (skuList) => {
    return await axios.post('/api/dataConnect/cost/first/blended', skuList);
  }
}
