import axios from 'axios';

export default class PriceDataServices {
  static fetchSkuDetails = async (skuNumber,userId,title) => {
    return await axios.get(
        '/api/security/fetchSkuData?skuNumber=' + skuNumber+'&userId='+userId+'&title='+title);
  };

    static getSkuStorePerformanceData = async (skuNumber,userId) => {
    return await axios.get(
        `/api/dataConnect/getSkuStorePerformance?skuNumber=${skuNumber}&userId=${userId}`);
  };

  static getPendingPriceChangeDetails = async (skuNumber,isPacManSku) => {
    if(isPacManSku){
    return await axios.get(
        '/api/security/fetchPendingPriceChange?skuNumber=' + skuNumber);
    }
    else{
      return await axios.get(
        '/api/security/fetchDWSkuPendingPriceChange?skuNumber=' + skuNumber);
    }
  };

  static fetchSkuImageSource = async (skuNumber) => {
    return await axios.get(
        '/api/security/fetchSkuImageSourcePath?skuNumber=' + skuNumber);
  };

  static getVendors = async (skuNumber) => {
    return await axios.get(
        '/api/security/getVendorsForSku?skuNumber=' + skuNumber);
  };

  static getThdSkuPriceChangeHistory = async (skuNumber) => {
    return await axios.get(
        '/api/price-history/thd-sku-history?skuNumber=' + skuNumber);
  };

  static getThdSkuStorePriceChangeHistory = async (skuNumber,storeNumber) => {
    return await axios.get(
        '/api/price-history/thd-sku-store-history?skuNumber=' + skuNumber +"&storeNumber="+storeNumber);
  };

  static getSalesMetrics = async (skuNumber) => {
    return await axios.get(
        '/api/security/getSalesMetrics?skuNumber=' + skuNumber);
  };

  static readFavSkusDetails= async (userId) => {
    return await axios.get(
        '/api/security/readFavSkusData?userId=' + userId);
  };

  static getPlanogramInfo = async (skuNumber, store) => {
    var params = new URLSearchParams();
    params.append("skuNumber", skuNumber);
    params.append("store", store);
    var request = {
      params: params
    };
    return await axios.get(
        '/api/security/getPlanogramInfo' , request);
  };

  static getSalesHistory = async (skuNumber, storeNumber, userId) => {
    return await axios.get(`/api/dataConnect/getSalesHistory/sku/${skuNumber}/store/${storeNumber}/user/${userId}`);
  };

  static performPreviewChanges = async (skuNumber, retailAmount, zones,
    userid) => {
  let skudto = [];
  zones.forEach(zone => {
    skudto.push({skuNumber, retailAmount, zoneNumber: zone});
  });
  let data = {skudto, userid};
  return await axios.post(
      '/api/multi-sku/previewChanges', data);
};

static executeTempRetailChanges = async (skuNumber, retailAmount, store,
  userid,tempRetailBeginDate,tempRetailEndDate) => {
let skuStoreList = [];
let storeNumber =store.toString()

skuStoreList.push({skuNumber, retailAmount, storeNumber});

let data = {skuStoreList, userid,tempRetailBeginDate,tempRetailEndDate};
return await axios.post(
    '/api/multi-sku/tempRetailExecutionChanges', data);
};

  static fetchPerformanceDataForSkus = async (skuNumbers,userId) => {

  return await axios.post(
      '/api/dataConnect/getPerformanceDataForGivenSkus?userId='+userId, skuNumbers?skuNumbers.map(k=>Number.parseInt(k)):[]);
  };

  static getAisleBay = async (skuNumber,storeNumber) => {
    return await axios.get(
        '/api/security/getAisleBay?skuNumber='+skuNumber+"&storeNumber="+storeNumber);
  };

  
  static getOHQuantityDetails = async (sku, stores) => {
    return await axios.post(
        '/api/security/getOnHandQuantity?skuNumber='+ sku,stores);
    };
  
    static getUnitsOnHandDetails = async (sku, stores) => {
      return await axios.post(
          '/api/security/getUnitsOnHand?skuNumber='+ sku,stores);
      };

    static getSkuVelocity = async (skuNumber,storeNumber) => {
      return await axios.get(
          '/api/security/getSkuVelocity?skuNumber=' + skuNumber+"&storeNumber="+storeNumber);
    };

  static readUserProfileDetails= async (userId) => {
    return await axios.get(
        '/api/security/readUserProfile?userId=' + userId);
  };

  static readPerformersDCSDetails= async (departmentNumber,classNumber,subclassNumber,subclassList,userId)=>{
      return await axios.get('/api/security/readPerformersForDCS?departmentNumber='+departmentNumber+
    "&classNumber="+classNumber+"&subclassNumber="+subclassNumber + "&subclassList="+subclassList+"&userId="+userId);
  };

  static getSubclassDetails = async () => {
    return await axios.get(
        '/api/security/getSubClasses');
  };

  static getSubDepartments = async () => {
    return await axios.get(
        '/api/security/getSubDepartments');
  };

  static createUserProfileData = async (title,dcsData,user) => {
    
    let userProfileData={
      "userId": user.userId,
      "firstName":user.firstName ,
      "lastName": user.lastName,
      "departmentNumber": dcsData.split("-")[0],
      "classNumber":dcsData.split("-")[1] ,
      "subClassNumber":dcsData.split("-")[2] ,
      "subClassName":dcsData.split(/-(.+)/)[1],
      "title": title
    };
    return await axios.post(
        '/api/security/createUserProfile', userProfileData);

    };

    static updateUserProfileData = async (title,dcsData,user) => {
      let userProfileData={
        "userId": user.userId,
        "departmentNumber": dcsData.split("-")[0],
        "classNumber":dcsData.split("-")[1] ,
        "subClassNumber":dcsData.split("-")[2] ,
        "title": title,
        "editFlag": true
      };
      return await axios.post(
          '/api/security/createUserProfile', userProfileData);
      };

  static getNearestCompetitorData = async (skuNumber, storeNumber) => {
    return await axios.get(
        '/api/security/getNearestCompetitor?skuNumber=' + skuNumber
        + "&storeNumber=" + storeNumber)
  };

  static getCompetitorSnapshotData = async (compid, cacheerid) => {
    return await axios.get(
        '/api/security/getCompetitorSnapshot?compid=' + compid + "&cacheerid=" + cacheerid);
  };

  static getCompetitorNearestTHDStore = async (competitorStore, competitorId) => {
    return await axios.get(
        '/api/security/getNearestTHDStore?competitorStore=' + competitorStore
        + "&competitorId=" + competitorId)
  };

  static getCompetitorPrices = async(skuNumber) => {
    return await axios.get('/api/security/getCompetitorPrices?skuNumber='+skuNumber)
  };

  //     static getCompetitorPrice1 = async(skuNumber) => {
       
  //       console.log("response");
      
  //        await axios.get('https://competitor-service.price-opt-stg.homedepot.com/v1/scrapes/thdSku/'+ skuNumber,
  //           { 
  //             withCredentials: true
  //           })
  //       .then(function (response) {
  //            console.log(response);
  //        })
  //        .catch(function (error) {
  //          console.log(error);
  //    });
  // };

  static addOrRemoveFavoriteSku = async (skuNumber, isRemoveSku, userId) => {
    return await axios.get(
        '/api/security/addOrRemoveFavSku?removeFavSku=' + isRemoveSku
        + '&userId=' + userId + '&skuNumber=' + skuNumber);
  };
  static getContacts = async (storeNumber) => {
    return await axios.get(
        '/api/security/getContacts?storeNumber=' + storeNumber);
  };

  static getThdSkuStorePriceHistory = async (thdSkuNum, thdStoreNum, startDate, endDate) => {
    return await axios.get(`/api/price-history/v1/thd-sku/${thdSkuNum}/thd-store/${thdStoreNum}`, { 
      params: { start_date: startDate, end_date: endDate} 
    })
  }

  static getCompetitorSkuStorePriceHistory = async (thdSkuNum, competitorId, competitorStoreNum, scrapeId, startDate, endDate) => {
    return await axios.get(`/api/price-history/v1/thd-sku/${thdSkuNum}/competitor-id/${competitorId}/competitor-store/${competitorStoreNum}/scrape-id/${scrapeId}`, {
      params: { start_date: startDate, end_date: endDate} 
    })
  }

  static getCompetitorSkuLevelPriceHistory = async (thdSkuNum, competitorId, startDate, endDate) => {
    return await axios.get(`/api/price-history/v1/thd-sku/${thdSkuNum}`, {
      params: { start_date: startDate, end_date: endDate, competitor_id: competitorId}
    })
  }

  static performOnlinePreviewChanges = async (skuNumber,userId,newRetail,newCost,beginDate,comments,vendorNumber) => {
     let postData = {
        "header": {
          "typeOfPriceChange": "ONLINE_MULTIPLE_PERM",
          "beginDateTime": beginDate,
          "comments": comments,
          "userId": userId
        },
        "data": [
          {
            "sku": skuNumber,
            "vendor": vendorNumber,
            "price": [
              {
                "retail": newRetail,
                "cost": newCost
              }
            ]
          }
        ]
      }
    return await axios.post('/api/multi-sku/onlinePreviewChanges', postData);
  };

}