import ReportsServices from './ReportsServices';
import axios from 'axios';

jest.mock('axios');

describe('ReportsServices', () => {

  it('Should runReportRequest', () => {
    const inputData = {
      "department": "21",
      "classNumber": "021-001",
      "subclasses": ["021-001-002"],
      "userId": "MC62YE",
      "includeDC": true
    };
    const response ={"id": 272, "lastUpdTs": "2023-03-29T09:07:38.889+00:00", "lastUpdId": "mc62ye", "submSysusrId": "MC62YE", "submTs": "2023-03-29T09:07:38.889+00:00", "endTs": null, "statCd": "SUBMITTED", "link": null, "fileNm": null, "rptTyp": "531", "rqstPayload": {"department": "21", "classNumber": "021-002", "subclasses": ["021-002-004"], "userId": "mc62ye", "includeDC": true}, "recCnt": null, "failureReason": null};

    axios.post.mockResolvedValue(response);
    ReportsServices.runReportsRequest(inputData).then(data => expect(data).toEqual(response));
  });

  it('Should fetchReportLog', () => {
  const userId = "MC62YE";
  const response =[{"id": 266, "lastUpdTs": "2023-03-29T08:30:29.601+00:00", "lastUpdId": "MC62YE", "submSysusrId": "MC62YE", "submTs": "2023-03-29T08:30:21.695+00:00", "endTs": null, "statCd": "FAILED", "link": null, "fileNm": null, "rptTyp": "531", "rqstPayload": {"department": null, "classNumber": null, "subclasses": null, "userId": "MC62YE", "includeDC": false}, "recCnt": null, "failureReason": "{\"timestamp\":\"2023-03-29T12:30:29.281+00:00\",\"status\":400,\"error\":\"Bad Request\",\"path\":\"/v1/report/generate/266\"}"}];

  axios.get.mockResolvedValue(response);
  ReportsServices.getReportsLog(userId).then(data => expect(data).toEqual(response));
  });

  it('Should getSkuDetails', () => {
    const skuList = [786446,122863,768651];
    const response = [{"sku":768651,"description":"6' FG STEP LADDER TIA 300LB","skuType":"normal","departmentNumber":22,"classNumber":8,"subClassNumber":4},{"sku":786446,"description":"1/16\" QEP SPACERS (250PK)","skuType":"normal","departmentNumber":23,"classNumber":14,"subClassNumber":5},{"sku":122863,"description":"#381 BRT  WHITE NONSAND GROUT 10LB","skuType":"normal","departmentNumber":23,"classNumber":14,"subClassNumber":9}];

    axios.post.mockResolvedValue(response);
    ReportsServices.getSkuDetails(skuList).then(data => expect(data).toEqual(response));
  });

  it('Should getVendorDetails', () => {
    const vendorList = [10319, 11424, 12039, 12132];
    const response = {"023F": [12039, 12132], "0027": [10319], "026P": [11424]};

    axios.post.mockResolvedValue(response);
    ReportsServices.getVendorDetails(vendorList).then(data => expect(data).toEqual(response));
  });

});
