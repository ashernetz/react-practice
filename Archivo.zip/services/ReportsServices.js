import axios from 'axios';

export default class  ReportsServices {

  static runReportsRequest = async (inputData) => {
    return axios.post(`/api/reports/runReports`, inputData);
  };

  static getReportsLog = async (userId,reportDate) => {
    return await axios.get(`/api/reports/reportsLog/${userId}`,{params:{reportDate:reportDate}});
  };

  static downloadReport = async (fileName) => {
    return await axios.get(`/api/reports/downloadReport/${fileName}`,{responseType: 'blob'});
  };

  static getVendorsFromVendorNumbers = async (vendorNumbers) => {
    return await axios.post(`/api/reports/getVendorsFromVendorNumbers`, vendorNumbers);
  };

  static getSkuDetails = async (skuList) => {
    return await axios.post(`/api/reports/getSkuDetails`, skuList);
  };

  static fetchLocationDetails = async () => {
    return await axios.get('/api/reports/getLocationDetails');
  };

  static getVendorDetails = async (vendorList) => {
    return await axios.post(`/api/reports/getVendorDetails`, vendorList);
  };

  static getVendorDetailsByVendorNameOrDepartment = async (vendorData) => {
    return await axios.post(`/api/reports/getVendorDetailsByVendorNameOrDepartment`,vendorData);
  }

}
