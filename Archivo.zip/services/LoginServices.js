import axios from 'axios';

export default class loginServices {
    static loginUser = async (storeNumber,username,pwd) => {

        return await axios({
            method: 'post',
            credentials:true,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            url: '/api/security/ssoLogin',
            data: JSON.stringify({
                callingProgram: "FlexiblePricingUI",
                j_storenumber: storeNumber,
                j_username: username,
                j_password: pwd
            })
        });
    };

    static isSessionValid = async () => {
        return await axios({
            method: 'get',
            credentials:true,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            url: '/api/security/isSessionValid',
           });
    };

    static getUserProfileFromToken = async () => {
        return await axios({
            method: 'get',
            credentials:true,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            url: '/api/security/isUserValid',
        });
    };



    static getUserProfileByLdap = async (ldap) => {
        return await axios({
            method: 'get',
            credentials:true,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            url: `/api/security/getUserProfile?username=${ldap}`,
        }).then(k=>k.data).catch(err=>{});
    };


    static getConfig = async () => {
        return await axios({
            method: 'get',
            credentials:true,
            url: '/api/security/config',
        });
    };

}