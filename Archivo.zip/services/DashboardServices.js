import axios from 'axios';

export default class DashboardServices {
  static getHealthOverviewDetails = async (hierarchyDetails,userId) => {
    return await axios.get(
        '/api/dataConnect/getHealthOverviewDetails',{params:this.prepareServiceInputData(hierarchyDetails,userId)});
  };

  static getZoneOverviewDetails = async (hierarchyDetails,userId) => {
    return await axios.get(
        '/api/dataConnect/getZoneOverviewDetails',{params:this.prepareServiceInputData(hierarchyDetails,userId)});
  };

  static getFinancialPerformanceDetails = async (hierarchyDetails,userId) => {
    return await axios.get(
        '/api/dataConnect/getFinancialPerformanceDetails',{params:this.prepareServiceInputData(hierarchyDetails,userId)});
  };


  static updateMpulseAccessRequest = async (userId,comments) => {
    return await axios.get(
        '/api/dashboard/mpulse-access-request?userId=' + userId+"&comments="+comments);
  };

  static getOffsideDetails = async (hierarchyDetails,favSkuList) => {
    return await axios.get(
        `/api/dashboard/offside/details?departmentNumber=${hierarchyDetails.departmentNumber}&classNumber=${hierarchyDetails.classNumber}&subClassNumber=${hierarchyDetails.subClassNumber}&favSkuList=${JSON.stringify(favSkuList)}`);
  };

  static getSkuImagesAndDescription = async (skuList) => {
    return await axios.post(
        "/api/dashboard/skus/images",skuList);
  };



  static prepareServiceInputData =(hierarchyDetails,userId)=>{
    let data={
      "subDepartmentDescription": hierarchyDetails.subDepartmentName,
      "subDepartmentNumber": hierarchyDetails.subDepartment?hierarchyDetails.subDepartment.toString():null,
      "departmentNumber": hierarchyDetails.departmentNumber?hierarchyDetails.departmentNumber.toString():null,
      "classDescription": hierarchyDetails.className,
      "classNumber": hierarchyDetails.classNumber?hierarchyDetails.classNumber.toString():null,
      "subClassDescription":hierarchyDetails.subClassName,
      "subClassNumber":hierarchyDetails.subClassNumber?hierarchyDetails.subClassNumber.toString(): null,
      "userId": userId?userId:null
    };
    return data;
  };

  static sendEmailForRequestAccess = async(dcs,userId,dcsAssignment,recipientEmailIds)=>{
    let data ={
      "body":this.prepareMailContent(dcs,userId,dcsAssignment),
      "fromAddress":"MPulse@homedepot.com",
      "priority":"NORMAL",
      "recipients":recipientEmailIds,
      "subject":"Requesting MPulse Access",
      "contentType":"html"
    };
    return await axios.post(
        '/api/security/sendEmail',data);
  };

  static prepareMailContent=(dcs,userId,dcsAssignment)=>{
    let mailContent = "<html><body><span><b>userId :</b></span>"+userId+
        "<br><span><b>selectedDCS :</b></span>"+dcs+
        "<br><span><b>DCSAssignment :</b></span>"+dcsAssignment.toString()+
        "</body></html>";
    return mailContent;
  };

  static getPacManRequestDetails = async (hierarchyDetails) => {
    return await axios.get(
        `/api/dashboard/pacMan/requests?departmentNumber=${hierarchyDetails.departmentNumber}&classNumber=${hierarchyDetails.classNumber}&subClassNumber=${hierarchyDetails.subClassNumber}&subDepartment=${hierarchyDetails.subDepartment}`);
  }

  static getCompetitorZonePriceDetails = async (skuNumber,competitorNumber) => {
    return await axios.get(
        `/api/dashboard/competitorZonePrice?skuNumber=${skuNumber}&competitorNumber=${competitorNumber}`
    );
  }

  static getGrossMargin = async (userId, hierarchyDetails) => {
    if(hierarchyDetails.departmentNumber){
    return await axios.post("/api/dataConnect/gross-margin/dcs", this.prepareServiceInputData(hierarchyDetails, userId))
    }
  }

  static getCpiWeeklyData = async (userId, hierarchyDetails) => {   
    if(hierarchyDetails.departmentNumber){
    return await axios.post("/api/dataConnect/cpi/weekly", this.prepareServiceInputData(hierarchyDetails, userId))
    }
  }

  static getOhWeeklyData = async (userId, hierarchyDetails) => {
    if(hierarchyDetails.departmentNumber){
    return await axios.post("/api/dataConnect/units/on-hand/weekly", this.prepareServiceInputData(hierarchyDetails, userId)) 
    }
  }

  static getMyPerformanceDataForDCS = async (dcsList, level) => {
    let hierarchyDetails = dcsList.map(dcs => {return this.prepareServiceInputData(dcs)})
    return await axios.post(`/api/dataConnect/my-performance/closer-look/${level.toLowerCase()}`, hierarchyDetails)
  }

}
