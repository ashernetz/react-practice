import OnlineServices from './HeaderServices'
import axios from 'axios';

jest.mock('axios');

describe('HeaderServices', () => {

    it('Should getFiscalWeek', () => {       
        const response = {"fiscalYear":2020,"fiscalWeek":38}      
        axios.get.mockResolvedValue(response);
        OnlineServices.getFiscalWeek().then(data => expect(data).toEqual(response));
    });

    it('Should getMarkets', () => {
        const response = [{"marketNumber":1,"marketName":"ATLANTA","active":true},{"marketNumber":2,"marketName":"MIAMI/FTL/WPALM","active":true}]
        axios.get.mockResolvedValue(response);
        OnlineServices.fetchMarketsList().then(data => expect(data).toEqual(response));

    });

    it('Should getZoneByDCS', () => {
        const response = { "subDepartment": "025H", "classNumber": 0, "subClassNumber": 0, "zoneDefinitionLevel": "SDPT", "zones": [ { "traitId": 21062, "zoneId": "1", "zoneName": "ATLANTA", "storeNumbers": [ "8413", "8412", "151", "152", "5616", "9854", "100", "9733", "9769" ] }  ] }
        axios.get.mockResolvedValue(response);
        OnlineServices.fetchZoneByDCS().then(data => expect(data).toEqual(response));

    });

});
