import axios from 'axios';

export default class HeaderServices {

  static getFiscalWeek = async () => {
    return await axios.get("/api/header/fiscal-week");
  };

  static postMultiSKuSearch = async (data) => {
    let initialval = {
      classNumber: 0,
      department: 0,
      lastKey: 0,
      searchType: null,
      skuGroupId: 0,
      subClassNumber: 0,
      userId: "",
      vendorNumber: 0,
    };
    return await axios.post(
        '/api/header/multi-sku/view', {...initialval,...data});
  };

  static fetchMarketsList = async () => {
    return await axios.get('/api/header/markets');
  }

  static fetchZoneByDCS = async (subDepartment,classNumber,subClassNumber) => {
    return await axios.get(`/api/header/zoneByDcs?subDepartment=${subDepartment}&classNumber=${classNumber}&subClassNumber=${subClassNumber}`);
  }

}
