import axios from 'axios';

let getUserProfile = async (username) => {
    var response = await axios.get('/api/security/getUserProfile', {
        params: {
            username
        }
    })
    return response.data;
}

let verifyUserAccess = async (userId,bearerToken) => {
    let headerData = {
        'access_token': `${bearerToken}`
    }
    return await axios.get(`/api/security/verifyUserAccess/${userId}`,{headers:headerData})
    .then(k => k.data)
    .catch(err => {
        console.log(err);
        return {allowUser:false,fullName:"" }
    });
};

function getUserJobTitle(jobTitleCode,userId) {
    return axios.get(`/api/security/getUserJobTitle/${userId}/${jobTitleCode}`)
}

function getUserPassportProfile() {
    return axios.get('/api/security/getUserPassportProfile', {withCredentials: true});
}

export { getUserProfile, verifyUserAccess, getUserJobTitle, getUserPassportProfile }
