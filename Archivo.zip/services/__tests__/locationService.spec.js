import axios from 'axios';

import { getStores, getDCs, getVendors } from '../locationService';

jest.mock('axios');

const error = new Error('Something went wrong');

describe('getStores() function', () => {
  it('returns stores data', async () => {
    const stores = ['first', 'second'];
    axios.post.mockResolvedValue({ data: stores });

    await expect(getStores([1, 2])).resolves.toEqual(stores);
    expect(axios.post).toHaveBeenCalledWith('/api/location/stores', {
      dc: [1, 2],
    });
  });

  it('returns empty list if request is failed', async () => {
    axios.post.mockRejectedValue(error);

    await expect(getStores([1, 2])).resolves.toEqual([]);
  });
});

describe('getDCs() function', () => {
  it('returns dc data', async () => {
    const dcs = [{ dcNumber: '1' }, { dcNumber: '2' }];
    axios.post.mockResolvedValue({ data: dcs });

    await expect(getDCs([42])).resolves.toEqual(dcs);
    expect(axios.post).toHaveBeenCalledWith(
      '/api/location/distribution-centers',
      { skus: [42] }
    );
  });

  it('returns empty list if request is failed', async () => {
    axios.post.mockRejectedValue(error);

    await expect(getDCs([42])).resolves.toEqual([]);
  });
});

describe('getVendors() function', () => {
  it('returns vendor data', async () => {
    const vendors = [{ id: 3 }, { id: 4 }];
    axios.post.mockResolvedValue({ data: vendors });

    await expect(getVendors([3, 4])).resolves.toEqual(vendors);
    expect(axios.post).toHaveBeenCalledWith('/api/location/vendors', {
      skus: [3, 4],
    });
  });

  it('returns empty list if request is failed', async () => {
    axios.post.mockRejectedValue(error);

    await expect(getVendors([3, 4])).resolves.toEqual([]);
  });
});
