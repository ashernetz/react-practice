import axios from 'axios';

export default class ZoneServices {

  static readZoneByDCS = async (subDept,deptNumber, classNumber,subClassList,category) => {


    return await axios.post('/api/zone/read/dcs',{
      "subDepartmentNumber": subDept,
      "departmentNumber": deptNumber,
      "classNumber": classNumber,
      "subClassNumbers": subClassList,
      "skipDefaultAndMissing": false,
      "category": category
    });
  };
}
