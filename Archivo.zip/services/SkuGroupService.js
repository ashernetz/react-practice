import axios from 'axios';

export default class SkuGroupService {
  static getSkuGroupPerformance = async (skuList, userId, onlineOnly) => {
    return await axios.post("/api/dataConnect/multi-sku-performance?userId=" + userId + "&onlineOnly=" + onlineOnly, skuList);
  };

  static getSkuGroupPerformanceAur = async (skuList, userId, onlineOnly) => {
    return await axios.post("/api/dataConnect/aur/historical/skus", skuList);
  };
  static getAurBySkuGroupIdsAndSkus = async (skuGroupMap, userId, onlineOnly) => {
    return await axios.post("/api/dataConnect/sku-group-aur", skuGroupMap);
  };
  
  static getAnchorSkusForGroups = async (skuGroupNumbers) => {
    return await axios.post(`/api/sku-relationship/sku-group-anchors`, skuGroupNumbers)
  }

  static getSkuGroups = async (ldap, dcsString) => {
    let url = '/api/sku-groups/getSkuGroups'

    if (ldap && dcsString) {
      url += "?ldap=" + ldap + "&dcs=" + dcsString
    } else if (ldap) {
      url += "?ldap=" + ldap
    } else if (dcsString) {
      url += "?dcs=" + dcsString
    }

    return await axios.post(url);
  };

  static insertSkuGroups = async (skuGroup) => {
    let url = 'api/sku-groups/insertSkuGroups';

    return await axios.post(url, skuGroup)
  }

  static getDcsPerformance_FWLevel = async (hierarchyDetails, userId) => {
    return await axios.post("/api/sku-groups/dcsPerformance?userId=" + userId, this.prepareServiceInputData(hierarchyDetails, userId));
  };

  static getCloserLookDCSPerformance = async (dcsList, userId, isClassType) => {
    let data = {
      "userId": userId ? userId : null,
      "dcsList": dcsList,
      "classType": isClassType

    }
    return await axios.post("/api/sku-groups/closerLookDCSPerformance", data);
  };

  static getFeatureToggle = async () => {
    return await axios.get("/api/sku-groups/featureToggle");
  }

  static prepareServiceInputData = (hierarchyDetails, userId) => {
    return {
      "subDepartmentDescription": hierarchyDetails.subDepartmentName,
      "subDepartmentNumber": hierarchyDetails.subDepartment ? hierarchyDetails.subDepartment.toString() : null,
      "departmentNumber": hierarchyDetails.departmentNumber ? hierarchyDetails.departmentNumber.toString() : null,
      "classDescription": hierarchyDetails.className,
      "classNumber": hierarchyDetails.classNumber ? hierarchyDetails.classNumber.toString() : null,
      "subClassDescription": hierarchyDetails.subClassName,
      "subClassNumber": hierarchyDetails.subClassNumber ? hierarchyDetails.subClassNumber.toString() : null,
      "userId": userId ? userId : null
    };
  };

  static getSkuGroupPerformanceData = async (skuGroupData, userId, onlineOnly) => {
    return await axios.post("/api/dataConnect/sku-group-performance?userId=" + userId + "&onlineOnly=" + onlineOnly, skuGroupData);
  };

  static savePlsGroup = async (plsGroupData) =>  {
    return await axios.put("/api/sku-groups/save-pls-group", plsGroupData);
  }

  static deleteSkuGroups = async (groupsIds) => {
    return await axios.delete('/api/sku-groups/delete', {data: groupsIds});
  }

  static updateSkuGroup = async (skuGroupData) =>  {
    return await axios.patch("/api/sku-groups/update-sku-group", skuGroupData);
  }
}
