import DashboardServices from './DashboardServices';
import axios from 'axios';

jest.mock('axios');

describe('DashboardServices', () => {

  it('Should getHealthOverviewDetails', () => {
    const hierarchyDetails = {"departmentNumber":25};
    const usedId = 'qwer26q';
    const response = {data:{"zonePerformanceDTOList":[{"zoneId":"2","zoneName":"MIAMI/FTL/WPALM","quarterToDateSalesPercentage":23,"yearToDateSalesPercentage":34,"rolling52SalesPercentage":43}]}};
    axios.get.mockResolvedValue(response);
    DashboardServices.getHealthOverviewDetails(hierarchyDetails,usedId).then(data => expect(data).toEqual(response));
  });


  it('Should getZoneOverviewDetails', () => {
    const hierarchyDetails = 25;
    const usedId = 'qwer26q';
    const response = {data:{"zonePerformanceData":[{"zoneId":"2","zoneName":"MIAMI/FTL/WPALM","storePerformanceData":[{"storeNumber":"6353","storeName":"MIRAMAR","compPercentage":0,"unitsPercentage":0,"latitudeNumber":25.979724,"longitudeNumber":-80.359646}],"zoneCompPercentage":null,"zoneUnitsPercentage":null}],"totalCompPercentage":0.00,"totalUnitsPercentage":0.00,"fiscalWeek":"FW20"}};
    axios.get.mockResolvedValue(response);
    return DashboardServices.getZoneOverviewDetails(hierarchyDetails,usedId).then(data => expect(data).toEqual(response));

  });

  it('Should getFinancialPerformanceDetails', () => {
    const hierarchyDetails = 21;
    const userId = 'qwer26q';
    const response = {data:{"fiscalWeek":15,"fiscalYear":2019,"rawSalesAmount":20,"rawSalesUnit":30}  };
    axios.get.mockResolvedValue(response);
    DashboardServices.getFinancialPerformanceDetails(hierarchyDetails,userId).then(data => expect(data).toEqual(response));
  });


  it('Should updateMpulseAccessRequest', () => {
    const userId = 'qwer26q';
    const comments = "";
    const response = {data:"success"  };
    axios.get.mockResolvedValue(response);
    DashboardServices.updateMpulseAccessRequest(userId,comments).then(data => expect(data).toEqual(response));
  });


  it('Should getOffsideDetails', () => {
    const hierarchyDetails = {departmentNumber:21};
    const favSkuList = [123,456];
    const response = {data:[{"SKU_NBR":1000021899,"SUB_DEPT_NBR":"025H","DEPT_NBR":25,"CLASS_NBR":3,"SUB_CLASS_NBR":8,"THD_PRICE":3.98,"THD_R12_SALES":null,"LOWES_PRICE":2.58,"MENARDS_PRICE":null,"FLOOR_DECOR_PRICE":null,"AMAZON_PRICE":null,"WALMART_PRICE":null,"OFFSIDE_FLG":"Y","USR_LDAP":null}]}
    axios.get.mockResolvedValue(response);
    DashboardServices.getOffsideDetails(hierarchyDetails,favSkuList).then(data => expect(data).toEqual(response));
  });


  it('Should getSkuImagesAndDescription', () => {
    const skuList = [159686];
    const response = {data:{skuImageUrl: "http://159686.test.url" , skuDesc:"test 1/23F"    }};
    axios.post.mockResolvedValue(response);
    DashboardServices.getSkuImagesAndDescription(skuList).then(data => expect(data).toEqual(response));
  });


  it('Should sendEmailForRequestAccess', () => {
    const dcs = '21-12-34';
    const userId = 'qwer26q';
    const dcsAssignment = [12];
    const recipientEmailIds = 'a@a.com';
    const response = {data:"success"};
    axios.post.mockResolvedValue(response);
    DashboardServices.sendEmailForRequestAccess(dcs,userId,dcsAssignment,recipientEmailIds).then(data => expect(data).toEqual(response));
  });

  it('Should getPacManRequestDetails', () => {
    const hierarchyDetails = {"departmentNumber":25};
    const response = {data:[{"requestId":18391859,"requestSubTypeCode":17,"requestSubType":"PERM COST","requestStatusCode":590,"requestStatus":"Delete Complete","requestDescription":"test","createdSystemUserId":"MPJ8G2Q","effBgnTimestamp":"2020-06-19T00:00:00","effEndTimestamp":"9999-12-30T00:00:00","lastUpdatedTimestamp":"2020-06-19T16:19:04"}]};
    axios.get.mockResolvedValue(response);
    DashboardServices.getPacManRequestDetails(hierarchyDetails).then(data => expect(data).toEqual(response));
  });

  it('should getCompetitorZonePriceDetails', function() {
    const skuNumber = 779779;
    const competitorNumber = 3141;
    const response = {data:[
        {
          "zoneId": "1",
          "zoneName": "Atlanta",
          "modeCompetitorPrice": 6.98
        },
        {
          "zoneId": "3",
          "zoneName": "Orl/mel/daytona",
          "modeCompetitorPrice": 6.98
        }]}
     axios.get.mockResolvedValue(response);
    DashboardServices.getCompetitorZonePriceDetails(skuNumber,competitorNumber).then(data => expect(data).toEqual(response))

  });

});