import axios from 'axios';

export async function getDCs(skus) {
  try {
    const { data } = await axios.post('/api/location/distribution-centers', {
      skus,
    });

    return data;
  } catch {
    return [];
  }
}

export async function getVendors(skus) {
  try {
    const { data } = await axios.post('/api/location/vendors', {
      skus,
    });

    return data;
  } catch {
    return [];
  }
}

export async function getStores(dcs) {
  try {
    const { data } = await axios.post('/api/location/stores', {
      dc: dcs,
    });

    return data;
  } catch {
    return [];
  }
}

export async function getAllRegions(){

  /**Hard coding regions as these are the only relevant data **/
  return [
    {
      "regionName": "MIDSOUTH",
      "regionNumber": 1
    },
    {
      "regionName": "PACIFIC NORTH",
      "regionNumber": 5
    },
    {
      "regionName": "PACIFIC CENTRAL",
      "regionNumber": 6
    },
    {
      "regionName": "CENTRAL",
      "regionNumber": 8
    },
    {
      "regionName": "MID-ATLANTIC",
      "regionNumber": 10
    },
    {
      "regionName": "SOUTHWEST",
      "regionNumber": 11
    },
    {
      "regionName": "PACIFIC NORTHWEST",
      "regionNumber": 12
    },
    {
      "regionName": "NJ METRO",
      "regionNumber": 16
    },
    {
      "regionName": "SOUTH ATLANTIC",
      "regionNumber": 17
    },
    {
      "regionName": "GULF",
      "regionNumber": 19
    },
    {
      "regionName": "PACIFIC SOUTH",
      "regionNumber": 20
    },
    {
      "regionName": "SOUTHEAST",
      "regionNumber": 24
    },
    {
      "regionName": "OHIO VALLEY",
      "regionNumber": 25
    },
    {
      "regionName": "NEW ENGLAND",
      "regionNumber": 27
    },
    {
      "regionName": "NORTHERN PLAINS",
      "regionNumber": 30
    },
    {
      "regionName": "NY METRO",
      "regionNumber": 31
    },
    {
      "regionName": "PAC MTN DESERT",
      "regionNumber": 34
    },
    {
      "regionName": "E-BUSINESS",
      "regionNumber": 44
    },
    {
      "regionName": "SOUTH FLORIDA/PR",
      "regionNumber": 47
    },
    {
      "regionName": "MIDWEST",
      "regionNumber": 48
    }
  ];
    //const {data} =  await axios.post('/api/location/getAllRegions');
    //return data;
}
